<?php

session_start();
require('../include/config.php');
require('validate.php');
require('common.php');

class User {	
	public $userTable = 'tbl_users';
	public $historyTable = 'tbl_histories';
	public $dbConnect = false;
	// const ACTIVE = '1';

    public function __construct() {
        if (!$this->dbConnect) { 		
			$config = new DbConfig();
			$this->dbConnect = $config->connect();
        }
    }

	// check login admin 
	public function adminLoginStatus() {
		if (empty($_SESSION["adminUserid"])) {
			header("Location: index.php");
		}
	}		

	// login admin page 
	public function adminLogin() {		
		$errorMessage = '';

		if (!empty($_POST["login"]) && $_POST["email"] != '' && $_POST["password"] != '') {	

			// handle input 
			$email = Validate::handle_input($_POST['email']);
			$password = Validate::handle_input($_POST['password']);

			// validate email 
			$errorMessage = Validate::validate_email($email);
			if ($errorMessage) {
				return $errorMessage;
			}

			$sqlQuery = 'SELECT * FROM ' . $this->userTable . ' 
			WHERE email = "' . $email . '" AND password = "' . md5($password) . '" AND status = "'. Common::ACTIVE .'" AND count_login_fail < 4';
			$resultSet = mysqli_query($this->dbConnect, $sqlQuery);
			$isValidLogin = mysqli_num_rows($resultSet);	
			
			if ($isValidLogin) {
				$userDetails = mysqli_fetch_assoc($resultSet);
				$_SESSION["adminUserid"] = $userDetails['id'];
				$_SESSION["role"] = $userDetails['role'];
				$_SESSION["admin"] = $userDetails['first_name'] . " " . $userDetails['last_name'];

				// log info into history table 
				$history_name = $_SESSION["admin"];
				$history_email = $userDetails['email'];

				DbConfig::set_time_zone();
				$date = date('Y-m-d H:i:s');
				$ip = Common::get_client_ip();

				// count numbers user login 
				$sqlQuery = "SELECT * FROM " . $this->historyTable . " 
				WHERE email = '" . $email . "'";
				$resultNumberLogin = mysqli_query($this->dbConnect, $sqlQuery);
				$isValidNumberLogin = mysqli_num_rows($resultNumberLogin);
				$number = $isValidNumberLogin + 1;

				$insertQuery = "INSERT INTO " . $this->historyTable . "(name, email, date, ip) 
				VALUES ('" . $history_name . "', '" . $history_email . "', '" . $date . "', '" . $ip . "')";
				mysqli_query($this->dbConnect, $insertQuery);

				// redirect to dashboard page 
				header("location: dashboard.php"); 		
			} else {
				$sqlQuery = "SELECT * FROM " . $this->userTable . " 
				WHERE email = '" . $email . "'";
				$resultEmail = mysqli_query($this->dbConnect, $sqlQuery);
				$isValidEmail = mysqli_num_rows($resultEmail);

				if ($isValidEmail) {
					$userEmail = mysqli_fetch_assoc($resultEmail);
					$count_login_fail = $userEmail['count_login_fail'];
					
					if ($count_login_fail >= 3) {
						// update status when login failed more 3 times
						$updateQuery = "UPDATE " . $this->userTable . " SET status = '2' WHERE email = '". $email ."'";
						mysqli_query($this->dbConnect, $updateQuery);

						$errorMessage = 'Your account was blocked because login failed more than ' . $count_login_fail . ' times!';	
					} else if ($count_login_fail == 2) {
							Common::count_login_fail($email);

							$errorMessage = "Password was wrong, your account is loging failed 3 times, if you fail login one more,
							your account will be block!";	
					} else {
							Common::count_login_fail($email);

							$errorMessage = "Password was wrong!";	
							
					}
				}
			}	
		} else if (!empty($_POST["login"]) && $_POST["email"] == '' && $_POST["password"] == '') {
			$errorMessage = "Enter Both user and password!";	
		} else if (!empty($_POST["login"]) && $_POST["email"] == '') {
			$errorMessage = "Email isn't blank!";	
		} else if (!empty($_POST["login"]) && $_POST["email"] != '' && $_POST["password"] == '') {
			$errorMessage = "Password isn't blank!";
		}

		return $errorMessage; 		
	}

	public function register() {		
		$message = '';
		if(!empty($_POST["register"]) && $_POST["email"] !='') {
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE email='".$_POST["email"]."'";
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$isUserExist = mysqli_num_rows($result);
			if($isUserExist) {
				$message = "User already exist with this email address.";
			} else {			
				$authtoken = $this->getAuthtoken($_POST["email"]);
				$insertQuery = "INSERT INTO ".$this->userTable."(first_name, last_name, email, password, authtoken) 
				VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["email"]."', '".md5($_POST["passwd"])."', '".$authtoken."')";
				$userSaved = mysqli_query($this->dbConnect, $insertQuery);
				if($userSaved) {				
					$link = "<a href='http://webdamn.com/demo/user-management-system/verify.php?authtoken=".$authtoken."'>Verify Email</a>";			
					$toEmail = $_POST["email"];
					$subject = "Verify email to complete registration";
					$msg = "Hi there, click on this ".$link." to verify email to complete registration.";
					$msg = wordwrap($msg,70);
					$headers = "From: info@webdamn.com";
					if(mail($toEmail, $subject, $msg, $headers)) {
						$message = "Verification email send to your email address. Please check email and verify to complete registration.";
					}
				} else {
					$message = "User register request failed.";
				}
			}
		}
		return $message;
	}	

	public function getAuthtoken($email) {
		$code = md5(889966);
		$authtoken = $code."".md5($email);
		return $authtoken;
	}	
	public function verifyRegister() {
		$verifyStatus = 0;
		if (!empty($_GET["authtoken"]) && $_GET["authtoken"] != '') {			
			$sqlQuery = "SELECT * FROM ".$this->userTable." 
				WHERE authtoken='".$_GET["authtoken"]."'";
			$resultSet = mysqli_query($this->dbConnect, $sqlQuery);
			$isValid = mysqli_num_rows($resultSet);	
			if ($isValid) {
				$userDetails = mysqli_fetch_assoc($resultSet);
				$authtoken = $this->getAuthtoken($userDetails['email']);
				if ($authtoken == $_GET["authtoken"]) {					
					$updateQuery = "UPDATE ".$this->userTable." SET status = 'active'
						WHERE id='".$userDetails['id']."'";
					$isUpdated = mysqli_query($this->dbConnect, $updateQuery);					
					if ($isUpdated) {
						$verifyStatus = 1;
					}
				}
			}
		}
		return $verifyStatus;
	}	

	public function userDetails() {
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
			WHERE id ='".$_SESSION["userid"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$userDetails = mysqli_fetch_assoc($result);
		return $userDetails;
	}	

	public function editAccount() {
		$message = '';
		$updatePassword = '';
		if (!empty($_POST["passwd"]) && $_POST["passwd"] != '' && $_POST["passwd"] != $_POST["cpasswd"]) {
			$message = "Confirm passwords do not match.";
		} else if (!empty($_POST["passwd"]) && $_POST["passwd"] != '' && $_POST["passwd"] == $_POST["cpasswd"]) {
			$updatePassword = ", password='".md5($_POST["passwd"])."' ";
		}	
		$updateQuery = "UPDATE ".$this->userTable." 
			SET first_name = '".$_POST["firstname"]."', last_name = '".$_POST["lastname"]."', email = '".$_POST["email"]."', mobile = '".$_POST["mobile"]."' , designation = '".$_POST["designation"]."', gender = '".$_POST["gender"]."' $updatePassword
			WHERE id ='".$_SESSION["userid"]."'";
		$isUpdated = mysqli_query($this->dbConnect, $updateQuery);	
		if ($isUpdated) {
			$_SESSION["name"] = $_POST['firstname']." ".$_POST['lastname'];
			$message = "Account details saved.";
		}
		return $message;
	}	
	public function resetPassword() {
		$message = '';
		if ($_POST['email'] == '') {
			$message = "Please enter username or email to proceed with password reset";			
		} else {
			$sqlQuery = "
				SELECT email 
				FROM ".$this->userTable." 
				WHERE email='".$_POST['email']."'";			
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$numRows = mysqli_num_rows($result);
			if ($numRows) {			
				$user = mysqli_fetch_assoc($result);
				$authtoken = $this->getAuthtoken($user['email']);
				$link="<a href='https://www.webdamn.com/demo/user-management-system/reset_password.php?authtoken=".$authtoken."'>Reset Password</a>";				
				$toEmail = $user['email'];
				$subject = "Reset your password on examplesite.com";
				$msg = "Hi there, click on this ".$link." to reset your password.";
				$msg = wordwrap($msg,70);
				$headers = "From: info@webdamn.com";
				if(mail($toEmail, $subject, $msg, $headers)) {
					$message =  "Password reset link send. Please check your mailbox to reset password.";
				}				
			} else {
				$message = "No account exist with entered email address.";
			}
		}
		return $message;
	}
	public function savePassword() {
		$message = '';
		if ($_POST['password'] != $_POST['cpassword']) {
			$message = "Password does not match the confirm password.";
		} else if ($_POST['authtoken']) {
			$sqlQuery = "
				SELECT email, authtoken 
				FROM ".$this->userTable." 
				WHERE authtoken='".$_POST['authtoken']."'";			
			$result = mysqli_query($this->dbConnect, $sqlQuery);
			$numRows = mysqli_num_rows($result);
			if ($numRows) {				
				$userDetails = mysqli_fetch_assoc($result);
				$authtoken = $this->getAuthtoken($userDetails['email']);
				if ($authtoken == $_POST['authtoken']) {
					$sqlUpdate = "
						UPDATE ".$this->userTable." 
						SET password='".md5($_POST['password'])."'
						WHERE email='".$userDetails['email']."' AND authtoken='".$authtoken."'";	
					$isUpdated = mysqli_query($this->dbConnect, $sqlUpdate);	
					if ($isUpdated) {
						$message = "Password saved successfully. Please <a href='login.php'>Login</a> to access account.";
					}
				} else {
					$message = "Invalid password change request.";
				}
			} else {
				$message = "Invalid password change request.";
			}	
		}
		return $message;
	}

	public function getUserList() {		
		$sqlQuery = "SELECT * FROM ".$this->userTable." WHERE id !='".$_SESSION['adminUserid']."'";
		if (!empty($_POST["search"]["value"])) {
			$sqlQuery .= '(id LIKE "%'. $_POST["search"]["value"] .'%" ';
			$sqlQuery .= ' OR first_name LIKE "%'. $_POST["search"]["value"] .'%" ';
			$sqlQuery .= ' OR last_name LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR designation LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR status LIKE "%'.$_POST["search"]["value"].'%" ';
			$sqlQuery .= ' OR mobile LIKE "%'.$_POST["search"]["value"].'%") ';			
		}
		if (!empty($_POST["order"])) {
			$sqlQuery .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
		} else {
			$sqlQuery .= 'ORDER BY id DESC ';
		}
		if ($_POST["length"] != -1) {
			$sqlQuery .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}	
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		
		$sqlQuery1 = "SELECT * FROM ".$this->userTable." WHERE id !='".$_SESSION['adminUserid']."'";
		$result1 = mysqli_query($this->dbConnect, $sqlQuery1);
		$numRows = mysqli_num_rows($result1);
		
		$userData = array();	
		while( $users = mysqli_fetch_assoc($result) ) {		
			$userRows = array();
			if($users['status'] == '1') {
				$status = '<span class="label label-success">Active</span>';
			} else if($users['status'] == '2') {
				$status = '<span class="label label-warning">Locked</span>';
			} else if($users['status'] == '3') {
				$status = '<span class="label label-danger">Deleted</span>';
			}

			if ($users['gender'] == '1') {
				$gender = '<span>Male</span>';
			} else if($users['gender'] == '2') {
				$gender = '<span>Female</span>';
			}

			if($users['role'] == '1') {
				$role = '<span>Admin</span>';
			} else if($users['role'] == '2') {
				$role = '<span>General</span>';
			}

			$disabled = 'disabled';

			$userRows[] = $users['id'];
			$userRows[] = ucfirst($users['first_name']." ".$users['last_name']);
			$userRows[] = $gender;			
			$userRows[] = $users['email'];	
			$userRows[] = $users['mobile'];	
			$userRows[] = $role;
			$userRows[] = $status;		
			if ($_SESSION['role'] != 1) {
				$userRows[] = '<button type="button" name="update" id="'. $users["id"] .'" class="btn btn-warning btn-xs update" '. $disabled .'>Update</button>';
				$userRows[] = '<button type="button" name="delete" id="'. $users["id"] .'" class="btn btn-danger btn-xs delete" '. $disabled .'>Delete</button>';
			} else {
				$userRows[] = '<button type="button" name="update" id="'. $users["id"] .'" class="btn btn-warning btn-xs update" >Update</button>';
				$userRows[] = '<button type="button" name="delete" id="'. $users["id"] .'" class="btn btn-danger btn-xs delete" >Delete</button>';
			}
			
			
			$userData[] = $userRows;
		}
		
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"  	=>  $numRows,
			"recordsFiltered" 	=> 	$numRows,
			"data"    			=> 	$userData
		);
		echo json_encode($output);
	}

	public function deleteUser() {
		if ($_POST["userid"]) {
			$sqlUpdate = "
				UPDATE ".$this->userTable." SET status = '3'
				WHERE id = '".$_POST["userid"]."'";		
			mysqli_query($this->dbConnect, $sqlUpdate);		
		}
	}

	public function getUser() {
		$sqlQuery = "
			SELECT * FROM ".$this->userTable." 
			WHERE id = '".$_POST["userid"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
		echo json_encode($row);
	}

	public function updateUser() {
		if ($_POST['userid']) {	
			$updateQuery = "UPDATE ".$this->userTable." 
			SET first_name = '".$_POST["firstname"]."', last_name = '".$_POST["lastname"]."', email = '".$_POST["email"]."', 
			mobile = '".$_POST["mobile"]."' , designation = '".$_POST["designation"]."', gender = '".$_POST["gender"]."', 
			status = '".$_POST["status"]."', role = '".$_POST['user_type']."'
			WHERE id ='".$_POST["userid"]."'";
			$isUpdated = mysqli_query($this->dbConnect, $updateQuery);		
		}	
	}	

	public function saveAdminPassword() {
		$message = '';
		if ($_POST['password'] && $_POST['password'] != $_POST['cpassword']) {
			$message = "Password does not match the confirm password.";
		} else {			
			$sqlUpdate = "
				UPDATE ".$this->userTable." 
				SET password='".md5($_POST['password'])."'
				WHERE id='".$_SESSION['adminUserid']."' AND role='1'";	
			$isUpdated = mysqli_query($this->dbConnect, $sqlUpdate);	
			if ($isUpdated) {
				$message = "Password saved successfully.";
			}				
		}
		return $message;
	}

	public function adminDetails() {
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
			WHERE id ='".$_SESSION["adminUserid"]."'";
		$result = mysqli_query($this->dbConnect, $sqlQuery);	
		$userDetails = mysqli_fetch_assoc($result);
		return $userDetails;
	}	

	public function addUser() {
		$insertQuery = "INSERT INTO ".$this->userTable."(first_name, last_name, email, gender, password, mobile, designation, role, status) 
		VALUES ('".$_POST["firstname"]."', '".$_POST["lastname"]."', '".$_POST["email"]."', '".$_POST["gender"]."', '".md5($_POST["password"])."', 
		'".$_POST["mobile"]."', '".$_POST["designation"]."', '".$_POST['user_type']."', '1')";
		$userSaved = mysqli_query($this->dbConnect, $insertQuery);
	}

	public function totalUsers($status) {
		$query = '';
		if ($status) {
			$query = " AND status = '".$status."'";
		}
		$sqlQuery = "SELECT * FROM ".$this->userTable." 
		WHERE id !='".$_SESSION["adminUserid"]."' $query";
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		$numRows = mysqli_num_rows($result);

		return $numRows;
	}

	public function dashboard_filter() {
		$data = $_POST['dashboard_value'];

		$first_day_this_month = date('Y-m-01');
		$last_day_this_month = date('Y-m-t');
		$first_day_previous_month = date('Y-m-d', strtotime(date('Y-m-01').' -1 MONTH'));

		$seven_days = date('Y-m-d', strtotime(' - 1 week'));
		$one_year = date('Y-m-d', strtotime(' - 1 year'));
		
		$today = date('Y-m-d');

		// echo $seven_days;

		if ($data == "sevenDays") {
			$sqlQuery = "SELECT * FROM ". $this->historyTable ." 
			WHERE email = '". $email ."'";
		}
	}
}
?>
