<?php
class DbConfig {
    private $serverName;
    private $userName;
    private $password;
    private $dbName;
    private $timeZone;


    public function connect() {
        $this->serverName = 'localhost';
        $this->userName = 'root';
        $this->password = 'cms-8341';
        $this->dbName = 'my_database';

        $conn = new mysqli($this->serverName, $this->userName, $this->password, $this->dbName);
            if ($conn->connect_error) {
                die("Error failed to connect to MySQL: " . $conn->connect_error);
            } else {
                return $conn;
            }
    }

    public static function set_time_zone() {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
    }

    public function get_data($sqlQuery) {
		$result = mysqli_query($this->connect(), $sqlQuery);
		if (!$result) {
			die('Error in query: '. mysqli_error());
		}
		$data = array();
		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$data[] = $row;            
		}

		return $data;
	}

    public function getNumRows($sqlQuery) {
		$result = mysqli_query($this->connect(), $sqlQuery);
		if (!$result) {
			die('Error in query: '. mysqli_error());
		}
		$numRows = mysqli_num_rows($result);

		return $numRows;
	}
}
?>
