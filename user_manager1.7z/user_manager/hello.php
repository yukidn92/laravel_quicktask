<?php
$x = date('d-m-Y H:i:s');
$date = new DateTime($x, new DateTimeZone('Asia/Ho_Chi_Minh'));
echo $date->format('Y-m-d H:i:s') . "\n";


?>