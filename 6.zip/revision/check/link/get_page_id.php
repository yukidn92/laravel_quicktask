<?php
/*
 * リンク一括チェック：ファイルパスからページIDを取得
 */
// ** require ----------------------------------
require ("../.htsetting");

// ** DB controll ------------------------------
global $objCnc;
global $objLogin;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);

// ** 変数初期化 -------------------------------


// ファイルリスト(,区切りを配列化)
$pageList = explode(",", $_POST['path']);
// レスポンス
$r = "";

// ページ情報取得 ------------------------------
// -- ページIDを,区切りで文字列として取得
foreach ($pageList as $path) {
	$path = str_replace(DOCUMENT_ROOT . RPR, "", $path);
	if ($objPage->selectFromPath($path, PUBLISH_TABLE) !== FALSE) {
		$r .= ($r != "") ? "," : "";
		$r .= $objPage->fld['page_id'];
	}
}

// -- Ajaxレスポンス用に出力
print $r;

?>