<?php
/*
 * リンク一括チェック
 */
require ("../.htsetting");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>リンクチェック</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/special/file/unnecessary/unnecessary.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
<script type="text/javascript">
<!--
var totalDirCnt = 0;
var totalOKCnt = 0;
var totalNGCnt = 0;
var nowCnt = 0;
var isCheck = FLAG_OFF;
function cxCheck() {
	if(isCheck == FLAG_ON){
		alert("現在動作中です");
		return;
	}
	
	var dir = $F('check_dir');
	//入力チェック
	var err_msg = '';
	if ( dir.match(/[^\w\-\_\/]/i) ) {
		alert( '対象フォルダは半角英数字で入力してください' );
		return false;
	}
	
	if (!confirm("リンク一括チェックを行います。\nこの処理は時間がかかります。実行してよろしいですか？")) {
		return false;
	}
	totalOKCnt = 0;
	totalNGCnt = 0;
	nowCnt = 0;
	var dir = $F('check_dir');
	if($('sub_dir').checked){
		var sub = FLAG_ON;
	} else {
		var sub = FLAG_OFF;
	}
	$('cms_result_check').innerHTML = "";
	$('cms_progressmsg').innerHTML = 'リンク一括チェック中です...';
	var prm = 'dir='+dir+'&sub='+sub+'&mode=link_check';
	cxAjaxCommand('cxGetAllFileList', prm, cxSuccessDirList);
	isCheck = FLAG_ON;
	cxSetLastSearchArea();
	return false;
}
//認証OK処理
function cxSuccessDirList(r) {
	var rText = r.responseText;
	if(rText == ""){
		alert("入力したフォルダは存在しません。");
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのリンク一括チェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}
	
	if ( rText == $F('check_dir') ) {
		alert("チェックするファイルが存在しません。");
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのリンク一括チェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}
	
	dirAry = rText.split(",");
	if( dirAry.length == 0 ){
		alert("入力したフォルダは存在しません。");
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのリンク一括チェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}

	// ページ情報取得
	var prm = 'path='+rText;
	// ページID取得PHP(Ajax)
	var a = new Ajax.Updater(
		'',
		cms8341admin_path+'/revision/check/link/get_page_id.php',
		{
			method: 'post',
			postBody: prm,
			// 成功した場合
			onSuccess: function( r ) {
				cxSuccessPageInfo( r );
			},
			// 失敗した場合
			onFailure: function(request) {
				cxFailurePageInfo( );
			}
		}
	);
	return false;
}
// リンクチェック
function cxSuccessPageInfo( r ) {
	
	var rText = r.responseText;
	
	if ( rText != "" ) {
		checkAry    = rText.split(",");
		totalDirCnt = checkAry.length;
		
		if (!confirm(totalDirCnt+"ファイルをチェックします。よろしいですか？")) {
			$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのリンク一括チェックを行います。';
			isCheck = FLAG_OFF;
			return false;
		}
	
		// リンクチェック
		chk_pid = 0;
		for(i = 0; i < checkAry.length; i++){
			// 現在チェック中のページID
			chk_pid = checkAry[i];
			// 引数作成
			prm  = '';
			prm  = 'check_mode=batch';
			prm += '&cms_dispMode=publish';
			prm += '&cms_page_id='+checkAry[i];
		
			// リンクチェックPHP(Ajax)
			a = new Ajax.Updater(
				'',
				cms8341admin_path+'/page/common/link_check.php',
				{
					method: 'post',
					postBody: prm,
					// 成功した場合
					onSuccess: function( r ) {
						cxSuccess( r );
					},
					// 失敗した場合
					onFailure: function(request) {
						cxFailure( );
					}
				}
			);
		}
	} else {
		alert("チェックするファイルが存在しません。");
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのリンク一括チェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}
	
	return false;
}
//認証OK処理
function cxSuccess(r) {
	var rText = r.responseText;
	nowCnt++;
	if(rText != ""){
		detail = rText.split(",");
		
		result  = detail[0];
		page_id = detail[1];
		path    = HTTP_REAL_ROOT+detail[2];
		title   = detail[3];
		
		if(result == "0"){
			result = "×";
			totalNGCnt++;
		} else if(result == "1"){
			result = "○";
			totalOKCnt++;
		} else {
			result  = "失敗";
			page_id = "";
			path    = "";
			title   = "【ページID:" + chk_pid + "】リンクチェック中にシステムエラーが発生しました。";
			totalNGCnt++;
		}
		str = '<tr>'
		    + '<td width="30" align="center" valign="middle">'+result+'</td>'
		    + '<td>'+title+'<br><a href="'+path+'" target="_blank">'+path+'</a></td>';
		if ( result == "失敗" ) {
			str +=  '<td>&nbsp;</td>'
		} else {
			str += '<td><a href="javascript:" target="_blank" onClick="return cxLinkCheck(\'cms_link_check\', ' + page_id + ', \'publish\')">詳細をみる</a></td>'
		}
		str += '</tr>';
		    
		repStr = $('cms_result_check').innerHTML;
		repStr = repStr.slice(repStr.indexOf("<!--HeaderEnd-->") + "<!--HeaderEnd-->".length);
		repStr = repStr.replace(/<\/TABLE>/i,"");
		$('cms_result_check').innerHTML = '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-workspace">'
		                                  + '<tr><th align="center" valign="middle" scope="col" width="5%" style="font-weight:normal">結果</th>'
		                                  + '<th align="center" valign="middle" width="75%" scope="col" style="font-weight:normal">チェックしたファイル</th>'
		                                  + '<th align="center" valign="middle" width="20%" scope="col" style="font-weight:normal">リンクチェック</th></tr><!--HeaderEnd-->'
		                                  + repStr + str 
		                                  + "</table>";
	}
	if(nowCnt == totalDirCnt){
		$('cms_progressmsg').innerHTML = 'リンク一括チェックが終了しました。（OK'+totalOKCnt+'件 NG'+totalNGCnt+'件）';
		isCheck = FLAG_OFF;
	} else {
		var p = (nowCnt*100)/totalDirCnt;
		$('cms_progressmsg').innerHTML = 'リンク一括チェックを実行中です。（'+Math.ceil(p)+'%終了）';
	}
	return false;
}
function cxLastSearch(){
	var prm = 'key=link_check';
	cxAjaxCommand('cxGetLastSearchSessionData', prm, cxSuccessLastDirList);
	return false;
}
function cxSuccessLastDirList(r){
	var xmlDoc = r.responseXML.documentElement;
	if (!xmlDoc || xmlDoc.nodeName != 'link_check') {
		cxFailure();
		return;
	}
        var xmlDocfix = xmlDoc.childElementCount;
        for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		if(nodeL.nodeName == 'check_dir')$('check_dir').value = nodeL.textContent;
		else if(nodeL.nodeName == 'sub_dir')$('sub_dir').checked = (nodeL.textContent == FLAG_ON)?true:false;
	}
	cxCheck();
	return false;
	
}
function cxSetLastSearchArea(){
	if($('cms_last_search_area').innerHTML == ""){
		$('cms_last_search_area').innerHTML = '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">'
										+ '<tr valign="top">'
										+ '<td colspan="3" align="right"><span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="<?=RPW?>/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span></td>'
										+ '</tr>'
										+ '</tr>'
										+ '</table>';
	}
}
//通信失敗処理
function cxFailure() {
	$('cms_progressmsg').innerHTML =  "リンク一括チェック中に通信エラーが発生しました。";  
	isCheck = FLAG_OFF;
	return false;
}
//ページ情報取得失敗
function cxFailurePageInfo() {
	$('cms_progressmsg').innerHTML =  "ファイル情報取得中に通信エラーが発生しました。";  
	isCheck = FLAG_OFF;
	return false;
}
function cxStop(){
	
}
function cxFileSubmit(event){
	if(event.keyCode == 13){
		cxCheck();
	}
}
function cxInit() {
	Event.observe(document,'keypress',cxFileSubmit,false);
}
Event.observe(window,'load',cxInit,false);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'check';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>

<form name="cms_link_check" id="cms_link_check" class="cms8341-form"
	method="post" action="" onSubmit="return false;"><input type="hidden"
	id="cms_page_id" name="cms_page_id" value=""> <input type="hidden"
	id="cms_dispMode" name="cms_dispMode" value="publish">

<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/revision/check/link/images/bar_title.jpg"
	alt="リンクチェック" width="920" height="30"></div>
<div class="cms8341-area-box">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/revision/check/images/bar_topbg.jpg);height:31px;"><img
			src="<?=RPW?>/admin/revision/check/images/bar_search.jpg"
			alt="チェック対象" width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">対象フォルダ</th>
				<td align="left" valign="middle"><?=HTTP_REAL_ROOT?>/&nbsp;<input
					type="text" id="check_dir" name="check_dir" value=""
					style="width: 300px; ime-mode: disabled;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"></th>
				<td align="left" valign="middle"><input type="checkbox" id="sub_dir"
					name="sub_dir" value=""><label for="sub_dir">サブディレクトリを含む</label></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxCheck();"><img
			src="<?=RPW?>/admin/revision/check/images/btn_submit.jpg" alt="実行する"
			width="100" height="20" border="0"></a></td>
	</tr>
</table>
</div>
<div id="cms_last_search_area">
<?php
if (isset($_SESSION['last_search_condition']['link_check'])) {
	?>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr valign="top">
		<td colspan="3" align="right"><span style="margin: 15px;"
			class="cms8341-verticalMiddle"><a href="javascript:"
			onclick="return cxLastSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search_condition.jpg"
			alt="前回の条件で検索" width="150" height="20" border="0"></a></span></td>
	</tr>
</table>
<?php
}
?>
</div>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
</table>
<p id="cms_progressmsg">指定したフォルダ以下または指定したファイルのリンク一括チェックを行います。</p>
<div id="cms_result_check"></div>
</div>
</div>
<!-- cms8341-contents --></form>

</body>
</html>
