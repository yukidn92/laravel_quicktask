<?php
/*
 *
 */
require ("../.htsetting");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>W3Cチェック</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/special/file/unnecessary/unnecessary.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
<script type="text/javascript">
<!--
var totalDirCnt = 0;
var totalOKCnt = 0;
var totalNGCnt = 0;
var nowCnt = 0;
var isCheck = FLAG_OFF;
function cxCheck() {
	if(isCheck == FLAG_ON){
		alert("現在動作中です");
		return;
	}
	
	var dir = $F('check_dir');
	//入力チェック
	var err_msg = '';
	if ( dir.match(/[^\w\-\_\/]/i) ) {
		alert( '対象フォルダは半角英数字で入力してください' );
		return false;
	}
	
	if (!confirm("W3Cチェックを行います。\nこの処理は時間がかかります。実行してよろしいですか？")) {
		return false;
	}
	totalOKCnt = 0;
	totalNGCnt = 0;
	nowCnt = 0;
	var dir = $F('check_dir');
	if($('sub_dir').checked){
		var sub = FLAG_ON;
	} else {
		var sub = FLAG_OFF;
	}
	$('cms_result_check').innerHTML = "";
	$('cms_progressmsg').innerHTML = 'W3Cチェック中です...';
	var prm = 'dir='+dir+'&sub='+sub+'&mode=w3c_check';
	cxAjaxCommand('cxGetAllFileList', prm, cxSuccessDirList);
	isCheck = FLAG_ON;
	cxSetLastSearchArea();
	return false;
}
//認証OK処理
function cxSuccessDirList(r) {
	var rText = r.responseText;
	if(rText == ""){
		// 080611 >>>> alert表示に変更
		// $('cms_progressmsg').innerHTML =  "入力したフォルダは存在しません。";  
		alert("入力したフォルダは存在しません。");
		// 080611 <<<<
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのW3Cチェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}
	
	if ( rText == $F('check_dir') ) {
		alert("チェックするファイルが存在しません。");
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのW3Cチェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}
	
	dirAry = rText.split(",");
	totalDirCnt = dirAry.length;
	if(totalDirCnt == 0){
		// 080611 >>>> alert表示に変更
		// $('cms_progressmsg').innerHTML =  "入力したフォルダは存在しません。";  
		alert("入力したフォルダは存在しません。");
		// 080611 <<<<
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのW3Cチェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}
	if (!confirm(dirAry.length+"ファイルをチェックします。よろしいですか？")) {
		$('cms_progressmsg').innerHTML = '指定したフォルダ以下または指定したファイルのW3Cチェックを行います。';
		isCheck = FLAG_OFF;
		return false;
	}
	for(i = 0; i < dirAry.length; i++){
		var prm = 'dir='+dirAry[i].replace(DOCUMENT_ROOT+RPR,"");
		cxAjaxCommand('cxW3cCheck', prm, cxSuccess);
	}
	return false;
}
//認証OK処理
function cxSuccess(r) {
	var rText = r.responseText;
	nowCnt++;
	if(rText != ""){
		detail = rText.split(",");
		if(detail[0] == "0"){
			result = "×";
			totalNGCnt++;
		} else if(detail[0] == "1"){
			result = "○";
			totalOKCnt++;
		} else {
			result = "無効";
			totalNGCnt++;
		}
		path = HTTP_REAL_ROOT+detail[1];
		title = detail[2];
		uri = encodeURI(path+'&charset=(detect+automatically)&doctype=Inline&group=0');
		str = '<tr>'
		    + '<td width="30" align="center" valign="middle">'+result+'</td>'
		    + '<td>'+title+'<br><a href="'+path+'" target="_blank">'+path+'</a></td>'
		    + '<td><a href="'+W3C_CHECKER_URL+'?url='+uri+'" target="_blank">詳細をみる</a></td>'
		    + '</tr>';
			
		repStr = $('cms_result_check').innerHTML;
		repStr = repStr.slice(repStr.indexOf("<!--HeaderEnd-->") + "<!--HeaderEnd-->".length);
		repStr = repStr.replace(/<\/TABLE>/i,"");
		$('cms_result_check').innerHTML = '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-workspace">'
		                                  + '<tr><th align="center" valign="middle" scope="col" width="5%" style="font-weight:normal">結果</th>'
		                                  + '<th align="center" valign="middle" width="75%" scope="col" style="font-weight:normal">チェックしたファイル</th>'
		                                  + '<th align="center" valign="middle" width="20%" scope="col" style="font-weight:normal">公式ページにてチェック実行</th></tr><!--HeaderEnd-->'
		                                  + repStr + str 
		                                  + "</table>";
	}
	if(nowCnt == totalDirCnt){
		$('cms_progressmsg').innerHTML = 'W3Cチェックが終了しました。（OK'+totalOKCnt+'件 NG'+totalNGCnt+'件）';
		isCheck = FLAG_OFF;
	} else {
		var p = (nowCnt*100)/totalDirCnt;
		$('cms_progressmsg').innerHTML = 'W3Cチェックを実行中です。（'+Math.ceil(p)+'%終了）';
	}
	return false;
}
function cxLastSearch(){
	var prm = 'key=w3c_check';
	cxAjaxCommand('cxGetLastSearchSessionData', prm, cxSuccessLastDirList);
	return false;
}
function cxSuccessLastDirList(r){
	var xmlDoc = r.responseXML.documentElement;
	if (!xmlDoc || xmlDoc.nodeName != 'w3c_check') {
		cxFailure();
		return;
	}
        for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		if(nodeL.nodeName == 'check_dir')$('check_dir').value = nodeL.textContent;
		else if(nodeL.nodeName == 'sub_dir')$('sub_dir').checked = (nodeL.textContent == FLAG_ON)?true:false;
	}
	cxCheck();
	return false;
	
}
function cxSetLastSearchArea(){
	if($('cms_last_search_area').innerHTML == ""){
		$('cms_last_search_area').innerHTML = '<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom:10px;padding:1px">'
										+ '<tr valign="top">'
										+ '<td colspan="3" align="right"><span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="<?=RPW?>/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span></td>'
										+ '</tr>'
										+ '</tr>'
										+ '</table>';
	}
}

//通信失敗処理
function cxFailure() {
	$('cms_progressmsg').innerHTML =  "W3Cチェック中に通信エラーが発生しました";  
	isCheck = FLAG_OFF;
	return false;
}

function cxStop(){
	
}
function cxFileSubmit(event){
	if(event.keyCode == 13){
		cxCheck();
	}
}
function cxInit() {
	Event.observe(document,'keypress',cxFileSubmit,false);
}
Event.observe(window,'load',cxInit,false);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'check';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/revision/check/w3c/images/bar_title.jpg"
	alt="W3Cチェック" width="920" height="30"></div>
<div class="cms8341-area-box">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/revision/check/images/bar_topbg.jpg);height:31px;"><img
			src="<?=RPW?>/admin/revision/check/images/bar_search.jpg"
			alt="チェック対象" width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">対象フォルダ</th>
				<td align="left" valign="middle"><?=HTTP_REAL_ROOT?>/&nbsp;<input
					type="text" id="check_dir" name="check_dir" value=""
					style="width: 300px; ime-mode: disabled;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"></th>
				<td align="left" valign="middle"><input type="checkbox" id="sub_dir"
					name="sub_dir" value=""><label for="sub_dir">サブディレクトリを含む</label></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxCheck();"><img
			src="<?=RPW?>/admin/revision/check/images/btn_submit.jpg" alt="実行する"
			width="100" height="20" border="0"></a></td>
	</tr>
</table>
</div>
<div id="cms_last_search_area">
<?php
if (isset($_SESSION['last_search_condition']['w3c_check'])) {
	?>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr valign="top">
		<td colspan="3" align="right"><span style="margin: 15px;"
			class="cms8341-verticalMiddle"><a href="javascript:"
			onclick="return cxLastSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search_condition.jpg"
			alt="前回の条件で検索" width="150" height="20" border="0"></a></span></td>
	</tr>
</table>
<?php
}
?>
</div>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
</table>
<p id="cms_progressmsg">指定したフォルダ以下または指定したファイルのW3Cチェックを行います。</p>

<div id="cms_result_check"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
