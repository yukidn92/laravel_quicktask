/*
 *
 */
//date check
function cxFutureDateCheck(obj) {
	var retAry = new Array();
	var stat;
	var c_days;
	//charactor check
	if(obj.sy) {
		stat = cxFutureDateNumeric(obj.sy);
		if(!stat) {
			retAry.push('入力された年に数字ではない文字列が入力されています。');
			obj.sy = false;
		}
	}
	if(obj.sm) {
		stat = cxFutureDateNumeric(obj.sm);
		if(!stat) {
			retAry.push('入力された月に数字ではない文字列が入力されています。');
			obj.sm = false;
		} else if(Number(obj.sm) < 1 || Number(obj.sm) > 12) {
			retAry.push('入力された月には 1 ～ 12 を指定してください。');
			obj.sm = false;
		}
	}
	if(obj.sd) {
		stat = cxFutureDateNumeric(obj.sd);
		if(!stat) {
			retAry.push('入力された日に数字ではない文字列が入力されています。');
			obj.sd = false;
		} else if(Number(obj.sd) < 1) {
			retAry.push('入力された日には 0 以下を指定することはできません。');
			obj.sd = false;
		}
	}
	if(obj.sy && obj.sm && obj.sd) {
		c_days  = cxGetDays(Number(obj.sy),Number(obj.sm));
		if(Number(obj.sd) > c_days) {
			retAry.push('入力された年月日は存在しません。');
			obj.sd = false;
		} else if(Number(obj.sy) > 2037) {
			retAry.push('未来の日付は2037年まで間を指定してください。');
		} else {
			var today;
			var temp_nm
			today = new Date();
			today_nm = cxChangeDate(today.getFullYear(),today.getMonth() + 1,today.getDate());
			temp_nm = cxChangeDate(obj.sy,obj.sm,obj.sd);
			
			if(today_nm > temp_nm){
				retAry.push('過去の日付は入力できません。');
			}
		}
	}
	//
	return retAry;
}

//
function cxFutureDateNumeric(p) {
	var temp1,temp2;
	var regObj = new RegExp("[^0-9]","i");
	//
	temp1 = p.match(regObj)
	if(temp1) {
		return false;
	} else {
		return true;
	}
}

//
function cxChangeDate(y,m,d) {
	var mm;
	var dd;
			
	mm  = "0" + m;
	mm = mm.substr(mm.length - 2, mm.length);
	dd  = "0" + d;
	dd = dd.substr(dd.length - 2, dd.length);
	
	return Number(y+mm+dd);
}
