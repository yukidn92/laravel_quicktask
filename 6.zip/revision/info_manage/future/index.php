<?php
/*
 *
 */
/** require **/
require ("../.htsetting");

//ウェブマスターのみアクセス可能
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error("不正なアクセスです。");
}

//
unset($_SESSION["hidden"]);

$today = getdate();
$page_id = 1;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
if ($objPage->selectFromPath(SITE_TOP_PAGE, PUBLISH_TABLE, 'page_id')) $page_id = $objPage->fld['page_id'];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>未来情報</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/revision/info_manage/future/future.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/revision/info_manage/future/js/future.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxFutureForm() {
	var msg = new Array();

	var dateObj = new Object();
	dateObj.sy = $('cms_pdsy').value;
	dateObj.sm = $('cms_pdsm').value;
	dateObj.sd = $('cms_pdsd').value;
	var dc = cxFutureDateCheck(dateObj);

	if(dc.length>=1 && dc[0]!='') {
		alert(dc.join("\n"));
	} else {
		$('future_form').action = cms8341admin_path + '/revision/info_manage/future/preview.php';
		document.future_form.submit();
	}
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'info_manage';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-approve">
<form id="future_form" class="cms8341-form" name="future_form" action=""
	method="post" target="_blank">
<div><img
	src="<?=RPW?>/admin/revision/info_manage/future/images/bar_future.jpg"
	alt="未来情報" width="920" height="30"></div>
<div class="cms8341-area-corner">
<p align="center">サイトの状態を確認したい未来の日付を入力してください。</p>
<p align="center"><input type="text" maxlength="4" id="cms_pdsy"
	name="cms_pdsy" value="<?=$today['year']?>"
	style="width: 50px; ime-mode: disabled"> 年 <input type="text"
	maxlength="2" id="cms_pdsm" name="cms_pdsm" value="<?=$today['mon']?>"
	style="width: 30px; ime-mode: disabled"> 月 <input type="text"
	maxlength="2" id="cms_pdsd" name="cms_pdsd"
	value="<?=$today['mday']?>" style="width: 30px; ime-mode: disabled"> 日
<a href="javascript:" onClick="return cxCalendarOpen('cms_pd', 'start')"><img
	src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
	width="14" height="17" border="0" align="absmiddle"></a></p>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:" onClick="return cxFutureForm()"><img
	src="<?=RPW?>/admin/master/images/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>

</div>
</div>
<!-- cms8341-contents -->
<input type="hidden" id="pid" name="pid" value="<?=$page_id?>">
</form>
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
</body>
</html>
