<?php
/*
 *
 */
/** プレビュー **/
require ("../.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<META http-equiv=Content-Type content="text/html; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>未来情報</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	media="screen" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/login.css"
	media="screen" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body>
<!--[if lte IE 7 ]>
<div id="cms8341-headareaDummy"></div>
<iframe id="cms8341-headareaDummyFrame" src="javascript:false"></iframe>
<![endif]-->
<div id="cms8341-headarea">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-header">
	<tr>
		<td align="left" valign="top"><img src="<?=DIR_PATH_LOGO_MENU?>"
			alt="<?=ALT_LOGO_MENU?>" width="330" height="41"></td>
		<td width="110" align="right" valign="top"><img
			src="<?=DIR_PATH_LOGO_CMSMENU?>" alt="<?=ALT_LOGO_CMSMENU?>"
			width="110" height="41"></td>
	</tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	id="cms8341-logininfo">
	<tr>
		<td width="15"><img src="<?=RPW?>/admin/images/spacer.gif" width="15"
			height="20" alt=""></td>
	</tr>
</table>
<div id="cms8341-tab">
<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td><img src="<?=RPW?>/admin/images/spacer.gif" alt="" width="5"
			height="21"></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	id="cms8341-toolbar">
	<tr>
		<td align="left" valign="middle" id="cms8341-toolbar-btns"><img
			src="<?=RPW?>/admin/images/menu/menu_bg.jpg" alt="" width="5"
			height="26"></td>
	</tr>
</table>
</div>
<div id="cms8341-contents">
<div align="center" id="cms8341-error">
<div><img
	src="<?=RPW?>/admin/revision/info_manage/future/images/bar_future.jpg"
	alt="未来情報" width="920" height="30"></div>
<div class="cms8341-area-corner">
<p align="left"><?=$_SESSION['error']?></p>
<p align="center" class="ctrl"><a href="<?=$_SESSION['back_page']?>"><img
	src="<?=RPW?>/admin/master/images/btn_small_back.jpg" alt="戻る"
	width="120" height="20" border="0"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
