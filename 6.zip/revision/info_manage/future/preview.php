<?php
/*
 *
 */
/** プレビュー **/
require ("../.htsetting");
//---別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

//---引数の取得
$arrArgs = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$_SESSION["hidden"]["cms_pdsy"] = $arrArgs['cms_pdsy'];
	$_SESSION["hidden"]["cms_pdsm"] = $arrArgs['cms_pdsm'];
	$_SESSION["hidden"]["cms_pdsd"] = $arrArgs['cms_pdsd'];
	$_SESSION["hidden"]["cms_base_date"] = $arrArgs['cms_pdsy'] . '-' . $arrArgs['cms_pdsm'] . '-' . $arrArgs['cms_pdsd'] . ' 23:59:59';
}

//---引数チェック
if (isset($arrArgs['pid']) == FALSE) {
	user_error('ページIDが指定されていません。');
}
if (isset($_SESSION["hidden"]["cms_pdsy"]) == FALSE || isset($_SESSION["hidden"]["cms_pdsm"]) == FALSE || isset($_SESSION["hidden"]["cms_pdsd"]) == FALSE || $_SESSION["hidden"]["cms_pdsy"] == "" || $_SESSION["hidden"]["cms_pdsm"] == "" || $_SESSION["hidden"]["cms_pdsd"] == "") {
	user_error('基準となる日付が指定されていません。');
}
if (is_numeric($_SESSION["hidden"]["cms_pdsy"]) == FALSE || is_numeric($_SESSION["hidden"]["cms_pdsm"]) == FALSE || is_numeric($_SESSION["hidden"]["cms_pdsd"]) == FALSE) {
	user_error('基準となる日付には数値以外は入力できません。');
}
if (!checkdate($_SESSION["hidden"]['cms_pdsm'], $_SESSION["hidden"]['cms_pdsd'], $_SESSION["hidden"]['cms_pdsy'])) {
	user_error('基準となる日付が正しく入力されていません。');
}

// 大規模災害ページIDを取得
$arrArgs['pid'] = getDisasterModePage($arrArgs['pid']);

$post['cms_page_id'] = $arrArgs['pid'];
$post['cms_prev_mode'] = MODE_PREVIEW_FUTURE;

$disp_mode = 0;
$error_msg = page_pub_chk($arrArgs['pid'], $disp_mode);
if (trim($error_msg) != "") disp_error_f($error_msg, "javascript:history.back();");

$post['cms_dispMode'] = $disp_mode;

//未来プレビュー用の仮想テーブル作成
if (_set_temp_table() === FALSE) {
	user_error('未来プレビューのデータ作成に失敗しました。');
}

include (APPLICATION_ROOT . "/common/inc/set_preview.inc");
include (APPLICATION_ROOT . "/common/inc/set_preview_htmlStr.inc");

//仮想テーブル削除
_delete_temp_table(TBL_FUTURE_PUBLISH);
_delete_temp_table(TBL_FUTURE_WORK);

// ページの非公開・削除によりリンク切れになるAタグをはずす
if (UPLOAD_DEL_A_TAGS_FLG) {
	_delete_future_a_tag_links($arrArgs['pid'], $disp_mode, $htmlStr);
}

$htmlStr = setRootPath($htmlStr);

// alt="#" を alt="" に置換
$htmlStr = preg_replace('/<(img|area|input)( [^>]*)? alt="[#＃\s　]*"/i', '<${1}${2} alt=""', $htmlStr);

print $htmlStr;
?>

<?php
//指定日付が期間前：0
//指定日付が期間内：1
//指定日付が期間後：2
function date_chk($ymd, $s_date, $e_date) {
	if (!isset($s_date) || trim($s_date) == "") return 1;
	if (strtotime($s_date) > strtotime($ymd)) return 0;
	if (strtotime($s_date) <= strtotime($ymd) && strtotime($ymd) <= strtotime($e_date)) return 1;
	if (strtotime($e_date) < strtotime($ymd)) return 2;
	return;
}

function get_error_msg($title, $url) {
	$error_msg = "このページは、「" . $_SESSION["hidden"]["cms_pdsy"] . "年" . $_SESSION["hidden"]["cms_pdsm"] . "月" . $_SESSION["hidden"]["cms_pdsd"] . "日」時点では公開されていません。<br><br>";
	$error_msg .= "【ページタイトル】" . $title . "<br>";
	$error_msg .= "【URL】" . $url;
	return $error_msg;
}

// エラーページ表示
function disp_error_f($pError, $pBackPage) {
	//セッションに引数の値を格納する
	$_SESSION['error'] = $pError;
	$_SESSION['back_page'] = $pBackPage;
	//エラーページを呼び出す
	header("Location: " . RPW . "/admin/revision/info_manage/future/error.php");
	exit();
}

// 指定日に対象ページが公開されているか確認
// 公開されている場合は、プレビューモードを取得
// 公開されていない場合は、エラーメッセージを返す
function page_pub_chk($pid, &$disp_mode) {
	global $objCnc;
	
	$error_msg = "";
	
	//---公開情報の取得
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
	$objPageP = new tbl_page($objCnc);
	
	if ($objPageP->selectFromID($pid, 1) === FALSE) {
		user_error("指定されたページは存在しません。");
	}
	
	$fld_P = $objPageP->fld;
	// トップページかどうかのフラグ
	$is_site_top_page = ($fld_P['file_path'] == SITE_TOP_PAGE) ? true : false;
	
	//---ページの状態により、プレビューモードを変更	
	//cms_dispMode = 1：編集中プレビュー
	//cms_dispMode = 2：編集前プレビュー
	

	//対象ページの現在の状態が公開待ち
	if ($fld_P['status'] == 401) {
		//公開テーブルの対象ページの公開期間を取得
		$date_chk_P = date_chk($_SESSION["hidden"]["cms_base_date"], $fld_P['publish_start'], $fld_P['publish_end']);
		
		//---未公開情報の取得
		$objPageW = new tbl_page($objCnc);
		
		if ($objPageW->selectFromID($pid, 2) === FALSE) {
			user_error("dac execute error. <br>tbl_page->selectFromID(" . $pid . ", 2);", E_USER_ERROR);
		}
		$fld_W = $objPageW->fld;
		
		//公開テーブルの対象ページの公開期間を取得
		$date_chk_W = date_chk($_SESSION["hidden"]["cms_base_date"], $fld_W['publish_start'], $fld_W['publish_end']);
		
		//新規ページの場合
		if ($fld_P['work_class'] == 1) {
			//指定日が公開期間内
			if ($date_chk_W == 1) {
				$disp_mode = 2;
				//指定日が公開期間外
			}
			else {
				$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
			}
			
		//更新ページの場合
		}
		elseif ($fld_P['work_class'] == 2) {
			
			//指定日が公開期間内
			if ($date_chk_W == 1) {
				// ページ出力なし
				if ($fld_W['output_html_flg'] == FLAG_OFF) {
					$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
				}
				$disp_mode = 2;
				//指定日が公開期間前
			}
			else if ($date_chk_W == 0) {
				
				//更新前のページのステータスが公開の場合
				if ($fld_P['bak_status'] == 402) {
					//非公開の場合
					if ($fld_P['close_flg'] == 1) {
						$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
					} // ページ出力設定がされていないページの場合
					elseif (isset($fld_P['output_html_flg']) && $fld_P['output_html_flg'] == FLAG_OFF) {
						$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
					}
					else {
						//更新前のページでは、指定日が公開期間内
						if ($date_chk_P == 1) {
							$disp_mode = 1;
							//更新前のページでは、指定日が公開期間前
						}
						else if ($date_chk_P == 0) {
							$disp_mode = 1;
							//更新前のページでは、指定日が公開期間後
						}
						else {
							$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
						}
					}
					//更新前のページのステータスが公開以外の場合
				}
				else {
					$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
				}
				
			//指定日が公開期間後
			}
			else {
				$disp_mode = 2;
				// トップページは自動非公開されない
				if (!$is_site_top_page) $error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
			}
			//削除または非公開ページの場合
		}
		else {
			//指定日が公開期間内
			if ($date_chk_W == 1) {
				$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
				//指定日が公開期間前
			}
			else if ($date_chk_W == 0) {
				
				//更新前のページのステータスが公開の場合
				if ($fld_P['bak_status'] == 402) {
					//非公開の場合
					if ($fld_P['close_flg'] == 1) {
						$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
					} // ページ出力設定がされていないページの場合
					elseif (isset($fld_P['output_html_flg']) && $fld_P['output_html_flg'] == FLAG_OFF) {
						$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
					}
					else {
						//更新前のページでは、指定日が公開期間内
						if ($date_chk_P == 1) {
							$disp_mode = 1;
							//更新前のページでは、指定日が公開期間前
						}
						else if ($date_chk_P == 0) {
							$disp_mode = 1;
							//更新前のページでは、指定日が公開期間後
						}
						else {
							$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
						}
					}
					//更新前のページのステータスが公開以外の場合
				}
				else {
					$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
				}
				
			//指定日が公開期間後
			}
			else {
				$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
			}
		}
		
	//対象ページの現在の状態が公開中
	}
	elseif ($fld_P['status'] == 402) {
		//非公開の場合
		if ($fld_P['close_flg'] == 1) {
			$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
		} // ページ出力設定がされていないページの場合
		elseif (isset($fld_P['output_html_flg']) && $fld_P['output_html_flg'] == FLAG_OFF) {
			$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
			
		//公開中の場合
		}
		else {
			//公開テーブルの対象ページの公開期間を取得
			$date_chk_P = date_chk($_SESSION["hidden"]["cms_base_date"], $fld_P['publish_start'], $fld_P['publish_end']);
			
			//指定日が公開期間内
			if ($date_chk_P == 1) {
				$disp_mode = 1;
				//指定日が公開期間前
			}
			else if ($date_chk_P == 0) {
				$disp_mode = 1;
				//指定日が公開期間後
			}
			else {
				$disp_mode = 1;
				// トップページは自動非公開されない
				if (!$is_site_top_page) $error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
			}
		}
		
	//対象ページの現在の状態が新規、保存中、完了、承認待ち、否認
	}
	else {
		//更新前のページの状態が公開中の場合
		if ($fld_P['bak_status'] == 402) {
			//非公開の場合
			if ($fld_P['close_flg'] == 1) {
				$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
			} // ページ出力設定がされていないページの場合
			elseif (isset($fld_P['output_html_flg']) && $fld_P['output_html_flg'] == FLAG_OFF) {
				$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
				
			//公開中の場合
			}
			else {
				//公開テーブルの対象ページの公開期間を取得
				$date_chk_P = date_chk($_SESSION["hidden"]["cms_base_date"], $fld_P['publish_start'], $fld_P['publish_end']);
				
				//指定日が公開期間内
				if ($date_chk_P == 1) {
					$disp_mode = 1;
					//指定日が公開期間前
				}
				else if ($date_chk_P == 0) {
					$disp_mode = 1;
					//指定日が公開期間後
				}
				else {
					$disp_mode = 1;
					// トップページは自動非公開されない
					if (!$is_site_top_page) $error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
				}
			}
			
		//新規ページ、もしくは更新前のページの状態が非公開の場合
		}
		else {
			$error_msg = get_error_msg($fld_P['page_title'], $fld_P['file_path']);
		}
	}
	
	return $error_msg;
}
/**
 * 未来プレビューのタイムスタンプを取得する
 * @return タイムスタンプ
 */
function get_future_time() {
	list($y, $m, $d) = explode('-', date('Y-m-d'));
	if (isset($_SESSION['hidden']['cms_pdsy'])) $y = $_SESSION['hidden']['cms_pdsy'];
	if (isset($_SESSION['hidden']['cms_pdsm'])) $m = $_SESSION['hidden']['cms_pdsm'];
	if (isset($_SESSION['hidden']['cms_pdsd'])) $d = $_SESSION['hidden']['cms_pdsd'];
	return mktime(0, 0, 0, $m, $d, $y);
}
/**
 * 現在公開中で、未来に非公開｜削除になるページのAタグを削除する
 * @param $pid プレビューするページID
 * @param $disp_mode 参照モード(公開待ちで未来に公開されている場合は編集テーブル)
 * @param $htmlStr 表示文字列
 * @return なし
 */
function _delete_future_a_tag_links($pid, $disp_mode, &$htmlStr) {
	
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
	$objLinks = new tbl_links($objCnc);
	//参照テーブル設定
	$tbl = ($disp_mode == 1) ? 1 : 2;
	//取得
	$objLinks->selectLinks($pid, $tbl);
	
	while ($objLinks->fetch()) {
		$l_page_fld = $objLinks->fld;
		//HTMLでない場合無視する
		if ($l_page_fld['file_exte'] != 'html') continue;
		//現在公開中でない場合は無視する。
		if ($l_page_fld['work_class'] == WORK_CLASS_NEW || $l_page_fld['close_flg'] == FLAG_ON) continue;
		//未来に公開中の場合は無視する。
		if (page_pub_chk($l_page_fld['linkpage_id'], $disp_mode) == "") continue;
		$check_file_path = reg_replace($objLinks->fld['path']);
		$pattern = '<a[^>]*href="' . $check_file_path . '(\?[^"]*)?"[^>]*>(.*?)<\/a>';
		$htmlStr = preg_replace('/' . $pattern . '/i', '$2', $htmlStr);
	}
}
/**
 * 対象テーブルのカラム名をすべて取得する
 * @param $tbl 対象テーブル
 * @return カラム名の入った配列
 */
function _get_column_all($tbl) {
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
	$objDac = new dac($objCnc);
	$sql = 'DESCRIBE ' . $tbl;
	$objDac->execute($sql);
	$fld = array();
	while ($objDac->fetch()) {
		$fld[] = $objDac->fld['Field'];
	}
	return $fld;
}
/**
 * 未来プレビューで使用する仮想テーブル作成
 *
 * @param $time タイムスタンプ
 * @return TRUE|FALSE
 */
function _set_temp_table($time = "") {
	
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
	$objDac = new b_dac($objCnc);
	$objDac2 = new b_dac($objCnc);
	// 日付設定
	if ($time == "") $time = get_future_time();
	$date_time = date('Ymd', $time);
	//================================================================
	// 公開されるワークページの仮想テーブル作成(非公開・削除・ページ出力なしは除く)
	//================================================================
	// 空テーブル作成
	$tmp_tbl = 'CREATE TEMPORARY TABLE `' . TBL_FUTURE_WORK . '`';
	$tmp_tbl .= ' SELECT page_id, parent_id, file_path, ancestor_path FROM tbl_publish_page WHERE 0';
	if (!$objDac2->execute($tmp_tbl)) return FALSE;
	// データ作成
	$sql = 'INSERT INTO ' . TBL_FUTURE_WORK;
	$sql .= ' SELECT page_id, parent_id, file_path, NULL as ancestor_path';
	$sql .= ' FROM tbl_work_page';
	// 公開待ちページ
	$sql .= ' WHERE ' . $objDac->_addslashesC('status', STATUS_PUBLISH_WAIT, '=');
	// 未来に自動公開により公開される
	$sql .= ' AND ' . $objDac->_addslashesC("DATE_FORMAT(publish_start,'%Y%m%d')", $date_time, '<=', 'DATE');
	// 未来に自動非公開により非公開されない
	$sql .= ' AND CASE 1';
	// サイトトップは自動非公開されない
	$sql .= ' WHEN ' . $objDac->_addslashesC('file_path', SITE_TOP_PAGE, '=');
	$sql .= ' THEN 1';
	$sql .= ' ELSE ' . $objDac->_addslashesC("DATE_FORMAT(publish_end,'%Y%m%d')", $date_time, '>', 'DATE');
	$sql .= ' END';
	// 非公開・削除まちではない
	$sql .= ' AND ' . $objDac->_addslashesC("work_class", WORK_CLASS_DELETE, '<>');
	// ページ出力なしではない
	$sql .= ' AND ' . $objDac->_addslashesC("output_html_flg", FLAG_ON);
	if (!$objDac2->execute($sql)) return FALSE;
	// 編集情報を公開情報に変更する。
	$sql = 'UPDATE ' . TBL_FUTURE_WORK . ' AS w';
	// 親ページと結合 w→子　p→親
	$sql .= ' LEFT JOIN tbl_publish_page AS p ON(w.parent_id = p.page_id)';
	// ワーククラスを公開済みに変更
	$sql .= ' SET w.ancestor_path=';
	$sql .= "CONCAT_WS(',',p.ancestor_path,p.file_path)";
	$objDac2->execute($sql);
	//================================================================
	// 指定日の仮想公開テーブル作成(指定日に非公開されていないページ＋公開待ちで公開されるページ)
	//================================================================
	$tmp_tbl = 'CREATE TEMPORARY TABLE `' . TBL_FUTURE_PUBLISH . '`';
	$tmp_tbl .= ' SELECT page_id, parent_id, file_path, ancestor_path, 0 AS w_flg';
	$tmp_tbl .= ' FROM tbl_publish_page';
	// 未来に自動非公開されないページ
	$tmp_tbl .= ' WHERE CASE 1';
	// サイトトップは自動非公開されない
	$tmp_tbl .= ' WHEN ' . $objDac->_addslashesC('file_path', SITE_TOP_PAGE, '=');
	$tmp_tbl .= ' THEN 1';
	$tmp_tbl .= ' ELSE ' . $objDac->_addslashesC("DATE_FORMAT(publish_end,'%Y%m%d')", $date_time, '>', 'DATE');
	$tmp_tbl .= ' END';
	// ページ出力あり
	$tmp_tbl .= ' AND ' . $objDac->_addslashesC("output_html_flg", FLAG_ON);
	// 現在公開中
	$tmp_tbl .= ' AND ' . create_common_public_sql();
	// 公開待ちで未来に自動公開されるページをはずす（一時テーブルと結合するため）
	$tmp_tbl .= ' AND page_id NOT IN(SELECT w.page_id FROM tbl_work_page AS w WHERE ';
	$tmp_tbl .= $objDac->_addslashesC('w.status', STATUS_PUBLISH_WAIT, '=');
	$tmp_tbl .= ' AND ' . $objDac->_addslashesC("DATE_FORMAT(w.publish_start,'%Y%m%d')", $date_time, '<=', 'DATE');
	$tmp_tbl .= ' AND ' . $objDac->_addslashesC("DATE_FORMAT(w.publish_end,'%Y%m%d')", $date_time, '>', 'DATE') . ')';
	// 公開待ちで未来に公開されるページを結合
	$tmp_tbl .= ' UNION ALL';
	$tmp_tbl .= ' SELECT *, 1 AS w_flg FROM ' . TBL_FUTURE_WORK;
	if (!$objDac->execute($tmp_tbl)) return FALSE;
	// ページ数取得
	$objDac->setTableName(TBL_FUTURE_PUBLISH);
	$public_cnt = $objDac->getCount();
	
	// ---公開待ちの公開によりパンくずがかわるページを更新する。
	$fields = 'w.ancestor_path AS w_ancestor_path, p.ancestor_path AS p_ancestor_path';
	$fields .= 'w.file_path AS w_file_path, p.file_path AS p_file_path';
	$table = TBL_FUTURE_WORK . ' AS w INNER tbl_publish_page ON(p.page_id = w.page_id)';
	// 親ページ変更・ファイルパス変更したページ
	$where = 'NOT(w.parent_id <=> p.parent_id) OR w.file_path <> p.file_path';
	$objDac->setTableName($table);
	$objDac->select($where, $fields);
	while ($objDac->fetch()) {
		// 変更対象のパンくず(親ページ変更・ファイルパス変更したページ)
		$rep_ancestor = $objDac->fld['p_ancestor_path'];
		if ($rep_ancestor != "") $rep_ancestor .= ',';
		$rep_ancestor .= $objDac->fld['p_file_path'];
		// 変更後のパンくず
		$set_ancestor = $objDac->fld['w_ancestor_path'];
		if ($set_ancestor != "") $set_ancestor .= ',';
		$set_ancestor .= $objDac->fld['w_file_path'];
		// 更新
		$sql = 'UPDATE ' . TBL_FUTURE_PUBLISH;
		$sql .= ' SET ancestor_path = REPLACE(ancestor_path';
		$sql .= ', ' . $objDac2->_addslashes($rep_ancestor);
		$sql .= ', ' . $objDac2->_addslashes($set_ancestor) . ')';
		$objDac2->execute($sql);
	}
	
	// ---指定日に非公開または公開待ちの非公開/削除によりパン屑・親ページが変わるページを更新する
	$fields = 'p.page_id, p.parent_id, p.file_path';
	$table = 'tbl_publish_page AS p';
	$table .= ' LEFT JOIN tbl_work_page AS w ON(p.page_id = w.page_id)';
	// 公開待ちで未来に非公開、削除、親ページなしで自動公開されるページ
	$where = 'CASE 1 WHEN p.status=' . STATUS_PUBLISH_WAIT . ' AND ' . $objDac->_addslashesC("DATE_FORMAT(w.publish_start,'%Y%m%d')", $date_time, '<=', 'DATE');
	$where .= ' THEN ' . $objDac->_addslashesC("DATE_FORMAT(w.publish_end,'%Y%m%d')", $date_time, '<', 'DATE');
	$where .= ' OR ' . $objDac->_addslashesC('w.work_class', WORK_CLASS_DELETE, '=');
	$where .= ' OR ' . $objDac->_addslashesC('w.output_html_flg', FLAG_OFF);
	// 上記以外で自動非公開により非公開されるページ
	$where .= ' ELSE ' . $objDac->_addslashesC("DATE_FORMAT(p.publish_end,'%Y%m%d')", $date_time, '<', 'DATE');
	$where .= ' AND ' . $objDac->_addslashesC('p.work_class', WORK_CLASS_NEW, '<>');
	$where .= ' AND ' . $objDac->_addslashesC('p.close_flg', FLAG_OFF);
	$where .= ' AND ' . $objDac->_addslashesC('p.output_html_flg', FLAG_ON);
	$where .= ' AND ' . $objDac->_addslashesC('p.file_path', SITE_TOP_PAGE, '<>');
	$where .= ' END';
	// 末端ページから取得する
	$order = 'LENGTH(p.ancestor_path) DESC';
	$objDac->setTableName($table);
	$objDac->select($where, $fields, $order);
	// 行数取得(非公開)
	$close_cnt = $objDac->getRowCount();
	// 非公開ページが少なかった場合(非公開ページから親ページ・パン屑パス修正)
	if ($close_cnt < $public_cnt) {
		while ($objDac->fetch()) {
			$sql = "UPDATE " . TBL_FUTURE_PUBLISH;
			$sql .= " SET parent_id =";
			// 親ページ変更(自身の親ページが非公開される場合)
			$sql .= " IF(" . $objDac->_addslashesC('parent_id', $objDac->fld['page_id']);
			// 親ページの親ページに変更する
			$sql .= ", " . $objDac->_addslashes($objDac->$fld['parent_id'], 'INT');
			$sql .= ", parent_id)";
			// パン屑変更
			$sql .= ", ancestor_path = REPLACE(ancestor_path";
			// 2ページ以上親ページがあった場合
			$sql .= ", IF(INSTR(ancestor_path,',')";
			$sql .= ', IF(' . $objDac->fld['parent_id'];
			// 非公開されるページが親ページありだった場合
			$sql .= ',' . "CONCAT(',', " . $objDac->_addslashes($objDac->fld['file_path']) . ")";
			// 非公開されるページが親ページなしだった場合
			$sql .= ',' . "CONCAT(" . $objDac->_addslashes($objDac->fld['file_path']) . ", ',')";
			// 親ページが1ページの場合
			$sql .= "), " . $objDac->_addslashes($objDac->fld['file_path']) . ")";
			$sql .= ", '')";
			// 非公開されるページを親ページに含む場合
			$sql .= " WHERE ancestor_path REGEXP '^(.*,)?" . $objDac->fld['file_path'] . "(,.*)?$'";
			$objDac2->execute($sql);
		}
	}
	// 非公開ページが多かった場合(公開中のページから親ページ・パン屑パス修正)
	else {
		$objDac2->setTableName(TBL_FUTURE_PUBLISH);
		$objDac->setTableName(TBL_FUTURE_PUBLISH);
		$fields = 'page_id, ancestor_path, file_path';
		// 親ページから抽出する
		$order = 'LENGTH(ancestor_path) ASC';
		$objDac->select('', $fields, $order);
		while ($objDac->fetch()) {
			// ancestor_pathをSQL用にエスケープ
			$file_path_ary = explode(',', $objDac->fld['ancestor_path']);
			foreach ($file_path_ary as $key => $file_path) {
				$file_path_ary[$key] = $objDac2->_addslashes($file_path);
			}
			// ancestor_pathから指定日に公開されているページを取得(末端優先)
			$where = $objDac2->_addslashesC('file_path', implode(',', $file_path_ary), 'IN');
			// 末端ページから抽出する
			$order = 'LENGTH(ancestor_path) DESC';
			$objDac2->select($where, $fields, $order, 0, 1);
			// 値設定
			if ($objDac2->fetch()) {
				$parent_id = $objDac2->fld['page_id'];
				$ancestor_path = $objDac2->fld['ancestor_path'];
				if ($ancestor_path != '') $ancestor_path .= ',';
				$ancestor_path .= $objDac2->fld['file_path'];
			}
			else {
				$parent_id = '';
				$ancestor_path = '';
			}
			$sql = "UPDATE " . TBL_FUTURE_PUBLISH;
			$sql .= " SET parent_id =" . $objDac2->_addslashes($parent_id);
			$sql .= ", ancestor_path = " . $objDac2->_addslashes($ancestor_path);
			$sql .= " WHERE " . $objDac2->_addslashesC('page_id', $objDac->fld['page_id']);
			$objDac2->execute($sql);
		}
	}
	
	//================================================================
	// 編集テーブル参照用と公開テーブル参照用とで分ける
	//================================================================
	// 編集テーブル更新
	$sql = 'UPDATE ' . TBL_FUTURE_WORK . ' AS w';
	$sql .= ' INNER JOIN ' . TBL_FUTURE_PUBLISH . ' AS p ON(w.page_id=p.page_id)';
	$sql .= ' SET w.parent_id = p.parent_id';
	$sql .= ', w.ancestor_path = p.ancestor_path';
	if (!$objDac->execute($sql)) return FALSE;
	// 公開テーブルから削除
	$sql = 'DELETE FROM ' . TBL_FUTURE_PUBLISH . ' WHERE w_flg=' . FLAG_ON;
	if (!$objDac->execute($sql)) return FALSE;
	return TRUE;
}
function get_future_table() {
	// ---取得カラムの設定
	// 公開テーブルの全カラム名
	$publish_col = _get_column_all('tbl_publish_page');
	$work_col = array();
	// 公開テーブルにあるけど編集テーブルにないカラム名
	$work_none_col = array_diff($publish_col, _get_column_all('tbl_work_page'));
	// 未来ビュー用の一時テーブルにあるカラム
	$future_col = _get_column_all(TBL_FUTURE_PUBLISH);
	// 結合するために取得カラム名を加工する
	foreach ($publish_col as $key => $col) {
		// 未来ビュー用の一時テーブルにあるカラムは未来ビュー用から取得するように設定
		if (in_array($col, $future_col)) {
			$work_col[$key] = 'f_page.' . $col;
			$publish_col[$key] = 'f_page.' . $col;
		}
		// 編集テーブルにないカラムはエラーにならないようにNULL値設定
		else if (in_array($col, $work_none_col)) {
			$work_col[$key] = 'NULL as ' . $col;
			$publish_col[$key] = 'page.' . $col;
		}
		// 公開中に変更
		else if ($col == 'work_class') {
			$work_col[$key] = WORK_CLASS_PUBLISH . ' AS work_class';
			$publish_col[$key] = WORK_CLASS_PUBLISH . ' AS work_class';
		}
		// 公開中に変更
		else if ($col == 'status') {
			$work_col[$key] = STATUS_PUBLISH . ' AS status';
			$publish_col[$key] = STATUS_PUBLISH . ' AS status';
		}
		else {
			$work_col[$key] = 'page.' . $col;
			$publish_col[$key] = 'page.' . $col;
		}
	}
	// ---実テーブルと合体
	$table = '(SELECT ' . implode(',', $publish_col);
	// 公開情報と結合
	$table .= ' FROM tbl_publish_page AS page';
	$table .= ' INNER JOIN ' . TBL_FUTURE_PUBLISH . ' AS f_page ON(page.page_id = f_page.page_id)';
	$table .= ' UNION ALL ';
	// 公開待ちで未来に公開される場合は編集情報と結合
	$table .= 'SELECT ' . implode(',', $work_col);
	$table .= ' FROM tbl_work_page AS page';
	$table .= ' INNER JOIN ' . TBL_FUTURE_WORK . ' AS f_page ON(page.page_id = f_page.page_id)';
	$table .= ')';
	
	return $table;
}
/**
 * 仮想テーブル削除
 *
 * @param $table_name テーブル名
 * @return TRUE|FALSE
 */
function _delete_temp_table($table_name) {
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
	$objDac = new dac($objCnc);
	$sql = 'DROP TEMPORARY TABLE `' . $table_name . '`';
	return $objDac->execute($sql);
}
?>
