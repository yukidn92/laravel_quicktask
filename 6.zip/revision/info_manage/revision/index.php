<?php
/*
 * 更新情報　コンテンツリスト画面(index.php)
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/

//表示&カテゴリレベル
define("G_CATE_LEVEL00", 0); //初期画面
define("G_CATE_LEVEL01", 1); //第1レベル
define("G_CATE_LEVEL02", 2); //第2レベル
define("G_CATE_LEVEL03", 3); //第3レベル
define("G_CATE_LEVEL04", 4); //第4レベル


//表示＆組織レベル
define("G_DEPT_LEVEL00", 0); //初期画面
define("G_DEPT_LEVEL01", 1); //部
define("G_DEPT_LEVEL02", 2); //課
define("G_DEPT_LEVEL03", 3); //係


//エクスプローラー風プラマイ記号イメージPath
define("G_LIST_IMG_P", "./images/dir_plus.jpg"); //プラス
define("G_LIST_IMG_M", "./images/dir_minus.jpg"); //マイナス
define("G_LIST_IMG_N", "./images/dir_none.jpg"); //マイナス


/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");

/*--- 初期値設定 ---*/
$mode = 'dept';
$PrmCode = "";
$DspLst = "";
$bar_img = "./images/bar_department.jpg";
$bar_alt = "組織別更新情報";

/*--- データアクセスクラス ---*/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---引数の取得---*/
$args = ($_SERVER['REQUEST_METHOD'] == 'GET') ? $_GET : $_POST;
//表示区分
if (isset($args['mode'])) {
	$mode = $args['mode'];
	if (($mode != 'cate') && ($mode != 'dept')) {
		DispError("有効ではないパラメーターが指定されました。", 'rev', "javascript:history.back()", MENU_KIND_REVISION);
		exit();
	}
}

switch ($mode) {
	case 'dept' : //組織別
		/*---初期レベル---*/
		switch ($objLogin->get('class')) {
			case USER_CLASS_WRITER :
			case USER_CLASS_APPROVER1 :
				$iniLevel = G_DEPT_LEVEL03;
				break;
			case USER_CLASS_APPROVER2 :
				$iniLevel = G_DEPT_LEVEL02;
				break;
			case USER_CLASS_APPROVER3 :
				$iniLevel = G_DEPT_LEVEL01;
				break;
			case USER_CLASS_WEBMASTER :
				$iniLevel = G_DEPT_LEVEL00;
				break;
		}
		//表示レベル
		$PrmLevel = $iniLevel;
		if (isset($args["level"]) == TRUE) {
			$PrmLevel = $args['level'];
			if (($PrmLevel != G_DEPT_LEVEL00) & ($PrmLevel != G_DEPT_LEVEL01) & ($PrmLevel != G_DEPT_LEVEL02)) {
				DispError("有効ではないパラメーターが指定されました。", 'rev', "javascript:history.back()", MENU_KIND_REVISION);
				exit();
			}
		}
		//組織コード
		if ($PrmLevel != G_DEPT_LEVEL00) {
			if (isset($args["dept_code"]) == TRUE) $PrmCode = $args['dept_code'];
			elseif ($objLogin->get('class') != USER_CLASS_WEBMASTER) $PrmCode = $objLogin->get('dept_code');
			else $PrmLevel = $iniLevel; //未指定の場合は初期画面表示
		}
		/*---一覧の取得---*/
		//取得レベルに応じた表示データの作成
		G_SetDspDeptList($objDac, $PrmLevel, $PrmCode, $DspLst, $objLogin);
		break;
	case 'cate' : //カテゴリ別
		$bar_img = "./images/bar_category.jpg";
		$bar_alt = "分類別更新情報";
		//表示レベル
		$PrmLevel = G_CATE_LEVEL00;
		if (isset($args["level"]) == TRUE) {
			$PrmLevel = $args['level'];
			if (($PrmLevel != G_CATE_LEVEL00) & ($PrmLevel != G_CATE_LEVEL01) & ($PrmLevel != G_CATE_LEVEL02) & ($PrmLevel != G_CATE_LEVEL03)) {
				DispError("有効ではないパラメーターが指定されました。", 'rev', "javascript:history.back()", MENU_KIND_REVISION);
				exit();
			}
		}
		//カテゴリーコード
		if ($PrmLevel != G_CATE_LEVEL00) {
			if (isset($args["cate_code"]) == TRUE) $PrmCode = $args['cate_code'];
			else $PrmLevel = G_CATE_LEVEL00; //未指定の場合は初期画面表示
		}
		/*---一覧の取得---*/
		//取得レベルに応じた表示データの作成
		G_SetDspCateList($objDac, $PrmLevel, $PrmCode, $DspLst, $objLogin);
		break;
}

/*-----------------------------------------------------------------------------
	関数
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
	組織ツリーの展開

【引数】$i_objDac		取得されたデーターオブジェクト
		$i_PrmLevel		引数で指定されたカテゴリレベル
		$i_PrmDeptCode	引数で指定された組織コード
		$o_DspLst		表示する一覧データ
		$i_objLogin		ログイン情報オブジェクト
		
【戻値】True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspDeptList($i_objDac, $i_PrmLevel, $i_PrmDeptCode, &$o_DspLst, $i_objLogin) {
	
	/*---組織コード(部)(課)を取得---*/
	$infoDept = array();
	if ($i_PrmDeptCode != "") $infoDept = getDeptCode($i_PrmDeptCode);
	
	/*---ウェブマスターが作成したページ---*/
	if ($i_objLogin->get('class') == USER_CLASS_WEBMASTER) {
		$sql = "SELECT MAX(pp.update_datetime) AS dt, COUNT(pp.page_id) AS rc" . " FROM tbl_publish_page AS pp INNER JOIN tbl_user AS u ON (u.user_id = pp.user_id)" . " WHERE pp.work_class IN (2, 3) AND u.dept_code = '" . WEB_MASTER_CODE . "'";
		$i_objDac->execute($sql);
		$page_rc = 0;
		$update_dt = "";
		if ($i_objDac->fetch()) {
			$page_rc = ($i_objDac->fld['rc'] != "") ? $i_objDac->fld['rc'] : 0;
			$update_dt = ($i_objDac->fld['dt'] != "") ? '　/　最終更新日時：' . dtFormat($i_objDac->fld['dt'], 'Y年m月d日 H時i分') : '';
		}
		$o_DspLst = $o_DspLst . '<p align="left"><img src="images/label_webmaster.gif" alt="ウェブマスター" width="50" height="20">';
		$o_DspLst = $o_DspLst . '　（' . $page_rc . 'ページ' . $update_dt . '）　</p>' . "\n";
	}
	
	/*---展開されたデータを作成---*/
	$where = "";
	$w1 = "";
	$w2 = "";
	$w3 = "";
	$infoDept_L = getDeptCode($i_objLogin->get('dept_code'));
	switch ($i_objLogin->get('class')) {
		case USER_CLASS_WRITER :
			$where = " AND u.user_id = " . $i_objLogin->get('user_id');
			$w1 = " AND d.dept_code LIKE '" . $infoDept_L['dept1'] . "%'";
			$w2 = " AND (d.dept_code LIKE '" . $infoDept_L['dept1'] . $infoDept_L['dept2'] . "%')";
			$w3 = " AND (d.dept_code = '" . $infoDept_L['dept3_code'] . "')";
			break;
		case USER_CLASS_APPROVER1 :
			$where = " AND u.dept_code = '" . $i_objLogin->get('dept_code') . "'";
			$w1 = " AND d.dept_code LIKE '" . $infoDept_L['dept1'] . "%'";
			$w2 = " AND (d.dept_code LIKE '" . $infoDept_L['dept1'] . $infoDept_L['dept2'] . "%')";
			$w3 = " AND (d.dept_code = '" . $infoDept_L['dept3_code'] . "')";
			break;
		case USER_CLASS_APPROVER2 :
			$where = " AND u.dept_code LIKE '" . $infoDept_L['dept1'] . $infoDept_L['dept2'] . "%'";
			$w1 = " AND d.dept_code LIKE '" . $infoDept_L['dept1'] . "%'";
			$w2 = " AND (d.dept_code LIKE '" . $infoDept_L['dept1'] . $infoDept_L['dept2'] . "%')";
			break;
		case USER_CLASS_APPROVER3 :
			$where = " AND u.dept_code LIKE '" . $infoDept_L['dept1'] . "%'";
			$w1 = " AND d.dept_code LIKE '" . $infoDept_L['dept1'] . "%'";
			break;
	}
	$sql = "SELECT d.level, d.dept_code, d.name, SUM(p.rc) AS rc, MAX(p.dt) AS dt FROM tbl_department AS d" . " LEFT JOIN (SELECT u.dept_code, MAX(pp.update_datetime) AS dt, COUNT(pp.page_id) AS rc" . " FROM tbl_publish_page AS pp INNER JOIN tbl_user AS u ON (u.user_id = pp.user_id)" . " WHERE pp.work_class IN (2, 3) " . $where . " GROUP BY u.dept_code) AS p" . " ON (p.dept_code LIKE CONCAT(LEFT(d.dept_code, (" . CODE_DIGIT_DEPT . "*d.level)), '%'))" . " WHERE ((d.level = " . G_DEPT_LEVEL01 . $w1 . ")";
	if ($i_PrmLevel >= G_DEPT_LEVEL01 && isset($infoDept['dept1'])) $sql .= "OR ((d.level = " . G_DEPT_LEVEL02 . ") AND (d.dept_code LIKE '" . $infoDept['dept1'] . "%')" . $w2 . ")";
	if ($i_PrmLevel >= G_DEPT_LEVEL02 && isset($infoDept['dept1']) && isset($infoDept['dept2'])) $sql .= "OR ((d.level = " . G_DEPT_LEVEL03 . ") AND (d.dept_code LIKE '" . $infoDept['dept1'] . $infoDept['dept2'] . "%')" . $w3 . ")";
	$sql .= ") GROUP BY d.dept_code ORDER BY d.dept_code, d.level, d.sort_order, d.dept_id";
	$i_objDac->execute($sql);
	
	//データ作成
	$leve_sec = "";
	$exp_img = "";
	$bak_level = "";
	while ($i_objDac->fetch()) {
		$dept_code = "";
		$page_rc = ($i_objDac->fld['rc'] != "") ? $i_objDac->fld['rc'] : 0;
		$update_dt = ($i_objDac->fld['dt'] != "") ? '　/　最終更新日時：' . dtFormat($i_objDac->fld['dt'], 'Y年m月d日 H時i分') : '';
		switch ($i_objDac->fld['level']) {
			case G_DEPT_LEVEL01 : //部
				$leve_sec = "dept_first";
				if (isset($infoDept['dept1_code'])) $dept_code = $infoDept['dept1_code'];
				break;
			case G_DEPT_LEVEL02 : //課
				$leve_sec = "dept_second";
				if (isset($infoDept['dept2_code'])) $dept_code = $infoDept['dept2_code'];
				break;
		}
		
		if ($i_objDac->fld['level'] == G_DEPT_LEVEL03) { //係
			$o_DspLst = $o_DspLst . "<p align=\"left\" class=\"dept_third\">";
			$o_DspLst = $o_DspLst . "<img src=\"" . G_LIST_IMG_N . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
			$o_DspLst = $o_DspLst . htmlDisplay($i_objDac->fld['name']);
			$o_DspLst = $o_DspLst . "　（" . $page_rc . "ページ" . $update_dt . "）　";
			$o_DspLst = $o_DspLst . "</p>" . "\n";
		}
		else {
			if (($i_PrmLevel >= $i_objDac->fld['level']) && ($dept_code == $i_objDac->fld['dept_code'])) {
				$exp_img = G_LIST_IMG_M;
				$bak_level = $i_objDac->fld['level'] - 1;
			}
			else {
				$exp_img = G_LIST_IMG_P;
				$bak_level = $i_objDac->fld['level'];
			}
			$o_DspLst = $o_DspLst . "<p align=\"left\" class=\"" . $leve_sec . "\">";
			$o_DspLst = $o_DspLst . "<a href=\"./index.php?mode=dept&level=" . $bak_level . "&dept_code=" . $i_objDac->fld['dept_code'] . "\">";
			$o_DspLst = $o_DspLst . "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
			$o_DspLst = $o_DspLst . "</a>";
			$o_DspLst = $o_DspLst . htmlDisplay($i_objDac->fld['name']);
			$o_DspLst = $o_DspLst . "　（" . $page_rc . "ページ" . $update_dt . "）　";
			$o_DspLst = $o_DspLst . "</p>" . "\n";
		}
	}

}

/*-----------------------------------------------------------------------------
	カテゴリツリーの展開

【引数】$i_objDac		取得されたデーターオブジェクト
		$i_PrmLevel		引数で指定されたカテゴリレベル
		$i_PrmCateCode	引数で指定された組織コード
		$o_DspLst		表示する一覧データ
		$i_objLogin		ログイン情報オブジェクト
		
【戻値】True	
		False	
		
【備考】
-----------------------------------------------------------------------------*/
function G_SetDspCateList($i_objDac, $i_PrmLevel, $i_PrmCateCode, &$o_DspLst, $i_objLogin) {
	
	/*---カテゴリコードの取得---*/
	$infoCate = array();
	if ($i_PrmCateCode != "") $infoCate = getCateCode($i_PrmCateCode);
	
	/*---ウェブマスターが作成したページ---*/
	if ($i_objLogin->get('class') == USER_CLASS_WEBMASTER) {
		$sql = "SELECT MAX(update_datetime) AS dt FROM tbl_publish_page" . " WHERE work_class IN (2, 3) AND cate_code IS NULL";
		$i_objDac->execute($sql);
		$o_DspLst = $o_DspLst . '<p align="left"><img src="images/label_top.gif" alt="トップ" width="50" height="20">';
		if ($i_objDac->fetch() && $i_objDac->fld['dt'] != "") {
			$o_DspLst = $o_DspLst . '　（最終更新日時：' . dtFormat($i_objDac->fld['dt'], 'Y年m月d日 H時i分') . '）';
		}
		$o_DspLst = $o_DspLst . '</p>' . "\n";
	}
	
	/*---展開されたデータを作成---*/
	$where = "";
	$w1 = "";
	$w2 = "";
	$w3 = "";
	$infoDept_L = getDeptCode($i_objLogin->get('dept_code'));
	switch ($i_objLogin->get('class')) {
		case USER_CLASS_WRITER :
			$where = " AND u.user_id = " . $i_objLogin->get('user_id');
			break;
		case USER_CLASS_APPROVER1 :
			$where = " AND u.dept_code = '" . $i_objLogin->get('dept_code') . "'";
			break;
		case USER_CLASS_APPROVER2 :
			$where = " AND u.dept_code LIKE '" . $infoDept_L['dept1'] . $infoDept_L['dept2'] . "%'";
			break;
		case USER_CLASS_APPROVER3 :
			$where = " AND u.dept_code LIKE '" . $infoDept_L['dept1'] . "%'";
			break;
	}
	$sql = "SELECT c.level, c.cate_code, c.name, SUM(p.rc) AS rc, MAX(p.dt) AS dt" . " FROM tbl_category AS c" . " LEFT JOIN (SELECT pp.cate_code, MAX(pp.update_datetime) AS dt, COUNT(pp.page_id) AS rc" . " FROM tbl_publish_page AS pp INNER JOIN tbl_user AS u ON (u.user_id = pp.user_id)" . " WHERE pp.work_class IN (2, 3) " . $where . " GROUP BY pp.cate_code) AS p" . " ON (p.cate_code LIKE CONCAT(LEFT(c.cate_code, (" . CODE_DIGIT_CATE . "*c.level)), '%'))" . 

	" WHERE ((c.level = " . G_CATE_LEVEL01 . ")";
	if ($i_PrmLevel >= G_CATE_LEVEL01 && isset($infoCate['cate1'])) $sql .= "OR ((c.level = " . G_CATE_LEVEL02 . ") AND (c.cate_code LIKE '" . $infoCate['cate1'] . "%'))";
	if ($i_PrmLevel >= G_CATE_LEVEL02 && isset($infoCate['cate1']) && isset($infoCate['cate2'])) $sql .= "OR ((c.level = " . G_CATE_LEVEL03 . ") AND (c.cate_code LIKE '" . $infoCate['cate1'] . $infoCate['cate2'] . "%'))";
	if ($i_PrmLevel >= G_CATE_LEVEL03 && isset($infoCate['cate1']) && isset($infoCate['cate2']) && isset($infoCate['cate3'])) $sql .= "OR ((c.level = " . G_CATE_LEVEL04 . ") AND (c.cate_code LIKE '" . $infoCate['cate1'] . $infoCate['cate2'] . $infoCate['cate3'] . "%'))";
	$sql .= ") GROUP BY c.cate_code ORDER BY c.cate_code, c.level, c.sort_order, c.cate_id";
	$i_objDac->execute($sql);
	
	//データ作成
	$leve_sec = "";
	$exp_img = "";
	$bak_level = 0;
	while ($i_objDac->fetch()) {
		$cate_code = "";
		$page_rc = ($i_objDac->fld['rc'] != "") ? $i_objDac->fld['rc'] : 0;
		$update_dt = ($i_objDac->fld['dt'] != "") ? '　/　最終更新日時：' . dtFormat($i_objDac->fld['dt'], 'Y年m月d日 H時i分') : '';
		switch ($i_objDac->fld['level']) {
			case G_CATE_LEVEL01 : //レベル１
				$leve_sec = "cate_first";
				if (isset($infoCate['cate1_code'])) $cate_code = $infoCate['cate1_code'];
				break;
			case G_CATE_LEVEL02 : //レベル２
				$leve_sec = "cate_second";
				if (isset($infoCate['cate2_code'])) $cate_code = $infoCate['cate2_code'];
				break;
			case G_CATE_LEVEL03 : //レベル３
				$leve_sec = "cate_third";
				if (isset($infoCate['cate3_code'])) $cate_code = $infoCate['cate3_code'];
				break;
		}
		
		if ($i_objDac->fld['level'] == G_CATE_LEVEL04) { //レベル４
			$o_DspLst = $o_DspLst . "<p align=\"left\" class=\"cate_fourth\">";
			$o_DspLst = $o_DspLst . "<img src=\"" . G_LIST_IMG_N . "\" alt=\"\" width=\"60\" height=\"20\">";
			$o_DspLst = $o_DspLst . htmlDisplay($i_objDac->fld['name']);
			$o_DspLst = $o_DspLst . "　（" . $page_rc . "ページ" . $update_dt . "）　";
			$o_DspLst = $o_DspLst . "</p>" . "\n";
		}
		else {
			if (($i_PrmLevel >= $i_objDac->fld['level']) && ($cate_code == $i_objDac->fld['cate_code'])) {
				$exp_img = G_LIST_IMG_M;
				$bak_level = $i_objDac->fld['level'] - 1;
			}
			else {
				$exp_img = G_LIST_IMG_P;
				$bak_level = $i_objDac->fld['level'];
			}
			$o_DspLst = $o_DspLst . "<p align=\"left\" class=\"" . $leve_sec . "\">";
			$o_DspLst = $o_DspLst . "<a href=\"./index.php?mode=cate&level=" . $bak_level . "&cate_code=" . $i_objDac->fld['cate_code'] . "\">";
			$o_DspLst = $o_DspLst . "<img src=\"" . $exp_img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
			$o_DspLst = $o_DspLst . "</a>";
			$o_DspLst = $o_DspLst . htmlDisplay($i_objDac->fld['name']);
			$o_DspLst = $o_DspLst . "　（" . $page_rc . "ページ" . $update_dt . "）　";
			$o_DspLst = $o_DspLst . "</p>" . "\n";
		}
	}

}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>更新情報</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="revision.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'info_manage';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-revision">
<div><img src="<?=$bar_img?>" alt="<?=$bar_alt?>" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="right"><a href="index.php?mode=dept"><img
	src="images/btn_department.jpg" alt="組織別" width="150" height="20"
	border="0" style="margin-right: 10px"></a> <a
	href="index.php?mode=cate"><img src="images/btn_category.jpg" alt="分類別"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
<?=$DspLst?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
