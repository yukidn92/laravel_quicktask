<?php
/*
 * ページ情報をエクスポートする
 */

// 設定ファイル読み込み
require ("../.htsetting");
global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$obj_tools = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
$obj_page2 = new tbl_page($objCnc);

// 定数の宣言

// 見出し文字
$G_HEADER_TITLE_ARY = array(
	'ページID', 
	'ページタイトル', 
	'ファイルパス', 
	'公開状態',
	'ステータス', 
	'ステータス（状態）', 
	'公開開始日', 
	'公開終了日', 
	'テンプレートID', 
	'テンプレート名称', 
	'分類コード', 
	'第一分類名称', 
	'第二分類名称', 
	'第三分類名称', 
	'第四分類名称', 
	'組織コード', 
	'第一組織名称', 
	'第二組織名称', 
	'第三組織名称', 
	'ユーザーID', 
	'ページ作成者', 
	'親ページID', 
	'親ページタイトル', 
	'親ページファイルパス', 
	'最終更新日'
);

// 変数の宣言

// CSVデータ用配列
$g_export_csv_data_ary = array();
$g_csv_line = 0;
$g_search = array();
$g_inquiry_flg = FLAG_OFF;
$g_inq_max_cnt = 0;
$g_inq_data_ary = array();
$g_table_name = 'publish';

// 検索条件の取得
$g_table = $_SESSION['page_info_export']['table'];
$g_where = implode(' AND ', $_SESSION['page_info_export']['where_ary']);
$g_order = $_SESSION['page_info_export']['orderby'];
$g_field = 'p.*, u.*, t.name as temp_name, c1.name as cate1, c2.name as cate2, c3.name as cate3, c4.name as cate4';

// ページの検索
$obj_page->select($g_where, $g_field, $g_order, '', '', $g_table);

// 出力データの作成
while ($obj_page->fetch()) {
	// 公開前のページは、編集テーブルより抽出する
	if ($obj_page->fld['work_class'] == 1) {
		$g_table_name = 'work';
		// 編集ページの情報を抽出
		if (!$obj_page2->selectFromID($obj_page->fld['page_id'], WORK_TABLE)) {
			user_error('編集ページ情報の取得に失敗しました。【' . $obj_page->fld['page_id'] . '】');
		}
		$fld = $obj_page2->fld;
		// ユーザー情報を抽出
		$sql = 'SELECT * FROM tbl_user WHERE user_id = ' . $obj_page2->fld['user_id'];
		if (!$obj_tools->execute($sql)) {
			user_error('ユーザー情報の取得に失敗しました。【' . $obj_page2->fld['user_id'] . '】');
		}
		if ($obj_tools->fetch()) {
			$fld += $obj_tools->fld;
		}
		// テンプレート情報を抽出
		$sql = 'SELECT name as temp_name FROM tbl_template WHERE template_id = ' . $obj_page2->fld['template_id'] . ' ORDER BY template_ver DESC LIMIT 1';
		if (!$obj_tools->execute($sql)) {
			user_error('テンプレート情報の取得に失敗しました。【' . $obj_page2->fld['template_id'] . '】');
		}
		if ($obj_tools->fetch()) {
			$fld += $obj_tools->fld;
		}
		// 分類情報を抽出
		$cate_info = getCateCode($obj_page2->fld['cate_code']);
		$sql = 'SELECT * FROM tbl_category WHERE cate_code IN (' . $cate_info['cate1_code'] . ', ' . $cate_info['cate2_code'] . ', ' . $cate_info['cate3_code'] . ', ' . $cate_info['cate4_code'] . ')';
		if (!$obj_tools->execute($sql)) {
			user_error('分類情報の取得に失敗しました。【' . $sql . '】');
		}
		while ($obj_tools->fetch()) {
			$fld['cate' . $obj_tools->fld['level']] = $obj_tools->fld['name'];
		}
	}
	// 一度でも公開したページは、公開テーブルより抽出する
	else {
		$g_table_name = 'publish';
		$fld = $obj_page->fld;
	}
	// ページID
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['page_id']) ? $fld['page_id'] : '');
	// ページタイトル
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['page_title']) ? $fld['page_title'] : '');
	// ファイルパス
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['file_path']) ? $fld['file_path'] : '');
	// 公開状態
	$ret_status_publish = getStatusPublish($fld);
	$g_export_csv_data_ary[$g_csv_line][] = $ret_status_publish;
	// ステータス
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['status']) ? $fld['status'] : '');
	// ステータス（状態）
	$ret_ary = get_status_icon($fld);
	// ▼暫定▼
//	$g_export_csv_data_ary[$g_csv_line][] = (isset($ret_ary['wc_alt']) ? $ret_ary['wc_alt'] : '');
	if ($fld['work_class'] == WORK_CLASS_DELETE && $fld['close_flg'] == FLAG_ON) {
		// tbl_publish_pageの情報が、work_class:3 close_flg:1 の場合には「削除中」とする
		// [補足]work_class 1の場合のみ、work_pageの情報を取得している
		// [補足]非公開中ページの非公開待ち（組織編制時）のページがあることは考慮しない
		$g_export_csv_data_ary[$g_csv_line][] = '削除中';
	}
	else {
		$g_export_csv_data_ary[$g_csv_line][] = (isset($ret_ary['wc_alt']) ? $ret_ary['wc_alt'] : '');
	}
	// ▲暫定▲
	// 公開開始日
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['publish_start']) ? $fld['publish_start'] : '');
	// 公開終了日
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['publish_end']) ? $fld['publish_end'] : '');
	// テンプレートID
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['template_id']) ? $fld['template_id'] : '');
	// テンプレート名称
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['temp_name']) ? $fld['temp_name'] : '');
	// 分類コード
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['cate_code']) ? $fld['cate_code'] : '');
	// 第一分類名称
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['cate1']) ? $fld['cate1'] : '');
	// 第二分類名称
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['cate2']) ? $fld['cate2'] : '');
	// 第三分類名称
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['cate3']) ? $fld['cate3'] : '');
	// 第四分類名称
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['cate4']) ? $fld['cate4'] : '');
	// 組織コード
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['dept_code']) ? $fld['dept_code'] : '');
	// 組織情報を取得
	$dept_code = getDeptCode($fld['dept_code']);
	// 第一組織名称
	if ($obj_tools->getDeaprtment($dept_code['dept1_code'])) {
		$g_export_csv_data_ary[$g_csv_line][] = $obj_tools->fld['name'];
	}
	else {
		$g_export_csv_data_ary[$g_csv_line][] = '';
	}
	// 第二組織名称
	if ($obj_tools->getDeaprtment($dept_code['dept2_code'])) {
		$g_export_csv_data_ary[$g_csv_line][] = $obj_tools->fld['name'];
	}
	else {
		$g_export_csv_data_ary[$g_csv_line][] = '';
	}
	// 第三組織名称
	if ($obj_tools->getDeaprtment($dept_code['dept3_code'])) {
		$g_export_csv_data_ary[$g_csv_line][] = $obj_tools->fld['name'];
	}
	else {
		$g_export_csv_data_ary[$g_csv_line][] = '';
	}
	// ユーザーID
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['user_id']) ? $fld['user_id'] : '');
	// ページ作成者
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['name']) ? $fld['name'] : '');
	// 親ページID
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['parent_id']) ? $fld['parent_id'] : '');
	// 親ページ情報の取得
	if ($obj_page2->selectFromID($fld['parent_id'])) {
		// 親ページタイトル
		$g_export_csv_data_ary[$g_csv_line][] = $obj_page2->fld['page_title'];
		// 親ページファイルパス
		$g_export_csv_data_ary[$g_csv_line][] = $obj_page2->fld['file_path'];
	}
	else {
		$g_export_csv_data_ary[$g_csv_line][] = '';
		$g_export_csv_data_ary[$g_csv_line][] = '';
	}
	// 最終更新日
	$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['update_datetime']) ? $fld['update_datetime'] : '');
	// 問い合わせ先の表示を行う場合
	if ($fld['inquiry_flg'] == FLAG_ON) {
		// 問い合わせ先（フリー入力）
		$g_export_csv_data_ary[$g_csv_line][] = (isset($fld['inquiry_memo']) ? $fld['inquiry_memo'] : '');
		$g_inquiry_flg = FLAG_ON;
		// 問い合わせ先情報の取得
		$sql = "SELECT * FROM tbl_" . $g_table_name . "_inquiry WHERE inquiry_id = '" . $fld['inquiry_id'] . "' ORDER BY inquiry_no";
		if ($obj_dac->execute($sql)) {
			if ($obj_dac->getRowCount() > 0) {
				$inq_cnt = 0;
				// 問い合わせの数分ループ
				while ($obj_dac->fetch()) {
					// 問い合わせ先（組織コード）
					$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_dac->fld['dept_code'];
					// 組織情報を取得
					$dept_code = getDeptCode($obj_dac->fld['dept_code']);
					// 問い合わせ先（第一組織名称）
					if ($dept_code['level'] >= 1 && $obj_tools->getDeaprtment($dept_code['dept1_code'])) {
						$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_tools->fld['name'];
					}
					else {
						$g_inq_data_ary[$g_csv_line][$inq_cnt][] = '';
					}
					// 問い合わせ先（第二組織名称）
					if ($dept_code['level'] >= 2 && $obj_tools->getDeaprtment($dept_code['dept2_code'])) {
						$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_tools->fld['name'];
					}
					else {
						$g_inq_data_ary[$g_csv_line][$inq_cnt][] = '';
					}
					// 問い合わせ先（第三組織名称）
					if ($dept_code['level'] >= 3 && $obj_tools->getDeaprtment($dept_code['dept3_code'])) {
						$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_tools->fld['name'];
					}
					else {
						$g_inq_data_ary[$g_csv_line][$inq_cnt][] = '';
					}
					// 問い合わせ先（担当者名）
					$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_dac->fld['name'];
					// 問い合わせ先（内線番号）
					$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_dac->fld['anex_number'];
					// 問い合わせ先（電話番号）
					$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_dac->fld['drxt_number'];
					// 問い合わせ先（ファックス番号）
					$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_dac->fld['fax'];
					// 問い合わせ先（Email）
					$g_inq_data_ary[$g_csv_line][$inq_cnt][] = $obj_dac->fld['email'];
					$inq_cnt++;
				}
				// 問い合わせの最大数を取得
				if ($g_inq_max_cnt < $inq_cnt) {
					$g_inq_max_cnt = $inq_cnt;
				}
			}
		}
	}
	else {
		// 問い合わせ先（フリー入力）
		$g_export_csv_data_ary[$g_csv_line][] = '';
	}
	$g_csv_line++;
}

// CSV用のデータ作成処理
$max_header_title_ary = $G_HEADER_TITLE_ARY;
// 問い合わせ先が存在する場合
if ($g_inquiry_flg == FLAG_ON) {
	$max_header_title_ary[] = '問い合わせ先（' . INQUIRY_FREE_NAME . '）';
	// 項目の最大数を取得
	$max_item_num = 0;
	if (isset($g_inq_data_ary[key($g_inq_data_ary)][0])) {
		$max_item_num = count($g_inq_data_ary[key($g_inq_data_ary)][0]);
	}
	// CSVの行数分ループ
	foreach ($g_export_csv_data_ary as $csv_line => $csv_ary) {
		// 問い合わせの最大数分ループ
		for ($cnt = 0; $cnt < $g_inq_max_cnt; $cnt++) {
			// 各問合せの数分ループ
			for ($i = 0; $i < $max_item_num; $i++) {
				// 問い合わせが存在する場合
				if (isset($g_inq_data_ary[$csv_line][$cnt])) {
					$csv_ary[] = $g_inq_data_ary[$csv_line][$cnt][$i];
				}
				// 問い合わせが存在しない場合
				else {
					$csv_ary[] = '';
				}
			}
			// 初回のみループ
			if ($csv_line == 0) {
				// 問い合わせ先（組織コード）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（' . INQUIRY_DEPT_NAME . '）';
				// 問い合わせ先（第一組織名称）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（第一組織名称）';
				// 問い合わせ先（第一組織名称）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（第二組織名称）';
				// 問い合わせ先（第一組織名称）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（第三組織名称）';
				// 問い合わせ先（担当者名）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（' . INQUIRY_CHARGE_NAME . '）';
				// 問い合わせ先（内線番号）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（' . INQUIRY_EXTENSIONNUMBER_NAME . '）';
				// 問い合わせ先（電話番号）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（' . INQUIRY_DIRECTNUMBER_NAME . '）';
				// 問い合わせ先（ファックス番号）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（' . INQUIRY_FAX_NAME . '）';
				// 問い合わせ先（Email）
				$max_header_title_ary[] = '問い合わせ先' . ($cnt + 1) . '（' . INQUIRY_EMAIL_NAME . '）';
			}
		}
		$g_export_csv_data_ary[$csv_line] = $csv_ary;
	}
}

// CSV出力処理
create_Csv('page_info.csv', $g_export_csv_data_ary, $max_header_title_ary, 0, "", "UTF-8", "\"");

/**
 * 公開状態	（"新規"、"公開"、"非公開"）を取得する
 *
 * @param $page_fld ページの情報
 * @return ページの公開状態の文字列
 */
function getStatusPublish($page_fld) {
	// 戻り値
	$ret ='';
	
	if ($page_fld['work_class'] == WORK_CLASS_NEW) {
		// "新規"
		$ret = '新規';
	}
	else {
		if ($page_fld['output_html_flg'] == FLAG_OFF) {
			$ret = 'ページ出力なし';
		}
		else {
			if ($page_fld['close_flg'] == FLAG_OFF) {
				// "公開"
				$ret = getStatusProcessing($page_fld, '公開');
			}
			else {
				// "非公開"
				$ret = getStatusProcessing($page_fld, '非公開');
			}
		}
	}
	return $ret;
}

/**
 * 処理状態	（"更新"、"非公開・削除処理"）の文字列を取得する
 *
 * @param $page_fld ページの情報
 * @param $str 公開状態の文字列
 * @return 公開状態に処理状態を付与した文字列
 */
function getStatusProcessing($page_fld, $str) {
	// 戻り値
	$ret = '';
	
	// 処理状態の判断
	if ($page_fld['work_class'] == WORK_CLASS_PUBLISH) {
		if ($page_fld['status'] == STATUS_PUBLISH) {
			$ret = $str;
		}
		else {
			// 更新
			$ret = $str . '(更新)';
		}
	}
	else if ($page_fld['work_class'] == WORK_CLASS_DELETE) {
		// 非公開・削除処理
		if ($page_fld['close_flg'] == FLAG_OFF) {
			$ret = $str . '(非公開・削除処理)';
		}
		else {
			$ret = $str . '(削除処理)';
		}
	}
	return $ret;
}
?>