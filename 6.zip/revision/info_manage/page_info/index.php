<?php
/*
 *
 */
/** require **/
require ("../.htsetting");
global $objCnc;

// ログイン情報
$login = $objLogin->login;

if ($login['class'] != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。');
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objUPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

//検索ウインドウ
$btn = array(
		"dis" => "display:none", 
		"img" => "btn_open_mini.jpg", 
		"alt" => "開く"
);

$html = '<tr>' . "\n";
$html .= '<th align="center" valign="middle" style="font-weight:normal" scope="col">状態</th>' . "\n";
$html .= '<th align="center" valign="middle" style="font-weight:normal" scope="col">タイトル</th>' . "\n";
$html .= '<th align="center" valign="middle" style="font-weight:normal" scope="col">表示切り替え</th>' . "\n";
$html .= '</tr>' . "\n";
//ロック
$lock_k = '<p class="page_info-p"><a href="javascript:" onClick="return cxUnlock(\'{id}\')"><img src="' . RPW . '/admin/images/btn/btn_unlock.jpg" alt="ロック解除" width="150" height="20" border="0"></a></p>' . "\n";
$lock_j = '<p class="page_info-p"><small>ロック中の組織：{lock_dept}</small></p>' . "\n";
$lock_j .= '<p class="page_info-p"><small>ロック中のユーザー：{lock_name}</small></p>' . "\n";
$lock_u = '<img src="' . RPW . '/admin/revision/info_manage/page_info/images/icon_lock.gif" alt="ロック中" width="16" height="14" border="0">' . "\n";
//リスト
$fmt = '<tr>' . "\n";
$fmt .= '<td width="10%" align="center" valign="middle">' . "\n";
$fmt .= '<p class="page_info-p"><img src="' . RPW . '/admin/revision/info_manage/page_info/images/{img_url}" alt="{alt}" width="59" height="16" border="0"></p>' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '<td width="70%" align="left" valign="top">' . "\n";
$fmt .= '<p class="page_info-p">{lock_img}<strong><a href="javascript:" onClick="return cxPreview(\'pageinfo\',\'{id}\',\'{pmode}\')">{page_title}</a>({page_id})</strong></p>' . "\n";
$fmt .= '<span id="{id}_dispmode" style="display:none">' . "\n";
$fmt .= '<p class="page_info-p"><small>ファイルパス：{url}</small></p>' . "\n";
$fmt .= '<p class="page_info-p"><small>公開期間：{publish_date}</small></p>' . "\n";
$fmt .= '<p class="page_info-p"><small>最終更新日：{publish_update}</small></p>' . "\n";
$fmt .= '<p class="page_info-p"><small>テンプレート：{temp}</small></p>' . "\n";
$fmt .= '<p class="page_info-p"><small>分類：{cate}</small></p>' . "\n";
$fmt .= '<p class="page_info-p"><small>組織：{dept_name}</small></p>' . "\n";
$fmt .= '<p class="page_info-p"><small>ページ作成者：{name}</small></p>' . "\n";
$fmt .= '{lock_j}';
$fmt .= '</td>' . "\n";
$fmt .= '</span>' . "\n";
$fmt .= '<td width="20%" align="center" valign="top">' . "\n";
$fmt .= '<p class="page_info-p"><a href="javascript:" onClick="cxdisp(\'{id}\')"><img src="' . RPW . '/admin/revision/info_manage/page_info/images/btn_details.jpg" alt="詳細情報に切り替え" id="{id}_btn" width="150" height="20" border="0"></a></p>' . "\n";
$fmt .= '{lock}</td></tr>' . "\n";

// 検索条件
$search = array(
		// ページID検索
		'page_id' => '',  //ページID
		'page_title' => '',  //ページタイトル
		'search_keywords' => '',  //キーワード検索
		'is_tag_search' => FLAG_OFF,  //タグを対象とするかどうか
		'url' => '',  //ファイルパス
		'publish_start' => '',  //公開開始日から
		'publish_end' => '',  //公開開始日まで
		'update_start' => date("Y-m-d"),  //最終更新日から
		'update_end' => '',  //最終更新日まで
		'pdsy' => '',  //公開
		'pdsm' => '',  //
		'pdsd' => '',  //
		'pdey' => '',  //
		'pdem' => '',  //
		'pded' => '',  //
		'kdsy' => (int) date("Y"),  //更新
		'kdsm' => (int) date("m"),  //
		'kdsd' => (int) date("d"),  //
		'kdey' => (int) date("Y"),  //
		'kdem' => (int) date("m"),  //
		'kded' => (int) date("d"),  //
		'dept_code' => array(
				'dept1' => '', 
				'dept2' => '', 
				'dept3' => ''
		),  //対象
		'cate_code' => array(
				'cate1' => '', 
				'cate2' => '', 
				'cate3' => '', 
				'cate4' => ''
		),  //分類
		'page_status' => array(),  //ステータス
		'page_status2' => array(),  //ステータス２
		'user_lock' => array(),  //ユーザーロック
		'temp_kind' => array(),  //テンプレート種類
		'temp_id' => '',  //テンプレートID
		'page_limit' => '10',  //ページ表示件数
		'disp_order' => 'update_datetime',  //表示順項目
		'sort_pattern' => 'DESC',  //昇順か降順か
		'p' => 1
);

$TEMPLATE_KIND = getDefineArray("TEMPLATE_KIND");
$MAXROW_LIST = getDefineArray("MAXROW_LIST");
$DISP_ORDER_ITEM = getDefineArray("DISP_ORDER_ITEM");
$DISP_ORDER_ITEM = array_flip($DISP_ORDER_ITEM); //キーと値を入れ替え
$disp_order_ary = array(
		"ASC" => "昇順", 
		"DESC" => "降順"
);
$PAGE_LIMIT = array(
		"10" => "10件", 
		"50" => "50件", 
		"100" => "100件"
);
$STATUS = array(
		STATUS_SAVE => "編集中", 
		STATUS_COMP => "編集完了", 
		STATUS_APPROVE_1 => "第一承認待ち", 
		STATUS_APPROVE_2 => "第二承認待ち", 
		STATUS_APPROVE_3 => "第三承認待ち", 
		STATUS_APPROVE_LAST => "最終承認待ち", 
		STATUS_DENIAL => "否認", 
		STATUS_PUBLISH_WAIT => "公開待ち", 
		"public" => "公開中", 
		"close" => "非公開"
);
$STIMG = array(
		STATUS_RESERVE => array(
				"url" => "stat_edit.jpg", 
				"alt" => "編集中"
		), 
		STATUS_NEW => array(
				"url" => "stat_edit.jpg", 
				"alt" => "編集中"
		), 
		STATUS_SAVE => array(
				"url" => "stat_edit.jpg", 
				"alt" => "編集中"
		), 
		STATUS_COMP => array(
				"url" => "stat_create_comp.jpg", 
				"alt" => "編集完了"
		), 
		STATUS_APPROVE_1 => array(
				"url" => "stat_approve.jpg", 
				"alt" => "承認待ち"
		), 
		STATUS_APPROVE_2 => array(
				"url" => "stat_approve.jpg", 
				"alt" => "承認待ち"
		), 
		STATUS_APPROVE_3 => array(
				"url" => "stat_approve.jpg", 
				"alt" => "承認待ち"
		), 
		STATUS_APPROVE_LAST => array(
				"url" => "stat_approve.jpg", 
				"alt" => "承認待ち"
		), 
		STATUS_DENIAL => array(
				"url" => "stat_nage.jpg", 
				"alt" => "否認"
		), 
		STATUS_PUBLISH_WAIT => array(
				"url" => "stat_publicwait.jpg", 
				"alt" => "公開待ち"
		), 
		"public" => array(
				"url" => "stat_public.jpg", 
				"alt" => "公開中"
		), 
		"close" => array(
				"url" => "stat_close.jpg", 
				"alt" => "非公開"
		)
);
$LOCK = array(
		"0" => "ロック状態のページのみ表示する"
);
// タグ内検索
$TAG_SEARCH = array(
		FLAG_OFF => "HTMLのタグを対象としない", 
		FLAG_ON => "HTMLのタグを対象とする"
);
$search_mode = (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] != "") ? $_POST['cms_dispMode'] : "init";
//同一ページ以外から来た場合セッション削除
if (!isset($_SERVER['HTTP_REFERER']) || preg_replace('/\?.*$/i', '', $_SERVER['HTTP_REFERER']) != HTTP_ROOT . $_SERVER['PHP_SELF']) {
	unset($_SESSION['search']);
	//$search['update_start'] = date("Y-m-d");
}

// 検索条件を削除
unset($_SESSION['page_info_export']);

//モード
switch ($search_mode) {
	case "search" :
		$btn['dis'] = "display:block";
		$btn['img'] = "btn_close_mini.jpg";
		$btn['alt'] = "閉じる";
		$search = margePost($search);
		$_SESSION['search'] = $search;
		$_SESSION['last_search_condition']['page_info_search'] = $search;
		search($search);
		break;
	case "pageset" :
		$search = $_SESSION['search'];
		$search['p'] = $_POST['p'];
		search($search);
		break;
	case "unlock" :
		if (!unlock($_POST['cms_page_id'])) {
			DispError("ロック解除に失敗しました。", 2, "javascript:history.back()");
		}
		$search = $_SESSION['search'];
		search($search);
		break;
	case "init" :
		$_SESSION['search'] = $search;
		search($search);
		break;
	case "disp_num" :
		$btn['dis'] = "display:none";
		$btn['img'] = "btn_open_mini.jpg";
		$btn['alt'] = "開く";
		$search = margePost($search);
		search($search);
		break;
	case "last_condition" :
		$btn['dis'] = "display:block";
		$btn['img'] = "btn_close_mini.jpg";
		$btn['alt'] = "閉じる";
		$search = $_SESSION['last_search_condition']['page_info_search'];
		$_SESSION['search'] = $search;
		search($search);
		break;
	default :
		break;
}

//対象項目生成
// ページID検索
$search_page_id = (!empty($search['page_id'])) ? implode(' ', $search['page_id']) : '';
$cms_target = create_department_list("dept", $search['dept_code'], "120"); //対象
$cms_category = create_category_list("cate", $search['cate_code'], "120"); //分類
$cms_temp_kind = mkcheckbox($TEMPLATE_KIND, "temp_kind", $search['temp_kind'], count($TEMPLATE_KIND)); //テンプ種類
$disp_order = create_list("disp_order", $DISP_ORDER_ITEM, $search['disp_order'], 120, 1); //表示順
$sort_pattern = mkradiobutton($disp_order_ary, "sort_pattern", $search['sort_pattern'], 2); //表示順
$page_suu = mkcombobox($MAXROW_LIST, "page_limit", $search['page_limit'], "cxDispNum(this.value)"); //ページ表示数
$page_status = mkcheckbox($STATUS, "page_status", $search['page_status'], 5); //ページステータス
$user_lock = mkcheckbox($LOCK, "user_lock", $search['user_lock'], 1); //ロック
$cms_is_tag_search = mkradiobutton($TAG_SEARCH, "is_tag_search", $search["is_tag_search"], 2); //タグを対象にするかどうか
$STATUS[STATUS_NEW] = "新規";
$disp_last_condition = ""; //前回の検索ボタンHTML
//前回の検索ボタン表示
if (isset($_SESSION['last_search_condition']['page_info_search'])) {
	$disp_last_condition = '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span>' . "\n";
}

// テンプレート読み込み
$template_name = "";
$template_id = "";
$template_id_ary = array();
if (isset($search['temp_id']) && $search['temp_id'] != '') {
	$template_id = $search['temp_id'];
	$template_id_ary = explode(",", $search['temp_id']);
	$template_id_ary = array_diff($template_id_ary, array(
			""
	));
	foreach ($template_id_ary as $id) {
		if ($objTool->selectTemplate($id) === FALSE) {
			user_error("Can't find template data.<br>dac_tools selectTemplate(" . $pub_fld['template_id'] . ")", E_USER_ERROR);
		}
		$template_name = $template_name . '<span id="template_id_' . $id . '">' . '&nbsp;<a href="javascript:" onClick="return cxTemplateUnSet(template_id_' . $id . ',\'' . $id . '\')">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" alt="削除" width="12" height="12" border="0">' . '</a>' . htmlDisplay($objTool->fld['name']) . '</span>';
	}
}

// テンプレート（最新バージョン）情報を取得
$sql = "SELECT t.* FROM tbl_template AS t" . " WHERE t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND " . $objTool->_addslashesC("t.template_kind", TEMPLATE_KIND_NONE, "<>") . " AND t.disp_flg = '" . FLAG_ON . "'" . " ORDER BY t.sort_order,t.template_id";
$objTool->execute($sql);

/** database controll **/
if ($objPage->getRowCount() > 0) {
	while ($objPage->fetch()) {
		$page_title = $objPage->fld['page_title'];
		
		if ($objPage->fld['status'] == STATUS_PUBLISH && $objPage->fld['close_flg'] == FLAG_OFF) {
			//公開中
			$status_img = "public";
		}
		else if ($objPage->fld['status'] == STATUS_PUBLISH && $objPage->fld['close_flg'] == FLAG_ON) {
			//非公開
			$status_img = "close";
		}
		else {
			$status_img = $objPage->fld['status'];
		}
		
		$file_path = $objPage->fld['file_path'];
		$publish_start = dtFormat($objPage->fld['publish_start'], 'Y年m月d日H時');
		$publish_end = get_publish_end_date($objPage->fld['publish_end']);
		$publish_update = dtFormat($objPage->fld['update_datetime'], 'Y年m月d日H時i分s秒');
		$temp = $objPage->fld['temp_name'];
		$page_id = $objPage->fld['page_id'];
		$dept_name = $objPage->fld['dept_name'];
		$name = $objPage->fld['name'];
		$cate = $objPage->fld['cate1'] . $objPage->fld['cate2'] . $objPage->fld['cate3'] . $objPage->fld['cate4'];
		$img_disp = "";
		$tmp = $fmt;
		
		if ($objPage->fld['user_lock'] != NULL) {
			$tmp = str_replace('{lock}', $lock_k, $tmp);
			$tmp = str_replace('{lock_j}', $lock_j, $tmp);
			$tmp = str_replace('{lock_img}', $lock_u, $tmp);
			$tmp = str_replace('{lock_name}', htmlspecialchars($objPage->fld['lock_name']), $tmp);
			$tmp = str_replace('{lock_dept}', htmlspecialchars($objPage->fld['lock_dept_name']), $tmp);
		}
		else {
			$tmp = str_replace('{lock}', "", $tmp);
			$tmp = str_replace('{lock_j}', "", $tmp);
			$tmp = str_replace('{lock_img}', "", $tmp);
		}
		$tmp = str_replace('{page_title}', htmlspecialchars($page_title), $tmp);
		$tmp = str_replace('{page_id}', htmlspecialchars($page_id), $tmp);
		$tmp = str_replace('{img_url}', $STIMG[$status_img]['url'], $tmp);
		$tmp = str_replace('{alt}', $STIMG[$status_img]['alt'], $tmp);
		if ($publish_start != '') {
			$tmp = str_replace('{publish_date}', htmlspecialchars($publish_start) . 'から' . htmlspecialchars($publish_end) . 'まで', $tmp);
		}
		else {
			$tmp = str_replace('{publish_date}', '', $tmp);
		}
		if ($objPage->fld['work_class'] == WORK_CLASS_NEW) {
			$tmp = str_replace('{pmode}', '2', $tmp);
		}
		else {
			$tmp = str_replace('{pmode}', '1', $tmp);
		}
		$tmp = str_replace('{publish_update}', htmlspecialchars($publish_update), $tmp);
		$tmp = str_replace('{temp}', htmlspecialchars($temp), $tmp);
		$tmp = str_replace('{id}', htmlspecialchars($page_id), $tmp);
		$tmp = str_replace('{name}', htmlspecialchars($name), $tmp);
		$tmp = str_replace('{cate}', htmlspecialchars($cate), $tmp);
		$tmp = str_replace('{img_disp}', htmlspecialchars($img_disp), $tmp);
		$tmp = str_replace('{dept_name}', htmlspecialchars($dept_name), $tmp);
		$tmp = str_replace('{url}', htmlspecialchars($file_path), $tmp);
		$html .= $tmp;
	}
}
//検索準備
function margePost($search) {
	
	foreach ($search as $key => $value) {
		if (!isset($_POST[$key])) continue;
		$search[$key] = $_POST[$key];
		if ($key == "page_title" || $key == "search_keywords") {
			$search[$key] = str_replace('　', ' ', $search[$key]);
			$search[$key] = preg_replace('/(^ | $)/', '', $search[$key]);
		}
	}
	if (!isset($_POST['page_status'])) {
		$search['page_status'] = array();
	}
	if (!isset($_POST['user_lock'])) {
		$search['user_lock'] = array();
	}
	if (!isset($_POST['temp_kind'])) {
		$search['temp_kind'] = array();
	}
	$search['p'] = 1;

	// ページID検索
	if (!empty($search['page_id'])) {
		$search['page_id'] = explode(' ', preg_replace('/\s+/', ' ', $search['page_id']));
	}
	//公開開始日、最終更新日
	if (($search['pdsy'] != '') && ($search['pdsm'] != '') && ($search['pdsd'] != '')) {
		$search['publish_start'] = $search['pdsy'] . '-' . $search['pdsm'] . '-' . $search['pdsd'];
	}
	else
		$search['publish_start'] = "";
	if (($search['pdey'] != '') && ($search['pdem'] != '') && ($search['pded'] != '')) {
		$search['publish_end'] = $search['pdey'] . '-' . $search['pdem'] . '-' . $search['pded'] . ' 23:59:59';
	}
	else
		$search['publish_end'] = "";
	if (($search['kdsy'] != '') && ($search['kdsm'] != '') && ($search['kdsd'] != '')) {
		$search['update_start'] = $search['kdsy'] . '-' . $search['kdsm'] . '-' . $search['kdsd'];
	}
	else
		$search['update_start'] = "";
	if (($search['kdey'] != '') && ($search['kdem'] != '') && ($search['kded'] != '')) {
		$search['update_end'] = $search['kdey'] . '-' . $search['kdem'] . '-' . $search['kded'] . ' 23:59:59';
	}
	else
		$search['update_end'] = "";
		
	// -- 分類
	if (isset($search['cate_code'])) {
		$search['cate_code']['cate1'] = $_POST['cate1'];
		$search['cate_code']['cate2'] = $_POST['cate2'];
		$search['cate_code']['cate3'] = $_POST['cate3'];
		$search['cate_code']['cate4'] = $_POST['cate4'];
	}
	// -- 対象
	if (isset($search['dept_code'])) {
		$search['dept_code']['dept1'] = $_POST['dept1'];
		$search['dept_code']['dept2'] = $_POST['dept2'];
		$search['dept_code']['dept3'] = $_POST['dept3'];
	}
	
	$_SESSION['search'] = $search;
	
	return $search;
}

//検索処理
function search($pSearch) {
	global $objLogin;
	global $objPage;
	$login = $objLogin->login;
	if (!$login) {
		require_once (APPLICATION_ROOT . '/common/dbcontrol/login.inc');
		$objLogin = new login();
		$login = $objLogin->login;
	}
	$table = "tbl_publish_page as p INNER JOIN tbl_user as u ON p.user_id = u.user_id " . "LEFT JOIN tbl_user AS u_lock on p.user_lock=u_lock.user_id " . "LEFT JOIN tbl_category AS c1 on LEFT(c1.cate_code,3)=LEFT(p.cate_code,3) AND c1.level=1 " . "LEFT JOIN tbl_category AS c2 on LEFT(c2.cate_code,6)=LEFT(p.cate_code,6) AND c2.level=2 " . "LEFT JOIN tbl_category AS c3 on LEFT(c3.cate_code,9)=LEFT(p.cate_code,9) AND c3.level=3 " . "LEFT JOIN tbl_category AS c4 on c4.cate_code=p.cate_code AND c4.level=4 " . "LEFT JOIN tbl_template AS t on t.template_id=p.template_id AND t.template_ver=p.template_ver";
	$objPage->setTableName($table);
	$whereAry = array();
	
	//ページタイトル
	if (isset($pSearch['page_title']) && $pSearch['page_title'] != '') {
		$keyAry = explode(" ", $pSearch['page_title']);
		foreach ($keyAry as $k => $v) {
			if ($v == '') continue;
			$whereAry[] = $objPage->_addslashesC("p.page_title", "%" . $v . "%", "LIKE");
		}
	}
	//ファイルパス
	if (isset($pSearch['url']) && $pSearch['url'] != '') {
		$whereAry[] = $objPage->_addslashesC("p.file_path", "%" . $pSearch['url'] . "%", "LIKE");
	}
	//公開開始から
	if (isset($pSearch['publish_start']) && $pSearch['publish_start'] != '') $whereAry[] = $objPage->_addslashesC('p.publish_start', $pSearch['publish_start'], '>=', 'DATE');
	//公開開始まで
	if (isset($pSearch['publish_end']) && $pSearch['publish_end'] != '') $whereAry[] = $objPage->_addslashesC('p.publish_start', $pSearch['publish_end'], '<', 'DATE');
	//最終更新から
	if (isset($pSearch['update_start']) && $pSearch['update_start'] != '') $whereAry[] = $objPage->_addslashesC('p.update_datetime', $pSearch['update_start'], '>=', 'DATE');
	//最終更新まで
	if (isset($pSearch['update_end']) && $pSearch['update_end'] != '') $whereAry[] = $objPage->_addslashesC('p.update_datetime', $pSearch['update_end'], '<', 'DATE');
	
	//対象
	$dept1 = (isset($pSearch['dept_code']['dept1'])) ? $pSearch['dept_code']['dept1'] : '';
	$dept2 = (isset($pSearch['dept_code']['dept2'])) ? $pSearch['dept_code']['dept2'] : '';
	$dept3 = (isset($pSearch['dept_code']['dept3'])) ? $pSearch['dept_code']['dept3'] : '';
	if ($dept3 != '') {
		$whereAry[] = $objPage->_addslashesC('u.dept_code', $dept3, '=', 'INT');
	}
	elseif ($dept2 != '') {
		$digit = 2 * CODE_DIGIT_DEPT;
		$dept2 = "^" . substr($dept2, 0, $digit);
		$whereAry[] = $objPage->_addslashesC('u.dept_code', $dept2, 'REGEXP', 'TEXT');
	}
	elseif ($dept1 != '') {
		$digit = 1 * CODE_DIGIT_DEPT;
		$dept1 = "^" . substr($dept1, 0, $digit);
		$whereAry[] = $objPage->_addslashesC('u.dept_code', $dept1, 'REGEXP', 'TEXT');
	}
	
	// 分類
	if (isset($pSearch['cate_code'])) {
		if (trim($pSearch['cate_code']['cate4']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', $pSearch['cate_code']['cate4'], "LIKE", "TEXT");
		}
		elseif (trim($pSearch['cate_code']['cate3']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', substr($pSearch['cate_code']['cate3'], 0, 9) . '%', "LIKE", "TEXT");
		}
		elseif (trim($pSearch['cate_code']['cate2']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', substr($pSearch['cate_code']['cate2'], 0, 6) . '%', "LIKE", "TEXT");
		}
		elseif (trim($pSearch['cate_code']['cate1']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', substr($pSearch['cate_code']['cate1'], 0, 3) . '%', "LIKE", "TEXT");
		}
	}
	//ロック
	if (isset($pSearch['user_lock']) && count($pSearch['user_lock']) != 0) {
		$whereAry[] = $objPage->_addslashesC('p.user_lock', 'NULL', '<>');
	}
	//テンプ種類
	if (isset($pSearch['temp_kind']) && count($pSearch['temp_kind']) != 0) {
		$whereAry[] = $objPage->_addslashesC("p.template_kind", implode(',', $pSearch['temp_kind']), "IN");
	}
	//テンプID
	if (isset($pSearch['temp_id']) && $pSearch['temp_id'] != '') {
		$whereAry[] = $objPage->_addslashesC('p.template_id', $pSearch['temp_id'], "IN");
	}
	
	//ステータス
	if (isset($pSearch['page_status']) && count($pSearch['page_status']) != 0) {
		if (in_array(STATUS_SAVE, $pSearch['page_status'])) $pSearch['page_status'][] = STATUS_NEW;
		$stwhere = array();
		foreach ($pSearch['page_status'] as $value) {
			if (is_numeric($value)) {
				$stwhere[] = $objPage->_addslashesC("p.status", $value, "=", "INT");
			}
			else if ($value == "public") {
				$stwhere[] = "(" . $objPage->_addslashesC("p.status", STATUS_PUBLISH, "=", "INT") . " AND " . $objPage->_addslashesC("p.close_flg", FLAG_OFF, "=", "INT") . ")";
			}
			else if ($value == "close") {
				$stwhere[] = "(" . $objPage->_addslashesC("p.status", STATUS_PUBLISH, "=", "INT") . " AND " . $objPage->_addslashesC("p.close_flg", FLAG_ON, "=", "INT") . ")";
			}
		}
		$whereAry[] = "(" . implode(' OR ', $stwhere) . ")";
	}
	// -- キーワード検索
	if (isset($pSearch['search_keywords']) && $pSearch['search_keywords'] != "") {
		// タグを対象にするかどうか
		$is_tag_search = (isset($pSearch['is_tag_search']) && $pSearch['is_tag_search'] == FLAG_ON) ? TRUE : FALSE;
		$keyAry = explode(" ", $pSearch['search_keywords']);
		foreach ($keyAry as $k => $v) {
			$whereAry[] = $objPage->_addslashesC('p.page_id', $objPage->mk_sql_kewords(PUBLISH_TABLE, 'DISTINCT page.page_id', $v, $is_tag_search), "IN");
		}
	}
	// ページID検索
	if (!empty($pSearch['page_id'])) {
		$whereAry[] = $objPage->_addslashesC('p.page_id', implode(',', $pSearch['page_id']), 'IN', 'INT');
	}
	$where = implode(' AND ', $whereAry);
	
	//HITしたページ数
	$all = $objPage->getCount($where, $table);
	
	if (isset($pSearch['p'])) {
		$objPage->objP = new page_control();
		$objPage->objP->limit = $pSearch['page_limit'];
		$p = (isset($pSearch['p'])) ? $pSearch['p'] : 1;
		$objPage->objP->set($p, $all);
		$offset = $objPage->objP->getOffset();
		$limit = $objPage->objP->getLimit();
	}
	else {
		$offset = '';
		//$limit = '';
	}
	
	//表示順
	if (isset($pSearch['disp_order']) && $pSearch['disp_order'] != "" && isset($pSearch['sort_pattern']) && $pSearch['sort_pattern'] != "") {
		$orderby = "p." . $pSearch['disp_order'] . " " . $pSearch['sort_pattern'];
	}
	else {
		$orderby = "p.publish_start DESC, p.publish_end DESC";
	}
	
	// 検索条件を保持
	$_SESSION['page_info_export']['table'] = $table;
	$_SESSION['page_info_export']['where_ary'] = $whereAry;
	$_SESSION['page_info_export']['orderby'] = $orderby;
	
	//$orderby = "p.publish_start DESC, p.publish_end DESC";
	$objPage->select($where, 'p.*,u.*,t.name as temp_name,u_lock.name as lock_name,u_lock.dept_name as lock_dept_name,c1.name as cate1,c2.name as cate2,c3.name as cate3,c4.name as cate4', $orderby, $offset, $limit);
	$objPage->fetchrow = 0;
}

//プルダウン作成
function create_list($name, $ary, $select, $width, $nasi = '0') {
	$liststr = '<select id="' . $name . '" name="' . $name . '" style="width:' . $width . 'px;">' . "\n";
	if ($nasi == 0) {
		$liststr .= '<option value="">指定なし</option>' . "\n";
	}
	foreach ($ary as $key => $listary) {
		$selected = ($key == $select) ? ' selected' : '';
		$liststr .= '<option value="' . $key . '"' . $selected . '>' . htmlDisplay($listary) . '</option>' . "\n";
	}
	$liststr .= '</select>' . "\n";
	return $liststr;
}

//ロック解除
function unlock($pid) {
	global $objPage;
	$table = "tbl_publish_page";
	$whereary = array(
			"page_id" => $pid, 
			"user_lock" => 'NULL'
	);
	if ($objPage->update($whereary, $table)) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ページ情報</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./page_info.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/revision/info_manage/page_info/page_info.js"
	type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'info_manage';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-pageinfo">
<div><img
	src="<?=RPW?>/admin/revision/info_manage/page_info/images/title_pageinfo.jpg"
	alt="ページ情報" width="920" height="30"></div>
<div class="cms8341-area-corner">
<form name="cms_fSearch" id="cms_fSearch" class="cms8341-form"
	method="post" action="index.php"><input type="hidden" id="dispMode"
	name="cms_dispMode" value=""> <input type="hidden" name="p" id="p"
	value=""> <input type="hidden" id="temp_id" name="temp_id"
	value="<?=$template_id?>">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(images/bar_topbg.jpg); height: 31px;"><img
			src="./images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="<?=$btn['dis']?>">
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページID</th>
				<td align="left" valign="middle"><input type="text"
					id="page_id" name="page_id"
					value="<?=htmlspecialchars($search_page_id)?>"
					style="width: 250px; ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページタイトル</th>
				<td align="left" valign="middle"><input type="text" id="page_title"
					name="page_title"
					value="<?=htmlspecialchars($search['page_title'])?>"
					style="width: 500px;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">キーワード</th>
				<td align="left" valign="middle"><?=$cms_is_tag_search?><input
					type="text" id="search_keywords" name="search_keywords"
					value="<?=htmlspecialchars($search['search_keywords'])?>"
					style="width: 500px;"><br>
				<small>※大文字と小文字は区別されません。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ファイルパス</th>
				<td align="left" valign="middle" nowrap><input type="text" id="url"
					name="url" value="<?=htmlspecialchars($search['url'])?>"
					style="width: 500px;"><br>
				<small>※<?=HTTP_REAL_ROOT?>/以下のパスを入力してください。部分一致します。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">公開開始日</th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="pdsy" name="pdsy"
					value="<?=htmlspecialchars($search['pdsy'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdsm" name="pdsm"
					value="<?=htmlspecialchars($search['pdsm'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pdsd" name="pdsd"
					value="<?=htmlspecialchars($search['pdsd'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="pdey" name="pdey"
					value="<?=htmlspecialchars($search['pdey'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdem" name="pdem"
					value="<?=htmlspecialchars($search['pdem'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pded" name="pded"
					value="<?=htmlspecialchars($search['pded'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">最終更新日</th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="kdsy" name="kdsy"
					value="<?=htmlspecialchars($search['kdsy'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="kdsm" name="kdsm"
					value="<?=htmlspecialchars($search['kdsm'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="kdsd" name="kdsd"
					value="<?=htmlspecialchars($search['kdsd'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('kd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="kdey" name="kdey"
					value="<?=htmlspecialchars($search['kdey'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="kdem" name="kdem"
					value="<?=htmlspecialchars($search['kdem'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="kded" name="kded"
					value="<?=htmlspecialchars($search['kded'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('kd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">テンプレート種類</th>
				<td align="left" valign="middle"><?=$cms_temp_kind?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">テンプレート</th>
				<td align="left" valign="middle"><a href="javascript:"
					onClick="return cxTemplateSet()"><img
					src="<?=RPW?>/admin/images/btn/btn_add_mini.jpg" alt="追加"
					width="102" height="21" border="0"></a> <span
					id="cms-template-selected" class="cms8341-templatearea"><?=$template_name?></span>
				</td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">分類</th>
				<td align="left" valign="middle"><?=$cms_category?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">対象</th>
				<td align="left" valign="middle"><?=$cms_target?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">状態</th>
				<td align="left" valign="middle"><?=$page_status?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"></th>
				<td align="left" valign="middle"><?=$user_lock?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">表示順</th>
				<td align="left" valign="middle"><?=$disp_order?><?=$sort_pattern?></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle"
			style="background-image: url(./images/bar_bottombg.jpg); height: 32px;"><a
			href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/<?=$btn['img']?>"
			alt="<?=$btn['alt']?>" width="80" height="15" border="0"
			style="margin-right: 10px;" id="cms-searchSwitch"></a></td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="800" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="800" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="800" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
					alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxTemplateClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 760px; height: 385px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="740" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list"><label for="cms_template_id">テンプレートリスト</label>
				<select name="cms_template_id" id="cms_template_id" size="12"
					style="width: 250px;" onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
while ($objTool->fetch()) {
	$src = DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
	if ($template_id != "" && $template_id == $objTool->fld['template_id']) {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '" _kanko_type="' . $objTool->fld['kanko_type'] . '" selected>' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
	else {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '" _kanko_type="' . $objTool->fld['kanko_type'] . '">' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
}
?>
</select></div>
				</td>
				<td width="475" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 475px; height: 365px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?=$def_src?>" name="cms_thumb" id="cms_thumb"
					width="470" height="360" frameborder="0" scrolling="no"
					style="border: solid 1px #666"></iframe></td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxTemplateSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* -->
<?php
if ($objPage->getRowCount() == 0) {
	?>
<?php

	if ($disp_last_condition != "") {
		?>
<div style="margin-bottom: 10px; padding: 1px" align="right"><?=$disp_last_condition?></div>
<?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当するページ情報はありません。</td>
	</tr>
</table>
</form>
<?php
}
else {
	?>
<!-- ページ送り -->
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr valign="top">
		<td colspan="3" align="right">
<?=$disp_last_condition?>
<?=$page_suu?>
</td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink()?></td>
	</tr>
</table>
</form>
<!-- ページ送り ここまで-->
</form>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$html?>
</table>
<!-- ページ送り -->
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink()?></td>
	</tr>
</table>
<!-- ページ送り ここまで-->
<div align="center">
	<p><img src="<?php echo RPW; ?>/admin/images/icon/icon-flow.jpg" alt="" width="36" height="26"></p>
	<p><a href="<?php echo RPW; ?>/admin/revision/info_manage/page_info/export.php"><img alt="エクスポート" src="<?php echo RPW; ?>/admin/images/btn/btn_export.jpg" width="150" height="20" border="0"></a></p>
</div>
<?php
}
?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<form id="pageinfo" class="cms8341-form" name="pageinfo" action=""
	method="post"><input type="hidden" id="cms_page_id" name="cms_page_id"
	value=""> <input type="hidden" id="cms_dispMode" name="cms_dispMode"
	value=""></form>

</body>
</html>
