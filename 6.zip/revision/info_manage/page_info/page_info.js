/*
 *
 */
function cxSearch() {
	if (!($F('pdsy') == "" && $F('pdsm') == "" && $F('pdsd') == "")) {
		dc = cxDateCheckNew("pd", "ymd", 2, "公開開始日");
		if (!disp_date_error(dc, "pdsd"))
			return false;
	}
	if (!($F('pdey') == "" && $F('pdem') == "" && $F('pded') == "")) {
		dc = cxDateCheckNew("pd", "ymd", 3, "公開開始日");
		if (!disp_date_error(dc, "pded"))
			return false;
	}
	if ($F('pdsy') != "" && $F('pdsm') != "" && $F('pdsd') != ""
			&& $F('pdey') != "" && $F('pdem') != "" && $F('pded') != "") {
		dc = cxDateCheckNew("pd", "ymd", 1, "公開開始日");
		if (!disp_date_error(dc, "pdsd"))
			return false;
	}
	if (!($F('kdsy') == "" && $F('kdsm') == "" && $F('kdsd') == "")) {
		dc = cxDateCheckNew("kd", "ymd", 2, "最終更新日");
		if (!disp_date_error(dc, "kdsd"))
			return false;
	}
	if (!($F('kdey') == "" && $F('kdem') == "" && $F('kded') == "")) {
		dc = cxDateCheckNew("kd", "ymd", 3, "最終更新日");
		if (!disp_date_error(dc, "kded"))
			return false;
	}
	if ($F('kdsy') != "" && $F('kdsm') != "" && $F('kdsd') != ""
			&& $F('kdey') != "" && $F('kdem') != "" && $F('kded') != "") {
		dc = cxDateCheckNew("kd", "ymd", 1, "最終更新日");
		if (!disp_date_error(dc, "kdsd"))
			return false;
	}
	$('dispMode').value = "search";
	document.cms_fSearch.submit();
	return false;
}
function cxLastSearch() {
	$('dispMode').value = "last_condition";
	document.cms_fSearch.submit();
	return false;
}
//表示件数
function cxDispNum(max_val) {
	$('dispMode').value = "disp_num";
	document.cms_fSearch.submit();
	return false;
}
function cxCloseError() {
	cxLayer('cms8341-error', 0);
	cxComboVisible();
}
// page sending
function cxPageSet(p) {
	document.cms_fSearch.dispMode.value = "pageset";
	document.cms_fSearch.p.value = p;
	document.cms_fSearch.submit();
	return false;
}
var cate_id;
function cxChangeCate(level, id, code) {
	cate_id = id;
	var prm = 'level=' + level + '&code=' + code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
}
function cxGetCateComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Categories') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for ( var i = level; i <= 4; i++) {
		var cmb = $(cate_id + i);
		while (cmb.length > 1) {
				cmb.options[1] = null;
		}
	}
	var cmb = $(cate_id + level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		cmb.length++;
		cmb.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		cmb.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}
// 組織変更プルダウン処理
function cxChangeDept(lv, val) {
	//reset
	if (val == "") {
		var t = lv + 1;
		for ( var i = t; i <= 3; i++) {
			var obj = $('dept' + i);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level=' + lv + '&code=' + val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for ( var i = level; i <= 3; i++) {
		var obj = $('dept' + i);
		while (obj.length > 1) {
				obj.options[1] = null;
		}
		if (i == level) {
				obj.options[0].text = "指定なし";
		} else {
				obj.options[0].text = "";
		}
	}
	var obj = $('dept' + level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		obj.length++;
		obj.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		obj.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}
//テンプレート
var cmsTemplate = null;
function cxTemplateSet() {
	cmsTemplate = document.cms_fSearch.cms_template_id.options.selectedIndex;
	// close
	cxCalendarClose();
	// hidden
	cxComboHidden(new Array("cms_template_id"));
	cxLayer('cms8341-template-select', 1, 800, 490);
}
//テンプレート
function cxTemplateUnSet(id_name, template_id) {
	if (!$('temp_id')) {
		return false;
	}

	temp_id = $('temp_id').value;
	$('temp_id').value = "";
	temp_id = temp_id.split(",");
	for (i = 0; i < temp_id.length; i++) {
		if (temp_id[i] != template_id) {
			$('temp_id').value = $('temp_id').value
					+ ($('temp_id').value != "" ? "," : "") + temp_id[i];
		}
	}
	Element.remove(id_name); // ドキュメントから要素を削除
}
//テンプレートクローズ
function cxTemplateClose() {
	//close
	cxLayer('cms8341-template-select', 0);
	// visible
	cxComboVisible();
	if (cmsTemplate != null) {
		document.cms_fSearch.cms_template_id.options.selectedIndex = cmsTemplate;
		// re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;
// テンプレートリスト選択
function cxSelectTemplate() {
	var si, src;
	si = $('cms_template_id').options.selectedIndex;
	if (si >= 0) {
		src = $('cms_template_id').options[si].id;
		//
		// テンプレート選択画面のプレビューでレスポンシブをOFF
		$('cms_thumb').src = cms8341admin_path
				+ "/page/common/tplview.php?path=" + encodeURI(src) + '&thum=1';
		if (cms_sid)
			clearInterval(cms_sid);
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom, cms_inv_tim);
	} else {
		$('cms_thumb').src = 'javascript:';
	}
}
//テンプレートイメージ
function cxIFrameZoom() {
	if ($('cms_thumb').contentWindow.document.body) {
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.5)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.5)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_inv_cnt++;
	if (cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}
//送信
function cxTemplateSubmit() {
	var si, label, cate;
	var temp_id = "";
	var temp_innerHTML = '';
	si = $('cms_template_id').options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		temp_id = $('temp_id').value;
		temp_id = temp_id.split(",");
		for (i = 0; i < temp_id.length; i++) {
			if (temp_id[i] == $('cms_template_id').options[si].value) {
				cxLayer('cms8341-template-select', 0);
				cxComboVisible();
				return;
			}
		}
		$('temp_id').value = $('temp_id').value
				+ ($('temp_id').value != "" ? "," : "")
				+ $('cms_template_id').options[si].value;
		temp_id = $('temp_id').value;
		temp_id = temp_id.split(",");
		for (i = 0; i < temp_id.length; i++) {
			for (j = 0; j < $('cms_template_id').options.length; j++) {
				if (temp_id[i] == $('cms_template_id').options[j].value) {
					temp_innerHTML = temp_innerHTML
							+ '<span id="template_id_'
							+ temp_id[i]
							+ '">'
							+ '&nbsp;<a href="javascript:" onClick="return cxTemplateUnSet(template_id_'
							+ temp_id[i]
							+ ',\''
							+ temp_id[i]
							+ '\')">'
							+ '<img src="'
							+ cms8341admin_path
							+ '/images/icon/result_error.gif" alt="削除" width="12" height="12" border="0">'
							+ '</a>' + $('cms_template_id').options[j].text
							+ '</span>';
					break;
				}
			}
		}
		$('cms-template-selected').innerHTML = temp_innerHTML;
	}
	cxLayer('cms8341-template-select', 0);
	// visible
	cxComboVisible();
}

//ロック解除
function cxUnlock(id) {
	if (window
			.confirm("ロック状態になっているページを解除します。\n現在編集中である場合は、解除しないで下さい。\nよろしいですか？")) {
		document.pageinfo.cms_dispMode.value = "unlock";
		document.pageinfo.cms_page_id.value = id;
		document.pageinfo.submit();
		return false;
	}
}

//使う画像の先読み
var imgObj = new Image();
imgObj.src = "./images/btn_details.jpg";
var imgObj = new Image();
imgObj.src = "./images/btn_simplicity.jpg";
// 情報の詳細表示
function cxdisp(id) {
	var obj = document.getElementById(id + '_dispmode');
	if (obj.style.display == 'none') {
		obj.style.display = 'block';
		$(id + '_btn').src = $(id + '_btn').src.replace("btn_details.jpg",
				"btn_simplicity.jpg");
	} else {
		obj.style.display = 'none';
		$(id + '_btn').src = $(id + '_btn').src.replace("btn_simplicity.jpg",
				"btn_details.jpg");
	}
}