<?php
/*
 * ログ管理　トップページ(index.php)
 */
/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
require ("./include/common.inc");
$objDac = new dac($objCnc);
$objP = new page_control();
$SEARCH_LOG_STATUS = getDefineArray("SEARCH_LOG_STATUS");
$SEARCH_LOG_CATEGORY = getDefineArray("SEARCH_LOG_CATEGORY");

/*--- 変数 ---*/
$limit = 10; //１ページ表示件数
$MAXROW_LIST = getDefineArray("MAXROW_LIST");
$disp_last_condition = ""; //前回の検索ボタンHTML


// 検索条件
$search = get_search_init_data();
// ユーザー条件
$disabled = array(
		'target1' => '', 
		'target2' => '', 
		'target3' => '', 
		'user_id' => ''
);
$hidden = "";
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	$infoDept = getDeptCode($objLogin->get('dept_code'));
	switch ($objLogin->get('class')) {
		case USER_CLASS_WRITER :
			$search['user_id'] = $objLogin->get('user_id');
			$disabled['user_id'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_user_id" value="' . htmlspecialchars($search['user_id']) . '">' . "\n";
			$disabled['target3'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target3" value="' . htmlspecialchars($search['target3']) . '">' . "\n";
			$disabled['target2'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target2" value="' . htmlspecialchars($search['target2']) . '">' . "\n";
			$disabled['target1'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target1" value="' . htmlspecialchars($search['target1']) . '">' . "\n";
			break;
		case USER_CLASS_APPROVER1 :
			$disabled['target3'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target3" value="' . htmlspecialchars($search['target3']) . '">' . "\n";
			$disabled['target2'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target2" value="' . htmlspecialchars($search['target2']) . '">' . "\n";
			$disabled['target1'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target1" value="' . htmlspecialchars($search['target1']) . '">' . "\n";
			break;
		case USER_CLASS_APPROVER2 :
			$disabled['target2'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target2" value="' . htmlspecialchars($search['target2']) . '">' . "\n";
			$disabled['target1'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target1" value="' . htmlspecialchars($search['target1']) . '">' . "\n";
			break;
		case USER_CLASS_APPROVER3 :
			$disabled['target1'] = ' disabled';
			$hidden .= '<input type="hidden" name="cms_target1" value="' . htmlspecialchars($search['target1']) . '">' . "\n";
			break;
	}
}
if (isset($_GET['ini']) && $_GET['ini'] == 1) {
	if (isset($_SESSION['search'])) unset($_SESSION['search']);
}
elseif (isset($_SESSION['search'])) {
	$search = $_SESSION['search'];
}
if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'search') {
	$search = get_search_post();
	$_SESSION['last_search_condition']['log_search'] = $search;
	$_SESSION['search'] = $search;
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'pageset') {
	$_SESSION['search'] = $search;
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'change_num') {
	$search['disp_num'] = (isset($_POST['disp_num'])) ? $_POST['disp_num'] : $limit;
	$search['p'] = 1;
	$_SESSION['search'] = $search;
}
elseif (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'last_condition') {
	$search = $_SESSION['last_search_condition']['log_search'];
	$_SESSION['search'] = $search;
	$_POST['cms_dispMode'] = 'search';
}
//前回の検索ボタン表示
if (isset($_SESSION['last_search_condition']['log_search'])) {
	$disp_last_condition = '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span>' . "\n";
}
//表示件数
$limit = $search['disp_num'];

//** ステータスチェックボックス **//
$status_cbox = '';
foreach ($SEARCH_LOG_CATEGORY as $val) {
	if (!isset($val['flg']) || !$val['flg']) continue;
	$status_cbox_array = array();
	foreach ($val['group'] as $status) {
		foreach ($SEARCH_LOG_STATUS[$status] as $user_class => $lavel) {
			$status_cbox_array[$status . '_' . $user_class] = $lavel;
		}
	}
	$status_cbox .= '<p><strong>' . htmlDisplay($val['name']) . '</strong></p>';
	$status_cbox .= mkcheckbox($status_cbox_array, "status", $search['status'], '', '', '', false);
}

//** 組織プルダウン **//
$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;"' . $disabled['target1'] . '>' . "\n";
$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;"' . $disabled['target2'] . '>' . "\n";
$dept_s3 = '<select id="cms_target3" name="cms_target3" onChange="javascript:cxChangeDept(3, this.value)" style="width:150px;"' . $disabled['target3'] . '>' . "\n";
$dept_opn = '<option value="" selected>----------------</option>' . "\n";
$dept_opd = '<option value="">指定なし</option>' . "\n";
$dept_ops = '<option value="" selected>指定なし</option>' . "\n";
$dept_op1 = '';
$dept_op2 = '';
$dept_op3 = '';
$dept_e = '</select>&nbsp;&nbsp;';
$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level = 1" . " ORDER BY dept_code, sort_order, dept_id";
$objDac->execute($sql);
while ($objDac->fetch()) {
	$sel = ($search['target1'] == $objDac->fld['dept_code']) ? ' selected' : '';
	$dept_op1 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>' . "\n";
}
if ($search['target1'] != "") {
	$sql = "SELECT dept_code, name FROM tbl_department" . " WHERE level = 2 AND dept_code LIKE '" . substr($search["target1"], 0, CODE_DIGIT_DEPT) . "%'" . " ORDER BY dept_code, sort_order, dept_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$sel = ($search['target2'] == $objDac->fld['dept_code']) ? ' selected' : '';
		$dept_op2 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>' . "\n";
	}
}
if ($search['target2'] != "") {
	$sql = "SELECT dept_code, name FROM tbl_department" . " WHERE level = 3 AND dept_code LIKE '" . substr($search["target2"], 0, (CODE_DIGIT_DEPT * 2)) . "%'" . " ORDER BY dept_code, sort_order, dept_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$sel = ($search['target3'] == $objDac->fld['dept_code']) ? ' selected' : '';
		$dept_op3 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $sel . '>' . $objDac->fld['name'] . '</option>' . "\n";
	}
}
//
$target1 = $dept_s1 . $dept_ops . $dept_op1 . $dept_e;
$target2 = $dept_s2 . $dept_opn . $dept_op2 . $dept_e;
$target3 = $dept_s3 . $dept_opn . $dept_op3 . $dept_e;
$cms_target = $target1 . $target2 . $target3;

//** ユーザープルダウン **//
$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;"' . $disabled['user_id'] . '>' . "\n";
$user_op = '<option value="" selected>----------------</option>' . "\n";
if ($search['target3'] != "") {
	$sql = "SELECT user_id,name FROM tbl_user WHERE class = " . USER_CLASS_WRITER . " AND dept_code = '" . $search["target3"] . "' ORDER BY user_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$sel = ($search['user_id'] == $objDac->fld['user_id']) ? ' selected' : '';
		$user_op .= '<option value="' . $objDac->fld['user_id'] . '"' . $sel . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
}
$combo_user = $user_s1 . $user_op . $dept_e;
// ページID検索
$search_page_id = (!empty($search['page_id'])) ? implode(' ', $search['page_id']) : '';

//** 抽出条件のセット **//
$where = get_search_sql($search);

//** ページ送り設定 **//
$all = $objDac->getCount($where, 'tbl_logs');
$p = (isset($_POST['cms_p']) && $_POST['cms_p'] > 0) ? $_POST['cms_p'] : 1;
$objP->limit = $limit;
$objP->set($p, $all);
$offset = $objP->getOffset();

//** ログ情報の取得 **//
$objDac->select($where, '*', 'action_datetime DESC, action_status', $offset, $limit, 'tbl_logs');
$objDac->fetchrow = 0;

if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'search') {
	$bind_display = "block";
	$bind_img = "close";
	$bind_alt = "閉じる";
}
else {
	$bind_display = "none";
	$bind_img = "open";
	$bind_alt = "開く";
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>ログ情報</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/revision/info_manage/log/log.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/revision/info_manage/log/log.js"
	type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'info_manage';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-log">
<div><img src="images/bar_log.jpg" alt="ログ情報" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(images/bar_topbg.jpg); height: 31px;"><img
			src="images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<form name="cms_fLogs" id="cms_fLogs" class="cms8341-form" method="post"
	action=""><input type="hidden" name="cms_dispMode" value=""> <input
	type="hidden" name="cms_p" value=""></form>
<form name="cms_fSearch" id="cms_fSearch" class="cms8341-form"
	method="post" action="index.php"><input type="hidden"
	name="cms_dispMode" value="">
<?=$hidden?>
<div  id="cms8341-search" style="display:<?=$bind_display?>">
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="log_range">操作日時</label></th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="cms_pdsy" name="cms_pdsy" value="<?=$search['pdsy']?>"
					style="width: 50px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="cms_pdsm" name="cms_pdsm"
					value="<?=$search['pdsm']?>"
					style="width: 30px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="cms_pdsd" name="cms_pdsd"
					value="<?=$search['pdsd']?>"
					style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('cms_pd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から &nbsp;
				<input type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
					value="<?=$search['pdey']?>"
					style="width: 50px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="cms_pdem" name="cms_pdem"
					value="<?=$search['pdem']?>"
					style="width: 30px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="cms_pded" name="cms_pded"
					value="<?=$search['pded']?>"
					style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('cms_pd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> まで</td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ステータス</th>
				<td align="left" valign="middle"><a href="javascript:"
					onClick="return cxStatusSet()"><img
					src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
					height="20" border="0"></a>
				<div id="cms-status-selected"></div>
				</td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">組織</th>
				<td align="left" valign="middle"><?=$cms_target?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページ作成者</th>
				<td align="left" valign="middle"><?=$combo_user?></td>
			</tr>
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="page_title">ページID</label></th>
				<td align="left" valign="middle"><input type="text"
					id="page_id" name="page_id"
					value="<?=htmlspecialchars($search_page_id)?>" size="35"
					maxlength="255" style=" ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="page_title">ページタイトル</label></th>
				<td align="left" valign="middle"><input type="text"
					name="page_title" id="page_title"
					value="<?=htmlspecialchars($search['page_title'])?>" size="70"
					maxlength="255"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="file_path">ファイルパス</label></th>
				<td align="left" valign="middle"><input type="text" name="file_path"
					id="file_path" value="<?=htmlspecialchars($search['file_path'])?>"
					size="70" maxlength="255"></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;"><a
			href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_<?=$bind_img?>_mini.jpg"
			alt="<?=$bind_alt?>" width="80" height="15" border="0"
			style="margin-right: 10px;" id="cms-searchSwitch"></a></td>
	</tr>
</table>

</div>
<?php
if ($objDac->getRowCount() == 0) {
	?>
<?php

	if ($disp_last_condition != "") {
		?>
<div style="margin-bottom: 10px; padding: 1px" align="right"><?=$disp_last_condition?></div>
<?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当するログ情報はありません。</td>
	</tr>
</table>
<?php
}
else {
	?>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr valign="top">
		<td colspan="3" align="right" class="cms8341-verticalMiddle">
			<?=$disp_last_condition?>
			<?=mkcombobox($MAXROW_LIST, "disp_num", $search['disp_num'], "cxDispNum(this.value)")?>
		</td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objP->getNextLink()?></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th width="190" align="center" valign="middle" scope="col"
			style="font-weight: normal">操作日時</th>
		<th width="190" align="center" valign="middle" scope="col"
			style="font-weight: normal">ステータス</th>
		<th width="250" align="center" valign="middle" scope="col"
			style="font-weight: normal">ページ情報</th>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">ユーザー情報</th>
	</tr>
<?php
	while ($objDac->fetch()) {
		$fld = $objDac->fld;
		print '<tr>' . "\n";
		print '<td align="center" valign="top">' . dtFormat($fld['action_datetime'], 'Y年m月d日 H時i分') . '</td>' . "\n";
		print '<td align="left" valign="top">' . get_status_name($fld) . '</td>' . "\n";
		if ($fld['page_id'] != "") {
			print '<td align="left" valign="top">' . htmlDisplay($fld['page_title']) . '（' . $fld['page_id'] . '）<br>';
			print htmlDisplay($fld['file_path']) . '</td>' . "\n";
		}
		else {
			print '<td align="left" valign="top">&nbsp;</td>';
		}
		print '<td align="left" valign="top">' . htmlDisplay($fld['dept_name']) . '<br>';
		print htmlDisplay($fld['user_name']) . '（' . $fld['user_id'] . '）</td>' . "\n";
		print '</tr>' . "\n";
	}
	?>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objP->getNextLink()?></td>
	</tr>
</table>

<?php
	if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
		?>
<p align="center">現在、一覧に表示されているログ情報のエクスポート、または削除を行います。<br>
※エクスポート、または削除するログ情報は、検索することにより絞込むことができます。</p>
<?php
	}
	else {
		?>
<p align="center">現在、一覧に表示されているログ情報のエクスポートを行います。<br>
※エクスポートするログ情報は、検索することにより絞込むことができます。</p>
<?php
	}
	?>

<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:" onClick="return log_export()"><img
	src="images/btn_export.jpg" alt="ログ情報エクスポート" width="150" height="20"
	border="0" style="margin-right: 20px;"></a>
<?php
	if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
		?>
<a href="javascript:" onClick="return log_delete()"><img
	src="images/btn_delete.jpg" alt="ログ情報削除" width="150" height="20"
	border="0" style="margin-left: 20px;"></a>
<?php
	}
	?>
</p>
<?php
}
?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***ログステータス選択レイヤー　ここから************************************* -->
<div id="cms8341-status-select" class="cms8341-layer">
<table width="800" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="800" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="800" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img src="./images/bar_status.jpg"
					alt="ステータス設定" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCloseStatus()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 760px; height: 385px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="740" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_status_list">
				<p><a href="javascript:" onClick="return cxCheckAll();"><img
					src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
					width="120" height="20" border="0"></a> <a href="javascript:"
					onClick="return cxReleaseAll();"><img
					src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
					width="120" height="20" hspace="20" border="0"></a></p>
				<?=$status_cbox?>
				</div>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxStatusSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
</form>
<!--***ログステータス選択レイヤー　ここまで************************************* -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
</body>
</html>
