<?php
/*
 * ログ情報のエクスポート(export.php)
 */
//--- 設定ファイル読み込み
require ("../.htsetting");
require ("./include/common.inc");

function logError($msg) {
	DispError($msg, 'log', "javascript:history.back()", MENU_KIND_REVISION);
	exit();
}

//アクセスエラー
if (!isset($_POST['cms_dispMode']) || $_POST['cms_dispMode'] != 1) {
	logError('アクセスエラー<br>検索により情報抽出してから実行してください。');
}
//検索条件
if (isset($_SESSION['search']) && is_array($_SESSION['search'])) {
	$search = $_SESSION['search'];
}
else {
	// 初期検索条件
	$search = get_search_init_data();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---CSVファイルの作成---*/
$LOGMAX = 65000;

// 条件式取得
$where = get_search_sql($search);
$sql = "SELECT * FROM tbl_logs";
if ($where != "") $sql .= " WHERE " . $where;
$sql .= " ORDER BY action_datetime DESC, action_status";

$objDac->execute($sql);

$log_cnt = $objDac->getRowCount();
if ($log_cnt <= 0) {
	logError("該当するログ情報はありません。");
}
elseif ($log_cnt > $LOGMAX) {
	logError("該当するログ情報が出力可能件数を超えています。抽出範囲を調整してください。");
}

// ログ情報の作成
// 見出し
$log_header = array(
		'操作日時', 
		'ステータス', 
		'ページID', 
		'ページタイトル', 
		'ファイルパス', 
		'組織名', 
		'ユーザーID', 
		'ユーザー名', 
		'ユーザークラス', 
		'セッションID'
);

// データ部分作成
$exp_log_csv = array();
$csv_line = 0;
while ($objDac->fetch()) {
	// 操作日時
	$exp_log_csv[$csv_line][] = $objDac->fld['action_datetime'];
	// ステータス
	$exp_log_csv[$csv_line][] = get_status_name($objDac->fld);
	// ページID
	$exp_log_csv[$csv_line][] = $objDac->fld['page_id'];
	// ページタイトル
	$exp_log_csv[$csv_line][] = $objDac->fld['page_title'];
	// ファイルパス
	$exp_log_csv[$csv_line][] = $objDac->fld['file_path'];
	// 組織名
	$exp_log_csv[$csv_line][] = $objDac->fld['dept_name'];
	// ユーザーID
	$exp_log_csv[$csv_line][] = $objDac->fld['user_id'];
	// ユーザー名
	$exp_log_csv[$csv_line][] = $objDac->fld['user_name'];
	// ユーザークラス
	$exp_log_csv[$csv_line][] = $objDac->fld['user_class'];
	// セッションID
	$exp_log_csv[$csv_line][] = $objDac->fld['session_id'];
	
	// カウントアップ
	$csv_line++;
}

// 出力処理
create_Csv("log.csv", $exp_log_csv, $log_header, 0, "", "sjis-win", "\"");
?>
