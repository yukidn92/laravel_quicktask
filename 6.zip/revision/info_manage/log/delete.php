<?php
/*
 * ログ情報の削除(delete.php)
 */
//--- 設定ファイル読み込み
require ("../.htsetting");
require ("./include/common.inc");

function logError($msg) {
	DispError($msg, 'log', "javascript:history.back()", MENU_KIND_REVISION);
	exit();
}

//アクセスエラー
if (!isset($_POST['cms_dispMode']) || $_POST['cms_dispMode'] != 1) {
	logError('アクセスエラー<br>検索により情報抽出してから実行してください。');
}
//検索条件
if (isset($_SESSION['search']) && is_array($_SESSION['search'])) {
	$search = $_SESSION['search'];
}
else {
	// 初期検索条件
	$search = get_search_init_data();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---ログ情報の削除---*/

// 条件式取得
$where = get_search_sql($search);
$sql = "DELETE FROM tbl_logs";
if ($where != "") $sql .= " WHERE " . $where;

$objDac->execute($sql);

header("Location: ./index.php");
?>
