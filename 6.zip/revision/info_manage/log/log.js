/*
 *
 */
cxPreImages(cms8341admin_path + '/images/menu/logout01_btn.jpg',
		cms8341admin_path + '/images/menu/logout02_btn.jpg',
		cms8341admin_path + '/images/btn/btn_close_mini.jpg',
		cms8341admin_path + '/images/btn/btn_prev.gif');
checked_ary = {};
Event.observe(window, 'load', cxLogStatusInit);
//
function log_export() {
	document.cms_fLogs.action = "export.php";
	document.cms_fLogs.cms_dispMode.value = 1;
	document.cms_fLogs.submit();
	return false;
}
function log_delete() {
	if (confirm("情報を削除するとデータの復元はできません。\n情報を完全に削除してよろしいですか？")) {
		document.cms_fLogs.action = "delete.php";
		document.cms_fLogs.cms_dispMode.value = 1;
		document.cms_fLogs.submit();
	}
	return false;
}
//通信失敗処理
function cxFailure() {
	//	alert('情報取得中に通信エラーが発生しました');
	$('cms8341-errormsg').innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
	cxCombHidden();
	cxLayer('cms8341-error', 1, 500, 375);
}
//
function cxChangeDept(lv, val) {
	//reset
	if (val == "") {
		var t = lv + 1;
		for ( var i = t; i <= 3; i++) {
			var obj = $('cms_target' + i);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "----------------";
		}
		var obj = $('cms_user_id');
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "----------------";
	} else {
		//get data
		if (lv < 3) {
			lv++;
			var prm = 'level=' + lv + '&code=' + val;
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
		} else {
			var prm = 'code=' + val;
			cxAjaxCommand('cxGetUserCombo', prm, cxGetUserComboOK);
		}
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for ( var i = level; i <= 3; i++) {
        var obj = $('cms_target' + i);
        while (obj.length > 1) {
                obj.options[1] = null;
        }
        if (i == level) {
                obj.options[0].text = "指定なし";
        } else {
                obj.options[0].text = "----------------";
        }
    }
    var obj = $('cms_user_id');
    while (obj.length > 1) {
        obj.options[1] = null;
    }
    obj.options[0].text = "----------------";
    var obj = $('cms_target' + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
function cxGetUserComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'User') {
        cxFailure();
        return;
    }
    var obj = $('cms_user_id');
    while (obj.length > 1) {
        obj.options[1] = null;
    }
    obj.options[0].text = "指定なし";
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
//search
function cxSearch() {
	var msg = new Array();
	var pdsy = $('cms_pdsy');
	var pdsm = $('cms_pdsm');
	var pdsd = $('cms_pdsd');
	var pdey = $('cms_pdey');
	var pdem = $('cms_pdem');
	var pded = $('cms_pded');
	if (pdsy.value || pdsm.value || pdsd.value) {
		if (!pdsy.value || !pdsm.value || !pdsd.value) {
			msg.push('操作日時の指定をする場合は、年月日すべてを指定してください。');
		}
	}
	if (pdey.value || pdem.value || pded.value) {
		if (!pdey.value || !pdem.value || !pded.value) {
			msg.push('操作日時の指定をする場合は、年月日すべてを指定してください。');
		}
	}
	var dateObj = new Object();
	dateObj.sy = pdsy.value;
	dateObj.sm = pdsm.value;
	dateObj.sd = pdsd.value;
	dateObj.ey = pdey.value;
	dateObj.em = pdem.value;
	dateObj.ed = pded.value;
	dc = cxDateCheckNew('cms_pd', 'ymd', 1, '操作日時');
	msg = msg.concat(dc);
	//
	if (msg.length >= 1 && msg[0] != '') {
		var output_msg = '<p>';
		for ( var i = 0; i < msg.length; i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';
		$('cms8341-errormsg').innerHTML = output_msg;
		cxComboHidden();
		cxLayer('cms8341-error', 1, 500, 375);
	} else {
		//main
		document.cms_fSearch.cms_dispMode.value = "search";
		document.cms_fSearch.submit();
		return false;
	}
}
function cxLastSearch() {
	document.cms_fSearch.cms_dispMode.value = "last_condition";
	document.cms_fSearch.submit();
	return false;
}
//
function cxCloseError() {
	cxLayer('cms8341-error', 0);
	cxComboVisible();
}

// page sending
function cxPageSet(p) {
	document.cms_fLogs.action = "index.php";
	document.cms_fLogs.cms_dispMode.value = "pageset";
	document.cms_fLogs.cms_p.value = p;
	document.cms_fLogs.submit();
	return false;
}
function cxDispNum() {
	document.cms_fSearch.cms_dispMode.value = "change_num";
	document.cms_fSearch.submit();
	return false;
}
/**
 * ステータス設定レイヤー表示
 */
function cxStatusSet() {
	cxComboHidden();
	cxLayer('cms8341-status-select', 1, 800, 490);
}
/**
 * ステータス設定レイヤー非表示
 */
function cxCloseStatus() {
	// チェックボックスを元に戻す
	for (id in checked_ary) {
		$(id).checked = checked_ary[id];
	}
	cxLayer('cms8341-status-select', 0);
	cxComboVisible();
}
/**
 * ステータス設定レイヤー決定
 */
function cxStatusSubmit() {
	cxSetStatusValue();
	cxDispStatus();
	cxLayer('cms8341-status-select', 0);
	cxComboVisible();
}
/**
 * ステータス名を表示する
 */
function cxDispStatus() {
	// 挿入領域
	var add_area = $('cms-status-selected');
	// テーブル作成
	var status_table = document.createElement('table');
	// 行数カウント
	var row_cnt = 0;
	// 行のエレメント格納
	var row_ele = status_table.insertRow(row_cnt);
	// 列数カウント
	var cell_cnt = 0;
	// 列のエレメント格納
	var cell_ele = row_ele.insertCell(cell_cnt);
	for (id in checked_ary) {
		if (!checked_ary[id])
			continue;
		// 4列のテーブル
		if (cell_cnt == 3) {
			row_cnt++;
			cell_cnt = 0;
			// 行追加
			row_ele = status_table.insertRow(row_cnt);
		}
		// 列追加
		cell_ele = row_ele.insertCell(cell_cnt);
		cell_ele.innerHTML = '・' + $(id + '_lbl').innerHTML;
		cell_cnt++;
	}

	// 挿入
	add_area.innerHTML = '';
	add_area.appendChild(status_table);
}
/**
 * 連想配列にチェックボックスの値を格納
 */
function cxSetStatusValue() {
	// ステータスチェックボックス
	var status_ele = document.getElementsByName('status[]');
	// 連想配列に格納
	$A(status_ele).each( function(obj) {
		checked_ary[obj.id] = obj.checked;
	});
}
/**
 * 初期表示
 */
function cxLogStatusInit() {
	cxSetStatusValue();
	cxDispStatus();
}
/**
 * 全て選択
 */
function cxCheckAll() {
	var status_ele = document.getElementsByName('status[]');
	$A(status_ele).each( function(obj) {
		obj.checked = true;
	});
}
/**
 * 全て解除
 */
function cxReleaseAll() {
	var status_ele = document.getElementsByName('status[]');
	$A(status_ele).each( function(obj) {
		obj.checked = false;
	});
}
