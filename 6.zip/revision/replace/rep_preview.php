<?php
/*
 *
 */
/** プレビュー **/
require ("../.htsetting");
require ("./include/replaceFunc.inc");
$replaceFunc = new replaceFunc($objCnc);
// 別ウィンドウ用
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

$post = $_POST;
include (DOCUMENT_ROOT . RPW . "/admin/revision/replace/include/set_rep_preview.inc");
include (DOCUMENT_ROOT . RPW . "/admin/revision/replace/include/set_rep_preview_htmlStr.inc");

$htmlStr = setRootPath($htmlStr);

// alt="#" を alt="" に置換
$htmlStr = preg_replace('/<(img|area|input)( [^>]*)? alt="[#＃\s　]*"/i', '<${1}${2} alt=""', $htmlStr);

// プレビューモード 1 : 置換前プレビュー / 2 : 置換後プレビュー
$mode = '1';
if (isset($post['cms_prevMode']) && $post['cms_prevMode'] != "") {
	$mode = $post['cms_prevMode'];
}
// チェックボックスが選択されている箇所を置換後文字列にする
$htmlStr = $replaceFunc->getReplaceStr($post['cms_page_id'], $htmlStr, $mode);
// イベント無効化
$htmlStr = repNonEvent($htmlStr);
print $htmlStr;
?>