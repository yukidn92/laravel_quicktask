<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../.htsetting");
$login = $objLogin->login;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
$objTool2 = new dac_tools($objCnc);

require ("./include/replaceFunc.inc");
$replaceFunc = new replaceFunc($objCnc);

//	// ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	user_error('不正アクセスです。');
}

//===========================================================
//	公開リスト処理
//===========================================================
// 検索条件
$search = array(
		'page_title' => '', 
		'url' => '', 
		'publish_start' => '', 
		'publish_end' => '', 
		'pdsy' => '', 
		'pdsm' => '', 
		'pdsd' => '', 
		'pdey' => '', 
		'pdem' => '', 
		'pded' => '', 
		'target1' => '', 
		'target2' => '', 
		'target3' => '', 
		'cate_code' => array(
				'cms_cate1' => '', 
				'cms_cate2' => '', 
				'cms_cate3' => '', 
				'cms_cate4' => ''
		), 
		'p' => 1, 
		'template_ids' => '', 
		'template_kind' => "", 
		'after_status' => STATUS_PUBLISH_WAIT, 
		'target_word' => '', 
		'replace_word' => '', 
		'target_status' => PUBLISH_TABLE, 
		'regular' => '', 
		'case_sensitive' => ''
);
$disp_mode = "";
$template_name = "";
$template_id = "";

if (isset($_GET['bak']) && $_GET['bak'] == 1 && isset($_SESSION['search']) && is_array($_SESSION['search'])) {
	$search = $_SESSION['search'];
}

// セッション情報初期化
unset($_SESSION['search']);
unset($_SESSION['replace']);
unset($_SESSION['replace_context']);

//対象項目生成
// ページID検索
$search_page_id = (!empty($search['page_id'])) ? implode(' ', $search['page_id']) : '';
$dept_code = array();
$dept_code['cms_target_1'] = (isset($search['target1']) ? $search['target1'] : "");
$dept_code['cms_target_2'] = (isset($search['target2']) ? $search['target2'] : "");
$dept_code['cms_target_3'] = (isset($search['target3']) ? $search['target3'] : "");

$cms_target = create_department_list("cms_target_", $dept_code, "120");

//分類項目生成
$cms_category = create_category_list("cms_cate", $search['cate_code'], '120');

// テンプレート（最新バージョン）情報を取得
if (isset($search['template_id'])) {
	$template_id = $search['template_id'];
}
//全テンプレート取得
$sql = "SELECT t.* FROM tbl_template AS t" . " WHERE t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND " . $objTool2->_addslashesC("t.template_kind", TEMPLATE_KIND_NONE, "<>") . " ORDER BY t.sort_order,t.template_id";
// 作成者の場合は所属に権限があるテンプレート
$objTool2->execute($sql);
$publish_all_temp_list = array();
$template_ary = array();
while ($objTool2->fetch()) {
	//定型は対象外
	if (isset($objTool2->fld['template_kind']) && $objTool2->fld['template_kind'] == TEMPLATE_KIND_FIXED) {
		continue;
	}
	
	$publish_all_temp_list[] = $objTool2->fld;
	
	$template_ary = explode(",", $template_id);
	$template_ary = array_diff($template_ary, array(
			""
	));
	
	if (in_array($objTool2->fld['template_id'], $template_ary)) {
		$template_name = $template_name . '<span id="template_id_' . $objTool2->fld['template_id'] . '">' . '&nbsp;<a href="javascript:" onClick="return cxTemplateUnSet(template_id_' . $objTool2->fld['template_id'] . ',\'' . $objTool2->fld['template_id'] . '\')">' . '<img src="' . RPW . '/admin/images/icon/result_error.gif" alt="削除" width="12" height="12" border="0">' . '</a>' . htmlDisplay($objTool2->fld['name']) . '</span>';
	}
}

//権限があるテンプレート
$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN tbl_handler AS h ON (h.item2 = t.template_id)" . " WHERE h.class = " . HANDLER_CLASS_TEMPLATE . " AND h.item1 = '" . $objLogin->get('dept_code') . "'" . " AND t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND " . $objTool2->_addslashesC("t.template_kind", TEMPLATE_KIND_NONE, "<>") . " AND t.disp_flg = '" . FLAG_ON . "'" . " ORDER BY t.sort_order,t.template_id";
$objTool2->execute($sql);
$publish_temp_list = array();
while ($objTool2->fetch()) {
	//定型は対象外
	if (isset($objTool2->fld['template_kind']) && $objTool2->fld['template_kind'] == TEMPLATE_KIND_FIXED) {
		continue;
	}
	$publish_temp_list[] = $objTool2->fld;
}

//テンプレート種類
$TEMPLATE_KIND = getDefineArray('TEMPLATE_KIND');
//定型は対象外
if (isset($TEMPLATE_KIND[TEMPLATE_KIND_FIXED])) {
	unset($TEMPLATE_KIND[TEMPLATE_KIND_FIXED]);
}
$template_kind = mkcheckbox($TEMPLATE_KIND, 'cms_template_kind', $search['template_kind'], count($TEMPLATE_KIND));

//ステータス
$target_status_ary = array(
		WORK_TABLE => '編集中ページ', 
		PUBLISH_TABLE => '公開中ページ'
);
$target_status = mkradiobutton($target_status_ary, 'cms_target_status', $search['target_status'], count($target_status_ary), '', 'cxStatusChange()');

//置換後ステータス
$after_status_ary = array(
		STATUS_COMP => '更新待ち', 
		STATUS_PUBLISH_WAIT => '公開待ち'
);
$after_status = mkradiobutton($after_status_ary, 'cms_after_status', $search['after_status'], count($after_status_ary));

//正規表現チェック
$regular_ary = array(
		1 => "正規表現を使用する"
);
$regular = mkcheckbox($regular_ary, 'cms_regular', $search['regular'], count($regular_ary));

//大文字・小文字チェック
$case_sensitive_ary = array(
		1 => "大文字と小文字を区別する"
);
$case_sensitive = mkcheckbox($case_sensitive_ary, 'cms_case_sensitive', $search['case_sensitive'], count($case_sensitive_ary));

//置換対象文字列
$target_word = "";
if (isset($_POST['cms_target_word']) && $_POST['cms_target_word'] != "") {
	$target_word = $_POST['cms_target_word'];
}

//置換後文字列
$replace_word = "";
if (isset($_POST['cms_replace_word']) && $_POST['cms_replace_word'] != "") {
	$replace_word = $_POST['cms_replace_word'];
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>編集領域一括置換</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/replace.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

Event.observe(window,'load',function(){
//処理
	if (!$('cms_template_id_name')) return false;
	
	if ($('cms_target2') && $('cms_target2').checked) {
		$('cms_template_id_name').value = "cms_target2";
	} else {
		$('cms_template_id_name').value = "cms_target1";
	}
	
	if ($('cms_target_status')) {
		cxStatusChange();
	}
	
});

//var id_name = "cms_target1";
function cxInitialize() {
	if (!$('cms_template_id_name')) return false;
	
	if ($('cms_target1') && $('cms_target1').checked) {
		if ($('cms_template_id_name').value != "cms_target1") {
			if ($('cms_template_id')) {
				$('cms_template_id').options.selectedIndex = -1;
			}
			if ($('cms_all_template_id')) {
				$('cms_all_template_id').options.selectedIndex = -1;
			}
			if ($('cms_template_ids')) {
				$('cms_template_ids').value = "";
			}
			if ($('cms-template-selected')) {
				$('cms-template-selected').innerHTML = "";
			}
		}
		$('cms_template_id_name').value = "cms_target1";
	} else {
		$('cms_template_id_name').value = "cms_target2";
	}
}

function cxStatusChange() {
	if ($('cms_target_status_1') && $('cms_target_status_1').checked) {
		Element.show('cms_after_status');
		if ($('cms_after_status_401')) {
			$('cms_after_status_401').checked = true;
		}
	} else {
		Element.hide('cms_after_status');
	}
	
	return false;
}


//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'replace';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-replace">
<form name="cms_Replace" id="cms_Replace" class="cms8341-form"
	method="post" action="replace_conf.php" enctype="multipart/form-data">
<input type="hidden" id="cms_filename" name="cms_filename" value=""> <input
	type="hidden" name="cms_template_kanko_type"
	id="cms_template_kanko_type" value=""> <input type="hidden"
	name="cms_template_ids" id="cms_template_ids" value="<?=$template_id?>">
<input type="hidden" name="cms_template_id_name"
	id="cms_template_id_name" value=""> <input type="hidden"
	name="cms_dispMode" id="cms_dispMode" value="">
<div><img
	src="<?=RPW?>/admin/revision/replace/images/bar_edit_area_replace.jpg"
	alt="編集領域一括置換" width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<!-- ページID検索 -->
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">ページID</th>
		<td align="left" valign="middle"><input type="text"
			id="cms_search_page_id" name="cms_search_page_id"
			value="<?=htmlspecialchars($search_page_id)?>"
			style="width: 250px; ime-mode: disabled;">
			<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
	</tr>

	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">ページタイトル</th>
		<td align="left" valign="middle"><input type="text" id="cms_search_page_title"
			name="cms_search_page_title"
			value="<?=htmlspecialchars($search['page_title'])?>"
			style="width: 500px;"></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">ファイルパス</th>
		<td align="left" valign="middle" nowrap><input type="text"
			id="cms_url" name="cms_url"
			value="<?=htmlspecialchars($search['url'])?>"
			style="width: 500px;"><br>
		<small>※<?=HTTP_REAL_ROOT?>/以下のパスを入力してください。部分一致します。</small></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">テンプレート種類</th>
		<td align="left" valign="middle" nowrap><?=$template_kind?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="top" scope="row">テンプレート</th>
		<td align="left" valign="top"><a href="javascript:"
			onClick="return cxTemplateSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_add_mini.jpg" alt="追加" width="102"
			height="21" border="0"></a> <span id="cms-template-selected"
			class="cms8341-templatearea"><?=$template_name?></span></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">公開開始日</th>
		<td align="left" valign="middle"><input type="text" maxlength="4"
			id="cms_pdsy" name="cms_pdsy"
			value="<?=htmlspecialchars($search['pdsy'])?>"
			style="width: 50px; ime-mode: disabled"> 年 <input type="text"
			maxlength="2" id="cms_pdsm" name="cms_pdsm"
			value="<?=htmlspecialchars($search['pdsm'])?>"
			style="width: 30px; ime-mode: disabled"> 月 <input type="text"
			maxlength="2" id="cms_pdsd" name="cms_pdsd"
			value="<?=htmlspecialchars($search['pdsd'])?>"
			style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
			onClick="return cxPublicCalendarOpen('cms_pd','start')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a> から <input
			type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
			value="<?=htmlspecialchars($search['pdey'])?>"
			style="width: 50px; ime-mode: disabled"> 年 <input type="text"
			maxlength="2" id="cms_pdem" name="cms_pdem"
			value="<?=htmlspecialchars($search['pdem'])?>"
			style="width: 30px; ime-mode: disabled"> 月 <input type="text"
			maxlength="2" id="cms_pded" name="cms_pded"
			value="<?=htmlspecialchars($search['pded'])?>"
			style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
			onClick="return cxPublicCalendarOpen('cms_pd','end')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">分類</th>
		<td align="left" valign="middle"><?=$cms_category?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">対象</th>
		<td align="left" valign="middle"><?=$cms_target?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">ステータス<span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=$target_status?></td>
	</tr>
	<tr id="cms_after_status">
		<th width="150" align="left" valign="middle" nowrap scope="row">置換後のステータス<br>
		<span class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><?=$after_status?></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">置換対象文字列<br>
		<span class="cms_require">（必須）</span></th>
		<td align="left" valign="middle"><input type="text"
			id="cms_target_word" name="cms_target_word"
			value="<?=htmlspecialchars($target_word)?>" style="width: 500px;">
		<br><?=$regular?>
		<small>※正規表現を使用する場合は「正規表現を使用する」にチェックを入れてください。</small><br>
		<?=$case_sensitive?>
		<small>※大文字と小文字を区別する場合は「大文字と小文字を区別する」にチェックを入れてください。</small></td>
	</tr>
	<tr>
		<th width="150" align="left" valign="middle" nowrap scope="row">置換後文字列</th>
		<td align="left" valign="middle"><input type="text"
			id="cms_replace_word" name="cms_replace_word"
			value="<?=htmlspecialchars($replace_word)?>" style="width: 500px;"></td>
	</tr>
</table>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center" id="cms_submit"><a href="javascript:"
	onClick="return cxSubmit()" onKeyDown="cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="800" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="800" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="800" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
					alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxTemplateClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 760px; height: 385px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="740" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list">テンプレートリスト <select name="cms_template_id"
					id="cms_template_id" size="12" style="width: 250px;"
					onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
foreach ((array) $publish_temp_list as $template_info) {
	$src = DIR_PATH_TEMPLATE . $template_info['temp_txt'];
	print '<option value="' . $template_info['template_id'] . '" id="' . $src . '" _kind="' . $template_info['template_kind'] . '" _kanko_type="' . $template_info['kanko_type'] . '">' . htmlDisplay($template_info['name']) . '</option>' . "\n";
}
?>
</select> <select name="cms_all_template_id" id="cms_all_template_id"
					size="12" style="width: 250px;" onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
foreach ((array) $publish_all_temp_list as $template_info) {
	$src = DIR_PATH_TEMPLATE . $template_info['temp_txt'];
	print '<option value="' . $template_info['template_id'] . '" id="' . $src . '" _kind="' . $template_info['template_kind'] . '" _kanko_type="' . $template_info['kanko_type'] . '">' . htmlDisplay($template_info['name']) . '</option>' . "\n";
}
?>
</select></div>
				</td>
				<td width="475" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 475px; height: 365px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?=$def_src?>" name="cms_thumb" id="cms_thumb"
					width="470" height="360" frameborder="0" scrolling="no"
					style="border: solid 1px #666"></iframe></td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxTemplateSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* --></form>
</div>
</div>
<!-- cms8341-contents -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<!--***ページプロパティレイヤー ここから********************************-->
<div id="cms8341-property" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/pageproperty/title_pageproperty.jpg"
					alt="ページプロパティ" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxPagePropertyClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 560px; height: 470px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center" id="cms8341-propertybody"><!-- ****** ページプロパティ表示領域 ここから ********* -->
		ここに各ページのページプロパティが代入されます。 <!-- ****** ページプロパティ表示領域 ここまで ********* --></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***ページプロパティレイヤー ここまで********************************-->
</body>
</html>
