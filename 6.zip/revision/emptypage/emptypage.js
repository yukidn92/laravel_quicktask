/*
 *
 */
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg');


//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}

//外部ページの取り込み
function cxSubmit() {
	var msg = new Array();
	if (!$('FrmCsvnm').value) {
		msg.push('取り込みファイルを入力してください。');
	} else {
		var filetype = $('FrmCsvnm').value.replace(/^.*\.([^\.]+$)/, '$1');
		filetype = filetype.toLowerCase();
		if (filetype != 'csv') msg.push('取り込みファイルはcsv形式でアップロードしてください。');
		//
		// 「[a-z]:\～」または「\\～」で始まるパスの指定のみを許容する
		var filepath = $('FrmCsvnm').value.match(/^([a-z]:\\|\\\\).+/i);
		if(!filepath) {
			msg.push('取り込みファイルの参照先を正しく指定してください。');
		}
	}
	if (!$('cms_template_id') || !$('cms_template_id').value) msg.push('テンプレートを選択してください。');
	if (!$('cms_cate1').value) msg.push('分類を選択してください。');
	if (!$('cms_user_id').value) msg.push('ページ作成者を選択してください。');
	// エラー表示
	if (msg.length > 0) {
		cxComboHidden(new Array("cms_template_id"));
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}
	$('cms_filename').value = $('FrmCsvnm').value;
	document.cms_fImport.submit();
	return false;
}

//組織選択
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('cms_target'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "                ";
		}
		var obj = $('cms_user_id');
		while(obj.length>1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "                ";
	} else {
		if (lv < 3) {
			//get data
			lv++;
			var prm = 'level='+lv+'&code='+val;
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
		} else {
			var prm = 'code='+val;
			cxAjaxCommand('cxGetUserCombo', prm, cxGetUserComboOK);
		}
	}
}
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i = level; i <= 3; i++) {
		var obj = $('cms_target' + i);
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "                ";
	}
	var obj = $('cms_user_id');
	while (obj.length > 1) {
		obj.options[1] = null;
	}
	obj.options[0].text = "                ";
	var obj = $('cms_target' + level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i = 0; i < xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		if (nodeL.textContent == " " || nodeL.textContent == "　")
			nodeL.textContent = "指定なし";
		obj.length++;
		obj.options[i + 1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		obj.options[i + 1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}
function cxGetUserComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'User') {
		cxFailure();
		return;
	}
	var obj = $('cms_user_id');
	while (obj.length > 1) {
		obj.options[1] = null;
	}
	obj.options[0].text = "------- 未選択 -------";
		var xmlDocfix = xmlDoc.childElementCount;
		for (var i=0; i<xmlDocfix; i++) {
			nodeL = xmlDoc.firstElementChild;
			obj.length++;
			obj.options[i+1].text = nodeL.textContent;
			var val = nodeL.attributes.getNamedItem('value').value;
			obj.options[i+1].value = val;
			xmlDoc.removeChild(xmlDoc.firstElementChild);
		}
}

//カテゴリ選択
function cxChangeCate(level, code) {
	move_level = level;
	var prm = 'level='+level+'&code='+code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
	if(move_level != 5){
		nextId = 'cms_cate' + move_level;
		$(nextId).focus();
	}
}
function cxGetCateComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Categories') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i=level; i<=4; i++) {
		var cmb = $('cms_cate'+i);
		while (cmb.length > 1) {
			cmb.options[1] = null;
		}
	}
	var cmb = $('cms_cate'+level);
		var xmlDocfix = xmlDoc.childElementCount;
		for (var i = 0; i < xmlDocfix; i++) {
			nodeL = xmlDoc.firstElementChild;
			cmb.length++;
			cmb.options[i + 1].text = nodeL.textContent;
			var val = nodeL.attributes.getNamedItem('value').value;
			cmb.options[i + 1].value = val;
			xmlDoc.removeChild(xmlDoc.firstElementChild);
		}
}
//テンプレート選択処理
var cmsTemplate = null;
function cxTemplateSet() {
	cmsTemplate = document.cms_fImport.cms_template_id.options.selectedIndex;
	//hidden
	cxComboHidden(new Array("cms_template_id"));
	$('cms_thumb').contentWindow.document.body.style.zoom = 0.3;
	$('cms_thumb').contentWindow.document.body.style.position = "relative";
	cxLayer('cms8341-template-select',1,600,340);
}
//
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;
function cxSelectTemplate() {
	var si,src;
	si = document.cms_fImport.cms_template_id.options.selectedIndex;
	if(si >= 0) {
		src = document.cms_fImport.cms_template_id.options[si].id;
		//
		// テンプレート選択画面のプレビューでレスポンシブをOFF
		$('cms_thumb').src = "tplview.php?path=" + encodeURI(src) + '&thum=1';
		if(cms_sid) clearInterval(cms_sid);
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom,cms_inv_tim);
	} else {
		$('cms_thumb').src = 'javascript:';
	}
}
function cxIFrameZoom() {
	if($('cms_thumb').contentWindow.document.body){
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.3)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.3)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_inv_cnt++;
	if(cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}
function cxTemplateSubmit() {
	var si,label,cate;
	si = $('cms_template_id').options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		label = $('cms_template_id').options[si].text;
		if($F('cms_template_kind') != $('cms_template_id').options[si].getAttribute('_kind')){
			cate = 'テンプレート';
			$('cms-template-selected').innerHTML = cate + '：' + label + ' が選択されています。';
			$('cms_template_kind').value = $('cms_template_id').options[si].getAttribute('_kind');
		}
	}
	//
	cxLayer('cms8341-template-select',0);
	//visible
	cxComboVisible();
}
function cxTemplateClose() {
	//close
	cxLayer('cms8341-template-select',0);
	//visible
	cxComboVisible();
	if (cmsTemplate != null) {
		document.cms_fImport.cms_template_id.options.selectedIndex = cmsTemplate;
		//re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}

function cxErrorClose() {
	cxComboVisible();
	cxLayer('cms8341-error',0);
}


function cxInit() {
	if($F('cms_template_kind') != ""){
		cxDispChange();
	}
}
Event.observe(window,'load',cxInit,false);
