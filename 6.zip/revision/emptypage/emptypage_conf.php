<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
unset($_SESSION['csv_data']);

//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

if (isset($_SESSION['post'])) unset($_SESSION['post']);
$_SESSION['post'] = $_POST;
gd_errorhandler_ini_set("html0", RPW . '/admin/emptypage.php');

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", 2, "javascript:history.back()");
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", 2, "javascript:history.back()");
	exit();
}
//---アップロード
$frmCsvFnm = DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/temp/" . $frmCsvFnm;
if (move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", 2, "javascript:history.back()");
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	$wk_str = "指定されたファイル【" . $frmCsvFnm . "】が存在しません。";
	DispError($wk_str, 2, "javascript:history.back()");
	exit();
}

// テンプレートが選択されていなければエラー
if (!isset($_POST['cms_template_id']) || $_POST['cms_template_id'] == '') {
	user_error('テンプレートを選択してください。');
}
// 選択されたテンプレートが存在しなければエラー
$sql = "SELECT * FROM tbl_template WHERE template_id = " . $_POST['cms_template_id'];
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('指定したテンプレートは登録されていません。');
}
$template_fld = $objDac->fld;

// 分類が選択されていなければエラー
if (!isset($_POST['cms_cate1']) || $_POST['cms_cate1'] == '') {
	user_error('分類を選択してください。');
}
$cate_code = $_POST['cms_cate1']; // 第一分類（必須）しか選択されていなければ$_POST['cms_cate1']が分類コードになる
if ($_POST['cms_cate2']) $cate_code = $_POST['cms_cate2']; // 第二分類が選択されていれば$_POST['cms_cate2']が分類コードになる
if ($_POST['cms_cate3']) $cate_code = $_POST['cms_cate3']; // 第三分類が選択されていれば$_POST['cms_cate3']が分類コードになる
if ($_POST['cms_cate4']) $cate_code = $_POST['cms_cate4']; // 第四分類が選択されていれば$_POST['cms_cate4']が分類コードになる
// 選択された分類が存在しなければエラー
$cateInfo = $objCate->getCategoryInfo($cate_code);
if ($cateInfo['name'] == '') {
	user_error('指定した分類は登録されていません。');
}
$_SESSION['post']['cate_code'] = $cate_code;

// ページ作成者の所属が選択されていなければエラー
if (!isset($_POST['cms_target3']) || $_POST['cms_target3'] == '') {
	user_error('ページ作成者の所属を選択してください。');
}
// 選択した所属が存在しなければエラー
$sql = "SELECT * FROM tbl_department" . " WHERE level = 3 AND dept_code = '" . $_POST['cms_target3'] . "'";
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('指定したページ作成者の所属は登録されていません。');
}
$dept_fld = $objDac->fld;

// ページ作成者が選択されていなければエラー
if (!isset($_POST['cms_user_id']) || $_POST['cms_user_id'] == '') {
	user_error('ページ作成者を選択してください。');
}
// 選択した作成者が存在しなければエラー
$sql = "SELECT * FROM tbl_user" . " WHERE user_id = " . $_POST['cms_user_id'] . " AND class = " . USER_CLASS_WRITER;
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('指定したページ作成者は登録されていません。');
}
$user_fld = $objDac->fld;

// 作成者にテンプレートの使用権限がなければエラー
$sql = "SELECT * FROM tbl_handler" . " WHERE class = " . HANDLER_CLASS_TEMPLATE . " AND item1 = '" . $_POST['cms_target3'] . "'" . " AND item2 = '" . $_POST['cms_template_id'] . "'";
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('指定したページ作成者にはテンプレートへの編集権限がありません。');
}

// 空ページの確認
$aryFilenameErr = array();
$aryFiles = array();
_chk_files($frmCsvFnm, $aryFiles);
$_SESSION['csv_data'] = $aryFiles;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部ファイル取り込み</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/revision/emptypage/emptypage.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/revision/emptypage/emptypage_conf.js"
	type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'emptypage';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="./images/bar_title.jpg" alt="空ページ作成" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(./images/bar_topbg.jpg); height: 31px;"><img
			src="<?=RPW?>/admin/images/outerimport/bar_importconf.jpg" alt="取込条件"
			width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="display: block">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">取り込みファイル</th>
		<td><?=htmlDisplay($_POST['cms_filename'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">テンプレート</th>
		<td><?=htmlDisplay($template_fld['name'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">分類</th>
		<td><?=$cateInfo['name']?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">ページ作成者</th>
		<td><?=htmlDisplay($dept_fld['dept_name'] . ' ' . $user_fld['name'])?></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle"
			style="background-image: url(./images/bar_bottombg.jpg); height: 32px;">
		<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる"
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a></td>
	</tr>
</table>
</div>
<form name="cms_fImport" id="cms_fImport" class="cms8341-form"
	method="post" action="emptypage_exec.php">
<p><a href="javascript:" onClick="return cxCheckAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
	width="120" height="20" border="0"></a> <a href="javascript:"
	onClick="return cxReleaseAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
	width="120" height="20" hspace="20" border="0"></a></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="50" align="center" valign="middle"
			style="font-weight: normal" scope="col">選択</th>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">作成ページ</th>
	</tr>
<?php
foreach ($aryFiles as $ary) {
	$icon_img = '&nbsp;';
	if (!$ary['error']) {
		if (!$ary['pagefile'] && $ary['overwrite']) $icon_img = '[上書き]';
		elseif ($ary['mode'] == 'upd') $icon_img = '<img src="' . RPW . '/admin/revision/emptypage/images/icon_edit.jpg" alt="更新" width="70" height="25">';
		elseif ($ary['mode'] == 'ins') $icon_img = '<img src="' . RPW . '/admin/revision/emptypage/images/icon_new.jpg" alt="新規" width="70" height="25">';
	}
	$chkbox_name = ($ary['pagefile']) ? 'cms_file_path' : 'cms_item_path';
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">';
	if ($ary['error']) print '&nbsp;';
	else print '<input type="checkbox" name="' . $chkbox_name . '[]" value="' . $ary['file_path'] . '">';
	print '</td>' . "\n";
	print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
	print '<td align="left" valign="top"><p>' . $ary['parent'] . '<br>' . htmlDisplay($ary['file_path']) . "\n";
	if ($ary['page_title'] != '') print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
	if ($ary['message'] != '') print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>
</table>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"
	onKeyDown="cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_start.jpg" alt="取り込み開始" width="150"
	height="20" border="0" style="margin-right: 10px;"></a> <a
	href="./index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px;"></a></p>
<input type="hidden" name="csv_file" id="csv_file"
	value="<?=$frmCsvFnm?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>
<?php
function _chk_files($frmCsvFnm, &$in_aryFiles) {
	global $objDac;
	global $objPage;
	//ファイルを開く
	if (!($CsvFno = fopen($frmCsvFnm, 'r'))) {
		//エラーページの表示
		DispError("csvファイルのオープンに失敗しました。", 3, "javascript:history.back()");
		exit();
	}
	
	$buf = file_get_contents($frmCsvFnm);
	$CsvFno = tmpfile();
	fwrite($CsvFno, $buf);
	rewind($CsvFno);
	
	//EOFになるまで読み出し
	$fst_line = 0;
	$err_msg = "";
	while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
		$entry = $data[0];
		$parent = $data[2];
		$context = (isset($data[3])) ? $data[3] : "";
		$entryExt = getExtension($entry);
		$parentExt = getExtension($parent);
		// ファイル情報を格納
		$aryF = array(
				'file_path' => $entry, 
				'page_title' => '', 
				'parent' => '', 
				'parent_path' => $parent, 
				'ancestor_path' => '', 
				'context' => $context, 
				'pagefile' => true, 
				'error' => false, 
				'mode' => '', 
				'overwrite' => false, 
				'message' => ''
		);
		// 既存ディレクトリの場合、権限チェック
		/*		if (!_isAbledDir(cms_dirname($entry))) {
			$in_aryFiles[] = _set_error($aryF, 'ディレクトリに権限がないためファイルをアップロードできません。');
			continue;
		}*/
		// 拡張子チェック
		if ($entryExt != "html") {
			$in_aryFiles[] = _set_error($aryF, '作成ページがHTMLではありません。');
			continue;
		}
		// 親ページ拡張子チェック
		if ($parentExt != "html") {
			$in_aryFiles[] = _set_error($aryF, '親ページがHTMLではありません。');
			continue;
		}
		// 既存チェック
		/*		if (file_exists(DOCUMENT_ROOT.RPW.$entry)) {
			$in_aryFiles[] = _set_error($aryF, '既に存在しているパスです。');
			continue;
		}*/
		// ページタイトル
		if ($data[1] == "") {
			$in_aryFiles[] = _set_error($aryF, 'タイトルが記述されていません。');
			continue;
		}
		$aryF['page_title'] = htmlEncode($data[1]);
		if ($data[1] == "施設一覧") {
			$test = "test";
		}
		// 親ページ
		$objPage->selectFromPath($parent);
		if ($objPage->getRowCount() == 0) {
			$ancestor_path = "";
			foreach ($in_aryFiles as $en => $ary) {
				if ($parent == $ary['file_path']) {
					$ancestor_path = $ary['ancestor_path'];
					$file_path = $ary['file_path'];
					$page_title = $ary['page_title'];
				}
			}
			if (!isset($ancestor_path) || $ancestor_path == "") {
				$in_aryFiles[] = _set_error($aryF, '親ページ【' . $parent . '】が存在しません。');
				continue;
			}
		}
		else {
			$ancestor_path = $objPage->fld['ancestor_path'];
			$page_title = $objPage->fld['page_title'];
			$file_path = $objPage->fld['file_path'];
		}
		$aryF['parent'] = getPankuzu($ancestor_path, $page_title, $in_aryFiles);
		
		// 親ページパスよりパンくず階層制限チェックを行う
		if (is_pankuzu_limit_over($parent)) {
			$in_aryFiles[] = _set_error($aryF, '取り込むページの階層がパンくず階層制限を超えるため取り込めません。');
			continue;
		}
		
		// 末端子ページ階層制限チェック
		// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
		$sql = "SELECT page_id FROM tbl_publish_page WHERE file_path = '" . $entry . "'";
		$objDac->execute($sql);
		if ($objDac->fetch()) {
			if (is_pankuzu_limit_over($parent, $objDac->fld['page_id'])) {
				$err_child_msg = "";
				if (isset($_SESSION['pankuzu_check']) && count($_SESSION['pankuzu_check'])) {
					$child_page_id = reset($_SESSION['pankuzu_check']);
					if ($objPage->selectFromID($child_page_id)) {
						$err_child_msg .= '<br>' . '※階層制限を越える子ページ【' . 'ページタイトル：' . htmlDisplay($objPage->fld['page_title']) . '】';
					}
				}
				$in_aryFiles[] = _set_error($aryF, '取り込むページを親ページに含む子ページの階層がパンくず階層制限を超えるため取り込めません。' . $err_child_msg);
				continue;
			}
		}
		
		if ($ancestor_path == "") {
			$aryF['ancestor_path'] = $file_path;
		}
		else {
			$aryF['ancestor_path'] = $ancestor_path . "," . $file_path;
		}
		
		// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
		$sql = "SELECT page_id,work_class,status FROM tbl_publish_page WHERE file_path = '" . $entry . "'";
		$objDac->execute($sql);
		if ($objDac->fetch()) {
			$aryF['mode'] = 'upd';
			// 既存データが公開待ちか公開済みじゃなければ更新できない（更新の場合）
			if ($objDac->fld['status'] < 401) {
				$in_aryFiles[] = _set_error($aryF, '現在このページは更新できません。');
				continue;
			}
		}
		else {
			$aryF['mode'] = 'ins';
		}
		$in_aryFiles[$entry] = $aryF;
	}
}

function _isAbledDir($in_dir) {
	global $_POST;
	global $objDac;
	$sql = "SELECT * FROM tbl_handler" . " WHERE class = " . HANDLER_CLASS_DIRECTORY . " AND item1 = '" . $_POST['cms_target3'] . "'" . " AND item2 = '" . $in_dir . "'";
	$objDac->execute($sql);
	return $objDac->fetch();
}

function _set_error($aryF, $msg) {
	$aryF['error'] = true;
	$aryF['message'] = $msg;
	return $aryF;
}
// get pankuzu
function getPankuzu($pAncestor = '', $pLastTitle = '', $in_aryFiles) {
	global $objPage;
	$pankuzu = '';
	if ($pAncestor != '') {
		foreach (explode(',', $pAncestor) as $ancestor_path) {
			$objPage->selectFromPath($ancestor_path);
			if ($objPage->getRowCount() == 0) {
				foreach ($in_aryFiles as $en => $ary) {
					if (isset($in_aryFiles[$ancestor_path])) {
						$title = $in_aryFiles[$ancestor_path]['page_title'];
					}
				}
			}
			else {
				$title = $objPage->fld['page_title'];
			}
			if ($title == '') continue;
			if ($pankuzu != '') $pankuzu .= PANKUZU_DELIMITER;
			$pankuzu .= htmlDisplay($title);
		}
	}
	if ($pLastTitle != '') {
		if ($pankuzu != '') $pankuzu .= PANKUZU_DELIMITER;
		$pankuzu .= htmlDisplay($pLastTitle);
	}
	return $pankuzu;
}
?>