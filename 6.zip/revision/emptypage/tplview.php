<?php
/*
 *
 */
/** require **/
require ("../.htsetting");
//
function tplError($msg) {
	$err = "<html>\n" . "<head>\n" . "<title>テンプレートプレビューエラー</title>\n" . "</head>\n" . "<body>\n" . "<script>\n" . "alert('" . $msg . "')\n" . "window.close();\n" . "</script>\n" . "</body>\n" . "</html>\n";
	print $err;
	exit();
}
//
$path = (isset($_GET["path"])) ? $_GET["path"] : FALSE;
if (!$path || strlen($path) == 0) {
	$msg = "テンプレートファイルへのパスが取得できませんでした。";
	tplError($msg);
}
else {
	$path = DOCUMENT_ROOT . $path;
	$fp = fopen($path, "r");
	if (!$fp) {
		$msg = "テンプレートファイルが開けませんでした。";
		tplError($msg);
	}
	$tpl = fread($fp, filesize($path));
	print $tpl;
	fclose($fp);
}
?>