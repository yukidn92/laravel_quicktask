<?php
/*
 *
 */
/** 空ページ作成処理 **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// セッションにデータがなければエラー
if (!isset($_SESSION['post']) || !isset($_SESSION['csv_data'])) {
	user_error("It isn't setted posted data in _session.", E_USER_ERROR);
}
$post = $_SESSION['post'];
$csv_data = $_SESSION['csv_data'];

// ファイルが一つも選択されていなければエラー
if ((!isset($_POST['cms_file_path']) || !is_array($_POST['cms_file_path']) || count($_POST['cms_file_path']) == 0) && (!isset($_POST['cms_item_path']) || !is_array($_POST['cms_item_path']) || count($_POST['cms_item_path']) == 0)) {
	user_error('取り込むファイルを選択してください。');
}

// テンプレート情報を取得
if ($objTool->selectTemplate($post['cms_template_id']) === FALSE) {
	user_error('指定したテンプレートは登録されていません。');
}
// テンプレートのバージョン（最新バージョン）：$template_ver
$template_ver = $objTool->fld['template_ver'];
// テンプレートファイルのパス：$template_path
$template_path = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
// テンプレートファイルが存在しなければエラー
if (!file_exists($template_path)) {
	user_error('テンプレートファイルが見つかりません。【' . $template_path . '】');
}
$template_kind = $objTool->fld['template_kind'];

// トランザクション
$objCnc->begin();

// 取り込み処理
$aryUpFiles = array();
$aryMkFiles = array();

if (isset($_POST['cms_file_path']) && is_array($_POST['cms_file_path'])) {
	foreach ($_POST['cms_file_path'] as $filename) {
		// ファイル情報を格納
		$aryF = array(
				'file_path' => $filename, 
				'page_title' => '', 
				'parent' => '', 
				'pagefile' => true, 
				'error' => false, 
				'mode' => 'ins', 
				'overwrite' => false, 
				'message' => ''
		);
		// 既存チェック
		if (file_exists(DOCUMENT_ROOT . RPW . $filename)) $aryF['overwrite'] = true;
		
		// 登録データのセット：$ary
		$ary = _set_data($post, $filename, $template_ver, $template_kind, $htmlStr, $csv_data);
		if (!is_array($ary) || count($ary) == 0) {
			$aryUpFiles[$filename] = _set_error($aryF, 'ページ情報の格納ができませんでした。');
			continue;
		}
		$aryF['page_title'] = $ary['page_title'];
		
		// 親ページ
		$objPage->selectFromPath($csv_data[$filename]['parent_path']);
		if ($objPage->getRowCount() == 0) {
			foreach ($csv_data as $en => $ancestor_ary) {
				if ($csv_data[$filename]['parent_path'] == $ancestor_ary['file_path']) {
					$ancestor_path = $ancestor_ary['ancestor_path'];
					$page_title = $ancestor_ary['page_title'];
					$file_path = $ancestor_ary['file_path'];
				}
			}
			if (!isset($ancestor_path)) {
				$aryUpFiles[$filename] = _set_error($aryF, '親ページ【' . $csv_data[$filename]['parent_path'] . '】が存在しません。');
				continue;
			}
		}
		else {
			$ancestor_path = $objPage->fld['ancestor_path'];
			$page_title = $objPage->fld['page_title'];
			$file_path = $objPage->fld['file_path'];
		}
		$aryF['parent'] = getPankuzu($ancestor_path, $page_title, $csv_data);
		
		// 親ページパスよりパンくず階層制限チェックを行う
		if (is_pankuzu_limit_over($csv_data[$filename]['parent_path'])) {
			$aryUpFiles[$filename] = _set_error($aryF, '取り込むページの階層がパンくず階層制限を超えるため取り込めません。');
			continue;
		}
		
		// 末端子ページ階層制限チェック
		// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
		$objPage->selectFromPath($filename);
		if ($objPage->getRowCount() > 0) {
			if (is_pankuzu_limit_over($csv_data[$filename]['parent_path'], $objPage->fld['page_id'])) {
				$err_child_msg = "";
				if (isset($_SESSION['pankuzu_check']) && count($_SESSION['pankuzu_check'])) {
					$child_page_id = reset($_SESSION['pankuzu_check']);
					if ($objPage->selectFromID($child_page_id)) {
						$err_child_msg .= '<br>' . '※階層制限を越える子ページ【' . 'ページタイトル：' . htmlDisplay($objPage->fld['page_title']) . '】';
					}
				}
				$aryUpFiles[$filename] = _set_error($aryF, '取り込むページを親ページに含む子ページの階層がパンくず階層制限を超えるため取り込めません。' . $err_child_msg);
				continue;
			}
		}
		
		if ($ancestor_path == "") {
			$ary['ancestor_path'] = $file_path;
		}
		else {
			$ary['ancestor_path'] = $ancestor_path . "," . $file_path;
		}
		
		// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
		$objPage->selectFromPath($filename);
		// 更新
		if ($objPage->getRowCount() > 0) {
			$aryF['mode'] = 'upd';
			$ary['page_id'] = $objPage->fld['page_id'];
			$ary['pub_status'] = $objPage->fld['status'];
			$ary['work_class'] = $objPage->fld['work_class'];
			// 新規
		}
		else {
			// ページIDの取得
			$ary['page_id'] = $objPage->getSeqNextval();
			// 新規作成ページをセット
		}
		$ary['class'] = $objLogin->get('class');
		$aryMkFiles[$ary['page_id']] = $filename;
		// ページ情報の登録
		if (_insert_data($aryF['mode'], $ary, $objPage, $errmsg) == FALSE) {
			_error($errmsg, $aryMkFiles);
		}
		$aryUpFiles[$filename] = $aryF;
	}
}

// 権限を与えるディレクトリ
$aryNewDir = array();

$errFlg = false;

// HTMLファイルの生成
foreach ($aryMkFiles as $PID => $filename) {
	$file_path = DOCUMENT_ROOT . RPW . $filename;
	$aryNewDir[] = cms_dirname($filename) . '/';
	mkNewPage($PID, $filename);
}

// 新しいディレクトリに権限を与える
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
foreach (array_unique($aryNewDir) as $dir_path) {
	if ($dir_path == '' || $dir_path == '/' || $dir_path == './') continue;
	//ディレクトリがない場合は、各ディレクトリにも権限を設定する
	if (!@file_exists($dir_path)) {
		// ディレクトリの作成、移動
		if (preg_match_all('/([^\/]+)/', $dir_path, $d)) {
			$d = $d[1];
			$dir_path_temp = '';
			foreach ($d as $directory) {
				$dir_path_temp .= "/" . $directory;
				if (@file_exists($dir_path_temp)) continue;
				$ary = array(
						'class' => HANDLER_CLASS_DIRECTORY, 
						'item1' => $post['cms_target3'], 
						'item2' => $dir_path_temp . "/"
				);
				if (!$objHandler->isExists($ary)) $objHandler->insert($ary);
			}
		}
	}
}

// 作成したページに親IDを設定
foreach ($aryUpFiles as $ary) {
	$objPage->selectFromPath($ary['file_path']);
	$page_id = $objPage->fld['page_id'];
	$ancestor_path = $objPage->fld['ancestor_path'];
	if (strrpos($ancestor_path, ",") === FALSE) {
		$parent_path = $ancestor_path;
	}
	else {
		$parent_path = substr($ancestor_path, strrpos($ancestor_path, ",") + 1);
	}
	$objPage->selectFromPath($parent_path);
	$parent_id = $objPage->fld['page_id'];
	
	$ary = array();
	$ary['page_id'] = $page_id;
	$ary['parent_id'] = $parent_id;
	$ary['menu_generation_order'] = $objPage->getNextMenuGenerationOrder($parent_id);
	$objPage->update($ary, PUBLISH_TABLE);
	$objPage->update($ary, WORK_TABLE);
}

if ($errFlg) {
	// ロールバック
	$objCnc->rollback();
}
else {
	// コミット
	$objCnc->commit();
}

// 取り込みファイルの削除
@unlink($_POST['csv_file']);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部ファイル取り込み</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/revision/emptypage/emptypage.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'emptypage';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="./images/bar_title.jpg" alt="空ページ作成" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="20%" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th width="80%" align="center" valign="middle"
			style="font-weight: normal" scope="col">親ページ</th>
	</tr>
<?php
foreach ($aryUpFiles as $ary) {
	$icon_img = '&nbsp;';
	if (!$ary['error']) {
		if (!$ary['pagefile'] && $ary['overwrite']) $icon_img = '[上書き]';
		elseif ($ary['mode'] == 'upd') $icon_img = '<img src="' . RPW . '/admin/revision/emptypage/images/icon_edit.jpg" alt="更新" width="70" height="25">';
		elseif ($ary['mode'] == 'ins') $icon_img = '<img src="' . RPW . '/admin/revision/emptypage/images/icon_new.jpg" alt="新規" width="70" height="25">';
	}
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
	print '<td align="left" valign="top" nowrap><p>' . $ary['parent'] . '<br>' . htmlDisplay($ary['file_path']) . "\n";
	if ($ary['page_title'] != '') print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
	if ($ary['message'] != '') print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>
</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
<?php
/***********************************/

// エラー
function _error($errmsg, $in_mkFiles) {
	global $objCnc;
	//HTMLファイルを削除
	foreach ($in_mkFiles as $filename) {
		$html_path = DOCUMENT_ROOT . RPW . $filename;
		if (file_exists($html_path)) unlink($html_path);
	}
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	user_error($errmsg);
	exit();
}

function _set_error($aryF, $msg) {
	$aryF['error'] = true;
	$aryF['message'] = $msg;
	return $aryF;
}

function _set_data($post, $file_path, $template_ver, $template_kind, &$htmlStr, $csv_data) {
	$dn = cms_dirname($file_path);
	$dn = ($dn == '.') ? '' : $dn . '/';
	$dir_path = $dn;
	$dir_path = str_replace("//", "/", $dir_path);
	$filename = basename($file_path);
	$ary = array();
	$r = "";
	
	$page_title = htmlEncode($csv_data[$file_path]['page_title']);
	// FCKeditor領域：$context
	if (trim($csv_data[$file_path]['context']) == "") {
		$context = "<h1>" . htmlEncode($page_title) . "</h1><p>&nbsp;</p>";
	}
	else {
		$context = $csv_data[$file_path]['context'];
	}
	
	// キーワード：$keywords
	$keywords = (preg_match('/<meta name="keywords" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? $r[1][0] : '';
	// 説明文：$description
	$description = (preg_match('/<meta name="description" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? $r[1][0] : '';
	// 見出し：$page_header
	$page_header = getMidString($htmlStr, '<!-- InstanceBeginEditable name="header" -->', '<!-- InstanceEndEditable -->');
	
	// ページ情報をセット
	$ary['cate_code'] = $post['cate_code']; // カテゴリ
	$ary['template_id'] = $post['cms_template_id']; // テンプレートID
	$ary['template_ver'] = $template_ver; // テンプレートバージョン
	$ary['user_id'] = $post['cms_user_id']; // 作成者ID
	$ary['dir_path'] = $dir_path; // ディレクトリパス
	$ary['filename'] = $filename; // ファイル名
	$ary['file_path'] = $dir_path . $filename; // ファイルパス
	$ary['page_title'] = $page_title; // ページタイトル
	$ary['header'] = $page_header; // 見出し
	$ary['context'] = $context; // FCKeditor領域
	$ary['keywords'] = $keywords; // （検索エンジン用）キーワード
	$ary['description'] = $description; // （検索エンジン用）説明文
	$ary['publish_start'] = date("Ymd"); // 公開開始日
	$ary['publish_end'] = date('Ymd', strtotime("+" . PUBLISH_END_MONTH . " month")); // 公開終了日
	$ary['status'] = 401; // ステータス
	$ary['update_datetime'] = 'NOW'; // 更新日時
	$ary['template_kind'] = $template_kind; // テンプレート種類
	

	return $ary;
}

function _insert_data($mode, $ary1, $objPage, &$errmsg) {
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
	$objTool = new dac_tools($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
	$objLibrary = new tbl_library($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
	$objHandler = new tbl_handler($objCnc);
	
	$errmsg = '';
	if (isset($ary1['pub_status'])) {
		$pub_status = $ary1['pub_status'];
		unset($ary1['pub_status']);
	}
	if ($mode != 'ins') {
		$objPage->deleteFromPageID($ary1['page_id'], PUBLISH_TABLE);
		$objPage->deleteFromPageID($ary1['page_id'], WORK_TABLE);
	}
	// 公開ページ情報の登録（INSERT INTO tbl_publish_page）
	if ($objPage->insert($ary1, 1) === FALSE) {
		$errmsg = '公開ページ情報の登録に失敗しました。';
		return FALSE;
	}
	// 編集ページ情報の登録（INSERT INTO tbl_work_page SELECT FROM tbl_publish_page）
	if ($objPage->insertWorkFromPublish($ary1['page_id'], $ary1) === FALSE) {
		$errmsg = '編集ページ情報の登録に失敗しました。';
		return FALSE;
	}
	
	// デフォルトライブラリを設定
	$libHtmlStr = $objTool->getTemplateContext($ary1['template_id'], $ary1['template_ver']);
	$libAry = array();
	// ライブラリ領域を検索
	while (getLibraryArea($libAry, $libHtmlStr, 0)) {
		// ライブラリ情報を登録
		if (isset($libAry["id"]) && $libAry["id"] != "" && $objLibrary->selectFromID($libAry["id"]) !== FALSE) {
			// 登録情報の作成
			$db_ary['page_id'] = $ary1['page_id'];
			$db_ary['area'] = $libAry["area"];
			$db_ary['library_id'] = $libAry["id"];
			$db_ary['library_ver'] = $objLibrary->fld['library_ver'];
			// DBに登録
			if ($objHandler->insertLibrary($db_ary, WORK_TABLE) === FALSE) {
				user_error('ライブラリ設定の登録に失敗しました。', E_USER_ERROR);
			}
		}
		// 登録したエリア情報を対象から除外
		$libHtmlStr = str_replace($libAry["match"], "", $libHtmlStr);
	}
	
	$total_str = create_page_check_context($ary1['page_id']);
	// ページで使用する自動リンク情報を登録
	entryAutolinkPage($total_str, $ary1['page_id']);
	
	// 公開ページ情報取得
	if (!$objPage->selectFromID($ary1['page_id'])) {
		$errmsg = '公開ページ情報の取得に失敗しました。';
		return FALSE;
	}
	// ディレクトリパス取得
	$current_dir = (isset($objPage->fld['file_path']) ? cms_dirname($objPage->fld['file_path']) : '');
	if ($current_dir == '') $current_dir = '/';
	if (substr($current_dir, -1) != '/') $current_dir .= '/';
	
	// 編集ページ情報取得
	if (!$objPage->selectFromID($ary1['page_id'], WORK_TABLE)) {
		$errmsg = '編集ページ情報の取得に失敗しました。';
		return FALSE;
	}
	// 編集領域の整形
	$context = '';
	if (isset($objPage->fld['context'])) {
		// HTTPルートを削除する
		$context = delHttpRoot($objPage->fld['context']);
		// パスから作業用ルートを削除
		$context = delRootPath($context);
		// 絶対パスにする
		$mobile_flg = FALSE;
		$context = setAbsolutePath($context, $current_dir, '', $mobile_flg);
		$context = deleteAutolinkDiv($context);
		//ローカルナビの表示用DIVを削除
		$context = delete_lnavi_div($context);
		// 画像 src から 引数を削除
		$context = replace_src($context);
	}
	// リンク情報、画像情報取得用コンテキスト：自動生成領域は除外する
	$chkContext = repMidStr(AUTOLINK_BEGIN, AUTOLINK_END, '', $context);
	
	// リンク情報の登録
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
	$objLinks = new tbl_links($objCnc);
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
	$objImages = new tbl_images($objCnc);
	$p = 0;
	$no2 = 0;
	$nontpl_no = 0;
	// リンク情報の削除（DELETE FROM tbl_work_links）
	if ($objLinks->deleteFromPageID($ary1['page_id'], WORK_TABLE) === FALSE) {
		user_error('リンク情報の削除に失敗しました。', E_USER_ERROR);
	}
	while (1) {
		$r = dac_insertLink($chkContext, $objLinks, $ary1['page_id'], $no2, $p);
		if ($r == -9) break;
		if ($r == -8) user_error('リンク情報の登録に失敗しました。', E_USER_ERROR);
	}
	
	// 画像情報の登録
	$p = 0;
	$no2 = 0;
	// 画像情報の削除（DELETE FROM tbl_work_images）
	if ($objImages->deleteFromPageID($ary1['page_id'], WORK_TABLE) === FALSE) {
		user_error('画像情報の削除に失敗しました。', E_USER_ERROR);
	}
	while (1) {
		$r = dac_insertImage($chkContext, $objImages, $ary1['page_id'], $no2, $p);
		if ($r == -9) break;
		if ($r == -8) user_error('画像情報の登録に失敗しました。', E_USER_ERROR);
	}
	
	return TRUE;
}
// get pankuzu
function getPankuzu($pAncestor = '', $pLastTitle = '', $in_aryFiles) {
	global $objPage;
	$pankuzu = '';
	if ($pAncestor != '') {
		foreach (explode(',', $pAncestor) as $ancestor_path) {
			$objPage->selectFromPath($ancestor_path);
			if ($objPage->getRowCount() == 0) {
				foreach ($in_aryFiles as $en => $ary) {
					if (isset($in_aryFiles[$ancestor_path])) {
						$title = $in_aryFiles[$ancestor_path]['page_title'];
					}
				}
			}
			else {
				$title = $objPage->fld['page_title'];
			}
			if ($title == '') continue;
			if ($pankuzu != '') $pankuzu .= PANKUZU_DELIMITER;
			$pankuzu .= htmlDisplay($title);
		}
	}
	if ($pLastTitle != '') {
		if ($pankuzu != '') $pankuzu .= PANKUZU_DELIMITER;
		$pankuzu .= htmlDisplay($pLastTitle);
	}
	return $pankuzu;
}

?>