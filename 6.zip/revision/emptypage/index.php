<?php
/*
 *
 */
/** 空ページ作成 **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// 初期表示値
$def = array();
$def['cms_template_id'] = '';
$def['cms_target1'] = '';
$def['cms_target2'] = '';
$def['cms_target3'] = '';
$def['cms_user_id'] = '';
$def['cms_template_kind'] = '';
$def['cms_filename'] = '';
$def['template_src'] = '';
$def['template_name'] = '';
$def['cms_cate1'] = '';
$def['cms_cate2'] = '';
$def['cms_cate3'] = '';
$def['cms_cate4'] = '';
$def_src = "";

// カテゴリプルダウン生成
$combo_cate = '';
$cate_s1 = '<select id="cms_cate1" name="cms_cate1" onChange="javascript:cxChangeCate(2, this.value)" style="width:150px;">' . "\n";
$cate_s2 = '<select id="cms_cate2" name="cms_cate2" onChange="javascript:cxChangeCate(3, this.value)" style="width:150px;">' . "\n";
$cate_s3 = '<select id="cms_cate3" name="cms_cate3" onChange="javascript:cxChangeCate(4, this.value)" style="width:150px;">' . "\n";
$cate_s4 = '<select id="cms_cate4" name="cms_cate4" onChange="javascript:cxChangeCate(5, this.value)" style="width:150px;">' . "\n";
$cate_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
$cate_e = '</select>&nbsp;&nbsp;';
$cate_op1 = $cate_opn;
$cate_op2 = $cate_opn;
$cate_op3 = $cate_opn;
$cate_op4 = $cate_opn;
// 第一カテゴリプルダウンの生成
$sql = "SELECT level,cate_code,name FROM tbl_category WHERE level = 1 ORDER BY disaster_flg " . (isDisasterFlg() ? 'DESC' : 'ASC') .  ", sort_order, cate_code";
$objDac->execute($sql);
while ($objDac->fetch()) {
	$selected = ($objDac->fld['cate_code'] == $def['cms_cate1']) ? ' selected' : '';
	$cate_op1 .= '<option value="' . $objDac->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
}
// 第二カテゴリプルダウンの生成（第一カテゴリが指定されている場合）
if ($def['cms_cate1'] != '') {
	$objCate->selectChildren($def['cms_cate1'], 1);
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $def['cms_cate2']) ? ' selected' : '';
		$cate_op2 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
// 第三カテゴリプルダウンの生成（第二カテゴリが指定されている場合）
if ($def['cms_cate2'] != '') {
	$objCate->selectChildren($def['cms_cate2'], 1);
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $def['cms_cate3']) ? ' selected' : '';
		$cate_op3 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
// 第四カテゴリプルダウンの生成（第三カテゴリが指定されている場合）
if ($def['cms_cate3'] != '') {
	$objCate->selectChildren($def['cms_cate3'], 1);
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $def['cms_cate4']) ? ' selected' : '';
		$cate_op4 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
$cate1 = $cate_s1 . $cate_op1 . $cate_e;
$cate2 = $cate_s2 . $cate_op2 . $cate_e;
$cate3 = $cate_s3 . $cate_op3 . $cate_e;
$cate4 = $cate_s4 . $cate_op4 . $cate_e;
$combo_cate = $cate1 . $cate2 . $cate3 . $cate4;

//組織プルダウン生成
$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;">' . "\n";
$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;">' . "\n";
$dept_s3 = '<select id="cms_target3" name="cms_target3" onChange="javascript:cxChangeDept(3, this.value)" style="width:150px;">' . "\n";
$dept_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
$dept_e = '</select>&nbsp;&nbsp;';
$dept_op1 = $dept_opn;
$dept_op2 = $dept_opn;
$dept_op3 = $dept_opn;
if ($objLogin->get('isOuter') == FALSE) {
	// 第一組織プルダウンの生成
	$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=1 ORDER BY sort_order, dept_code";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$selected = ($objDac->fld['dept_code'] == $def['cms_target1']) ? ' selected' : '';
		$dept_op1 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
	// 第二組織プルダウンの生成（第一組織が指定されている場合）
	if ($def['cms_target1'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=2 AND dept_code REGEXP '^" . substr($def["cms_target1"], 0, CODE_DIGIT_DEPT) . "' ORDER BY sort_order, dept_code";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['dept_code'] == $def['cms_target2']) ? ' selected' : '';
			$dept_op2 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
		}
	}
	// 第三組織プルダウンの生成（第二組織が指定されている場合）
	if ($def['cms_target2'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=3 AND dept_code REGEXP '^" . substr($def["cms_target2"], 0, (CODE_DIGIT_DEPT * 2)) . "' ORDER BY sort_order, dept_code";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['dept_code'] == $def['cms_target3']) ? ' selected' : '';
			$name = ($objDac->fld['name'] == " " || $objDac->fld['name'] == "　") ? "指定なし" : $objDac->fld['name'];
			$dept_op3 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($name) . '</option>' . "\n";
		}
	}
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
	// ユーザプルダウンの生成（第三組織が指定されている場合）
	if ($def['cms_target3'] != '') {
		$sql = "SELECT user_id,name FROM tbl_user WHERE class = " . USER_CLASS_WRITER . " AND dept_code = '" . $def["cms_target3"] . "' ORDER BY user_id";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['user_id'] == $def['cms_user_id']) ? ' selected' : '';
			$user_op .= '<option value="' . $objDac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
		}
	}
}
else {
	// 外部ファイル取り込みを許可されている組織の場合は、組織プルダウンは自分の組織しか表示しない
	$deptAry = getDeptCode($objLogin->get('dept_code'));
	// 第一組織プルダウンの生成
	$objDept->selectFromCode($deptAry['dept1_code']);
	$dept_op1 = '<option value="' . $objDept->fld['dept_code'] . '" selected>' . htmlDisplay($objDept->fld['name']) . '</option>' . "\n";
	// 第二組織プルダウンの生成
	$objDept->selectFromCode($deptAry['dept2_code']);
	$dept_op2 = '<option value="' . $objDept->fld['dept_code'] . '" selected>' . htmlDisplay($objDept->fld['name']) . '</option>' . "\n";
	// 第三組織プルダウンの生成
	$objDept->selectFromCode($deptAry['dept3_code']);
	$dept_op3 = '<option value="' . $objDept->fld['dept_code'] . '" selected>' . htmlDisplay($objDept->fld['name']) . '</option>' . "\n";
	
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '';
	// ユーザプルダウンの生成
	$sql = "SELECT user_id,name FROM tbl_user WHERE class = " . USER_CLASS_WRITER . " AND dept_code = '" . $objLogin->get('dept_code') . "' ORDER BY user_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$selected = ($objDac->fld['user_id'] == $objLogin->get('user_id')) ? ' selected' : '';
		$user_op .= '<option value="' . $objDac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
}
$combo_user = $user_s1 . $user_op . $dept_e;

// テンプレート（最新バージョン）情報を取得
// ウェブマスターの場合は全テンプレート
if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
	$sql = "SELECT t.* FROM tbl_template AS t" . " WHERE t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND t.template_kind = '" . TEMPLATE_KIND_FREE . "'" . " ORDER BY t.sort_order,t.template_id";
	// 作成者の場合は所属に権限があるテンプレート
}
else {
	$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN tbl_handler AS h ON (h.item2 = t.template_id)" . " WHERE h.class = " . HANDLER_CLASS_TEMPLATE . " AND h.item1 = '" . $objLogin->get('dept_code') . "'" . " AND t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND t.template_kind = '" . TEMPLATE_KIND_FREE . "'" . " ORDER BY t.sort_order,t.template_id";
}
$objTool->execute($sql);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>空ページ作成</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/revision/emptypage/emptypage.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/revision/emptypage/emptypage.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'emptypage';
include (APPLICATION_ROOT . "/common/inc/revision_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="./images/bar_title.jpg" alt="空ページ作成" width="920"
	height="30"></div>
<form name="cms_fImport" id="cms_fImport" class="cms8341-form"
	method="post" action="emptypage_conf.php" enctype="multipart/form-data">
<input type="hidden" id="cms_filename" name="cms_filename" value=""> <input
	type="hidden" name="cms_template_kind" id="cms_template_kind"
	value="<?=$def['cms_template_kind']?>">
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">取り込みファイル<br>
		<span class="cms_require">（必須）</span></th>
		<td><input type="file" id="FrmCsvnm" name="FrmCsvnm"
			style="width: 500px;"><br>
		※csv形式のファイルを指定してください</td>
	</tr>
	<tr id="cms_cate_tr">
		<th align="left" valign="top" nowrap scope="row"><label
			for="cms_cate1">分類 <span class="cms_require">（必須）</span></label></th>
		<td><?=$combo_cate?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row" width="170"><label
			for="">テンプレート<br>
		<span class="cms_require">（必須）</span></label></th>
		<td>
		<p id="cms-template-selected"><?=$def['template_name']?></p>
		<p><a href="javascript:" onClick="return cxTemplateSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0"></a></p>
		</td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">ページ作成者 <span
			class="cms_require">（必須）</span></th>
		<td><?=$combo_dept?><?=$combo_user?></td>
	</tr>
</table>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center" id="cms_submit"><a href="javascript:"
	onClick="return cxSubmit()" onKeyDown="cxSubmit()"><img
	src="<?=RPW?>/admin/images/outerimport/btn_import_confirm.jpg"
	alt="取り込み確認" width="150" height="20" border="0"
	style="margin-right: 10px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="800" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="800" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="800" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
					alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxTemplateClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 760px; height: 385px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="740" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list"><label for="cms_template_id">テンプレートリスト</label>
				<select name="cms_template_id" id="cms_template_id" size="12"
					style="width: 250px;" onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
while ($objTool->fetch()) {
	if ($objTool->fld['template_id'] == TEMPLATE_ID_NONE) continue;
	$src = DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
	if ($def['cms_template_id'] != "" && $def['cms_template_id'] == $objTool->fld['template_id']) {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '" _kanko_type="' . $objTool->fld['kanko_type'] . '" selected>' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
	else {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '" _kanko_type="' . $objTool->fld['kanko_type'] . '">' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
}
?>
</select></div>
				</td>
				<td width="475" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 475px; height: 365px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?=$def_src?>" name="cms_thumb" id="cms_thumb"
					width="470" height="360" frameborder="0" scrolling="no"
					style="border: solid 1px #666"></iframe></td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxTemplateSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* --></form>
</div>
</div>
<!-- cms8341-contents -->
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxErrorClose();"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
</body>
</html>
