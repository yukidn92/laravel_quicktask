<?php
/**
 * 動画設定ファイル更新 更新実行、完了画面
 */
/** require **/
require ("./.htsetting");
require ("./include/updateFunc.inc");
$updateFunc = new updateFunc();

// パラメータチェック
if (ENABLE_OPTION_FLASH_VIDEO == false) {
	user_error('不正なパラメータです。');
}

//player_setting.xml
$ary = array(
		'infoPath' => PLAYER_INFOPATH, 
		'fmsDomain' => PLAYER_IFMSDOMAIN
);
//setting.xml
$sary = array(
		'infoPath' => PLAYER_S_INFOPATH, 
		'uploadPath' => PLAYER_UPLOADPATH, 
		'uploadCompPath' => PLAYER_UPLOADCOMPPATH, 
		'hostName' => PLAYER_HOSTNAME, 
		'servName' => PLAYER_SERVNAME, 
		'playerVer' => PLAYER_PLAYERVER, 
		'uploadLimit' => PLAYER_UPLOADLIMIT
);
$msg = "";
if (create_player_xml(APPLICATION_ROOT . '/common/player_setting.xml', $ary)) $msg = "動画設定ファイルの再生成を行いました。";
if (create_player_xml(APPLICATION_ROOT . '/common/setting.xml', $sary)) $msg = "動画設定ファイルの再生成を行いました。";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>動画設定ファイル再生成確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'update';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-autolink">
<div><img src="images/bar_gene_comp.jpg" alt="動画設定ファイル再生成完了" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?=$msg?>
<p align="center"><a href="<?=$updateFunc->backUrl?>"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</form>
</body>
</html>
