<?php
/*
 * プログラム更新 初期表示画面
 */
require ("./.htsetting");
require ("./include/updateFunc.inc");
$updateFunc = new updateFunc();

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	$updateFunc->_error('不正アクセスです。');
}

$msg = "";
//オプションの動画機能がfalseの場合再生成を表示しない
$display = "display:none";
if (ENABLE_OPTION_FLASH_VIDEO == true) {
	//表示
	$display = "display:block";
	
	//player_setting.xml
	$ary = array(
			'infoPath' => PLAYER_INFOPATH, 
			'fmsDomain' => PLAYER_IFMSDOMAIN
	);
	//setting.xml
	$sary = array(
			'infoPath' => PLAYER_S_INFOPATH, 
			'uploadPath' => PLAYER_UPLOADPATH, 
			'uploadCompPath' => PLAYER_UPLOADCOMPPATH, 
			'hostName' => PLAYER_HOSTNAME, 
			'servName' => PLAYER_SERVNAME, 
			'playerVer' => PLAYER_PLAYERVER, 
			'uploadLimit' => PLAYER_UPLOADLIMIT
	);
	$msg = player_file_search(APPLICATION_ROOT . '/common/player_setting.xml', $ary, $msg);
	$msg = player_file_search(APPLICATION_ROOT . '/common/setting.xml', $sary, $msg);
}
//生成又は更新する動画設定ファイルの有無の検索
function player_file_search($file_path, $tag_ary, $msg) {
	if ($msg != "") return $msg;
	if (file_exists($file_path)) {
		$xml = simplexml_load_file($file_path);
		foreach ($tag_ary as $key => $val) {
			if ($xml->$key != $val) {
				$msg = "動画設定ファイルに再生成の必要があります。再生成する場合は再生成開始ボタンをクリックしてください。";
				break;
			}
		}
	}
	else {
		$msg = "動画設定ファイルに再生成の必要があります。再生成する場合は再生成開始ボタンをクリックしてください。";
	}
	return $msg;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>プログラム更新</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
// 画面遷移
function cxSubmit(bv) {
	switch(bv) {
		// 適用確認画面へ
		case 1:
			$('fUpdate').action = "confirm.php";
			break;
		// 更新履歴画面へ
		case 2:
			$('fUpdate').action = "history.php";
			break;
		// 再生成画面へ
		case 3:
			$('fUpdate').action = "player_update.php";
			break;
		// そのた
		defulat:
			alert("不正な操作です。");
			return false;
	}
	$('fUpdate').submit();
	return false;
}
//再生成確認
function cxConfirm(bv){
	if(window.confirm("動画設定ファイルの再生成を行います。\nよろしいですか？")){
		cxSubmit(bv);
		return false;
	}
}

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'update';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-autolink">
<div><img src="images/bar_update_index.jpg" alt="プログラム更新" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form id="fUpdate" class="cms8341-form" name="fUpdate" action=""
	method="post" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr id="cms_FrmZipnm_tr">
		<th width="150" align="left" valign="top" scope="row">取り込みファイル<br>
		<span class="cms_require">（必須）</span></th>
		<td><input type="file" id="FrmZipnm" name="FrmZipnm"
			style="width: 500px;"><br>
		※zip形式の圧縮ファイルを指定してください</td>
	</tr>
</table>
<p align="center" id="cms_submit"><a href="javascript:"
	onClick="return cxSubmit(1)"><img src="./images/btn_update_start.jpg"
	alt="更新開始" width="150" height="20" border="0"
	style="margin-right: 10px;"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
<br />
<div align="center" id="cms8341-autolink" style="<?=$display?>">
<div><img src="images/bar_gene_index.jpg" alt="動画設定ファイルの再生成" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?php
if ($msg != "") {
	?>
<p class="cms_require"><?=$msg?></p>
<p align="center" id="cms_submit"><a href="javascript:"
	onClick="return cxConfirm(3)"><img src="./images/btn_gene_start.jpg"
	alt="再生成開始" width="150" height="20" border="0"
	style="margin-right: 10px;"></a></p>
<?php
}
else {
	?>
<p>再生成する必要はありません。</p>
<?php
}
?>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</form>
</body>
</html>
