<?php
/**
 * プログラム更新 更新履歴画面
 */
require ("./.htsetting");
require ("./include/updateFunc.inc");
$updateFunc = new updateFunc();
$historyAry = array();

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	$updateFunc->_error('不正アクセスです。');
}

// パッチ内容ファイルの存在チェックと内容チェック
if ($updateFunc->readHistory($historyAry) === FALSE) {
	$updateFunc->_error();
}
$historyAry = array_reverse($historyAry);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>プログラム更新履歴確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxRecovery(patchName){
	if (!confirm("この更新プログラムを元に戻します。\nよろしいですか？")) {
		return false;
	}
	$('cms_patch_name').value = patchName;
	$('fUpdate').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'update';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-autolink">
<div><img src="images/bar_update_history.jpg" alt="プログラム更新履歴確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form id="fUpdate" class="cms8341-form" name="fUpdate"
	action="recovery.php" method="post"><input type="hidden"
	id="cms_patch_name" name="cms_patch_name" value=""></form>
<table width="100%" border="0" cellpadding="5" cellspacing="0">
<?php
// 履歴がない場合
if (count($historyAry) == 0) {
	echo '<tr><td align="left" valign="top">適用履歴はありません</td></tr>' . "\n";
}
// 履歴がある場合
foreach ($historyAry as $key => $history) {
	echo '<tr>' . "\n";
	echo '<td align="left" valign="top">' . "\n";
	echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">';
	echo '<tr>' . "\n";
	echo '<th align="left" valign="top" width="20%">適用日</th>' . "\n";
	echo '<td align="left" valign="top">' . date("Y年m月d日H時i分s秒", $history[0]) . '</td>' . "\n";
	echo '</tr>' . "\n";
	echo '<tr>' . "\n";
	echo '<th align="left" valign="top">適用内容</th>' . "\n";
	echo '<td align="left" valign="top">' . htmlDisplay(preg_replace('/<br>/i', "\n", $history[2])) . '</td>' . "\n";
	echo '</tr>' . "\n";
	echo '</table>';
	echo '</td>' . "\n";
	// 最新の履歴にのみ戻すボタンをつける
	if ($key == 0) {
		echo '<td align="left"><a href="javascript:" onClick="return cxRecovery(\'' . $history[1] . '\')"><img src="./images/btn_recovery.jpg" alt="適用前へ戻す" border="0"></a></td>' . "\n";
	}
	else {
		echo '<td align="left">&nbsp;</td>' . "\n";
	}
	echo '</tr>' . "\n";
}
?>
</table>
<p align="center"><a href="javascript:history.back()"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
