<?php
/**
 * プログラム更新 更新実行、完了画面
 */
/** require **/
require ("./.htsetting");
require ("./include/updateFunc.inc");
global $objCnc;
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_shared_upload.inc');
$obj_shared = new tbl_shared_upload($objCnc);
$updateFunc = new updateFunc();

// パラメータチェック
if (!isset($_SESSION['update'])) {
	$updateFunc->_error('不正アクセスです。');
}

// 確認画面からの値の受け取り
$updateFunc->getSession();

// パッチを適用するファイルのバックアップを作成
if ($updateFunc->backup() === FALSE) {
	$updateFunc->_error();
}

// DBのバックアップを作成する
if ($updateFunc->dbBackup() === FALSE) {
	$updateFunc->_error();
}

// Array content file patch.txt
$ary_upfiles = $updateFunc->checkFilePath(); 
// Process transaction
$objCnc->begin();
foreach ($ary_upfiles as $upfile_path) {
	$file_path_data = explode('/', trim($upfile_path), 3);
	// Remove /cms8341/ on url $file_path_data
	$short_file_path_data = '/' . $file_path_data[2];
	$obj_shared->select($obj_shared->_addslashesC('file_path', $short_file_path_data));
	// Process updates database
	if ($obj_shared->getRowCount() > 0 && $obj_shared->fetch()) {
		$data_update = array(
			'id' => $obj_shared->fld['id'],
			'entry_datetime' => date('Y-m-d H:i:s')
		);
		if (!$obj_shared->update($data_update)) {
			$updateFunc->_error('DB:ファイル情報の更新に失敗しました。');
		}
	}
	// Process insert database
	else {
		$ary_shared = array(
			'file_path' => $short_file_path_data,
			'upload_class' => @file_exists(trim(DOCUMENT_ROOT . $upfile_path)) ? $obj_shared::SHARED_OVERWRITE : $obj_shared::SHARED_NEW
		);
		if (!$obj_shared->insert($ary_shared)) {
			$updateFunc->_error('DB:ファイル情報の登録に失敗しました。');
		}
	}
}
$objCnc->commit();

// パッチファイルを適用する
if ($updateFunc->updatePatch() === FALSE) {
	$updateFunc->_error();
}

// 履歴ファイルに書き込みを行う
if ($updateFunc->writeHistory() === FALSE) {
	$updateFunc->_error();
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>プログラム更新確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit() {
	$('fUpdate').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'update';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-autolink">
<div><img src="images/bar_update_submit.jpg" alt="プログラム更新完了" width="920"
	height="30"></div>
<div class="cms8341-area-corner">以下の更新を行いました。
<form id="form" class="cms8341-form" name="fUpdate" action="submit.php"
	method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">更新内容</th>
		<td align="left" valign="top">
<?php
foreach ($updateFunc->patchInfoAry as $info) {
	echo htmlDisplay($info) . "<br>";
}
?>
</td>
	</tr>
</table>
<p align="center"><a href="<?=$updateFunc->backUrl?>"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</form>
</body>
</html>
