<?php
/**
 * プログラム更新 戻す画面
 */
require ("./.htsetting");
require ("./include/updateFunc.inc");
$updateFunc = new updateFunc();

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	$updateFunc->_error('不正アクセスです。');
}

// パラメータチェック	
if (!isset($_POST['cms_patch_name']) || (isset($_POST['cms_patch_name']) && $_POST['cms_patch_name'] == "")) {
	$updateFunc->_error('パラメータが足りません');
}

// リカバリを行う
if ($updateFunc->recovery($_POST['cms_patch_name']) === FALSE) {
	$updateFunc->_error();
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>プログラム更新履歴確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'update';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-autolink">
<div><img src="images/bar_update_submit.jpg" alt="プログラム更新完了" width="920"
	height="30"></div>
<div class="cms8341-area-corner">更新プログラムを元に戻しました。
<table width="100%" border="0" cellpadding="5" cellspacing="0">
	<tr>
		<td></td>
	</tr>
</table>
<p align="center"><a href="<?=$updateFunc->backUrl?>"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
