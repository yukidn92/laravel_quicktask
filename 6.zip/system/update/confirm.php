<?php
/**
 * プログラム更新 確認画面
 */
require ("./.htsetting");
require ("./include/updateFunc.inc");
$updateFunc = new updateFunc();
unset($_SESSION['update']);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	$updateFunc->_error('不正アクセスです。');
}

// （php.ini）post_max_size をオーバーすると$_POSTの値が飛んでこない
if (count($_FILES) == 0) {
	$updateFunc->_error('取り込みファイルのファイルサイズが大きすぎる可能性があります。');
}
// 取り込みファイルが指定されていなければエラー
if (!isset($_FILES['FrmZipnm']) || $_FILES['FrmZipnm']['name'] == '') {
	$updateFunc->_error('取り込みファイルを指定してください。');
}
// （php.ini）upload_max_filesize をオーバーすると$_FILES['FrmZipnm']['size']はゼロになる
// ファイルサイズがゼロならエラー
if ($_FILES['FrmZipnm']['size'] <= 0) {
	$updateFunc->_error('取り込みファイルの指定が正しくないか、取り込みファイルのファイルサイズが大きすぎる可能性があります。');
}
// 取り込みファイルはzip圧縮のファイルでなければエラー
if (!preg_match('/\.zip$/i', $_FILES['FrmZipnm']['name'])) {
	$updateFunc->_error('取り込みファイルはzip形式の圧縮ファイルを指定してください。');
}
// 取り込みファイルの展開ディレクトリ
$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';
chmodAll($tmpUpDir, 0777);
if (@file_exists($tmpUpDir)) removeDir($tmpUpDir);
if (!@mkdir($tmpUpDir, 0777)) {
	$updateFunc->_error('取り込みファイルの展開フォルダ作成に失敗しました。');
}
chmod($tmpUpDir, 0777);

// 圧縮ファイルを解凍する
if (defined("SET_UNZIP_EXE")) {
	exec(SET_UNZIP_EXE . ' ' . $_FILES['FrmZipnm']['tmp_name'] . ' ' . $tmpUpDir);
}
else {
	exec('unzip ' . $_FILES['FrmZipnm']['tmp_name'] . ' -d ' . $tmpUpDir);
}

// パッチ内容ファイルの存在チェックと内容チェック
if ($updateFunc->checkPatchTxt($tmpUpDir) === FALSE) {
	$updateFunc->_error();
}

// 取り込みファイルの確認
if ($updateFunc->checkPatch() === FALSE) {
	$updateFunc->_error();
}

// セッションに格納
$updateFunc->setSession();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>プログラム更新確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit() {
	$('fUpdate').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'update';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-autolink">
<div><img src="images/bar_update_confirm.jpg" alt="プログラム更新確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">以下の更新を行います。
<form id="fUpdate" class="cms8341-form" name="fUpdate"
	action="submit.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">更新内容</th>
		<td align="left" valign="top">
<?php
foreach ($updateFunc->patchInfoAry as $info) {
	echo htmlDisplay($info) . "<br>";
}
?>
</td>
	</tr>
</table>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="../images/btn_update.jpg" alt="更新" width="150" height="20"
	border="0" style="margin-left: 10px"></a> <a
	href="<?=$updateFunc->backUrl?>"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0" style="margin-left: 10px"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</form>
</body>
</html>
