<?php
/*
 *
 */
/** 手動アップロード **/
require ("./.htsetting");
//
$error = $_SESSION['error'];
$headerMode = $_SESSION['tab'];
$backurl = $_SESSION['back_page'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>エラーページ</title>
<link rel="stylesheet" href="../style/shared.css" type="text/css">
<link rel="stylesheet" href="../master/error/error.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../js/library/prototype.js" type="text/javascript"></script>
<script src="../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-error">
<div><img src="../master/error/images/bar_error.jpg" alt="エラー"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<p align="left"><?=$error?></p>
<p align="center" class="ctrl"><a href="<?=$backurl?>"><img
	src="<?=RPW?>/admin/master/images/btn_small_back.jpg" alt="戻る"
	width="120" height="20" border="0"></a></p>
</div>
<div><img src="../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>