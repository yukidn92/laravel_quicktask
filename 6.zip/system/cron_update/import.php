<?php
/*
 * 自動実行処理設定インポート処理
 */

// 設定ファイル読み込み
require ("./.htsetting");

// 定数の宣言
// CRONのファイルパス
$G_CRON_FILE_PATH = DOCUMENT_ROOT . DIR_PATH_CRON_FILE . CRON_FILE_NAME;

// 変数の宣言
// アップロードされたファイルのファイル名
$g_org_cron_file_name = basename($_FILES['cron_file']['name']);

// ファイルのチェック
if (strlen($g_org_cron_file_name) <= 0) {
	user_error('インポートをするファイルを指定してください。');
	exit();
}
// アップロード用ディレクトリの作成
if (mkNewDirectory($G_CRON_FILE_PATH) === FALSE) {
	user_error('アップロード用ディレクトリの作成に失敗しました。【' . $G_CRON_FILE_PATH . '】');
	exit();
}
// アップロード
if (@move_uploaded_file($_FILES['cron_file']['tmp_name'], $G_CRON_FILE_PATH) === FALSE) {
	user_error('ファイルのアップロードに失敗しました。【' . $G_CRON_FILE_PATH . '】');
	exit();
}
// ファイル存在チェック
if (@is_file($G_CRON_FILE_PATH) === FALSE) {
	user_error('指定されたファイル【' . $G_CRON_FILE_PATH . '】が存在しません。');
	exit();
}
// CRONファイルをインポート
exec(CRON_COMMAND . ' ' . $G_CRON_FILE_PATH);

// CRONファイルが適用されたかどうか比較を行う
exec(CRON_COMMAND . ' -l > ' . $G_CRON_FILE_PATH . '2');
// ファイルを読み込む
$cron_up_file = file_get_contents($G_CRON_FILE_PATH);
$cron_setting_file = file_get_contents($G_CRON_FILE_PATH . '2');
// ファイルを比較する
if ($cron_up_file === $cron_setting_file) {
	$msg = 'インポートが完了しました。';
}
else {
	$msg = 'インポートに失敗しました。';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		<title>自動実行処理設定</title>
		<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
		<?php print(TOOLBAR_FIX_CSS); ?>
		<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
		<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
	</head>
	<body id="cms8341-mainbg">
		<?php
			// ヘッダーメニュー挿入
			$headerMode = 'cron_update';
			include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
		?>
		<div id="cms8341-contents">
			<div align="center">
				<div><img src="./images/bar_cron_update_index.jpg" alt="自動実行処理設定ファイルインポート" width="920" height="30"></div>
				<div class="cms8341-area-corner">
					<p><?php echo $msg; ?></p>
					<p align="center">
						<a href="./index.php"><img src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150" height="20" border="0" style="margin-left: 10px;"></a>
					<p>
				</div>
				<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
			</div>
		</div>
		<!-- cms8341-contents -->
	</body>
</html>
