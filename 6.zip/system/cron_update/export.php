<?php
/*
 * 自動実行処理設定エクスポート処理
 */

// 設定ファイル読み込み
require ("./.htsetting");

// 定数の宣言
// CRONのファイルパス
$G_CRON_FILE_PATH = DOCUMENT_ROOT . DIR_PATH_CRON_FILE . CRON_FILE_NAME;

// CRONファイルを作成
exec(CRON_COMMAND . ' -l > ' . $G_CRON_FILE_PATH);

// ファイルの存在チェック
if (@is_file($G_CRON_FILE_PATH) === FALSE) {
	user_error('ファイルのエクスポートに失敗しました。【' . $G_CRON_FILE_PATH . '】');
	exit();
}

// ファイルの出力
if (($cron_file = @file_get_contents($G_CRON_FILE_PATH)) === FALSE) {
	user_error('ファイルの読み込みに失敗しました。【' . $G_CRON_FILE_PATH . '】');
	exit();
}

//ヘッダ出力
$file_size = @filesize($G_CRON_FILE_PATH);
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=" . basename(CRON_FILE_NAME));
header('Content-Length: ' . $file_size);
echo $cron_file;

exit();
?>
