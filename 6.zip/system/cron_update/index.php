<?php
/*
 * 自動実行処理設定
 */

// 設定ファイル読み込み
require ("./.htsetting");

// 定数の宣言
// CRONのファイルパス
$G_CRON_FILE_PATH = DOCUMENT_ROOT . DIR_PATH_CRON_FILE . CRON_FILE_NAME;
// ファイルの削除
if (is_file($G_CRON_FILE_PATH)) {
	@unlink($G_CRON_FILE_PATH);
}
if (is_file($G_CRON_FILE_PATH . '2')) {
	@unlink($G_CRON_FILE_PATH . '2');
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		<title>自動実行処理設定</title>
		<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
		<?php print(TOOLBAR_FIX_CSS); ?>
		<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
		<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
	</head>
	<body id="cms8341-mainbg">
		<?php
			// ヘッダーメニュー挿入
			$headerMode = 'cron_update';
			include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
		?>
		<div id="cms8341-contents">
			<div align="center">
				<div><img src="./images/bar_cron_update_index.jpg" alt="自動実行処理設定ファイルインポート" width="920" height="30"></div>
				<div class="cms8341-area-corner">
					<p style="margin-top:0px;margin-bottom:20px;">自動実行処理用設定ファイルをインポートします。</p>
					<form id="cron_update" class="cms8341-form" name="cron_update" action="./import.php" method="post" enctype="multipart/form-data">
						<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
							<tr>
								<th width="150" align="left" valign="top" scope="row">インポートファイル<br /><span class="cms_require">（必須）</span></th>
								<td>
									<input type="file" id="cron_file" name="cron_file" style="width: 500px;">
								</td>
							</tr>
						</table>
						<p style="font-size:80%;color:#FF0000;">※設定ファイルをインポートする場合は、弊社へ相談の上変更をお願いします。</p>
						<p align="center" id="cms_submit">
							<input type="image" src="<?=RPW?>/admin/images/btn/btn_import.jpg" alt="インポート" width="150" height="20" border="0" style="margin-right: 10px;">
						</p>
					</form>
				</div>
				<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
			</div>
			<br />
			<div align="center">
				<div><img src="./images/bar_cron_export_index.jpg" alt="自動実行処理設定ファイルエクスポート" width="920" height="30"></div>
				<div class="cms8341-area-corner">
					<p style="margin-top:0px;margin-bottom:20px;">自動実行処理用設定ファイルをエクスポートします。</p>
					<p align="center">
						<a href="./export.php"><img src="<?=RPW?>/admin/images/btn/btn_export.jpg" alt="エクスポート" width="150" height="20" border="0" style="margin-right: 10px;"></a>
					</p>
				</div>
				<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
			</div>
		</div>
		<!-- cms8341-contents -->
	</body>
</html>
