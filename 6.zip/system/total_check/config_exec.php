<?php
/*
 * システム管理　各種チェック設定
 * 各チェック項目の「ON/OFF」設定をDBに登録
 */
/** require **/
require ("./.htsetting");

if (!isset($_POST['check_config']) || !is_array($_POST['check_config'])) {
	_rollback("パラメータ取得エラー（check_config）");
}

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
$objDac = new b_dac($objCnc);

// モード取得
$mode = "acc";
if (isset($_POST['mode']) && $_POST['mode'] != "") {
	$mode = $_POST['mode'];
	$temp_ary = array(
			"acc", 
			"header", 
			"contrast", 
			"spell", 
			"others"
	);
	if (!in_array($mode, $temp_ary)) $mode = "acc";
}

$objCnc->begin();

$objDac->setTableName("tbl_check_config"); // 対象テーブル設定
// 各種チェック設定を削除
$objDac->add_where("class", implode(',', array_keys($_POST['check_config'])), 'IN'); // 条件設定
if (!$objDac->delete()) {
	_rollback("各種チェックの設定変更に失敗しました。");
}

foreach ($_POST['check_config'] as $k => $v) {
	// コントラストチェック基準設定を登録
	$objDac->pk = 'class'; // PK(プライマリーキー)設定
	$ary = array(
			'class' => $k, 
			'check_flg' => $v
	);
	if (!$objDac->insert($ary)) {
		_rollback("各種チェックの設定変更に失敗しました。");
	}
}

$objCnc->commit();

header("Location: " . HTTP_ROOT . RPW . "/admin/system/total_check/index.php?mode=" . $mode);
exit();

/**
 * エラー表示関数
 *
 * @param $msg エラーメッセージ
 */
function _rollback($msg) {
	DispError($msg, "total_check", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
?>