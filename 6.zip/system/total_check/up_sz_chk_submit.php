<?php
/*
 * システム管理　アップロードチェック設定
 * アップロードチェック設定DB登録
 */
/** require **/
require ("./.htsetting");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// POSTデータ取得
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	foreach ($_POST as $k => $v) {
		if (get_magic_quotes_gpc()) $v = stripslashes($v);
		$$k = $v;
	}
}
if (isset($dir_list)) {
	
	//トランザクション開始
	$objCnc->begin();
	//登録データの削除
	$sql = "DELETE FROM tbl_handler WHERE class = " . HANDLER_CLASS_SIZECHECK_NONE_DIR;
	if (!$objDac->execute($sql)) _rollback($objCnc, 'リサイズ無効フォルダの削除に失敗しました。');
	
	//データ登録
	//カンマ区切り
	$dir_list_ary = explode(",", $dir_list);
	$values_ary = array();
	foreach ($dir_list_ary as $val) {
		//空白削除
		$val = str_replace(' ', '', (mb_convert_kana($val, "s")));
		if ($val == "") continue;
		//念のためサブミット時にもファルダ名チェック
		if (preg_match('/[^0-9a-zA-Z\~\.\-\_\/]/', $val)) _rollback($objCnc, 'フォルダ名としてふさわしくない文字が使用されています。【' . $val . '】');
		if (substr($val, 0, 1) != '/') $val = '/' . $val;
		if (substr($val, -1) != '/') $val .= '/';
		
		$values_ary[] = '(' . HANDLER_CLASS_SIZECHECK_NONE_DIR . ",'" . gd_addslashes($val) . "')";
		if (!mkNewDirectory(DOCUMENT_ROOT . RPW . $val . 'dummy.txt')) {
			_rollback($objCnc, 'フォルダの作成に失敗しました。');
		}
	}
	if (count($values_ary) > 0) {
		//SQL作成
		$sql = "INSERT INTO tbl_handler (class,item1) VALUES " . implode(',', $values_ary);
		//登録
		if (!$objDac->execute($sql)) _rollback($objCnc, 'サイズチェック無効フォルダの登録に失敗しました。');
	}
}
else {
	DispError("パラメータ取得エラー", 3, "javascript:history.back()");
	exit();
}
//コミット
$objCnc->commit();

header("Location: " . HTTP_ROOT . RPW . "/admin/system/total_check/index.php?mode=others");
exit();

function _rollback($objCnc, $msg) {
	$objCnc->rollback();
	DispError($msg, 3, "javascript:history.back()");
	exit();
}
?>
