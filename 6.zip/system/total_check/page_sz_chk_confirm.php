<?php
/*
 * システム管理　ページ容量チェック設定
 * ページ容量チェック設定確認画面
 */
/** require **/
require ("./.htsetting");

// POSTデータを変数化
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	foreach ($_POST as $k => $v) {
		if (get_magic_quotes_gpc()) $v = stripslashes($v);
		$$k = $v;
	}
}

$err_msg = "";
if (!isset($text_size) || (trim($text_size) == "")) {
	$err_msg .= 'テキスト総容量が入力されていません。<br>';
}
else if (!preg_match("/^[0-9]{1,9}$/", $text_size)) {
	$err_msg .= 'テキスト総容量は数値で入力して下さい。<br>';
}

if (!isset($use_file_size) || (trim($use_file_size) == "")) {
	$err_msg .= '画像ファイル総容量が入力されていません。<br>';
}
else if (!preg_match("/^[0-9]{1,9}$/", $use_file_size)) {
	$err_msg .= '画像ファイル総容量は数値で入力して下さい。<br>';
}

if (!isset($text_size_k) || (trim($text_size_k) == "")) {
	$err_msg .= '携帯用テキスト総容量が入力されていません。<br>';
}
else if (!preg_match("/^[0-9]{1,9}$/", $text_size_k)) {
	$err_msg .= '携帯用テキスト総容量は数値で入力して下さい。<br>';
}

if (!isset($use_file_size_k) || (trim($use_file_size_k) == "")) {
	$err_msg .= '携帯用画像ファイル総容量が入力されていません。<br>';
}
else if (!preg_match("/^[0-9]{1,9}$/", $use_file_size_k)) {
	$err_msg .= '携帯用画像ファイル総容量は数値で入力して下さい。<br>';
}

if ($err_msg != "") {
	user_error($err_msg); // リスト形式で表示したい
	exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>各種チェック詳細設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="total_check.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'total_check';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-total_check">
<div><img src="images/bar_paegsize_conf.jpg" alt="ページ容量詳細設定確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form class="cms8341-form" name="form" id="form"
	action="page_sz_chk_submit.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" width="300">テキスト総容量(キロバイト数)</th>
		<td><?php
		if (isset($text_size)) print $text_size;
		?></td>
	</tr>
	<tr>
		<th align="left" width="300">画像ファイル総容量(キロバイト数)</th>
		<td><?php
		if (isset($use_file_size)) print $use_file_size;
		?></td>
	</tr>
	<tr>
		<th align="left" width="300">携帯用テキスト総容量(キロバイト数)</th>
		<td><?php
		if (isset($text_size_k)) print $text_size_k;
		?></td>
	</tr>
	<tr>
		<th align="left" width="300">携帯用画像ファイル総容量(キロバイト数)</th>
		<td><?php
		if (isset($use_file_size_k)) print $use_file_size_k;
		?></td>
	</tr>
	<tr>
		<th align="left" width="300">一時保存時チェック</th>
		<td><?php
		print $tmp_size_chk ? '実行' : '無効';
		?></td>
	</tr>
	<tr>
		<th align="left" width="300">編集完了時チェック</th>
		<td><?php
		print $edit_size_chk ? '実行' : '無効';
		?></td>
	</tr>
	<tr>
		<th align="left" width="300">編集完了時の保存禁止<br>
		※編集完了時の容量チェックで設定値を超えている場合、編集完了できなくします。</th>
		<td><?php
		print $err_handle ? '実行' : '無効';
		?></td>
	</tr>
</table>
<p align="center"><a href="javascript:document.form.submit()"><img
	src="../images/btn_config.jpg" alt="設定を変更" width="150" height="20"
	border="0" style="margin-right: 10px"></a><a
	href="javascript:history.back()"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<input type="hidden" name="text_size"
	value="<?php
	if (isset($text_size)) print $text_size;
	?>">
<input type="hidden" name="use_file_size"
	value="<?php
	if (isset($use_file_size)) print $use_file_size;
	?>">
<input type="hidden" name="text_size_k"
	value="<?php
	if (isset($text_size_k)) print $text_size_k;
	?>">
<input type="hidden" name="use_file_size_k"
	value="<?php
	if (isset($use_file_size_k)) print $use_file_size_k;
	?>">
<input type="hidden" name="tmp_size_chk" value="<?=$tmp_size_chk?>">
<input type="hidden" name="edit_size_chk" value="<?=$edit_size_chk?>">
<input type="hidden" name="err_handle" value="<?=$err_handle?>">
<input type="hidden" name="exist_setting" value="<?=$exist_setting?>">
</form>
</body>
</html>
