<?php
/*
 * システム管理　各種チェック詳細設定のインポート
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");
//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);
//csvファイル項目数
define("G_CSV_ITM_CNT", 2);

$ChkItemFlg = array(
		1, 
		1
);

//--- 設定ファイル読み込み
require ("./.htsetting");

if (!isset($_POST['behavior']) || $_POST['behavior'] != 4) {
	DispError("パラメータ取得エラー（behavior）", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//表示設定
require ("./include/detailset.inc");

//---引数チェック
$frmCsvFnm = basename($_FILES['FrmCsvnm']['name']);
if (strlen($frmCsvFnm) <= 0) {
	DispError("インポートをするcsvファイルを指定してください。", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//---ファイルサイズチェック
if ($_FILES['FrmCsvnm']['size'] <= 0) {
	DispError("csvファイルのファイルサイズが0バイトです。", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//---アップロード
$frmCsvFnm = CSV_UPLOAD . $frmCsvFnm;
if (@move_uploaded_file($_FILES['FrmCsvnm']['tmp_name'], $frmCsvFnm) == FALSE) {
	DispError("csvファイルのアップロードに失敗しました。", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//(念のため)ファイル存在チェック
if (file_exists($frmCsvFnm) == FALSE) {
	DispError("指定されたファイル【" . $frmCsvFnm . "】が存在しません。", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---csvを読込み、tbl_check_wordsに追加していく---*/
// トランザクション開始
$objCnc->begin();

//詳細設定の全削除
$sql = "DELETE FROM tbl_check_words WHERE class = " . $class;
$objDac->execute($sql);

//ファイルを開く
if (!($CsvFno = csvRead_UTF8($frmCsvFnm))) {
	$objCnc->rollback();
	DispError("csvファイルのオープンに失敗しました。", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//一行目は飛ばす
$data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE);
//EOFになるまで読み出し
$err_msg = "";

// csv全データ
$csv_data = array();
while ($data = cms_fgetcsv($CsvFno, G_CSV_MAX_LINE)) {
	// 行の項目数が組織情報の項目数よりも少なければ空で埋める
	while (count($data) <= G_CSV_ITM_CNT) {
		$data[] = "";
	}
	
	//各項目のチェック
	if (strlen($data[0]) <= 0) $err_msg = "対象文字列が指定されていないデータが存在します。";
	
	// 文中表記チェック用登録データチェック
	if ($class == CHECK_CLASS_STRING) {
		// チェック結果フラグが指定されていない又は「0」「1」以外が指定されていた場合エラー 
		if (!isset($data[3]) || ($data[3] != "0" && $data[3] != "1")) {
			$err_msg = "チェック結果が指定されていない又は「0」「1」以外の値が指定されているデータが存在します。";
		}
		elseif (isset($csv_data[$data[0]])) {
			$err_msg = "対象文字列に同一文言が指定されているデータが存在します。【" . $data[0] . "】";
		}
		
		// データ保持
		$csv_data[$data[0]] = "";
	}
	
	//tbl_check_wordsに追加
	if (strlen($err_msg) <= 0) {
		switch ($class) {
			case CHECK_CLASS_HEAD :
			case CHECK_CLASS_LINK_TEXT :
			case CHECK_CLASS_ALT_TEXT :
			case CHECK_CLASS_SPELL :
				$sql = "INSERT INTO tbl_check_words (class, word)" . " VALUES (" . $class . ", '" . gd_addslashes($data[0]) . "')";
				break;
			case CHECK_CLASS_STRING :
				$sql = "INSERT INTO tbl_check_words (class, word, rep_word, rep_word2, convert_flg)" . " VALUES (" . $class . ", '" . gd_addslashes($data[0]) . "', '" . gd_addslashes($data[1]) . "', '" . gd_addslashes($data[2]) . "', '" . gd_addslashes($data[3]) . "')";
				break;
			default :
				$sql = "INSERT INTO tbl_check_words (class, word, rep_word, rep_word2)" . " VALUES (" . $class . ", '" . gd_addslashes($data[0]) . "', '" . gd_addslashes($data[1]) . "', '" . gd_addslashes($data[2]) . "')";
		}
		if (!$objDac->execute($sql, "utf-8", "auto")) $err_msg = "詳細設定の登録に失敗しました。";
	}
	
	//エラーがあった場合
	if (strlen($err_msg) > 0) {
		//ファイルClose
		fclose($CsvFno);
		//ファイルを削除
		unlink($frmCsvFnm);
		//ロールバック
		$objCnc->rollback();
		//エラーページの表示
		DispError($err_msg, "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
		exit();
	}
}

//ファイルClose
fclose($CsvFno);
//ファイルを削除
if (unlink($frmCsvFnm) == FALSE) {
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	DispError("csvファイルの削除に失敗しました。", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

// コミット
$objCnc->commit();

/*---アクセシビリティチェック詳細画面へと戻る---*/
header("Location: " . "./detail.php?class=" . $class);
?>
