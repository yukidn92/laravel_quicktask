<?php
/*
 * システム管理　コントラストチェック設定
 * 設定画面にて指定されたコントラストの基準をDBに登録
 */
/** require **/
require ("./.htsetting");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
$objDac = new b_dac($objCnc);

// 開始
$objCnc->begin();

// POSTデータ取得
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	foreach ($_POST as $k => $v) {
		if (get_magic_quotes_gpc()) $v = stripslashes($v);
		$$k = $v;
	}
	// ポスト値チェック
	$tmp_ary = array(
			1, 
			2
	);
	if (!isset($contrast_standard) || !in_array($contrast_standard, $tmp_ary)) {
		_rollback("ステータスの取得に失敗した又は値が不正です。");
	}
	
	$objDac->setTableName("tbl_handler"); // 対象テーブル設定
	// コントラストチェック基準設定を削除
	$objDac->add_where("class", HANDLER_CLASS_CONTRASTCHECK_STANDARD); // 条件設定
	if (!$objDac->delete()) {
		_rollback("コントラストチェック基準設定の削除に失敗しました。");
	}
	
	// コントラストチェック基準設定を登録
	$objDac->pk = 'class'; // PK(プライマリーキー)設定
	$ary = array(
			'class' => HANDLER_CLASS_CONTRASTCHECK_STANDARD, 
			'item1' => $contrast_standard
	);
	if (!$objDac->insert($ary)) {
		_rollback("コントラストチェック基準設定の登録に失敗しました。");
	}
}

//コミット
$objCnc->commit();

header("Location: " . HTTP_ROOT . RPW . "/admin/system/total_check/index.php?mode=contrast");
exit();

/**
 * エラー表示関数
 *
 * @param $msg エラーメッセージ
 */
function _rollback($msg) {
	DispError($msg, "total_check", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
?>
