<?php
/*
 * システム管理　アップロードチェック設定
 * アップロードチェック設定入力画面
 */
/** require **/
require ("./.htsetting");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/** 変数宣言 **/
$text_area = "";

// 現在設定値の取得
$sql = "SELECT item1 FROM tbl_handler WHERE class = " . HANDLER_CLASS_SIZECHECK_NONE_DIR;
if ($objDac->execute($sql) && ($objDac->getRowCount() > 0)) {
	while ($objDac->fetch()) {
		$text_area .= $objDac->fld['item1'] . "\n";
	}
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>各種チェック詳細設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="total_check.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'total_check';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-total_check">
<div><img src="images/bar_upsize_check.jpg" alt="アップロードチェック詳細設定"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form class="cms8341-form" name="form" id="form"
	action="up_sz_chk_confirm.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" valign="middle" scope="row">サイズチェック無効フォルダ</th>
		<td align="left" valign="top"><textarea id="dir_list" name="dir_list"
			cols="50" rows="5">
<?=$text_area?>
</textarea></td>
	</tr>
</table>
<p>※指定されたフォルダのサブフォルダも対象となります。</p>
<p align="center"><a href="javascript:document.form.submit()"><img
	src="../../master/images/btn_conf.jpg" alt="確認" width="150" height="20"
	border="0" style="margin-right: 10px"></a><a
	href="index.php?mode=others"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</form>
</body>
</html>
