<?php
/*
 * システム管理　アップロードチェック設定
 * アップロードチェック設定確認画面
 */
/** require **/
require ("./.htsetting");

// POSTデータを変数化
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	foreach ($_POST as $k => $v) {
		if (get_magic_quotes_gpc()) $v = stripslashes($v);
		$$k = $v;
	}
}

$err_msg = "";
if (isset($dir_list)) {
	//改行区切り
	$dir_list_ary = explode("\n", preg_replace('/\r?\n/', "\n", $dir_list));
	foreach ($dir_list_ary as $key => $val) {
		//空白削除
		$val = str_replace(' ', '', (mb_convert_kana($val, "s")));
		//未入力は削除後にスキップ
		if ($val == "") {
			unset($dir_list_ary[$key]);
			continue;
		}
		//フォルダ名に使えない文字列
		if (preg_match('/[^0-9a-zA-Z\~\-\_\/]/', $val)) {
			$err_msg .= "フォルダ名としてふさわしくない文字が使用されています。【" . $val . "】<br>";
			continue;
		}
		if (substr($val, 0, 1) != '/') $val = '/' . $val;
		if (substr($val, -1) != '/') $val .= '/';
		$dir_list_ary[$key] = $val;
	}
	//重複した値の削除
	$dir_list_ary = array_unique($dir_list_ary);
	//自然順アルゴリズムでソート
	natsort($dir_list_ary);
}
else {
	$err_msg .= "パラメータの取得に失敗しました。<br>";
}
if ($err_msg != "") {
	user_error($err_msg);
	exit();
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>各種チェック詳細設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="total_check.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'total_check';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-total_check">
<div><img src="images/bar_upsize_conf.jpg" alt="アップロードチェック設定確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form class="cms8341-form" name="form" id="form"
	action="up_sz_chk_submit.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" width="300">サイズチェック無効フォルダ</th>
		<td><?=implode("<br>", $dir_list_ary)?></td>
	</tr>
</table>
<p align="center"><a href="javascript:document.form.submit()"><img
	src="../images/btn_config.jpg" alt="設定を変更" width="150" height="20"
	border="0" style="margin-right: 10px"></a><a
	href="javascript:history.back()"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<input type="hidden" name="dir_list"
	value="<?=implode(',', $dir_list_ary)?>">
</form>
</body>
</html>