<?php
/*
 * システム管理　コントラストチェック設定
 * コントラストチェックを行う基準を設定する
 */
/** require **/
require ("./.htsetting");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/b_dac.inc');
$objDac = new b_dac($objCnc);

$check_standard_ary = array(
		1 => 'AA(ダブルエー) /', 
		2 => 'AAA(トリプルエー)'
);
$check_standard_AA = array(
		1 => ' checked', 
		2 => ''
);
$check_standard_AAA = array(
		1 => '', 
		2 => ' checked'
);

$contrast_chk_standard = $check_standard_AA;

// 現在設定値の取得
$standard = 1;
$objDac->add_where("class", HANDLER_CLASS_CONTRASTCHECK_STANDARD); // 条件分設定
$objDac->setTableName("tbl_handler"); // 対象テーブル設定
$objDac->select(); // SQL実行
$objDac->fetch(); // 結果取得
if (isset($objDac->fld['item1'])) {
	$standard = $objDac->fld['item1'];
	$contrast_chk_standard = ($standard == 2 ? $check_standard_AAA : $check_standard_AA);
}

// ラジオボタン作成
$status_str = mkradiobutton($check_standard_ary, "contrast_standard", $standard, 2);

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>各種チェック詳細設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="total_check.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'total_check';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-total_check">
<div><img src="images/bar_contrast_check_detail.jpg"
	alt="コントラストチェック詳細設定" width="920" height="30"></div>
<div class="cms8341-area-corner">
<form class="cms8341-form" name="form" id="form"
	action="contrast_chk_submit.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">

	<tr>
		<th align="center" width="300">チェック項目</th>
		<th align="center">チェック基準設定</th>
	</tr>

	<tr>
		<td align="center" width="300">コントラストチェック</td>
		<td align="center"><?=$status_str?></td>
	</tr>

</table>
<br>

<p align="center"><a href="javascript:document.form.submit()"><img
	src="../images/btn_config.jpg" alt="設定を変更" width="150" height="20"
	border="0" style="margin-right: 10px"></a><a
	href="index.php?mode=contrast"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</form>
</body>
</html>
