<?php
/*
 * システム管理　ページ容量チェック設定
 * ページ容量チェック設定入力画面
 */
/** require **/
require ("./.htsetting");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

//	$checkNone = array(0 => '', 1 => '');
$checkON = array(
		0 => '', 
		1 => ' checked'
);
$checkOFF = array(
		0 => ' checked', 
		1 => ''
);
$r_tmp_size_chk = $r_edit_size_chk = $r_err_handle = $checkOFF;

$exist_setting = 1;
// 現在設定値の取得
$sql = "SELECT * FROM tbl_check_pagesize";
if ($objDac->execute($sql) && (0 < $objDac->getRowCount())) {
	if ($objDac->fetch()) {
		$text_size = $objDac->fld['text_size'];
		$use_file_size = $objDac->fld['use_file_size'];
		$text_size_k = $objDac->fld['text_size_k'];
		$use_file_size_k = $objDac->fld['use_file_size_k'];
		$tmp_size_chk = $objDac->fld['tmp_size_chk'];
		$r_tmp_size_chk = $tmp_size_chk ? $checkON : $checkOFF;
		$edit_size_chk = $objDac->fld['edit_size_chk'];
		$r_edit_size_chk = $edit_size_chk ? $checkON : $checkOFF;
		$err_handle = $objDac->fld['err_handle'];
		$r_err_handle = $err_handle ? $checkON : $checkOFF;
	}
}
else {
	$exist_setting = 0;
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>各種チェック詳細設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="total_check.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'total_check';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-total_check">
<div><img src="images/bar_paegsize_check.jpg" alt="ページ容量詳細設定"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form class="cms8341-form" name="form" id="form"
	action="page_sz_chk_confirm.php" method="post">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" width="300">テキスト総容量(キロバイト数)</th>
		<td><input type="text" name="text_size" size="30" maxlength="9"
			value="<?php
			if (isset($text_size)) print $text_size;
			?>"></td>
	</tr>
	<tr>
		<th align="left" width="300">画像ファイル総容量(キロバイト数)</th>
		<td><input type="text" name="use_file_size" size="30" maxlength="9"
			value="<?php
			if (isset($use_file_size)) print $use_file_size;
			?>"></td>
	</tr>
	<tr>
		<th align="left" width="300">携帯用テキスト総容量(キロバイト数)</th>
		<td><input type="text" name="text_size_k" size="30" maxlength="9"
			value="<?php
			if (isset($text_size_k)) print $text_size_k;
			?>"></td>
	</tr>
	<tr>
		<th align="left" width="300">携帯用画像ファイル総容量(キロバイト数)</th>
		<td><input type="text" name="use_file_size_k" size="30" maxlength="9"
			value="<?php
			if (isset($use_file_size_k)) print $use_file_size_k;
			?>"></td>
	</tr>
	<tr>
		<th align="left" width="300">一時保存時チェック</th>
		<td><input type="radio" name="tmp_size_chk" value="1" id="r1"
			<?=$r_tmp_size_chk[1]?> /> <label for="r1">実行</label> <input
			type="radio" name="tmp_size_chk" value="0" id="r2"
			<?=$r_tmp_size_chk[0]?> /> <label for="r2">無効</label></td>
	</tr>
	<tr>
		<th align="left" width="300">編集完了時チェック</th>
		<td><input type="radio" name="edit_size_chk" value="1" id="r3"
			<?=$r_edit_size_chk[1]?> /> <label for="r3">実行</label> <input
			type="radio" name="edit_size_chk" value="0" id="r4"
			<?=$r_edit_size_chk[0]?> /> <label for="r4">無効</label></td>
	</tr>
	<tr>
		<th align="left" width="300">編集完了時の保存禁止<br>
		※編集完了時の容量チェックで設定値を超えている場合、編集完了できなくします。</th>
		<td><input type="radio" name="err_handle" value="1" id="r5"
			<?=$r_err_handle[1]?> /> <label for="r5">実行</label> <input
			type="radio" name="err_handle" value="0" id="r6"
			<?=$r_err_handle[0]?> /> <label for="r6">無効</label></td>
	</tr>
</table>
<p align="center"><a href="javascript:document.form.submit()"><img
	src="../../master/images/btn_conf.jpg" alt="確認" width="150" height="20"
	border="0" style="margin-right: 10px"></a><a
	href="index.php?mode=others"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0"></a></p>

</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<input type="hidden" name="exist_setting" value="<?=$exist_setting?>">
</form>
</body>
</html>
