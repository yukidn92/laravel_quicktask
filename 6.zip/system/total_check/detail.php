<?php
/*
 * システム管理　各種チェック設定
 * 各種チェック設定詳細画面
 */
/*---------------------------------------------
	定数 
----------------------------------------------*/
//csvファイルupload先
define("CSV_UPLOAD", "./tmp/");
//csvファイル最大行
define("G_CSV_MAX_LINE", 20000);

/** require **/
require ("./.htsetting");

//表示設定
require ("./include/detailset.inc");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// 「index」画面表示モード
$mode = "acc";
//createList
switch ($class) {
	case CHECK_CLASS_HEAD :
		$th_format = '<tr><th align="center" valign="middle" nowrap scope="col">対象文字</th></tr>';
		$td_format = '<tr>' . "\n" . '<td align="left" valign="top">{$word}</td>' . "\n" . '</tr>' . "\n";
		break;
	case CHECK_CLASS_LINK_TEXT :
	case CHECK_CLASS_ALT_TEXT :
		$th_format = '<tr><th align="center" valign="middle" nowrap scope="col">対象文字</th></tr>';
		$td_format = '<tr>' . "\n" . '<td align="left" valign="top">{$word}</td>' . "\n" . '</tr>' . "\n";
		break;
	case CHECK_CLASS_SPELL :
		$th_format = '<tr><th align="center" valign="middle" nowrap scope="col">スペルチェック除外文字列</th></tr>';
		$td_format = '<tr>' . "\n" . '<td align="left" valign="top">{$word}</td>' . "\n" . '</tr>' . "\n";
		$mode = "spell";
		break;
	case CHECK_CLASS_STRING :
		$th_format = '<tr>';
		$th_format .= '<th align="center" valign="middle" nowrap scope="col">対象文字</th>';
		$th_format .= '<th>変換文字(日本語)</th>';
		$th_format .= '<th>変換文字(第3国言語)</th>';
		$th_format .= '<th>チェック結果</th>';
		$th_format .= '</tr>';
		
		$td_format = '<tr>' . "\n";
		$td_format .= '<td align="left" valign="top">{$word}</td>' . "\n";
		$td_format .= '<td align="left" valign="top">{$rep_word}</td>' . "\n";
		$td_format .= '<td align="left" valign="top">{$rep_word2}</td>' . "\n";
		$td_format .= '<td align="left" valign="top">{$convert_flg}</td>' . "\n";
		$td_format .= '</tr>' . "\n";
		break;
	default :
		$th_format = '<tr>';
		$th_format .= '<th align="center" valign="middle" nowrap scope="col">対象文字</th>';
		$th_format .= '<th>変換文字(日本語)</th>';
		$th_format .= '<th>変換文字(第3国言語)</th>';
		$th_format .= '</tr>';
		
		$td_format = '<tr>' . "\n";
		$td_format .= '<td align="left" valign="top">{$word}</td>' . "\n";
		$td_format .= '<td align="left" valign="top">{$rep_word}</td>' . "\n";
		$td_format .= '<td align="left" valign="top">{$rep_word2}</td>' . "\n";
		$td_format .= '</tr>' . "\n";
}
// 変換処理対応表
$convert_ary = array(
		"0" => "表示する", 
		"1" => "変換する"
);

$sql = "SELECT * FROM tbl_check_words WHERE class = " . $class . " ORDER BY word";
$objDac->execute($sql);
$html = '';
if ($objDac->getRowCount() > 0) {
	$html = $th_format;
	while ($objDac->fetch()) {
		$td_str = str_replace('{$word}', htmlspecialchars($objDac->fld['word']), $td_format);
		$td_str = str_replace('{$rep_word}', htmlspecialchars($objDac->fld['rep_word']), $td_str);
		$td_str = str_replace('{$rep_word2}', htmlspecialchars($objDac->fld['rep_word2']), $td_str);
		$html .= str_replace('{$convert_flg}', (isset($convert_ary[$objDac->fld['convert_flg']]) ? $convert_ary[$objDac->fld['convert_flg']] : $convert_ary[FLAG_ON]), $td_str);
	}
}
else {
	$html = '<tr><td align="center" valign="top">現在、対象文字は登録されていません。</td></tr>';
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>各種チェック詳細設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="total_check.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxTotalChkForm(bv, id) {
	if (bv == 1 || bv == 2) {
		$('TotalCheck').action = 'form.php';
	} else if (bv == 3) {
		$('TotalCheck').action = 'confirm.php';
	} else if (bv == 4) {
		$('TotalCheck').action = 'import.php';
	} else if (bv == 5) {
		$('TotalCheck').action = 'export.php';
	} else { 
		alert('パラメータエラー（behavior）');
		return false;
	}
	$('word_id').value = id;
	$('behavior').value = bv;
	document.TotalCheck.submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'total_check';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-total_check">
<div><img src="images/<?=$bar_img?>.jpg" alt="<?=$bar_alt?>" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p align="right"><!--<a href="javascript:" onClick="return cxTotalChkForm(1,'')"><img src="images/btn_add.jpg" alt="新規追加" width="150" height="20" border="0" style="margin-right:10px"></a>-->
<a href="javascript:" onClick="return cxTotalChkForm(4,'')"><img
	src="images/btn_import.jpg" alt="詳細設定のインポート" width="150" height="20"
	border="0" style="margin-right: 10px"></a> <a href="javascript:"
	onClick="return cxTotalChkForm(5,'')"><img src="images/btn_export.jpg"
	alt="詳細設定のエクスポート" width="150" height="20" border="0"></a></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$html?>
</table>
<?php
$temp_ary = array(
		CHECK_CLASS_LINK_TEXT
);
if (in_array($class, $temp_ary)) {
	?>
<span class="cms8341-error">※空文字やスペース等のページ上に表示されない文字は機械的にチェックします</span>
<?php
}
?>
<p align="center"><a href="index.php?mode=<?=$mode?>"><img
	src="../../master/images/btn_back.jpg" alt="戻る" width="150" height="20"
	border="0"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="TotalCheck" class="cms8341-form" name="TotalCheck" action=""
	method="post"><input type="hidden" id="behavior" name="behavior"
	value=""> <input type="hidden" id="word_id" name="word_id" value=""> <input
	type="hidden" id="class" name="class" value="<?=$class?>"></form>
</body>
</html>
