<?php
/*
 * システム管理　チェックツール詳細設定のエクスポート(export.php)
 */
/*---------------------------------------------------------------------------------
	export.php
---------------------------------------------------------------------------------*/
//--- 設定ファイル読み込み
require ("./.htsetting");
//--- 変数宣言
$G_SetHead = array(); //CSV見出し
$ExpCavData = array(); //CSVデータ
$CsvLine = 0; //CSV行数カウント
$char_code = ''; //CSV出力文字コード
$esc_char = '"'; //CSVエスケープ文字


if (!isset($_POST['behavior']) || $_POST['behavior'] != 5) {
	DispError("パラメータ取得エラー（behavior）", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//表示設定
require ("./include/detailset.inc");

//見出し文字
switch ($class) {
	case CHECK_CLASS_HEAD :
	case CHECK_CLASS_LINK_TEXT :
	case CHECK_CLASS_ALT_TEXT :
		$G_SetHead = array(
				"対象文字列"
		);
		break;
	case CHECK_CLASS_SPELL :
		$G_SetHead = array(
				"スペルチェック除外文字列"
		);
		break;
	case CHECK_CLASS_STRING :
		$G_SetHead = array(
				"対象文字列", 
				"変換文字列(日本語)", 
				"変換文字列(第3国言語)", 
				"チェック結果"
		);
		break;
	default :
		$G_SetHead = array(
				"対象文字列", 
				"変換文字列(日本語)", 
				"変換文字列(第3国言語)"
		);
}

// データアクセスクラス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

/*---CSVファイルの作成---*/
//tbl_check_wordsの取得
$sql = "SELECT * FROM tbl_check_words WHERE class = " . $class . " ORDER BY word";
$objDac->execute($sql);
if ($objDac->getRowCount() <= 0) {
	DispError("現在、対象文字は登録されていません。", "acc", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//詳細設定情報の作成
while ($objDac->fetch()) {
	switch ($class) {
		case CHECK_CLASS_HEAD :
		case CHECK_CLASS_LINK_TEXT :
		case CHECK_CLASS_ALT_TEXT :
		case CHECK_CLASS_SPELL :
			//対象文字列
			$ExpCavData[$CsvLine] = array(
					$objDac->fld['word']
			);
			break;
		case CHECK_CLASS_STRING :
			//対象文字列 , 変換文字(日本語) , 変換文字(第3国言語) , 実行処理
			$ExpCavData[$CsvLine] = array(
					$objDac->fld['word'], 
					$objDac->fld['rep_word'], 
					$objDac->fld['rep_word2'], 
					$objDac->fld['convert_flg']
			);
			break;
		default :
			//対象文字列 , 変換文字(日本語) , 変換文字(第3国言語)
			$ExpCavData[$CsvLine] = array(
					$objDac->fld['word'], 
					$objDac->fld['rep_word'], 
					$objDac->fld['rep_word2']
			);
	}
	$CsvLine++;
}

/*---CSVファイルのダウンロード---*/
if ($class == CHECK_CLASS_M_CODE) {
	$char_code = 'utf-8';
}
else {
	$char_code = 'sjis-win';
}
create_Csv($acc_filename, $ExpCavData, $G_SetHead, 0, "", $char_code, $esc_char);

?>
