<?php
/*
 * システム管理　各種チェック設定
 * 各チェックの「ON/OFF」を設定する
 */
/** require **/
require ("./.htsetting");
//
unset($_SESSION["hidden"]);

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// モード取得
$mode = "acc";
if (isset($_GET['mode']) && $_GET['mode'] != "") {
	$mode = $_GET['mode'];
	$temp_ary = array(
			"acc", 
			"header", 
			"contrast", 
			"spell", 
			"others"
	);
	if (!in_array($mode, $temp_ary)) $mode = "acc";
}

//アクセシビリティチェック設定
$aryAcc = array();
$total_chk_radio = array();
$total_chk_detail = array();
$checkON = array(
		0 => '', 
		1 => ' checked'
);
$checkOFF = array(
		0 => ' checked', 
		1 => ''
);
$sql = "SELECT * FROM tbl_check_config ORDER BY class";
$objDac->execute($sql);
while ($objDac->fetch()) {
	$aryAcc[$objDac->fld['class']] = $objDac->fld['check_flg'];
}
for($i = CHECK_CLASS_SPELL; $i <= CHECK_CLASS_DISP_ALT; $i++) {
	if (isset($aryAcc[$i]) && $aryAcc[$i] == 1) {
		$checked = $checkON;
		if ($i != CHECK_CLASS_SIZE && $i != CHECK_CLASS_UPLOAD && $i != CHECK_CLASS_CONTRAST) {
			$total_chk_detail[$i] = '<a href="detail.php?class=' . $i . '">';
		}
		elseif ($i != CHECK_CLASS_SIZE && $i != CHECK_CLASS_CONTRAST) {
			$total_chk_detail[$i] = '<a href="up_sz_chk_edit.php">';
		}
		elseif ($i != CHECK_CLASS_CONTRAST) {
			$total_chk_detail[$i] = '<a href="page_sz_chk_edit.php">';
		}
		else {
			$total_chk_detail[$i] = '<a href="contrast_chk_edit.php">';
		}
		$total_chk_detail[$i] .= '<img src="images/btn_deteil_on.jpg" alt="詳細設定" width="150" height="20" border="0"></a>';
	}
	else {
		$checked = $checkOFF;
		$total_chk_detail[$i] = '<img src="images/btn_deteil_off.jpg" alt="詳細設定" width="150" height="20" border="0">';
	}
	$total_chk_radio[$i] = '<input type="radio" name="check_config[' . $i . ']" value="1" id="check_config' . $i . '_1"' . $checked[1] . '><label for="check_config' . $i . '_1">ON</label> / ' . '<input type="radio" name="check_config[' . $i . ']" value="0" id="check_config' . $i . '_0"' . $checked[0] . '><label for="check_config' . $i . '_0">OFF</label>';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>各種チェック設定</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="total_check.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'total_check';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<?php
if ($mode == "acc") {
	?>
<div align="center" id="cms8341-acc_check">
<div><img src="images/bar_acc_check.jpg" alt="アクセシビリティチェック設定"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form id="fAccCheck" class="cms8341-form" name="fAccCheck"
	action="config_exec.php" method="post"><input type="hidden" name="mode"
	id="mode_acc" value="acc" />
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" nowrap scope="col">チェック項目</th>
		<th align="center" valign="middle">設定</th>
		<th>&nbsp;</th>
	
	
	<tr>
		<td align="center" valign="middle" nowrap scope="col">機種依存文字変換</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_M_CODE]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_M_CODE]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">全角スペース削除</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_SPACE]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">時間表記変換</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_TIME]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">日付表記変換</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_DATE]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">曜日表記変換</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_WEEK]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">行頭文字削除</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_HEAD]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_HEAD]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">全角英数字変換</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_ZENKAKU]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_ZENKAKU]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">半角カナ変換</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_HANKAKU]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_HANKAKU]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">文中表記チェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_STRING]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_STRING]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">リンクテキストチェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_LINK_TEXT]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_LINK_TEXT]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">画像代替テキストチェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_ALT_TEXT]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_ALT_TEXT]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">半角スペース削除</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_HANKAKU_SPACE]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">テーブル構造チェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_TABLE]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">代替テキスト表示</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_DISP_ALT]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_config.jpg"
	alt="設定を変更" width="150" height="20" border="0"></p>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
<br />
<?php
}
elseif ($mode == "header") {
	?>
<div align="center" id="cms8341-header_check">
<div><img src="images/bar_header_check.jpg" alt="見出しチェック設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form id="HeaderCheck" class="cms8341-form" name="HeaderCheck"
	action="config_exec.php" method="post"><input type="hidden" name="mode"
	id="mode_header" value="header" />
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" nowrap scope="col">チェック項目</th>
		<th align="center" valign="middle">設定</th>
		<th>&nbsp;</th>
	
	
	<tr>
		<td align="center" valign="middle" nowrap scope="col">見出しチェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_HEADER]?></td>
		<td width="250" align="center" valign="middle">&nbsp;</td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_config.jpg"
	alt="設定を変更" width="150" height="20" border="0"></p>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
<br />
<?php
}
elseif ($mode == "contrast") {
	?>
<div align="center" id="cms8341-contrast_check">
<div><img src="images/bar_contrast_check.jpg" alt="コントラストチェック設定"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form id="ContrastCheck" class="cms8341-form" name="ContrastCheck"
	action="config_exec.php" method="post"><input type="hidden" name="mode"
	id="mode_contrast" value="contrast" />
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" nowrap scope="col">チェック項目</th>
		<th align="center" valign="middle">設定</th>
		<th>&nbsp;</th>
	
	
	<tr>
		<td align="center" valign="middle" nowrap scope="col">コントラストチェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_CONTRAST]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_CONTRAST]?></td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_config.jpg"
	alt="設定を変更" width="150" height="20" border="0"></p>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
<br />
<?php
}
elseif ($mode == "spell") {
	?>
<div align="center" id="cms8341-spell_check">
<div><img src="images/bar_spell_check.jpg" alt="スペルチェック設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form id="SpellCheck" class="cms8341-form" name="SpellCheck"
	action="config_exec.php" method="post"><input type="hidden" name="mode"
	id="mode_spell" value="spell" />
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" nowrap scope="col">チェック項目</th>
		<th align="center" valign="middle">設定</th>
		<th>&nbsp;</th>
	
	
	<tr>
		<td align="center" valign="middle" nowrap scope="col">スペルチェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_SPELL]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_SPELL]?></td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_config.jpg"
	alt="設定を変更" width="150" height="20" border="0"></p>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
<br />
<?php
}
elseif ($mode == "others") {
	?>
<div align="center" id="cms8341-others_check">
<div><img src="images/bar_others_check.jpg" alt="その他のチェック設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form id="OthersCheck" class="cms8341-form" name="OthersCheck"
	action="config_exec.php" method="post"><input type="hidden" name="mode"
	id="mode_others" value="others" />
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" nowrap scope="col">チェック項目</th>
		<th align="center" valign="middle">設定</th>
		<th>&nbsp;</th>
	
	
	<tr>
		<td align="center" valign="middle" nowrap scope="col">ページ容量チェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_SIZE]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_SIZE]?></td>
	</tr>
	<tr>
		<td align="center" valign="middle" nowrap scope="col">アップロードチェック</td>
		<td width="250" align="center" valign="middle"><?=$total_chk_radio[CHECK_CLASS_UPLOAD]?></td>
		<td width="250" align="center" valign="middle"><?=$total_chk_detail[CHECK_CLASS_UPLOAD]?></td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_config.jpg"
	alt="設定を変更" width="150" height="20" border="0"></p>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
<?php
}
?>


</div>
<!-- cms8341-contents -->
</body>
</html>
