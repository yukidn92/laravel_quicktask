<?php
/*
 * システム管理　ページ容量チェック設定
 * ページ容量チェック設定DB登録
 */
/** require **/
require ("./.htsetting");

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// POSTデータが存在するとき
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	foreach ($_POST as $k => $v) {
		if (get_magic_quotes_gpc()) $v = stripslashes($v);
		$$k = $v;
	}
	
	// データの登録
	

	if (isset($exist_setting) && $exist_setting) {
		$sql = "UPDATE tbl_check_pagesize SET ";
		$sql .= "text_size=" . $text_size;
		$sql .= "," . "use_file_size=" . $use_file_size;
		$sql .= "," . "text_size_k=" . $text_size_k;
		$sql .= "," . "use_file_size_k=" . $use_file_size_k;
		$sql .= "," . "tmp_size_chk=" . $tmp_size_chk;
		$sql .= "," . "edit_size_chk=" . $edit_size_chk;
		$sql .= "," . "err_handle=" . $err_handle;
	}
	else {
		$sql = "INSERT INTO tbl_check_pagesize";
		$sql .= " (text_size, use_file_size, text_size_k, use_file_size_k, tmp_size_chk, edit_size_chk, err_handle)";
		$sql .= " VALUES (" . $text_size . "," . $use_file_size . "," . $text_size_k . "," . $use_file_size_k . "," . $tmp_size_chk . "," . $edit_size_chk . "," . $err_handle . ")";
	}
	
	if (!$objDac->execute($sql)) {
		DispError("ページ容量チェック設定登録エラー", 3, "javascript:history.back()");
		exit();
	}
}

$checkNone = array(
		0 => '', 
		1 => ''
);
$checkON = array(
		0 => '', 
		1 => ' checked'
);
$checkOFF = array(
		0 => ' checked', 
		1 => ''
);
$r_tmp_size_chk = $r_edit_size_chk = $r_err_handle = $checkNone;

header("Location: " . HTTP_ROOT . RPW . "/admin/system/total_check/index.php?mode=others");
exit();
?>
