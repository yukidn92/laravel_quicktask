<?php
/*
 *
 */
if (!isset($_GET['ppp']) || $_GET['ppp'] != "glode") exit();
require_once 'include/settingFunc.inc';
$settingFunc = new settingFunc();
$dir = $settingFunc->get_ducument_root() . '/cms8341_sys/common/';
$setting_vars = $settingFunc->get_setting($dir);
//ファイルを開く
if (!($fp = fopen($setting_vars, "r"))) {
	user_error("設定ファイルの読み込みに失敗");
}

//ファイルの読み込みと出力
while (!feof($fp)) {
	$r = array();
	$line = fgets($fp, 4096);
	if (strpos($line, 'define(') === FALSE) continue;
	if (!preg_match('/define\("([^"]*)" *,(.*)\);/i', $line, $r, PREG_OFFSET_CAPTURE)) continue;
	$mode = (preg_match('/^\/\//i', $line)) ? "comment" : "nomal";
	$key = $r[1][0];
	$val = $r[2][0];
	$ret_ary[$key]['val'] = trim($val);
	$ret_ary[$key]['mode'] = $mode;
}

//ファイルを閉じる
fclose($fp);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>設定ファイル変更</title>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function add() {
	id = window.prompt("定数名を入力してください","");
	if(id == null || id == "") return;
	add_str  =  '<div style="float:left;width:100%;height:30px;margin:5px;padding:0px;border: 1px solid;font-weight: bold;word-break:break-all">';
	add_str +=  '<div style="float:left;width:250px;height:30px;margin:0px;padding:5px;font-weight: bold;word-break:break-all;border-right:1px solid gray;">'+id+'</div>';
	add_str +=  '<div style="float:left;width:60px;height:30px;margin:0px;padding:5px;font-size:80%;border-right:1px solid gray;">';
	add_str +=  	'<select name="cms_mode_'+id+'">';
	add_str +=  		'<option value="nomal" selected>有効';
	add_str +=  		'<option value="comment">コメント';
	add_str +=  		'<option value="delete">削除';
	add_str +=  	'</select>';
	add_str +=  '</div>';
	add_str +=  '<div style="float:left;width:500px;height:30px;margin:0px;padding:5px;font-weight: bold;font-size:80%">';
	add_str +=  	'<input type="text" name="cms_key_'+id+'" value="" style="width:95%">';
	add_str +=  '</div>';
	add_str +=  '<div style="clear:left;"></div>';
	add_str +=  '</div>';
	new Insertion.Bottom('item', add_str); 	
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<form id="fUpdate" class="cms8341-form" name="fUpdate"
	action="confirm.php" method="post" enctype="multipart/form-data">

<div id="item" style="float: left; width: 95%;">
<?php
foreach ($ret_ary as $key => $ret) {
	echo '<div style="float:left;width:100%;height:30px;margin:5px;padding:0px;border: 1px solid;font-weight: bold;word-break:break-all">' . "\n";
	echo '<div style="float:left;width:250px;height:30px;margin:0px;padding:5px;font-weight: bold;word-break:break-all;border-right:1px solid gray;">' . htmlspecialchars($key) . '</div>' . "\n";
	echo '<div style="float:left;width:60px;height:30px;margin:0px;padding:5px;font-size:80%;border-right:1px solid gray;">';
	echo '<select name="cms_mode_' . $key . '">';
	echo '<option value="nomal"' . (($ret['mode'] == "nomal") ? " selected" : "") . '>有効';
	echo '<option value="comment"' . (($ret['mode'] == "comment") ? " selected" : "") . '>コメント';
	echo '<option value="delete">削除';
	echo '</select>';
	echo '</div>' . "\n";
	echo '<div style="float:left;width:500px;height:30px;margin:0px;padding:5px;font-weight: bold;font-size:80%">';
	echo '<input type="text" name="cms_key_' . $key . '" value="' . htmlspecialchars($ret['val']) . '" style="width:95%">';
	echo '</div>' . "\n";
	echo '<div style="clear:left;"></div>';
	echo '</div>' . "\n";
}
?>
</div>
<br>
<input type="button" value="項目追加" onClick="return add();"> <input
	type="submit" value="設定変更"></form>
</body>
</html>
