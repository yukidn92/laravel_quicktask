<?php
/*
 *
 */
require_once 'include/settingFunc.inc';
$settingFunc = new settingFunc();
$dir = $settingFunc->get_ducument_root() . '/cms8341_sys/common/';
$setting_vars = $settingFunc->get_setting($dir);
$contents = file_get_contents($setting_vars);
$add_contents = "";

foreach ($_POST as $key => $val) {
	if (strpos($key, "cms_key_") === FALSE) continue;
	$key = str_replace("cms_key_", "", $key);
	if (strpos($contents, 'define("' . $key . '"') !== FALSE) {
		$contents = preg_replace('/define\("' . $key . '" *,(.*)\);/i', 'define("' . $key . '",' . $val . ');', $contents);
	}
	else {
		$add_contents = "\t" . 'define("' . $key . '",' . $val . ');';
	}
}
$pos = strrpos($contents, "?>");
$rep_str = ($add_contents != "") ? $add_contents . "\n?>" : $add_contents . "?>";
$contents = substr_replace($contents, $rep_str, $pos);

//ファイルを開く
if (!($fp = fopen($setting_vars, "w"))) {
	user_error("設定ファイルの読み込みに失敗");
}

fwrite($fp, $contents);
fclose($fp);

//ファイルを開く
if (!($fp = fopen($setting_vars, "r"))) {
	user_error("設定ファイルの読み込みに失敗");
}

$ret = "";
//ファイルの読み込みと出力
while (!feof($fp)) {
	$r = array();
	$line = fgets($fp, 4096);
	if (strpos($line, 'define(') === FALSE) {
		$ret .= $line;
		continue;
	}
	preg_match('/define\("([^"]*)"/i', $line, $r, PREG_OFFSET_CAPTURE);
	$key = $r[1][0];
	$mode = (isset($_POST["cms_mode_" . $key])) ? $_POST["cms_mode_" . $key] : "nomal";
	switch ($mode) {
		case "nomal" :
			$line = preg_replace('/^\/\//', '', $line);
			break;
		case "comment" :
			if (!preg_match('/^\/\//', $line)) $line = "//" . $line;
			break;
		case "delete" :
			$line = "";
			break;
	}
	$ret .= $line;
}

//ファイルを閉じる
fclose($fp);

if ($contents != $ret) {
	//ファイルを開く
	if (!($fp = fopen($setting_vars, "w"))) {
		user_error("設定ファイルの読み込みに失敗");
	}
	fwrite($fp, $ret);
	fclose($fp);
}

header("Location: ./index.php?ppp=glode");
exit();
?>
