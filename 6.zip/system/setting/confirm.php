<?php
/*
 *
 */
require_once 'include/settingFunc.inc';
$settingFunc = new settingFunc();
$dir = $settingFunc->get_ducument_root() . '/cms8341_sys/common/';
$setting_vars = $settingFunc->get_setting($dir);
//ファイルを開く
if (!($fp = fopen($setting_vars, "r"))) {
	user_error("設定ファイルの読み込みに失敗");
}

//ファイルの読み込みと出力
while (!feof($fp)) {
	$r = array();
	$line = fgets($fp, 4096);
	if (strpos($line, 'define(') === FALSE) continue;
	if (!preg_match('/define\("([^"]*)" *,(.*)\);/i', $line, $r, PREG_OFFSET_CAPTURE)) continue;
	$mode = (preg_match('/^\/\//i', $line)) ? "comment" : "nomal";
	$key = $r[1][0];
	$val = $r[2][0];
	$ret_ary[$key]['val'] = trim($val);
	$ret_ary[$key]['mode'] = $mode;
}
//ファイルを閉じる
fclose($fp);

$def_ary = array();
foreach ($_POST as $key => $val) {
	if (strpos($key, "cms_key_") === FALSE) continue;
	$key = str_replace("cms_key_", "", $key);
	$mode = $_POST["cms_mode_" . $key];
	if (isset($ret_ary[$key])) {
		$b_ret = $ret_ary[$key];
		if ($val == $b_ret['val'] && $mode == $b_ret['mode']) continue;
		$b_ret['a_val'] = $val;
		$b_ret['a_mode'] = $mode;
	}
	else {
		$b_ret = array(
				'val' => '新規項目', 
				'mode' => '新規項目', 
				'a_val' => $val, 
				'a_mode' => $mode
		);
	}
	$def_ary[$key] = $b_ret;
}

function get_mode_name($mode) {
	if ($mode == "nomal") return "有効";
	if ($mode == "comment") return "コメント";
	if ($mode == "delete") return "削除";
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>設定ファイル変更</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function add() {
	id = window.prompt("定数名を入力してください","");
	if(id == "") return;
	add_str = '<div style="float:left;width:300px;height:30px;padding:0px;border: 1px solid;font-weight: bold;font-size:80%">'+id+'</div>';
	add_str += '<div style="height:30px;padding:0px;border: 1px solid;"><input type="text" name="cms_key_'+id+'" value="" style="width:99%"></div>';
	add_str += '<div style="clear:left;"></div>';
	new Insertion.Bottom('item', add_str); 	
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<form id="fUpdate" class="cms8341-form" name="fUpdate"
	action="submit.php" method="post" enctype="multipart/form-data">

<div id="item" style="float: left; width: 95%;">
<?php
foreach ($def_ary as $key => $def) {
	echo '<div style="float:left;width:100%;height:30px;margin:5px;padding:0px;border: 1px solid;font-weight: bold;word-break:break-all">' . "\n";
	echo '<div style="float:left;width:250px;height:50px;margin:0px;padding:5px;font-weight: bold;word-break:break-all;border-right:1px solid gray;">' . htmlspecialchars($key) . '</div>' . "\n";
	echo '<div style="float:left;width:100px;height:50px;margin:0px;padding:5px;font-size:80%;border-right:1px solid gray;">';
	if ($def['mode'] == $def['a_mode']) {
		echo get_mode_name($def['mode']);
	}
	else {
		echo get_mode_name($def['mode']) . "<br>↓<br>" . get_mode_name($def['a_mode']);
	}
	echo '</div>' . "\n";
	echo '<div style="float:left;width:500px;height:50px;margin:0px;padding:5px;font-size:80%">';
	if ($def['val'] == $def['a_val']) {
		echo $def['val'];
	}
	else {
		echo $def['val'] . "<br>↓<br>" . $def['a_val'];
	}
	echo '</div>' . "\n";
	echo '<div style="clear:left;"></div>';
	echo '</div>' . "\n";
}
?>
</div>
<div style="clear: left;"></div>
<br>
<?php
foreach ($_POST as $key => $val) {
	echo '<input type="hidden" name="' . $key . '" value="' . htmlspecialchars($val) . '">' . "\n";
}
?>
<input type="button" value="戻る" onClick="history.back();">
<?php
if (count($def_ary) > 0) {
	?>
<input type="submit" value="実行">
<?php
}
?>

</form>
</body>
</html>
