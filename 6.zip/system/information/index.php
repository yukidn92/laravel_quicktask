<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
unset($_SESSION["hidden"]);
unset($_SESSION["cms_maintenance"]);

//変数の宣言
$ssl_str = "";
$total_str = "";
$mail_str = "";
$setting_str = "";
$info = "";
$cms_maintenance = FLAG_OFF;

//DBアクセス
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objDac->setTableName("tbl_infomation");
$objDac->select();

//レコード数の取得
$Cnt = $objDac->getRowCount();
//お知らせ情報あり
if ($Cnt != 0) {
	//レコード数分ループ
	while ($objDac->fetch()) {
		//お知らせ情報の取得
		if ($objDac->fld["class"] == INFOMATION_CLASS_INFO) $info = $objDac->fld["info"];
		//メンテナンス情報の取得
		else if ($objDac->fld["class"] == INFOMATION_CLASS_MAINTE) $cms_maintenance = $objDac->fld["info"];
	}
}
$info = str_replace("<br>", "\n", $info);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>お知らせ設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxDelete(){
	$('cms_maintenance').checked = false;
	if($('cms_info').innerHTML == "") {
		alert("現在、お知らせ内容は入力されていません。");
		return;
	}
	if (!confirm("設定されているお知らせ内容を削除します。\nよろしいですか？")) {
		return false;
	}
	$('cms_info').innerHTML = "";
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'information';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><img src="images/bar_fix.jpg" alt="お知らせ設定" width="920" height="30"></div>
<div class="cms8341-area-corner">
<form id="tpl_form" class="cms8341-form" name="tpl_form" method="post"
	action="confirm.php" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">お知らせ内容</th>
		<td align="left" valign="middle"><textarea name="cms_info" rows="20"
			id="cms_info" style="width: 600px;"><?=$info?></textarea></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">ログイン制御</th>
		<td><input type="checkbox" name="cms_maintenance" id="cms_maintenance"
			value="1"
			<?php
			print((($cms_maintenance == FLAG_ON) ? ("checked") : ("")));
			?>><label for="cms_maintenance">メンテナンス状態にする</label><br>
		<small>
メンテナンス状態の時は、以下のページからログインできます。
<?php
print('<br><a href="' . HTTP_ROOT . RPW . '/admin/maintenance_login.html">' . HTTP_ROOT . RPW . '/admin/maintenance_login.html</a>');
?>
</small></td>
	</tr>
</table>
<p align="center"><input type="image"
	src="<?=RPW?>/admin/master/images/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px"> <img
	src="./images/btn_clear.jpg" alt="クリア" onClick="cxDelete()" width="150"
	height="20" border="0" style="margin-right: 10px; cursor: pointer"></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
