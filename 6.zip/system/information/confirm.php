<?php
/*
 *
 */
/** require **/
require ("./.htsetting");
unset($_SESSION["hidden"]);

//引数エラーチェック
$err = "";
//内容
if (!isset($_POST['cms_info'])) {
	$err = "お知らせ内容が設定されていません。<br>";
}
//メンテナンスチェックボックス
if (isset($_POST['cms_maintenance']) && $_POST['cms_maintenance'] != "") {
	//値チェック
	if ($_POST['cms_maintenance'] != FLAG_ON) $err = "不正な情報が入力されています。<br>";
}

//エラーがあれば、エラーを表示
if ($err != "") {
	DispError($err, "info", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

//値のセット
$info = $_POST['cms_info'];
$info = str_replace("\n", "<br>", $info);
$_SESSION["hidden"] = $info;
//メンテナンス状態
if (isset($_POST['cms_maintenance']) && $_POST['cms_maintenance'] != "") $_SESSION["cms_maintenance"] = FLAG_ON;
//ノーマル状態
else $_SESSION["cms_maintenance"] = FLAG_OFF;
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>お知らせ確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="enquete.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'information';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><img src="images/bar_conf.jpg" alt="お知らせ設定確認" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form id="tpl_form" class="cms8341-form" name="tpl_form" method="post"
	action="submit.php" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">お知らせ内容</th>
		<td align="left" valign="middle"><?=$info?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">ログイン制御</th>
		<td><?php
		print(($_SESSION["cms_maintenance"] == FLAG_ON) ? ("メンテナンス状態にする") : ("メンテナンス状態にしない"));
		?></td>
	</tr>
</table>
<p align="center"><input type="image" src="../images/btn_config.jpg"
	alt="設定を変更" width="150" height="20" border="0"
	style="margin-right: 10px"><a href="javascript:history.back()"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
