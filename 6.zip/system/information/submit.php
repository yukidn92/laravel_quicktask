<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

$err = "";
/** init **/
//引数エラーチェック
//内容
if (!isset($_SESSION["hidden"]) || !isset($_SESSION["cms_maintenance"])) {
	$err = "お知らせ内容が設定されていません。<br>";
}
//メンテナンスチェックボックス
if (isset($_SESSION['cms_maintenance']) && $_SESSION['cms_maintenance'] != "") {
	//値チェック
	if (!in_array($_SESSION['cms_maintenance'], array(
			FLAG_ON, 
			FLAG_OFF
	))) $err = "不正な情報が入力されています。<br>";
}

//エラーがあれば、エラー表示
if ($err != "") {
	DispError($err, "info", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
$info = $_SESSION["hidden"];
$cms_maintenance = $_SESSION['cms_maintenance'];

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
$objCnc->begin();
$sql = "delete from tbl_infomation";
if (!$objDac->execute($sql)) {
	$objCnc->rollback();
	DispError("データの変更に失敗しました。", "info", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
$sql = "insert into tbl_infomation (info,class) values " . //お知らせ情報
"('" . $info . "','" . INFOMATION_CLASS_INFO . "') , " . //メンテナンス情報
"(" . $objCnc->cncid->quote($cms_maintenance) . ",'" . INFOMATION_CLASS_MAINTE . "')";
if (!$objDac->execute($sql)) {
	$objCnc->rollback();
	DispError("データの変更に失敗しました。", "info", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
$objCnc->commit();

//後処理
unset($_SESSION["cms_maintenance"]);

header("Location: " . HTTP_ROOT . RPW . "/admin/system/information/index.php");
?>