<?php
// -----------------------------------------------------------------------------
// 
// 大規模災害用分類登録（完了処理）
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
// 有効な処理種別
$enable_mode_ary = array(
		'new', 
		'upd', 
		'del'
);
// 大規模災害用一覧表示ページ情報配列
$DISASTER_LIST_ARY = getDefineArray('DISASTER_LIST_ARY');
// 登録先分類階層（第1分類）
$level = 1;
// 処理種別
$mode = '';
// 分類コード
$cate_code = '';
// 分類名
$cate_name = '';

// -----------------------------------------------
// エラーチェック
// -----------------------------------------------
// 処理種別
if (!isset($_POST['cms_mode'])) {
	disasterError("パラメーターエラー【mode】");
}
if (!in_array($_POST['cms_mode'], $enable_mode_ary)) {
	disasterError("不正な処理種別のため処理を実行できませんでした。");
}
$mode = $_POST['cms_mode'];

// 分類コード
if (!isset($_POST['cms_cate_code'])) {
	disasterError("パラメーターエラー【cate_code】");
}
$cate_code = $_POST['cms_cate_code'];

// 分類名
if (!isset($_POST['cms_cate_name'])) {
	disasterError("パラメーターエラー【cate_name】");
}
$cate_name = $_POST['cms_cate_name'];

// -----------------------------------------------
// トランザクション【開始】
// -----------------------------------------------
$objCnc->begin();

// -----------------------------------------------
// 種別ごとの処理を実行
// -----------------------------------------------
switch ($mode) {
	// -------------------------------------------
	// 新規
	// -------------------------------------------
	case 'new':
		// 登録する分類コードが既に登録されていないかチェック
		if ($obj_cate->selectFromCode($cate_code)) {
			$objCnc->rollback();
			disasterError(htmlDisplay('分類コード「' . $cate_code) . '」は既に登録されています。<br />登録をやり直してください。');
		}
		
		// 分類名の入力チェック
		if ($cate_name == "") {
			$objCnc->rollback();
			disasterError("分類名の省略はできません。");
		}
		
		// データベース登録用配列
		$db_ary = array(
				'level'        => $level, 
				'cate_code'    => $cate_code, 
				'name'         => $cate_name, 
				'sort_order'   => getNextCateSortOrder($level, FLAG_ON), 
				'disaster_flg' => FLAG_ON
		);
		
		// 分類情報の登録
		if (!$obj_cate->insert($db_ary)) {
			$objCnc->rollback();
			disasterError('大規模災害用分類の登録に失敗しました。');
		}
		
		// 大規模災害用一覧表示ページの件数の初期値を登録
		foreach ($DISASTER_LIST_ARY as $kind => $ary) {
			if (!$obj_dis_handle->entryDisasterListMaxResult($cate_code, $kind, $ary['def_max_result'])) {
				$objCnc->rollback();
				disasterError('大規模災害用分類の登録に失敗しました。');
			}
		}
		break;
	// -------------------------------------------
	// 更新
	// -------------------------------------------
	case 'upd':
		// 大規模災害用でない分類の場合はエラー
		if (!$obj_cate->isDisasterCategory($cate_code)) {
			$objCnc->rollback();
			disasterError("大規模災害用でない分類を修正することはできません。");
		}
		
		// 分類名の入力チェック
		if ($cate_name == "") {
			$objCnc->rollback();
			disasterError("分類名の省略はできません。");
		}
		
		// データベース登録用配列
		$db_ary = array(
				'cate_code'    => $cate_code, 
				'name'         => $cate_name, 
				'disaster_flg' => FLAG_ON
		);
		
		// 分類情報の更新
		if (!$obj_cate->update($db_ary)) {
			$objCnc->rollback();
			disasterError('大規模災害用分類の修正に失敗しました。');
		}
		break;
	// -------------------------------------------
	// 削除
	// -------------------------------------------
	case 'del':
		// 大規模災害用でない分類の場合はエラー
		if (!$obj_cate->isDisasterCategory($_POST['cms_cate_code'])) {
			$objCnc->rollback();
			disasterError("大規模災害用でない分類を削除することはできません。");
		}
		
		// 分類情報の削除
		if (!$obj_cate->delete($cate_code)) {
			$objCnc->rollback();
			disasterError('大規模災害用分類の削除に失敗しました。');
		}
		
		// 大規模災害用一覧表示ページの件数を削除
		foreach ($DISASTER_LIST_ARY as $kind => $ary) {
			if (!$obj_dis_handle->deleteDisasterListMaxResult($cate_code, $kind)) {
				$objCnc->rollback();
				disasterError('大規模災害用分類の削除に失敗しました。');
			}
		}
		break;
}

// -----------------------------------------------
// トランザクション【終了】
// -----------------------------------------------
$objCnc->commit();

// -----------------------------------------------
// 即公開処理
// -----------------------------------------------
if (isDisasterPublicHtml()) {
	header("Location: " . "./public_html.php?cate_code=" . $cate_code);
	exit();
}

// -----------------------------------------------
// トップページに戻る
// -----------------------------------------------
header("Location: " . "./index.php");
exit();
?>
