<?php
// -----------------------------------------------------------------------------
// 
// 分類の表示順変更（完了処理）
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
// データベース登録用配列
$db_all_ary = array();

// -----------------------------------------------
// 一覧取得
// -----------------------------------------------
$obj_cate->selectDisasterCategory();
while ($obj_cate->fetch()) {
	
	$args_name = 'cms_cate_' . $obj_cate->fld['cate_code'];
	
	// 引数が取得できない場合はスキップ
	if (!isset($_POST[$args_name])) {
		continue;
	}
	
	$args = trim($_POST[$args_name]);
	
	// 半角数字に変換
	$args = mb_convert_kana($args, "n", 'UTF-8');
	
	// 入力チェック
	if (strlen($args) <= 0) {
		disasterError("表示順序の省略はできません。");
	}
	// 数値のみ
	if (!preg_match("/^[0-9]+$/", $args)) {
		disasterError("表示順序は半角数値のみ有効です。");
	}
	
	// データベース登録用配列の作成
	$db_all_ary[] = array(
			'cate_code'  => $obj_cate->fld['cate_code'], 
			'sort_order' => $args
	);
}

// -----------------------------------------------
// トランザクション【開始】
// -----------------------------------------------
$objCnc->begin();

// -----------------------------------------------
// データベース登録
// -----------------------------------------------
foreach ($db_all_ary as $db_ary) {
	// 実行
	if (!$obj_cate->update($db_ary)) {
		// ロールバック
		$objCnc->rollback();
		disasterError('大規模災害用分類の表示順序の更新に失敗しました。');
	}
}

// -----------------------------------------------
// トランザクション【終了】
// -----------------------------------------------
$objCnc->commit();

// -----------------------------------------------
// 即公開処理
// -----------------------------------------------
if (isDisasterPublicHtml()) {
	header("Location: " . "../public_html.php?cate_code=" . str_pad('', (CODE_DIGIT_CATE * 4), "0", STR_PAD_RIGHT));
	exit();
}

// -----------------------------------------------
// トップページに戻る
// -----------------------------------------------
header("Location: " . "../index.php");
exit();
?>
