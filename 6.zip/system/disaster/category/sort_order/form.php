<?php
// -----------------------------------------------------------------------------
// 
// 分類の表示順変更（入力画面）
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
// 公開設定
$public_view_flg = FLAG_OFF; 
$public_html = '';
// 一覧HTML
$list_html = '';

// -----------------------------------------------
// 一覧取得
// -----------------------------------------------
$obj_cate->selectDisasterCategory();
while ($obj_cate->fetch()) {
	// 取得結果代入
	$fld_ary = $obj_cate->fld;
	
	$disp_name = htmlDisplay($fld_ary['name']);
	
	$disp_cate_id    = 'cms_cate_' . htmlspecialchars($fld_ary['cate_code']);
	$disp_sort_order = htmlspecialchars($fld_ary['sort_order']);
	
	$list_html .= '<tr>' . "\n";
	$list_html .= '<td width="150" align="center" valign="middle">';
	$list_html .= '<input type="text" style="width:100px;text-align:center" id="' .$disp_cate_id .'" name="' . $disp_cate_id . '" value="' . $disp_sort_order . '">';
	$list_html .= '</td>' . "\n";
	$list_html .= '<td align="left" valign="top">';
	$list_html .= $disp_name;
	$list_html .= '</td>' . "\n";
	$list_html .= '</tr>' . "\n";
}

// -----------------------------------------------
// 公開設定
// -----------------------------------------------
if (isDisasterFlg()) {
	$public_view_flg = FLAG_ON;
	$public_html = createDisasterPublicCheckbox();
}

// -----------------------------------------------
// HTML画面表示設定
// -----------------------------------------------
// タイトル
$title_html = '大規模災害用分類表示順変更';
$title_image = '<img src="../../images/bar_disaster_category_listorder.jpg" alt="大規模災害用分類表示順変更" width="920" height="30" />';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="../../style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="../../js/common.js" type="text/javascript"></script>
<script src="../../js/category.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<p align="left" id="cms8341-pankuzu">トップ</p>
<form id="cms_complete_sortorder" class="cms8341-form" name="cms_complete_sortorder" method="post" action="">
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<th width="150" align="center" valign="middle" scope="col">表示順 <span class="cms_require">（必須）</span></th>
<th align="center" valign="middle" scope="col">分類名</th>
</tr>
<?=$list_html?>
</table>
<?php
// 公開設定ありの場合
if ($public_view_flg == FLAG_ON) {
	echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" style="margin-top:10px;">' . "\n";
	echo '<tr>' . "\n";
	echo '<th width="150" align="left" valign="top" scope="row">公開設定</th>' . "\n";
	echo '<td align="left" valign="top">' . $public_html . '</td>' . "\n";
	echo '</tr>' . "\n";
	echo '</table>' . "\n";
}
?>
<p align="center"><a href="javascript:" onClick="return cxSendCompleteSortOrder();"><img src="../../images/btn_listorder.jpg" alt="表示順を変更" width="150" height="20" border="0" class="disaster-button10" /></a><a href="javascript:history.back();"><img src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" class="disaster-button10" /></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
