<?php
// -----------------------------------------------------------------------------
// 
// 大規模災害用分類一覧ページ表示設定
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
$DISASTER_LIST_ARY = getDefineArray('DISASTER_LIST_ARY');
// 分類コード
$cate_code = '';
// 種別
$kind = '';
// 一覧表示件数
$max_result = '';
// データベース登録用配列
$db_all_ary = array();

// -----------------------------------------------
// エラーチェック
// -----------------------------------------------
if (!isset($_POST['cms_change_cate_code'])) {
	disasterError("パラメーターエラー【cate_code】");
}
if (!isset($_POST['cms_change_kind'])) {
	disasterError("パラメーターエラー【kind】");
}
if (!isset($_POST['cms_disaster_max_result'])) {
	disasterError("パラメーターエラー【max_result】");
}

// 登録されているカテゴリーかチェック
if (!$obj_cate->isDisasterCategory($_POST['cms_change_cate_code'])) {
	disasterError('大規模災害用分類以外の分類で表示設定することはできません。');
}
$cate_code = $_POST['cms_change_cate_code'];

// 作成可能な種別かチェック
if (!isset($DISASTER_LIST_ARY[$_POST['cms_change_kind']])) {
	disasterError('不正な種別のため表示設定することができません。');
}
$kind = $_POST['cms_change_kind'];

// 一覧表示件数
$max_result = trim($_POST['cms_disaster_max_result']);
// 数値のみかチェック
if (strlen($max_result) > 0 && !preg_match("/^[0-9]$/", $max_result)) {
	disasterError("表示件数は半角数値のみ有効です。");
}

// -----------------------------------------------
// 表示設定内容取得
// -----------------------------------------------
$obj_page->selectDisasterCatePage($cate_code, $kind, PUBLISH_TABLE, DISASTER_LIST_PAGE_SORT);
while ($obj_page->fetch()) {
	
	$args_name = 'cms_page_' . $obj_page->fld['page_id'];
	
	// 引数が取得できない場合はスキップ
	if (!isset($_POST[$args_name])) {
		continue;
	}
	
	$args = trim($_POST[$args_name]);
	
	// 半角数字に変換
	$args = mb_convert_kana($args, "n", 'UTF-8');
	
	// 入力がない場合
	if (strlen($args) <= 0) {
		continue;
	}
		
	// 数値のみかチェック
	if (!preg_match("/^[0-9]$/", $args)) {
		disasterError("表示順序は半角数値のみ有効です。");
	}
	
	// データベース登録用配列の作成
	$db_all_ary[] = array(
			'page_id'    => $obj_page->fld['page_id'], 
			'sort_order' => $args
	);
}

// -----------------------------------------------
// トランザクション【開始】
// -----------------------------------------------
$objCnc->begin();

// 既に登録されている対象一覧の表示設定を全て削除
if (!$obj_dis_handle->deleteDisasterListSort($cate_code, $kind)) {
	$objCnc->rollback();
	disasterError("大規模災害用分類ページ表示設定の初期化に失敗しました。");
}

// データベース登録
foreach ($db_all_ary as $db_ary) {
	if (!$obj_dis_handle->insertDisasterListSort($cate_code, $kind, $db_ary['page_id'], $db_ary['sort_order'])) {
		$objCnc->rollback();
		disasterError("大規模災害用分類ページ表示設定の登録に失敗しました。");
	}
}

// 表示件数の登録
if (strlen($max_result) > 0) {
	if (!$obj_dis_handle->entryDisasterListMaxResult($cate_code, $kind, $max_result)) {
		$objCnc->rollback();
		disasterError("表示件数の登録に失敗しました。");
	}
}
// 表示件数の削除
else {
	if (!$obj_dis_handle->deleteDisasterListMaxResult($cate_code, $kind)) {
		$objCnc->rollback();
		disasterError("表示件数の削除に失敗しました。");
	}
}

// -----------------------------------------------
// トランザクション【終了】
// -----------------------------------------------
$objCnc->commit();

// -----------------------------------------------
// 即公開処理
// -----------------------------------------------
if (isDisasterPublicHtml()) {
	header("Location: " . "../public_html.php?cate_code=" . $cate_code . "&kind=" . $kind);
	exit();
}

// -----------------------------------------------
// トップページに戻る
// -----------------------------------------------
header("Location: " . "../index.php");
?>
