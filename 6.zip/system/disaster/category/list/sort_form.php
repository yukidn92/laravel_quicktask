<?php
// -----------------------------------------------------------------------------
// 
// 大規模災害用分類一覧ページ表示設定
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
$DISASTER_LIST_ARY = getDefineArray('DISASTER_LIST_ARY');
// 分類コード
$cate_code = '';
// 分類名
$cate_name = '';
// 種別
$kind = '';
// 公開設定
$public_view_flg = FLAG_OFF; 
$public_html = '';
// 一覧HTML
$list_html = '';
// 一覧件数
$row_count = 0;

// -----------------------------------------------
// エラーチェック
// -----------------------------------------------
if (!isset($_POST['cms_change_cate_code'])) {
	disasterError("パラメーターエラー【cate_code】");
}
if (!isset($_POST['cms_change_kind'])) {
	disasterError("パラメーターエラー【kind】");
}

// 登録されているカテゴリーかチェック
if (!$obj_cate->isDisasterCategory($_POST['cms_change_cate_code'])) {
	disasterError('大規模災害用分類以外の分類で表示設定することはできません。');
}
$cate_code = $_POST['cms_change_cate_code'];
$cate_name = $obj_cate->fld['name'];

// 作成可能な種別かチェック
if (!isset($DISASTER_LIST_ARY[$_POST['cms_change_kind']])) {
	disasterError('不正な種別のため表示設定することができません。');
}
$kind = $_POST['cms_change_kind'];

// -----------------------------------------------
// 表示設定内容取得
// -----------------------------------------------
$obj_page->selectDisasterCatePage($cate_code, $kind, PUBLISH_TABLE, DISASTER_LIST_PAGE_SORT);
while ($obj_page->fetch()) {
	
	// 取得結果代入
	$fld_ary = $obj_page->fld;
	
	$disp_name = htmlDisplay($fld_ary['page_title']);
	$disp_path = htmlDisplay($fld_ary['file_path']);
	
	$disp_page_id    = 'cms_page_' . htmlspecialchars($fld_ary['page_id']);
	$disp_sort_order = htmlspecialchars($fld_ary['disaster_sort_order']);
	
	// 一覧HTML作成
	$list_html .= '<tr>' . "\n";
	$list_html .= '<td width="150" align="center" valign="middle">';
	$list_html .= '<input type="text" style="width:100px;text-align:center" id="' .$disp_page_id .'" name="' . $disp_page_id . '" value="' . $disp_sort_order . '">';
	$list_html .= '</td>' . "\n";
	$list_html .= '<td align="left" valign="top">';
	$list_html .= $disp_name . '<br />' . $disp_path;
	$list_html .= '</td>' . "\n";
	$list_html .= '</tr>' . "\n";
}

// 結果件数
$row_count = $obj_page->getRowCount();

// 一覧表示件数
$disaster_result_max = getDisasterListMaxResult($cate_code, $kind);

// -----------------------------------------------
// 公開設定
// -----------------------------------------------
if (isDisasterFlg()) {
	$public_view_flg = FLAG_ON;
	$public_html = createDisasterPublicCheckbox();
}

// -----------------------------------------------
// HTML画面表示設定
// -----------------------------------------------
// タイトル
$title_html = '大規模災害用一覧ページ表示設定';
$title_image = '<img src="../../images/bar_disaster_listpage_setting.jpg" alt="大規模災害用一覧ページ表示設定" width="920" height="30" />';

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="../../style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="../../js/common.js" type="text/javascript"></script>
<script src="../../js/category.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">

<p align="left" id="cms8341-pankuzu"><?=htmlDisplay($cate_name)?>【<?=$DISASTER_LIST_ARY[$kind]['label']?>】</p>

<form id="cms_complete_changelistpage" class="cms8341-form" name="cms_complete_changelistpage" method="post" action="">
<input type="hidden" id="cms_change_cate_code" name="cms_change_cate_code" value="<?=htmlspecialchars($cate_code)?>" />
<input type="hidden" id="cms_change_kind" name="cms_change_kind" value="<?=htmlspecialchars($kind)?>" />

<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<?php
if ($row_count <= 0) {
	echo '<tr><td align="center" valign="middle">対象のページは存在しません。</td></tr>';
}
else {
?>
<th width="150" align="center" valign="middle" scope="col">表示順</th>
<th align="center" valign="middle" scope="col">ページタイトル</th>
</tr>
<?php
	echo $list_html;
}
?>
</table>

<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" style="margin-top:10px;">
<tr>
<th width="150" align="left" valign="top" scope="row">表示件数</th>
<td><input type="text" style="width:100px;text-align:center" id="cms_disaster_max_result" name="cms_disaster_max_result" value="<?=htmlspecialchars($disaster_result_max)?>" /></td>
</tr>
<?php
// 公開設定ありの場合
if ($public_view_flg == FLAG_ON) {
	echo '<tr>' . "\n";
	echo '<th width="150" align="left" valign="top" scope="row">公開設定</th>' . "\n";
	echo '<td align="left" valign="top">' . $public_html . '</td>' . "\n";
	echo '</tr>' . "\n";
}
?>
</table>

<p align="center"><a href="javascript:" onClick="return cxSendCompleteChangeListPage();"><img src="../../images/btn_listorder.jpg" alt="表示順を変更" width="150" height="20" border="0" class="disaster-button10" /></a><a href="javascript:history.back();"><img src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" class="disaster-button10" /></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>