<?php
/* 大規模災害管理設定
 * 
 */
require ("./.htsetting");
require_once("../../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$obj_tool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$obj_handler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$obj_inquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$obj_library = new tbl_library($objCnc);

// POSTに含まれているか確認
$is_post_ary = array(
		// ページ作成情報
		'cms_parent_id' => 'parent_id', 
		'cms_page_title' => 'page_title', 
		'cms_template_id' => 'template_id', 
		'cms_template_kind' => 'template_kind', 
		'cms_cate_code' => 'cate_code', 
		'cms_dir_path' => 'dir_path', 
		'cms_filename' => 'filename', 
		// 大規模災害用分類情報
		'cms_list_cate_code' => 'cate_code', 
		'cms_list_kind' => 'list_kind'
);
foreach ((array)$is_post_ary as $pkey => $perr) {
	if (!isset($_POST[$pkey])) {
		disasterError("パラメーターエラー【" . $perr . "】");
	}
}

// 登録されているカテゴリーかチェック
if (!$obj_cate->isDisasterCategory($_POST['cms_list_cate_code'])) {
	disasterError('大規模災害用分類以外の分類に一覧ページを作成することはできません。');
}
$cate_code = $_POST['cms_list_cate_code'];

// 作成可能な種別かチェック
if (!isset($DISASTER_LIST_ARY[$_POST['cms_list_kind']])) {
	disasterError('不正な種別のため一覧ページを作成することができません。');
}
$kind = $_POST['cms_list_kind'];

// 登録済みの場合は作成できない
if ($obj_dis_handle->isCreateDisasterListPage($cate_code, $kind)) {
	disasterError('既に一覧ページが作成されているため、一覧ページを作成することができません。');
}

// 保存先の存在チェック
$filename = DOCUMENT_ROOT . RPW . $_POST['cms_dir_path'] . $_POST['cms_filename'];
if (@file_exists($filename)) {
	faqError($filename . ' は既に存在します。');
}

// 新しいページIDの取得
$PID = $obj_page->getSeqNextval();
$tpl_kind     = $_POST['cms_template_kind'];
$cate_code    = $_POST['cms_cate_code'];
$template_ver = "";
$context      = "";

// -----------------------------------------------
// テンプレート
// -----------------------------------------------
// テンプレート情報取得
if ($obj_tool->selectTemplate($_POST['cms_template_id']) === FALSE) {
	user_error("Can't find template data.<br>dac_tools selectTemplate(" . $_POST['cms_template_id'] . ")", E_USER_ERROR);
}
$template_path = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $obj_tool->fld['temp_txt'];
// テンプレートファイルエラー
if (!file_exists($template_path)) {
	user_error("The template file doesn't exist.<br>temp_txt[" . $obj_tool->fld['temp_txt'] . "]", E_USER_ERROR);
}
// テンプレートのバージョン（最新バージョン）
$template_ver = $obj_tool->fld['template_ver'];

// テンプレートファイルの読み込み
$fp = fopen($template_path, "r");
$html_str = fread($fp, filesize($template_path));
fclose($fp);

// -----------------------------------------------
// 大規模災害用一覧ページテンプレート
// -----------------------------------------------
// テンプレートファイルの読み込み
if (!getDisasterListTemplate($context, 'disaster_list_page', $kind)) {
	$objCnc->rollback();
	disasterError("テンプレートファイルの読み込みに失敗しました。【disaster_list_page.txt】");
}

// 置換）ページタイトル
$context = str_replace("<!-- page_title area -->", $_POST['cms_page_title'], $context);

// -----------------------------------------------
// 親ページ情報の作成
// -----------------------------------------------
// ぱんくずパス
$ancestor_path = "";
$parent_id = "";
// 親ページIDに空白以外が渡された場合
if (isset($_POST['cms_parent_id']) && $_POST['cms_parent_id'] != "") {
	// 親ページ情報（tbl_publish_pageから）の取得配列$parent_fldに格納
	if ($obj_page->selectFromID($_POST['cms_parent_id'], 1) === FALSE) {
		user_error("Can't find parent page data.<br>cms_parent_id[" . $_POST['cms_parent_id'] . "]", E_USER_ERROR);
	}
	$ancestor_path = ($obj_page->fld['ancestor_path'] != '') ? $obj_page->fld['ancestor_path'] . ',' : '';
	$ancestor_path .= $obj_page->fld['file_path'];
	$parent_id = $_POST['cms_parent_id'];
}

// -----------------------------------------------
// 登録情報の作成
// -----------------------------------------------
// 登録情報のセット
$ary1 = array(
		'page_id' => $PID, 
		'cate_code' => $cate_code, 
		'template_id' => $_POST['cms_template_id'], 
		'template_ver' => $template_ver, 
		'parent_id' => $parent_id, 
		'ancestor_path' => $ancestor_path, 
		'user_id' => $objLogin->get('user_id'), 
		'dir_path' => $_POST['cms_dir_path'], 
		'filename' => $_POST['cms_filename'], 
		'file_path' => $_POST['cms_dir_path'] . $_POST['cms_filename'], 
		'page_title' => $_POST['cms_page_title'], 
		'header' => $_POST['cms_page_title'], 
		'context' => $context, 
		'keywords' => "", 
		'description' => "", 
		'summary' => "", 
		'index_title' => "", 
		'contents_top_flg' => 0, 
		'status' => STATUS_PUBLISH_WAIT, 
		'template_kind' => $_POST['cms_template_kind'], 
		'faq_id' => ""
);
// メニュー生成順
$ary1['menu_generation_order'] = $obj_page->getNextMenuGenerationOrder($parent_id);

// 公開開始日
$Y = date('Y');
$n = date('n');
$j = date('j');
$H = date('H');
$ary1['publish_start'] = $Y . '-' . $n . '-' . $j . ' ' . $H . ':00:00';
// 公開終了日
$Y = date('Y', strtotime("+" . PUBLISH_END_MONTH . " month"));
$n = date('n', strtotime("+" . PUBLISH_END_MONTH . " month"));
$j = date('j', strtotime("+" . PUBLISH_END_MONTH . " month"));
$ary1['publish_end'] = $Y . '-' . $n . '-' . $j . ' ' . $H . ':00:00';

// -----------------------------------------------
// トランザクション【開始】
// -----------------------------------------------
$objCnc->begin();

// -----------------------------------------------
// 公開情報の登録
// -----------------------------------------------
// ページ情報
if ($obj_page->insert($ary1, PUBLISH_TABLE) === FALSE) {
	$objCnc->rollback();
	disasterError("新規ページの作成に失敗しました。");
}

// -----------------------------------------------
// 編集情報の登録
// -----------------------------------------------
// ページ情報
if ($obj_page->insertWorkFromPublish($PID, $objLogin->login) === FALSE) {
	$objCnc->rollback();
	disasterError("新規ページの作成に失敗しました。");
}

// -----------------------------------------------
// 大規模災害管理テーブルの情報を更新
// -----------------------------------------------
if (!$obj_dis_handle->entryDisasterListPage($cate_code, $kind, $PID)) {
	$objCnc->rollback();
	disasterError("大規模災害用一覧ページ情報の登録に失敗しました。");
}

// -----------------------------------------------
// ライブラリの登録
// -----------------------------------------------
// デフォルトライブラリを設定
$lib_html_str = $html_str;
$lib_ary = array();
// ライブラリ領域を検索
while (getLibraryArea($lib_ary, $lib_html_str, 0)) {
	// ライブラリ情報を登録
	if (isset($lib_ary["id"]) && $lib_ary["id"] != "" && $obj_library->selectFromID($lib_ary["id"]) !== FALSE) {
		// 登録情報の作成
		$db_ary = array();
		$db_ary['page_id'] = $PID;
		$db_ary['area'] = $lib_ary["area"];
		$db_ary['library_id'] = $lib_ary["id"];
		$db_ary['library_ver'] = $obj_library->fld['library_ver'];
		// DBに登録
		if ($obj_handler->insertLibrary($db_ary, WORK_TABLE) === FALSE) {
			$objCnc->rollback();
			disasterError('ライブラリ設定の登録に失敗しました。');
		}
	}
	// 登録したエリア情報を対象から除外
	$lib_html_str = str_replace($lib_ary["match"], "", $lib_html_str);
}

// -----------------------------------------------
// ページHTMLの作成
// -----------------------------------------------
if (!mkNewPage($PID, $_POST['cms_dir_path'] . $_POST['cms_filename'])) {
	$objCnc->rollback();
	disasterError("新規ページ作成に失敗しました。");
}

// -----------------------------------------------
// トランザクション【終了】
// -----------------------------------------------
$objCnc->commit();

// -----------------------------------------------
// 完了画面へ移動
// -----------------------------------------------
header("Location: " . "./complete.php");
?>
