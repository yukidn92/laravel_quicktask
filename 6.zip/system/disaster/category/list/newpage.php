<?php
/* 大規模災害管理設定
 * 
 */
require ("./.htsetting");
require_once("../../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$obj_tool = new dac_tools($objCnc);

// 
$DISASTER_LIST_ARY = getDefineArray('DISASTER_LIST_ARY');


// 
if (!isset($_POST['cms_list_cate_code'])) {
	disasterError("パラメーターエラー【cate_code】");
}
if (!isset($_POST['cms_list_kind'])) {
	disasterError("パラメーターエラー【list_kind】");
}

// 登録されているカテゴリーかチェック
if (!$obj_cate->isDisasterCategory($_POST['cms_list_cate_code'])) {
	disasterError('大規模災害用分類以外の分類に一覧ページを作成することはできません。');
}
$cate_code = $_POST['cms_list_cate_code'];

// 作成可能な種別かチェック
if (!isset($DISASTER_LIST_ARY[$_POST['cms_list_kind']])) {
	disasterError('不正な種別のため一覧ページを作成することができません。');
}
$kind = $_POST['cms_list_kind'];

// 登録済みの場合は作成できない
if ($obj_dis_handle->isCreateDisasterListPage($cate_code, $kind)) {
	disasterError('既に一覧ページが作成されているため、一覧ページを作成することができません。');
}

// 新規作成するページID( 仮 )
$_SESSION['cms_page_id']    = -1;
$_SESSION['cms_pankuzu_id'] = -1;
// 親ページ ID
if (!$obj_page->selectFromPath(SITE_TOP_PAGE)) {
	disasterError('サイトトップページ情報の取得に失敗しました。');
}
$pub_fld_ary = $obj_page->fld;
$PID = $pub_fld_ary['page_id'];
// テンプレート
$template_name = "";
$template_id = "";
$template_kind = "";
// ページタイトル
$page_title_from = "";
// カテゴリコード
$cate_info_ary = $obj_cate->getCategoryInfo($cate_code, PANKUZU_DELIMITER);
$cate_str = htmlDisplay($cate_info_ary['name']);
// 問い合わせ番号
$inquiry_cnt = 1;

// -----------------------------------------------
// パンくず作成
// -----------------------------------------------
// 親ページのページタイトルを取得
// 自分が作業中のページの場合は編集情報から取得
if ($pub_fld_ary['status'] < STATUS_PUBLISH && $pub_fld_ary['user_id'] == $objLogin->get('user_id')) {
	if ($obj_page->selectFromID($PID, WORK_TABLE, 'page_title, cate_code') === FALSE) {
		user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 2, 'page_title');", E_USER_ERROR);
	}
	$page_title = $obj_page->fld['page_title'];
	// 自分が作業中のページじゃなければ公開情報から取得
}
else {
	$page_title = $pub_fld_ary['page_title'];
}

// ぱんくずのセット
$pankuzu = $obj_tool->getPankuzu(FLAG_OFF, $template_kind, 0, $pub_fld_ary['ancestor_path'], $page_title, $objLogin->get('user_id'), FALSE);
// ルートからのパスにする
$pankuzu = setRootPath($pankuzu);

// -----------------------------------------------
// テンプレート（最新バージョン）情報を取得
// -----------------------------------------------
$obj_tool->setTableName('tbl_template AS t');
$field = 't.*';
$order = 't.sort_order,t.template_id';
$where_ary = array();

// 作成する一覧ページの種別ごとの処理
switch ($kind) {
	// PC
	case DISASTER_LIST_PC:
		$where_ary[] = $obj_tool->_addslashesC('t.template_kind', TEMPLATE_KIND_FREE);
		break;
	// 携帯
	case DISASTER_LIST_MOBILE:
		$where_ary[] = $obj_tool->_addslashesC('t.template_kind', TEMPLATE_KIND_MOBILE);
		break;
}
// 最新バージョン
$where_ary[] = 't.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)';
// 表示
$where_ary[] = $obj_tool->_addslashesC('t.disp_flg', FLAG_ON);

// テンプレート取得
$obj_tool->select(implode(' AND ', $where_ary), $field, $order);

// -----------------------------------------------
// ファイル保存先設定レイヤーの表示取得
// -----------------------------------------------
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");

$_SESSION['reffer'] = array();
$where_ary = array();
$def_folder = "";

// 通常ページ初期ディレクトリ
$where_ary[] = $obj_dac->_addslashesC('class', HANDLER_CLASS_DEF_DIR1);
// ログイン組織
$where_ary[] = $obj_dac->_addslashesC('item1', $objLogin->get('dept_code'));

// 取得
$obj_dac->setTableName("tbl_handler");
$obj_dac->select(implode(' AND ', $where_ary));
// 取得できた場合は初期ディレクトリを代入
if ($obj_dac->fetch()) {
	$def_folder = $obj_dac->fld['item2'];
}
// ファイル保存先レイヤーのディレクトリの移動
$reffer_str = cxRefferMoveDir($objCnc, $def_folder);

// -----------------------------------------------------------------------------
// HTML画面表示設定
// -----------------------------------------------------------------------------
// タイトル
$title_html = '大規模災害用一覧ページ作成';
$title_image = '<img src="../../images/bar_disaster_list_new.jpg" alt="大規模災害用一覧ページ作成" width="920" height="30" />';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/newpage.css" type="text/css">
<link rel="stylesheet" href="../../style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/reffer.js" type="text/javascript"></script>
<script src="../../js/common.js" type="text/javascript"></script>
<script src="../../js/list.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>

</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-newpage">
<form id="cms_disaster_newpage" name="cms_disaster_newpage" class="cms8341-form" method="post" action="" onSubmit="return false;">
<input type="hidden" name="cms_parent_id" id="cms_parent_id" value="<?=$PID?>">
<input type="hidden" name="cms_page_id" id="cms_page_id" value="<?=$PID?>">
<input type="hidden" name="cms_dir_path" id="cms_dir_path" value="">
<input type="hidden" name="cms_filename" id="cms_filename" value="">
<input type="hidden" name="cms_template_kind" id="cms_template_kind" value="<?=$template_kind?>">
<input type="hidden" name="cms_inquiry_cnt" id="cms_inquiry_cnt" value="<?=$inquiry_cnt?>">
<input type="hidden" name="cms_dispMode" id="cms_dispMode" value="">
<input type="hidden" name="cms_copy_page_id" id="cms_copy_page_id" value="<?=$PID?>">
<input type="hidden" name="cms_user_class" id="cms_user_class" value="<?=$objLogin->get('class')?>">
<input type="hidden" name="cms_cate_code" id="cms_cate_code" value="<?=$cate_code?>">

<input type="hidden" name="cms_list_cate_code" id="cms_list_cate_code" value="<?=$cate_code?>" />
<input type="hidden" name="cms_list_kind" id="cms_list_kind" value="<?=$kind?>" />

<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<p id="cms8341-pankuzu"><?=$pankuzu?> &gt; </p>

<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable">

<tr>
<th width="170" align="left" valign="top" scope="row">テンプレート <span class="cms_require">（必須）</span></th>
<td align="left" valign="top">
<p id="cms-template-selected"><?=$template_name?></p>
<p><a href="javascript:" onClick="return cxTemplateSet()"><img src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100" height="20" border="0"></a></p>
</td>
</tr>

<tr id="cms_page_title_tr">
<th width="150" align="left" valign="top" scope="row"><label
for="cms_page_title">タイトル <span class="cms_require">（必須）</span></label>
<div class="cms_recommend"></div>
</th>
<td><input type="text" maxlength="255" name="cms_page_title" id="cms_page_title" style="width: 240px;" value="<?=htmlspecialchars($page_title_from)?>"></td>
</tr>

<tr>
<th width="170" align="left" valign="top" nowrap scope="row">親ページ</th>
<td align="left" valign="top">
<div align="left">
<div><a href="javascript:" onClick="return cxOpenPanset()"><img src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100" height="20" border="0"></a> <a href="javascript:" onClick="return cxParentDel()"><img src="<?=RPW?>/admin/images/btn/btn_parent_unset.jpg" alt="親ページなしにする" width="150" height="20" border="0"></a></div>
</div>
</td>
</tr>

<tr id="cms_cate_tr">
<th align="left" valign="top" nowrap scope="row">分類</th>
<td><?=$cate_str?></td>
</tr>

<tr id="cms_reffer_tr">
<th align="left" valign="top" scope="row">ファイル保存先 <span
class="cms_require">（必須）</span></th>
<td align="left" valign="top">
<p id="cms_file_path"></p>
<p><a href="javascript:" onClick="return cxRefferSet()"><img
src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
height="20" border="0"></a></p>
</td>
</tr>

</table>

<br>
<div id="cms_kanko_area"></div>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
alt="" width="36" height="26"></p>
<p align="center" id="cms_submit"><a href="javascript:" onClick="return cxSubmit('<?=$objLogin->get('class')?>')"><img src="<?=RPW?>/admin/images/btn/btn_submit_large.jpg" alt="作成" width="150" height="20" border="0" class="disaster-button10"></a><a href="javascript:" onClick="return cxPageCancel()"><img src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" class="disaster-button10"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
width="920" height="10"></div>

<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
style="border: solid 1px #343434;">
<table width="600" border="0" cellspacing="0" cellpadding="0"
class="cms8341-layerheader">
<tr>
<td align="left" valign="middle"><img
src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
<td width="78" align="right" valign="middle"><a href="javascript:"
onClick="return cxTemplateClose()"><img
src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
height="19" border="0" style="margin: 4px 10px;"></a></td>
</tr>
</table>
<div
style="width: 560px; height: 235px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
<div align="center">
<table width="540" border="0" cellpadding="0" cellspacing="0"
class="cms8341-noneBorder">
<tr>
<td align="left" valign="top">
<div id="cms_template_list"><label for="cms_template_id">テンプレートリスト</label>
<select name="cms_template_id" id="cms_template_id" size="12"
style="width: 250px;" onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
while ($obj_tool->fetch()) {
	$src = DIR_PATH_TEMPLATE . $obj_tool->fld['temp_txt'];
	if ($template_id != "" && $template_id == $obj_tool->fld['template_id']) {
		print '<option value="' . $obj_tool->fld['template_id'] . '" id="' . $src . '" _kind="' . $obj_tool->fld['template_kind'] . '" selected>' . htmlDisplay($obj_tool->fld['name']) . '</option>' . "\n";
	}
	else {
		print '<option value="' . $obj_tool->fld['template_id'] . '" id="' . $src . '" _kind="' . $obj_tool->fld['template_kind'] . '">' . htmlDisplay($obj_tool->fld['name']) . '</option>' . "\n";
	}
}
?>
</select></div>
</td>
<td width="275" align="left" valign="middle">
<div id="cms_thumb_cover" style="position: absolute; width: 275px; height: 215px; filter: Alpha(opacity = 0)"></div>
<iframe src="<?=$def_src?>" name="cms_thumb" id="cms_thumb"
width="270" height="210" frameborder="0" scrolling="no"
style="border: solid 1px #666"></iframe></td>
</tr>
</table>
</div>
</div>
<p style="margin: 10px 0px;"><a href="javascript:"
onClick="return cxTemplateSubmit()"><img
src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
height="21" border="0"></a></p>
</td>
</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* --></form>
</div>
</div>
<!-- cms8341-contents -->
<!--***ファイル保存先設定レイヤー　ここから***********-->
<div id="cms8341-reffer" class="cms8341-layer">
<?=$reffer_str?>
</div>
<!--***ファイル保存先設定レイヤー　ここまで***********-->
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
style="border: solid 1px #343434;">
<table width="500" border="0" cellspacing="0" cellpadding="0"
class="cms8341-layerheader">
<tr>
<td align="left" valign="middle"><img
src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
width="480" height="20" style="margin: 4px 10px;"></td>
</tr>
</table>
<div
style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
<div align="center">
<div
style="width: 430px; height: 120px; padding: 5px; text-align: left"
id="cms8341-errormsg">メッセージ</div>
<div style="margin: 15px 0px;"><a href="javascript:"
onClick="return cxLayer('cms8341-error',0);"><img
src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
height="20" border="0"></a></div>
</div>
</div>
</td>
</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
<?php
echo $obj_tool->setAccessibility();
?>
</body>
</html>
