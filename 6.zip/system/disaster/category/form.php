<?php
// -----------------------------------------------------------------------------
// 
// 大規模災害用分類登録（入力画面）
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
// 有効な処理モード
$enable_mode_ary = array(
		'new', 
		'upd', 
		'del'
);
// 登録先分類階層（第1分類）
$level = 1;
// 処理種別
$mode = '';
// 分類コード
$cate_code = '';
// 分類名
$cate_name = '';
// 公開設定
$public_view_flg = FLAG_OFF; 
$public_html = '';

// -----------------------------------------------
// エラーチェック（共通）
// -----------------------------------------------
// 処理種別
if (!isset($_POST['cms_mode'])) {
	disasterError("パラメーターエラー【mode】");
}
if (!in_array($_POST['cms_mode'], $enable_mode_ary)) {
	disasterError("不正な処理種別のため処理を実行できませんでした。");
}
$mode = $_POST['cms_mode'];

// 分類コード
if (!isset($_POST['cms_cate_code'])) {
	disasterError("パラメーターエラー【cate_code】");
}
$cate_code = $_POST['cms_cate_code'];

// -----------------------------------------------
// 種別ごとの処理を実行
// -----------------------------------------------
switch ($_POST['cms_mode']) {
	// -------------------------------------------
	// 新規
	// -------------------------------------------
	case 'new':
		// 新規追加する分類コードを取得
		$cate_code = getNextCateCode1st();
		break;
	// -------------------------------------------
	// 更新
	// -------------------------------------------
	case 'upd':
		// 分類内容取得
		if (!$obj_cate->selectFromCode($cate_code)) {
			disasterError("分類情報の取得に失敗しました。");
		}
		$cate_ary = $obj_cate->fld;
		
		// 大規模災害用の分類かチェック
		if ($cate_ary['disaster_flg'] != FLAG_ON) {
			disasterError("大規模災害用でない分類を修正することはできません。");
		}
		
		// 分類名
		$cate_name = $cate_ary['name'];
		break;
	// -------------------------------------------
	// 削除
	// -------------------------------------------
	case 'del':
		disasterError("不正アクセスです。");
		break;
}

// -----------------------------------------------
// 公開設定
// -----------------------------------------------
if (isDisasterFlg()) {
	$public_view_flg = FLAG_ON;
	$public_html = createDisasterPublicCheckbox();
}

// -----------------------------------------------
// HTML画面表示設定
// -----------------------------------------------
// タイトル
$title_html = '大規模災害用分類追加';
$title_image = '<img src="../images/bar_disaster_category_new.jpg" alt="大規模災害用分類追加" width="920" height="30" />';

// 処理別
switch ($_POST['cms_mode']) {
	// 更新
	case 'upd':
		$title_html = '大規模災害用分類修正';
		$title_image = '<img src="../images/bar_disaster_category_upd.jpg" alt="大規模災害用分類修正" width="920" height="30" />';
		break;
	// 新規
	case 'del':
		$title_html = '大規模災害用分類削除';
		$title_image = '<img src="../images/bar_disaster_category_del.jpg" alt="大規模災害用分類削除" width="920" height="30" />';
		break;
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="../style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="../js/common.js" type="text/javascript"></script>
<script src="../js/category.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<p align="left" id="cms8341-pankuzu">トップ</p>
<form id="cms_confirm_category" class="cms8341-form" name="cms_confirm_category" method="post" action="" onsubmit="return false;">
<input type="hidden" id="cms_mode" name="cms_mode" value="<?=htmlDisplay($_POST['cms_mode'], 'nonconvert_br')?>" />
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<tr>
<th width="150" align="left" valign="top" scope="row">分類コード</th>
<td align="left" valign="top"><?=htmlDisplay($cate_code)?>
<input type="hidden" id="cms_cate_code" name="cms_cate_code" value="<?=htmlspecialchars($cate_code)?>" /></td>
</tr>
<tr>
<th width="150" align="left" valign="top" scope="row">分類名 <span class="cms_require">（必須）</span></th>
<td align="left" valign="top"><input type="text" style="width: 540px;" id="cms_cate_name" name="cms_cate_name" value="<?=htmlspecialchars($cate_name)?>" maxlength="255" /></td>
</tr>
<?php
// 公開設定ありの場合
if ($public_view_flg == FLAG_ON) {
	echo '<tr>' . "\n";
	echo '<th width="150" align="left" valign="top" scope="row">公開設定</th>' . "\n";
	echo '<td align="left" valign="top">' . $public_html . '</td>' . "\n";
	echo '</tr>' . "\n";
}
?>
</table>
<p align="center"><a href="javascript:" onClick="return cxSendConfirmCategory();"><img src="<?=RPW?>/admin/images/btn/btn_conf.jpg" alt="確認" width="150" height="20" border="0" class="disaster-button10"" /></a><a href="javascript:history.back();"><img src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" class="disaster-button10" /></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
