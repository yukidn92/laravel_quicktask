<?php
// -----------------------------------------------------------------------------
// 
// 大規模災害用分類一覧
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
$DISASTER_LIST_ARY = getDefineArray('DISASTER_LIST_ARY');
// 一覧HTML
$list_html = '';
// 共通メニュー
$menu_html = '';

// -----------------------------------------------
// 共通メニュー作成
// -----------------------------------------------
$menu_html .= '<a href="javascript:" onClick="return cxSendFormCategory(\'new\', \'\');">';
$menu_html .= '<img src="../images/btn_add_category.jpg" alt="分類を追加" width="150" height="20" border="0" class="disaster-button05" /></a>';
$menu_html .= '<a href="javascript:" onClick="return cxSendFormSortOrder();">';
$menu_html .= '<img src="../images/btn_sortorder_category.jpg" alt="分類の表示順変更" width="150" height="20" border="0" class="disaster-button05" /></a>';

// -----------------------------------------------
// 一覧取得
// -----------------------------------------------
$obj_cate->selectDisasterCategory();
while ($obj_cate->fetch()) {
	// 取得結果代入
	$fld_ary = $obj_cate->fld;
	// 件数取得
	$fld_ary['disaster_max_result'] = '';
	$disp_name = '<strong>' . htmlDisplay($fld_ary['name']) . '</strong>' . '（' . htmlDisplay($fld_ary['cate_code']) . '）';
	
	$list_html .= '<tr>' . "\n";
	$list_html .= '<td>' . "\n";
	$list_html .= '<table width="100%" border="0" cellpadding="5" cellspacing="0" style="border: none;">' . "\n";
	// -------------------------------------------
	// 分類名
	// -------------------------------------------
	$list_html .= '<tr>' . "\n";
	$list_html .= '<td width="60%" align="left" valign="middle" style="border: none">';
	$list_html .= $disp_name . '</td>' . "\n";
	$list_html .= '<td width="40%" align="right" valign="middle" style="border: none">' . "\n";
	
	// -------------------------------------------
	// 修正
	// -------------------------------------------
	$list_html .= '<a href="javascript:" onClick="return cxSendFormCategory(\'upd\', \'' . javaStringEscape($fld_ary['cate_code']) . '\');">';
	$list_html .= '<img src="../images/btn_mini_fix.jpg" alt="修正" width="60" height="20" border="0" class="disaster-button05" />';
	$list_html .= '</a>';
	
	// -------------------------------------------
	// 削除
	// -------------------------------------------
	if (isDeleteDisasterCategory($fld_ary['cate_code'])) {
		// 削除できる場合
		$list_html .= '<a href="javascript:" onClick="return cxSendFormCategory(\'del\', \'' . javaStringEscape($fld_ary['cate_code']) . '\');">';
		$list_html .= '<img src="../images/btn_mini_del.jpg" alt="削除" width="60" height="20" border="0" class="disaster-button05" />';
		$list_html .= '</a>';
	}
	else {
		// 削除できない場合
		$list_html .= '<img src="' . RPW . '/admin/images/spacer.gif" alt="" width="60" height="20" border="0" class="disaster-button05" />';
	}
	$list_html .= '</td>' . "\n";
	$list_html .= '</tr>' . "\n";
	$list_html .= '</table>' . "\n";
	
	// -------------------------------------------
	// 一覧ページ
	// -------------------------------------------
	$list_html .= '<table class="cms8341-dataTable" width="100%" cellpadding="5" cellspacing="0">' . "\n";
	// 種別数分作成
	foreach ($DISASTER_LIST_ARY as $kind => $ary) {
		// 一覧ページが作成されているかチェック
		$list_page_html = '';
		
		$create_list_page_flg = $obj_dis_handle->isCreateDisasterListPage($fld_ary['cate_code'], $kind);
		
		$list_html .= '<tr>' . "\n";
		$list_html .= '<td style="background-color: #F0F0F0; width: 180px;">一覧ページ【' . htmlDisplay($ary['label']) . '】</td>' . "\n";
		$list_html .= '<td>';
		
		// ---------------------------------------
		// 一覧ページ作成済みの場合
		// ---------------------------------------
		if ($create_list_page_flg) {
			// ページ情報取得
			if (!$obj_page->selectFromID($obj_dis_handle->fld['page_id'], PUBLISH_TABLE)) {
				$list_html .= 'ページ情報の取得に失敗しました。【' . $obj_dis_handle->fld['page_id'] . '】';
			}
			else {
				// プレビューモード
				$prev_mode = PUBLISH_TABLE;
				// 新規作成中の場合は編集情報を取得
				if ($obj_page->fld['work_class'] == WORK_CLASS_NEW) {
					if (!$obj_page->selectFromID($obj_dis_handle->fld['page_id'], WORK_TABLE)) {
						disasterError('ページ情報の取得に失敗しました。【' . $obj_dis_handle->fld['page_id'] . '】');
					}
					$prev_mode = WORK_TABLE;
				}
				$prev_id    = $obj_dis_handle->fld['page_id'];
				$prev_title = htmlDisplay($obj_page->fld['page_title'], 'convert_space');
				$prev_path  = htmlDisplay($obj_page->fld['file_path'], 'convert_space');
				
				// プレビュー表示
				$list_html .= "<a href=\"javascript:\" onClick=\"return cxPreview('cms_form_preview', " . $prev_id . ", " . $prev_mode . ")\">";
				$list_html .= $prev_title . "</a>";
				$list_html .= '（' . $prev_id . '）' . '<br />' . "\n";
				$list_html .= $prev_path;
				$list_html .= '<br />' . "\n";
			}
		}
		// ---------------------------------------
		// 一覧ページ作成
		// ---------------------------------------
		if (!$create_list_page_flg) {
			$list_html .= '<a href="javascript:" onClick="return cxSendFormCreateListPage(\'' . javaStringEscape($fld_ary['cate_code']) . '\',\'' . javaStringEscape($kind) . '\');">';
			$list_html .= '<img src="../images/btn_create_' . $ary['name'] . '.jpg" alt="' . $ary['label'] . '一覧ページ作成" width="150" height="20" border="0" class="disaster-button05" />';
			$list_html .= '</a>';
		}
		// ---------------------------------------
		// 一覧の表示順変更
		// ---------------------------------------
		$list_html .= '<a href="javascript:" onClick="return cxSendFormChangeListPage(\'' . javaStringEscape($fld_ary['cate_code']) . '\',\'' . javaStringEscape($kind) . '\');">';
		$list_html .= '<img src="../images/btn_disp_setting.jpg" alt="表示設定" width="100" height="20" border="0" class="disaster-button05" />';
		$list_html .= '</a>';
		
		$list_html .= '</td>' . "\n";
		$list_html .= '</tr>' . "\n";
	}
	
	$list_html .= '</table>' . "\n";
	$list_html .= '</td>' . "\n";
	$list_html .= '</tr>' . "\n";
}

// -----------------------------------------------
// HTML画面表示設定
// -----------------------------------------------
// タイトル
$title_html = '大規模災害用分類一覧';
$title_image = '<img src="../images/bar_disaster_category.jpg" alt="大規模災害用分類一覧" width="920" height="30" />';

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="../style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="../js/common.js" type="text/javascript"></script>
<script src="../js/category.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<p align="right"><?=$menu_html?></p>
<form id="cms_disaster_form" class="cms8341-form" name="cms_disaster_form" method="post" action="" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<?=$list_html;?>
</table>
</form>
<?php /* 分類を追加 */ ?>
<form id="cms_form_category" class="cms8341-form" name="cms_form_category" method="post" action="">
<input type="hidden" id="cms_mode" name="cms_mode" value="" />
<input type="hidden" id="cms_cate_code" name="cms_cate_code" value="" />
</form>
<?php /* 分類の表示順変更 */ ?>
<form id="cms_form_sortorder" class="cms8341-form" name="cms_form_sortorder" method="post" action="">
</form>
<?php /* 一覧ページ作成 */ ?>
<form id="cms_form_createlistpage" class="cms8341-form" name="cms_form_createlistpage" method="post" action="">
<input type="hidden" id="cms_list_cate_code" name="cms_list_cate_code" value="" />
<input type="hidden" id="cms_list_kind" name="cms_list_kind" value="" />
</form>
<?php /* 一覧ページ表示順変更 */ ?>
<form id="cms_form_changelistpage" class="cms8341-form" name="cms_form_changelistpage" method="post" action="">
<input type="hidden" id="cms_change_cate_code" name="cms_change_cate_code" value="" />
<input type="hidden" id="cms_change_kind" name="cms_change_kind" value="" />
</form>
<?php /* プレビュー */ ?>
<form id="cms_form_preview" class="cms8341-form" name="cms_form_preview" method="post" action="">
<input type="hidden" id="cms_page_id" name="cms_page_id" value="" />
<input type="hidden" id="cms_dispMode" name="cms_dispMode" value="" />
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
