<?php
// -----------------------------------------------------------------------------
// 
// 大規模災害用分類管理での即公開処理
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);

require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
$pgrs_func = new progressbar();

// -----------------------------------------------
// 初期化
// -----------------------------------------------
// 分類コード
$cate_code = '';
// 種別
$kind = '';
// 即公開ページ情報
$public_page_ary = array();
// 即公開ページ件数
$all_pages_count = 0;
// 処理件数
$processing_cnt = 0;

// -----------------------------------------------
// エラーチェック
// -----------------------------------------------
// 大規模災害状態
if (!isDisasterFlg()) {
	disasterError('大規模災害状態ではないため即公開を行うことができません。');
}
// FTP接続フラグ
if (!FTP_UPLOAD_FLG) {
	disasterError('FTP接続が無効に設定されているため即公開を行うことができません。');
}
// アップロードロック
if (lock_file_management('lock') === FALSE) {
	disasterError("現在アップロード処理中のため即公開を行うことができません。<br />しばらく時間をおいてから再度お試しください。<br />", "javascript:history.back()");
}
// 分類コード
if (isset($_GET['cate_code'])) {
	$cate_code = trim($_GET['cate_code']);
}
// 種別
if ($cate_code != "" && isset($_GET['kind'])) {
	$kind = trim($_GET['kind']);
}

// -----------------------------------------------
// 即公開ページ取得
// -----------------------------------------------
// 大規模災害用分類一覧ページ取得
if ($obj_dis_handle->selectDisasterListTopList(PUBLISH_TABLE)) {
	// 取得結果を配列に格納
	while ($obj_dis_handle->fetch()) {
		$public_page_ary[$obj_dis_handle->fld['page_id']] = $obj_dis_handle->fld['page_id'];
	}
}
// 大規模災害用一覧表示ページ取得
if ($obj_dis_handle->selectDisasterListPage($cate_code, $kind)) {
	// 取得結果を配列に格納
	while ($obj_dis_handle->fetch()) {
		$public_page_ary[$obj_dis_handle->fld['page_id']] = $obj_dis_handle->fld['page_id'];
	}
}

foreach ($public_page_ary as $page_id => $value) {
	// 公開ページ情報取得
	if (!$obj_page->selectFromID($page_id, PUBLISH_TABLE)) {
		return FALSE;
	}
	
	// 新規作成中
	if ($obj_page->fld['work_class'] == WORK_CLASS_NEW) {
		unset($public_page_ary[$page_id]);
		continue;
	}
	// 非公開中
	if ($obj_page->fld['close_flg'] == FLAG_ON) {
		unset($public_page_ary[$page_id]);
		continue;
	}
	// ページ出力なし
	if ($obj_page->fld['output_html_flg'] == FLAG_OFF) {
		unset($public_page_ary[$page_id]);
		continue;
	}
	
	// ページ情報を格納
	$public_page_ary[$page_id] = $obj_page->fld;
	
	// ファイルパス変更
	$public_page_ary[$page_id]['file_path'] = getDisasterModePage($page_id, "file_path");
}

$all_pages_count = count($public_page_ary);

// -----------------------------------------------
// HTML画面表示設定
// -----------------------------------------------
// タイトル
$title_html = '大規模災害用一覧ページの即公開';
$title_image = '<img src="../images/bar_disaster_listpage_recreate.jpg" alt="大規模災害用一覧ページの即公開" width="920" height="30" />';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="../style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="../js/common.js" type="text/javascript"></script>
<script src="../js/category.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
$pgrs_func = new progressbar();
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<?=$pgrs_func->get_progress_area()?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<?php
// コメント表示
$pgrs_func->start("大規模災害用一覧ページの公開を実行しています。");

// 公開ページなし
if ($all_pages_count == 0) {
	// 完了メッセージ
	$pgrs_func->progress(0, 0);
	$pgrs_func->send_msg('即公開が必要なページは存在しませんでした。');
}
// 公開ページあり
else {
	// FTP接続
	if (!SFTP_FLG) {
		disasterConnectFtp($ftpCnc, $ftpCgiCnc, FLAG_ON);
	}
	
	foreach ($public_page_ary as $page_id => $fld_ary) {
		// SFTP接続
		if (SFTP_FLG) {
			disasterConnectFtp($ftpCnc, $ftpCginc, FLAG_ON);
		}
		
		if (!create_html($page_id, $fld_ary['file_path'], $objCnc, $ftpCnc, $out_errmsg, false)) {
			$pgrs_func->error($out_errmsg);
		}
		
		$processing_cnt++;
		$pgrs_func->progress($processing_cnt, $all_pages_count);
		
		// SFTP接続解除
		if (SFTP_FLG) {
			disasterConnectFtp($ftpCnc, $ftpCginc, FLAG_OFF);
		}
	}
	
	// FTP接続解除
	if (!SFTP_FLG) {
		disasterConnectFtp($ftpCnc, $ftpCgiCnc, FLAG_OFF);
	}
	
	// 完了メッセージ
	$pgrs_func->send_msg('大規模災害用一覧ページの公開が終了しました。');
}

$pgrs_func->disp_btn(HTTP_ROOT . RPW . "/admin/system/disaster/category/index.php");
$pgrs_func->end();

// アップロードロック解除
lock_file_management('unlock');
?>
</body>
</html>