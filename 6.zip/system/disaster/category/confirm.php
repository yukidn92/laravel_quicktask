<?php
// -----------------------------------------------------------------------------
// 
// 大規模災害用分類登録（確認画面）
// 
// -----------------------------------------------------------------------------
require ("./.htsetting");
require_once("../include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$obj_cate = new tbl_category($objCnc);

// -----------------------------------------------
// 初期化
// -----------------------------------------------
// 有効な処理種別
$enable_mode_ary = array(
		'new', 
		'upd', 
		'del'
);
// 登録先分類階層（第1分類）
$level = 1;
// 処理種別
$mode = '';
// 分類コード
$cate_code = '';
// 分類名
$cate_name = '';
// 公開設定
$public_view_flg = FLAG_OFF; 
$public_html = '';
// 完了画面に遷移するためのボタン画像
$next_button = '';

// -----------------------------------------------
// エラーチェック（共通）
// -----------------------------------------------
// 処理種別
if (!isset($_POST['cms_mode'])) {
	disasterError("パラメーターエラー【mode】");
}
if (!in_array($_POST['cms_mode'], $enable_mode_ary)) {
	disasterError("不正な処理種別のため処理を実行できませんでした。");
}
$mode = $_POST['cms_mode'];

// 分類コード
if (!isset($_POST['cms_cate_code'])) {
	disasterError("パラメーターエラー【cate_code】");
}
$cate_code = $_POST['cms_cate_code'];

// -----------------------------------------------
// 種別ごとの処理を実行
// -----------------------------------------------
switch ($mode) {
	// -------------------------------------------
	// 新規
	// -------------------------------------------
	case 'new':
		// 登録する分類コードが既に登録されていないかチェック
		if ($obj_cate->selectFromCode($cate_code)) {
			disasterError(htmlDisplay('分類コード「' . $cate_code) . '」は既に登録されています。<br />登録をやり直してください。');
		}
		
		// 分類名の入力チェック
		if (!isset($_POST['cms_cate_name'])) {
			disasterError("パラメーターエラー【cate_name】");
		}
		$cate_name = trim($_POST['cms_cate_name']);
		// 必須
		if ($cate_name == "") {
			disasterError("分類名の省略はできません。");
		}
		
		// 公開設定
		if (isDisasterFlg()) {
			$public_view_flg = FLAG_ON;
			$public_html = createDisasterPublicConfirm(FLAG_OFF);
		}
		
		// 完了画面に遷移するためのボタン画像
		$next_button = '<img src="' . RPW . '/admin/images/btn/btn_add.jpg" alt="追加" width="150" height="20" border="0" class="disaster-button10" />';
		break;
	// -------------------------------------------
	// 更新
	// -------------------------------------------
	case 'upd':
		// 大規模災害用でない分類の場合はエラー
		if (!$obj_cate->isDisasterCategory($cate_code)) {
			disasterError("大規模災害用でない分類を修正することはできません。");
		}
		
		// 分類名の入力チェック
		if (!isset($_POST['cms_cate_name'])) {
			disasterError("パラメーターエラー【cate_name】");
		}
		$cate_name = trim($_POST['cms_cate_name']);
		// 必須
		if ($cate_name == "") {
			disasterError("分類名の省略はできません。");
		}
		
		// 公開設定
		if (isDisasterFlg()) {
			$public_view_flg = FLAG_ON;
			$public_html = createDisasterPublicConfirm(FLAG_OFF);
		}
		
		// 完了画面に遷移するためのボタン画像
		$next_button = '<img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" class="disaster-button10" />';
		break;
	// -------------------------------------------
	// 削除
	// -------------------------------------------
	case 'del':
		// 大規模災害用でない分類の場合はエラー
		if (!$obj_cate->isDisasterCategory($_POST['cms_cate_code'])) {
			disasterError("大規模災害用でない分類を削除することはできません。");
		}
		
		// 分類名取得
		$cate_name = $obj_cate->fld['name'];
		
		// 公開設定
		if (isDisasterFlg()) {
			$public_view_flg = FLAG_ON;
			$public_html = createDisasterPublicCheckbox();
		}
		
		// 完了画面に遷移するためのボタン画像
		$next_button = '<img src="' . RPW . '/admin/images/btn/btn_del.jpg" alt="削除" width="150" height="20" border="0" class="disaster-button10" />';
		break;
}

// -----------------------------------------------
// HTML画面表示設定
// -----------------------------------------------
// タイトル
$title_html = '大規模災害用分類確認';
$title_image = '<img src="../images/bar_disaster_category_conf.jpg" alt="大規模災害用分類確認" width="920" height="30" />';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="../style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="../js/common.js" type="text/javascript"></script>
<script src="../js/category.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<p align="left" id="cms8341-pankuzu">トップ</p>
<form id="cms_complete_category" class="cms8341-form" name="cms_confirm_category" method="post" action="">
<input type="hidden" id="cms_mode" name="cms_mode" value="<?=htmlspecialchars($mode)?>" />
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<tr>
<th width="150" align="left" valign="top" scope="row">分類コード</th>
<td align="left" valign="top"><?=htmlDisplay($cate_code)?>
<input type="hidden" id="cms_cate_code" name="cms_cate_code" value="<?=htmlspecialchars($cate_code)?>" /></td>
</tr>
<tr>
<th width="150" align="left" valign="top" scope="row">分類名</th>
<td align="left" valign="top"><?=htmlDisplay($cate_name)?>
<input type="hidden" id="cms_cate_name" name="cms_cate_name" value="<?=htmlspecialchars($cate_name)?>" /></td>
</tr>
<?php
// 公開設定ありの場合
if ($public_view_flg == FLAG_ON) {
	echo '<tr>' . "\n";
	echo '<th width="150" align="left" valign="top" scope="row">公開設定</th>' . "\n";
	echo '<td align="left" valign="top">' . $public_html . '</td>' . "\n";
	echo '</tr>' . "\n";
}
// 公開設定なしの場合
else {
	// 即公開なし
	echo '<input type="hidden" id="cms_public" name="cms_public" value="' . FLAG_OFF . '" />';
}
?>
</table>
<p align="center"><a href="javascript:" onClick="return cxSendCompleteCategory();"><?=$next_button?></a><a href="javascript:history.back();"><img src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" class="disaster-button10" /></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
