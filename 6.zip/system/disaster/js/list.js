// -----------------------------------------------------------------------------
// 
// 大規模災害用分類一覧ページ新規作成　javascript
// 
// -----------------------------------------------------------------------------
/**
 * 初期設定
 * 
 * @return
 */
function cxInit() {
	Event.observe(document,'keypress',cxFileSubmit,false);
}
Event.observe(window,'load',cxInit,false);

/**
 * 新規ページ作成フォームの送信
 * 
 * @return
 */
var cmsCateTop = '';
function cxSubmit(uc) {
	// 
	var info = new Array();
	var kind = $F('cms_template_kind');
	
	// -------------------------------------------
	// 入力チェック：ページタイトル
	// -------------------------------------------
	if(!$('cms_page_title').value) {
		alert('タイトルが入力されていません。');
		$('cms_page_title').focus();
		return false;
	}
	// -------------------------------------------
	// 入力チェック：テンプレート
	// -------------------------------------------
	if(!$('cms_template_id').value) {
		alert('テンプレートが選択されていません。');
		cxTemplateSet();
		return false;
	}
	// -------------------------------------------
	// 入力チェック：ファイル保存先
	// -------------------------------------------
	if(!$('cms_dir_path').value || !$('cms_filename').value) {
		alert('ファイルの保存先が設定されていません。');
		cxRefferSet();
		return false;
	}
	
	// -------------------------------------------
	// アクセシビリティチェック
	// -------------------------------------------
	// ページタイトル
	info = fckCheck('タイトル',$('cms_page_title').value,info);
	if(!info)return false;
	if (info.length > 0) {
		var msg = info.join('\n') + '\nよろしいですか？';
		if (!confirm(msg)) {
			return false;
		}
	}
	
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_disaster_newpage').action = cms8341disaster_path + '/category/list/addpage.php';
	$('cms_disaster_newpage').submit();
	return false;
}

/**
 * 作成キャンセル
 * 
 * @return
 */
function cxPageCancel() {
	// 確認
	if (!confirm("作成を行わないと現在の内容は保存されません。\nキャンセルしてもよろしいですか？")) {
		return false;
	}
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_disaster_newpage').action = cms8341disaster_path + '/category/index.php';
	$('cms_disaster_newpage').submit();
	return false;
}

/**
 * Ajaxの通信失敗時のエラー処理
 * 
 * @return
 */
function cxFailure() {
	// エラー出力
	$('cms8341-reffer').innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
}

// -----------------------------------------------
// テンプレート
// -----------------------------------------------
// 初期化
var cmsTemplate = null;
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;

/**
 * テンプレートの選択
 * 
 * @param v
 * @return
 */
function cxSelectTemplate(v) {
	var t_id = 'cms_template_' + v;
	$('cms_template_image').src = $(t_id).src;
}

/**
 * テンプレート設定レイヤーの表示
 * 
 * @return
 */
function cxTemplateSet() {
	cmsTemplate = $('cms_template_id').options.selectedIndex;
	// close
	cxLayer('cms8341-reffer',0);
	// hidden
	cxComboHidden(new Array("cms_template_id"));
	$('cms_thumb').contentWindow.document.body.style.zoom = 0.3;
	$('cms_thumb').contentWindow.document.body.style.position = "relative";
	cxLayer('cms8341-template-select',1,600,340);
}

/**
 * テンプレートの選択
 * 
 * @return
 */
function cxSelectTemplate() {
	var si,src;
	si = $('cms_template_id').options.selectedIndex;
	if(si >= 0) {
		src = $('cms_template_id').options[si].id;
		//
		// テンプレート選択画面のプレビューでレスポンシブをOFF
		$('cms_thumb').src = cms8341admin_path + "/page/common/tplview.php?path=" + encodeURI(src) + '&thum=1';
		if(cms_sid) clearInterval(cms_sid);
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom,cms_inv_tim);
	} else {
		$('cms_thumb').src = 'javascript:';
	}
}

/**
 * テンプレートプレビューの表示調整
 * 
 * @return
 */
function cxIFrameZoom() {
	if($('cms_thumb').contentWindow.document.body){
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.3)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.3)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_inv_cnt++;
	if(cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}

/**
 * テンプレート決定
 * 
 * @return
 */
function cxTemplateSubmit() {
	var si,label,cate;
	si = $('cms_template_id').options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		label = $('cms_template_id').options[si].text;
		cate = 'テンプレート';
		$('cms-template-selected').innerHTML = cate + '：' + label + ' が選択されています。';
		$('cms_template_kind').value = $('cms_template_id').options[si].getAttribute('_kind');
	}
	//
	cxLayer('cms8341-template-select',0);
	// visible
	cxComboVisible();
}

/**
 * テンプレート設定レイヤーを閉じる
 * 
 * @return
 */
function cxTemplateClose() {
	//close
	cxLayer('cms8341-template-select',0);
	// visible
	cxComboVisible();
	if (cmsTemplate != null) {
		$('cms_template_id').options.selectedIndex = cmsTemplate;
		// re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}

/**
 * エンターキーの処理
 * 
 * @param event イベント
 * @return
 */
function cxFileSubmit(event){
	var item = Event.element(event);
	if($('cms_file_submit') && item.id == "cms_new_file" && event.keyCode == 13){
		cxRefferSubmit();
	}
}

// -----------------------------------------------
// パンくず
// -----------------------------------------------
/**
 * 親ページ設定
 * 
 * @return
 */
function cxOpenPanset() {
	var pid = $('cms_parent_id').value;
	if (pid == '') pid = $F('cms_page_id');
	var uri = cms8341admin_path+'/page/common/pankuzu_set.php?pid='+pid;
	window.name='win_cms8341Main';
		cxIframeLayer(uri, 800, 600, COVER_SETTING.COLOR, 'panset' );
	return false;
}

/**
 * Ajaxでパンくずを生成
 * 
 * @param pid 親ページID
 * @return
 */
function cxPankuzuSet(pid) {
	$('cms_parent_id').value = pid;
	var prm = 'page_id='+pid;
	cxAjaxCommand('cxGetPankuzu', prm, cxPankuzuSetSubmit);
}

/**
 * パンくずの表示を更新
 * 
 * @param r Ajax処理の戻値
 * @return
 */
function cxPankuzuSetSubmit(r) {
	// Ajax処理の戻値のテキスト
	var rText = r.responseText;
	// パンくず表示
	cmsPanAncestor = rText.replace(/<(a|area)( [^>]*)?>/ig, '<$1 href="#">');
	if ($('cms8341-pankuzu')) $('cms8341-pankuzu').innerHTML = rText.replace(/<\/?(a|area)( [^>]*)?>/ig, '');
}

/**
 * 親ページなし設定
 * 
 * @return
 */
function cxParentDel(){
	// 確認
	if(!confirm("現在設定されている親ページ情報を削除します。\n本当によろしいですか？")) {
		return false;
	}
	// 値を消す
	$('cms_parent_id').value = "";
	// 表示を消す
	$('cms8341-pankuzu').innerHTML = "&nbsp;";
	cmsPanAncestor = "";
	return false;
}
