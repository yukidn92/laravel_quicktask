// -----------------------------------------------------------------------------
// 
// 大規模災害分類管理　javascript
// 
// -----------------------------------------------------------------------------
// -----------------------------------------------
// 分類の追加・修正・削除
// -----------------------------------------------
/**
 * 「分類の追加・修正・削除」入力画面への遷移
 * 
 * @param mode
 * @param cate_code
 * @return
 */
function cxSendFormCategory(mode, cate_code) {
	$('cms_mode').value = (!mode ? "new" : mode);
	$('cms_cate_code').value = cate_code;
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	if ($('cms_mode').value != 'del') {
		$('cms_form_category').action = cms8341disaster_path + '/category/form.php';
	}
	else {
		$('cms_form_category').action = cms8341disaster_path + '/category/confirm.php';
	}
	$('cms_form_category').target = '_self';
	$('cms_form_category').submit();
	return false;
}

/**
 * 「分類の追加・修正・削除」確認画面への遷移
 * 
 * @return
 */
function cxSendConfirmCategory() {
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_confirm_category').action = cms8341disaster_path + '/category/confirm.php';
	$('cms_confirm_category').target = '_self';
	$('cms_confirm_category').submit();
	return false;
}

/**
 * 「分類の追加・修正・削除」完了画面への遷移
 * 
 * @return
 */
function cxSendCompleteCategory() {
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_complete_category').action = cms8341disaster_path + '/category/complete.php';
	$('cms_complete_category').target = '_self';
	$('cms_complete_category').submit();
	return false;
}

// -----------------------------------------------
// 分類の表示順変更
// -----------------------------------------------
/**
 * 「分類の表示順変更」入力画面への遷移
 * 
 * @return
 */
function cxSendFormSortOrder() {
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_form_sortorder').action = cms8341disaster_path + '/category/sort_order/form.php';
	$('cms_form_sortorder').target = '_self';
	$('cms_form_sortorder').submit();
	return false;
}

/**
 * 「分類の表示順変更」完了画面への遷移
 * 
 * @return
 */
function cxSendCompleteSortOrder() {
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_complete_sortorder').action = cms8341disaster_path + '/category/sort_order/complete.php';
	$('cms_complete_sortorder').target = '_self';
	$('cms_complete_sortorder').submit();
	return false;
}

// -----------------------------------------------
// 大規模災害用分類一覧ページ新規作成
// -----------------------------------------------
/**
 * 「大規模災害用分類一覧ページ新規作成」入力画面への遷移
 * 
 * @param cate_code
 * @param kind
 * @return
 */
function cxSendFormCreateListPage(cate_code, kind) {
	$('cms_list_cate_code').value = cate_code;
	$('cms_list_kind').value = kind;
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_form_createlistpage').action = cms8341disaster_path + '/category/list/newpage.php';
	$('cms_form_createlistpage').target = '_self';
	$('cms_form_createlistpage').submit();
	return false;
}

/**
 * 「大規模災害用分類一覧ページ新規作成」トップページへの遷移
 * 
 * @return
 */
function cxSendReturnCreateListPage() {
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_return_createlistpage').action = cms8341disaster_path + '/category/index.php';
	$('cms_return_createlistpage').target = '_self';
	$('cms_return_createlistpage').submit();
	return false;
}

// -----------------------------------------------
// 大規模災害用分類一覧ページ表示設定
// -----------------------------------------------
/**
 * 「大規模災害用分類一覧ページ表示設定」入力画面への遷移
 * 
 * @param cate_code
 * @param kind
 * @return
 */
function cxSendFormChangeListPage(cate_code, kind) {
	$('cms_change_cate_code').value = cate_code;
	$('cms_change_kind').value = kind;
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_form_changelistpage').action = cms8341disaster_path + '/category/list/sort_form.php';
	$('cms_form_changelistpage').target = '_self';
	$('cms_form_changelistpage').submit();
	return false;
}

/**
 * 「大規模災害用分類一覧ページ表示設定」完了画面への遷移
 * 
 * @return
 */
function cxSendCompleteChangeListPage() {
	// -------------------------------------------
	// フォーム送信
	// -------------------------------------------
	$('cms_complete_changelistpage').action = cms8341disaster_path + '/category/list/sort_complete.php';
	$('cms_complete_changelistpage').target = '_self';
	$('cms_complete_changelistpage').submit();
	return false;
}
