<?php
/* 大規模災害管理設定
 * 
 */
require ("./.htsetting");
require_once ("./include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$obj_page = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/function/func_progressbar.inc');
$pgrs_func = new progressbar();

// 大規模災害状態のフラグ
$disaster_flg = ($obj_dis_handle->isDisasterFlg() ? FLAG_ON : FLAG_OFF);

// 引数で受け取った大規模災害状態のフラグ
$disaster_post_flg = FLAG_OFF;

if (isset($_POST['cms_disaster_mode'])) {
	
	foreach ((array) $_POST['cms_disaster_mode'] as $value) {
		
		if ($value != FLAG_ON) continue;
		
		$disaster_post_flg = FLAG_ON;
		break;
	}
}

// 変更の必要がない場合はトップページに戻る
if ($disaster_flg == $disaster_post_flg) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/system/disaster/index.php");
	exit();
}

$all_pages_count = 0;

// アップロードロック
if (lock_file_management('lock') === FALSE) {
	// ロック中の場合はエラー
	disasterError("現在アップロード処理中のため即公開を行うことができません。<br />しばらく時間をおいてから再度お試しください。<br />", "javascript:history.back()");
	exit();
}

// トランザクション開始
$objCnc->begin();

// データベース更新
if (!$obj_dis_handle->change_disaster_flg()) {
	disasterError("大規模災害状態の変更に失敗しました。");
}

// 公開する必要があるページ一覧を取得
$disaster_upload_ary = getDisaseterUploadPageList();

// 合計数
$all_pages_count = count($disaster_upload_ary);

// タイトル
$title_html = '大規模災害管理';
$title_image = '<img src="./images/bar_disaster_page_recreate.jpg" alt="大規模災害ページの即公開" width="920" height="30" />';

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="./js/common.js" type="text/javascript"></script>
<script src="./index.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<?php
// 表示領域の取得
echo $pgrs_func->get_progress_area();

// コメント表示
$pgrs_func->start("大規模災害ページの公開を実行しています。");

// 公開ページなし
if ($all_pages_count == 0) {
	// 完了メッセージ
	$pgrs_func->progress(0, 0);
	$pgrs_func->send_msg('変更が必要な処理はありませんでした。');
}
// 公開ページあり
else {
	// 処理件数
	$processing_cnt = 0;
	
	// FTP接続
	if (FTP_UPLOAD_FLG && !SFTP_FLG) {
		disasterConnectFtp($ftpCnc, $ftpCgiCnc, FLAG_ON);
	}
	
	// 公開処理
	disasterPublicHtml($ftpCnc, $ftpCgiCnc, $pgrs_func, $disaster_upload_ary, $disaster_post_flg);
	
	// FTP接続解除
	if (FTP_UPLOAD_FLG && !SFTP_FLG) {
		disasterConnectFtp($ftpCnc, $ftpCgiCnc, FLAG_OFF);
	}
	
	// 完了メッセージ
	$pgrs_func->send_msg('大規模災害ページの公開が終了しました。');
}

$pgrs_func->disp_btn(HTTP_ROOT . RPW . "/admin/system/disaster/index.php");
$pgrs_func->end();

// 処理完了
$objCnc->commit();
// アップロードロック解除
lock_file_management('unlock');
?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
