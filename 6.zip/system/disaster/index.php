<?php
/* 大規模災害管理設定
 * 
 */
require ("./.htsetting");
require_once("./include/common.inc");

// データベース
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_disaster_handler.inc');
$obj_dis_handle = new tbl_disaster_handler($objCnc);

// 大規模災害状態のフラグ
$disaster_flg = ($obj_dis_handle->isDisasterFlg() ? FLAG_ON : FLAG_OFF);



// 状態切替用チェックボックス配列
$disaster_check_ary = array(
		FLAG_ON => '大規模災害状態にする'
);
// 初期値
$disaster_check_def = array();
// 大規模災害状態であればチェック済みにする
if ($disaster_flg == FLAG_ON) {
	$disaster_check_def[FLAG_ON] = FLAG_ON;
}

// 入力項目配列
$input_ary = array(
		"1" => array(
				"input" => mkcheckbox($disaster_check_ary, "cms_disaster_mode", $disaster_check_def, 0),
				"label" => "大規模災害制御",
				"memo"  => "大規模災害状態の時はトップページなどが、大規模災害に作成されたページに切り替わります。",
				"memo_elements" => array(
						"class" => "disaster-memo"
				)
		)
);

// タイトル
$title_html = '大規模災害設定';
$title_image = '<img src="./images/bar_disaster_index.jpg" alt="大規模災害設定" width="920" height="30" />';

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title><?=$title_html?></title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="./style/disaster.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="./js/common.js" type="text/javascript"></script>
<script src="./js/index.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'disaster';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><?=$title_image?></div>
<div class="cms8341-area-corner">
<form id="cms_disaster_form" class="cms8341-form" name="tpl_form" method="post" action="" enctype="multipart/form-data">

<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<?php
foreach ($input_ary as $number => $detail) {
	
	if (!isset($detail['label'])) $detail['label'] = htmlDisplay("");
	if (!isset($detail['input'])) $detail['input'] = htmlDisplay("");
	
	echo '<tr>' , "\n";
	// 項目
	echo '<th width="200" align="left" valign="top" scope="row">';
	echo $detail['label'];
	echo '</th>' . "\n";
	// 入力
	echo '<td align="left" valign="middle">';
	echo $detail['input'];
	// 説明
	if (isset($detail['memo']) && $detail['memo'] != "") {
		echo '<p';
		// 属性追加
		if (isset($detail['memo_elements']) && is_array($detail['memo_elements'])) {
			foreach ($detail['memo_elements'] as $element => $value) {
				echo " ";
				echo $element . '="' . $value . '"';
			}
		}
		echo '>';
		// 説明内容
		echo $detail['memo'];
		echo '</p>';
	}
	echo '</td>' . "\n";
	echo '</tr>' . "\n";
}
?>
</table>

<p align="center"><a href="javascript:" onClick="return cx_disaster_change();"><img src="./images/btn_disaster_change.jpg" alt="大規模災害切替" width="150" height="20" border="0" /></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
