<?php
/*
 * 外部ファイル出力
 */
//外部ファイル読み込み
require ("./.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

//「tbl_publish_～」がつくテーブルより情報を取得する際に使用する配列
$GET_PUBLISH_TBL_INFO = getDefineArray("GET_PUBLISH_TBL_INFO");
//「tbl_work_～」がつくテーブルより情報を取得する際に使用する配列
$GET_WORK_TBL_INFO = getDefineArray("GET_WORK_TBL_INFO");
//「tbl_～」がつくテーブルより情報を取得する際に使用する配列
$GET_UNIQUE_TBL_INFO = getDefineArray("GET_UNIQUE_TBL_INFO");

//パラメータチェック
if (!isset($_POST['cms_log_out']) || !isset($_POST['cms_dir'])) {
	DispError("パラメータが不正です。", "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

//変数の宣言
//ログの出力を制御するフラグ
$log_export_flg = (isset($_POST['cms_log_out']) ? $_POST['cms_log_out'] : FLAG_OFF);
//エラーメッセージ用変数
$err_msg = "";
//CSV作成用データ取得変数
$page_data = array();
//テキストエリアにて指定されたファイルパス取得変数
$ary_file_path = array();
//一時ファイルパス
$temp_file_path = array();
//重複削除後ファイルパス
$file_path_ary = array();

//テキストエリアに指定されたファイルパスを改行文字区切りで取得する
$ary_file_path = explode("\n", $_POST['cms_dir']);

//ファイルパス前後にあるスペースを消し先頭に「/」がつくようにパスを修正
foreach ((array) $ary_file_path as $file_path) {
	$file_path = trim(mb_convert_kana($file_path, "as"));
	if ($file_path == "") {
		continue;
	}
	if (preg_match('/^[^\/]/', $file_path)) {
		$file_path = '/' . $file_path;
	}
	
	$temp_file_path[] = $file_path;

}

//重複削除後ファイルパス取得
$file_path_ary = array_unique($temp_file_path);

//フォルダパスとhtmlのパスを分離
$dirpath_ary = array();
$file_paths = array();
foreach ($file_path_ary as $file_path) {
	if (substr($file_path, -5) == ".html") {
		$file_paths[] = $file_path;
	}
	else {
		if (substr($file_path, -1) != "/") $file_path .= "/";
		$dirpath_ary[] = $file_path;
	}
}

//パスが指定されてない場合エラーだして終了		
if (count($file_paths) < 1 && count($dirpath_ary) < 1 && $log_export_flg == FLAG_OFF) {
	DispError("ページ情報を出力するファイルパス又はフォルダパスを指定してください。", "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}
//エラーメッセージ
$err_msg = "";
//フォルダパスからファイルパスを取得
if (count($dirpath_ary) != 0) {
	$objPage->setTableName('tbl_publish_page');
	//サブディレクトリを含む場合
	if (isset($_POST['sub_dir']) && $_POST['sub_dir'] == "1") {
		foreach ($dirpath_ary as $path) {
			$where = $objPage->_addslashesC("dir_path", $path . "%", "LIKE");
			$objPage->select($where, 'file_path');
			$objPage->fetchrow = 0;
			if ($objPage->getRowCount() == 0) {
				if ($err_msg == "") $err_msg = "指定されたフォルダパスの公開ページ情報の取得に失敗しました。" . "<br>";
				$err_msg .= "・" . html_convert($path) . "<br>";
			}
			else {
				while ($objPage->fetch()) {
					$file_paths[] = $objPage->fld['file_path'];
				}
			}
		}
	}
	else { //サブディレクトリを含まない場合
		foreach ($dirpath_ary as $path) {
			$where = $objPage->_addslashesC("dir_path", $path, '=', 'TEXT');
			$objPage->select($where, 'file_path');
			$objPage->fetchrow = 0;
			if ($objPage->getRowCount() == 0) {
				if ($err_msg == "") $err_msg = "指定されたフォルダパスの公開ページ情報の取得に失敗しました。" . "<br>";
				$err_msg .= "・" . html_convert($path) . "<br>";
			}
			else {
				while ($objPage->fetch()) {
					$file_paths[] = $objPage->fld['file_path'];
				}
			}
		}
	}
}
//重複削除
$file_path_ary = array();
$file_path_ary = array_unique($file_paths);

foreach ((array) $file_path_ary as $file_path) {
	$temp_file_path = preg_replace("/\s/i", "", $file_path);
	
	if ($temp_file_path == "") continue;
	
	//公開ページ情報取得
	if (isset($_POST['root_dir']) && $_POST['root_dir'] != "") {
		$objPage->selectFromPath($_POST['root_dir'] . $file_path);
	}
	else {
		$objPage->selectFromPath($file_path);
	}
	if ($objPage->getRowCount() < 1) {
		if ($err_msg == "") $err_msg = "指定されたファイルパスの公開ページ情報の取得に失敗しました。" . "<br>";
		$err_msg .= "・" . html_convert($file_path) . "<br>";
		continue;
	}
	$page_data[$file_path]['tbl_publish_page'] = array(
			$objPage->fld
	);
	
	//tbl_publish_～より情報を取得
	foreach ((array) $GET_PUBLISH_TBL_INFO as $tbl => $column) {
		$val = $objPage->fld[$column];
		$page_data[$file_path][$tbl] = getCsvData($tbl, $column, $val);
	}
	
	//tbl_work_～より情報を取得
	foreach ((array) $GET_WORK_TBL_INFO as $tbl => $column) {
		$val = $objPage->fld[$column];
		$page_data[$file_path][$tbl] = getCsvData($tbl, $column, $val);
	}
	
	//「publish」「work」のつかないテーブル
	foreach ((array) $GET_UNIQUE_TBL_INFO as $tbl => $column) {
		$val = $objPage->fld[$column];
		$page_data[$file_path][$tbl] = getCsvData($tbl, $column, $val);
	}

}

if ($err_msg != "") {
	DispError($err_msg, "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

$csvData = "";
//CSVデータ作成
foreach ((array) $page_data as $file_name => $tbl_data) {
	if ($csvData != "") $csvData .= "\n";
	$csvData .= csvWrite("※※※" . $file_name . "※※※", "\"") . "\n";
	
	foreach ((array) $tbl_data as $tbl => $data) {
		$csvData .= csvWrite("【" . $tbl . "】", "\"") . "\n";
		
		// ファイルパス生成
		// データ生成
		$cnt = 0;
		$line = "";
		foreach ($data as $key => $value) {
			if ($cnt == 0) {
				//テーブル情報の1行目にはカラム名を入れる
				foreach ((array) $value as $column => $v) {
					if ($column != 'message') {
						if ($line != "") $line .= ",";
						$line .= csvWrite($column, "\"");
					}
				}
				if ($column != 'message') {
					$csvData .= $line . "\n";
				}
			}
			$line = "";
			foreach ((array) $value as $column => $v) {
				if ($line != "") $line .= ",";
				$line .= csvWrite($v, "\"");
			}
			$csvData .= $line . "\n";
			$cnt++;
		}
	}
}

//ファイル削除
removeDir(DOCUMENT_ROOT . DIR_PATH_ZIP);
if (@file_exists(DOCUMENT_ROOT . DIR_PATH_ZIP)) $err_msg .= "<br />\nフォルダの中に存在するファイルの削除に失敗しました。【" . DOCUMENT_ROOT . DIR_PATH_ZIP . "】" . "<br />\n";

//フォルダの作成
if ($err_msg == "") {
	$mk_dir_path = DOCUMENT_ROOT . DIR_PATH_ZIP;
	if ($log_export_flg == FLAG_ON) {
		$dummy_file_path = "log/dummy.txt";
	}
	else {
		$dummy_file_path = "dummy.txt";
	}
	if (mkNewDirectory($mk_dir_path . $dummy_file_path) == FALSE) {
		$err_msg .= "ディレクトリの作成に失敗しました。【" . $mk_dir_path . "】" . "<br />\n";
	}
}

//logフォルダ内ファイルコピー
if ($err_msg == "" && $log_export_flg == FLAG_ON) {
	$log_file_paths = getDirFilesAry("/log");
	
	for($i = 0; $i < count($log_file_paths); $i++) {
		//拡張子がlog以外のファイルはスルー
		if (pathinfo($log_file_paths[$i], PATHINFO_EXTENSION) != "log") continue;
		if (!@copy(DOCUMENT_ROOT . RPW . $log_file_paths[$i], DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/zip" . $log_file_paths[$i])) {
			$err_msg .= "ログファイルのコピーに失敗しました。(コピー元)【" . DOCUMENT_ROOT . RPW . $log_file_paths[$i] . "】" . "<br />\n\n";
		}
	}

}

if ($err_msg == "" && $csvData != "") {
	$fileName = "dump.csv";
	$to_csv_path = DOCUMENT_ROOT . DIR_PATH_ZIP . $fileName;
	if (!mkNewDirectory($to_csv_path)) return FALSE;
	$fp = @fopen($to_csv_path, 'w', 0777);
	if (@fwrite($fp, UTF8toSJIS($csvData)) === false) {
		if (isset($fp) && $fp != "") @fclose($fp);
		$err_msg = "CSVファイルの作成に失敗しました。";
	}
	@fclose($fp);
}

//setting_varsファイルのコピー
if ($err_msg == "") {
	$incAry = explode("/", get_setting_vars(APPLICATION_ROOT . "/common"));
	$inc_file_name = end($incAry);
	$setting_vars_path = get_setting_vars(APPLICATION_ROOT . "/common");
	if (!@copy($setting_vars_path, DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/zip/" . $inc_file_name)) {
		$err_msg .= "settingファイルのコピーに失敗しました。(コピー元)【" . $setting_vars_path . "】" . "<br />\n\n";
	}
}

//エラーが無い場合
if ($err_msg == "") {
	//フォルダが存在する場合
	if (@file_exists(DOCUMENT_ROOT . DIR_PATH_UPLOAD . "/zip")) {
		//Zipを作成
		$zip_path = DOCUMENT_ROOT . DIR_PATH_ZIP . date("YmdHis") . ".zip";
		//Zipの作成に失敗
		if (!create_Zip(DOCUMENT_ROOT . DIR_PATH_ZIP, $zip_path)) $err_msg .= "Zipファイルの作成に失敗しました。【" . $zip_path . "】" . "<br />\n";
		//Zipの作成に成功
		else if (@file_exists($zip_path)) {
			if (($fp = @fopen($zip_path, 'rb')) === FALSE) $err_msg .= "Zipファイルの読み込みに失敗しました。【" . $zip_path . "】" . "<br>\n";
			else {
				//ヘッダ出力
				header("Content-Type: application/octet-stream");
				header("Content-Disposition: attachment; filename=" . basename($zip_path));
				header('Content-Length: ' . @filesize($zip_path));
				while ($zip_data = @fread($fp, 4096)) {
					print($zip_data);
				}
			}
			if ($fp) @fclose($fp);
		}
	}
}

//エラーメッセージがある場合
if ($err_msg != "") DispError($err_msg, "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
exit();

//文字変換
function html_convert($p_str) {
	$p_str = str_replace("&", "&amp;", $p_str);
	$p_str = str_replace("\"", "&quot;", $p_str);
	$p_str = str_replace("<", "&lt", $p_str);
	$p_str = str_replace(">", "&gt;", $p_str);
	$p_str = str_replace(",", "&#44", $p_str);
	$p_str = str_replace("'", "&#39", $p_str);
	$p_str = str_replace("\r\n", "\n", $p_str);
	$p_str = str_replace("\r", "\n", $p_str);
	$p_str = str_replace(" ", "&nbsp;", $p_str);
	$p_str = str_replace("\n", "<br />", $p_str);
	return $p_str;
}
/**
 * Zip圧縮を行う
 *
 * @param $folder_path 圧縮対象フォルダパス
 * @param $zip_path 圧縮後Zipパス
 * @return 作成に成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function create_Zip($folder_path, $zip_path) {
	//引数のチェック
	if ($folder_path == "" || $zip_path == "") return FALSE;
	//フォルダの存在チェック
	if (!@file_exists($folder_path)) return TRUE;
	// ディレクトリパスを正規化
	$folder_path = preg_replace('/\/+/i', '/', $folder_path);
	$zip_path = preg_replace('/\/+/i', '/', $zip_path);
	//実際に圧縮する
	if (defined("SET_ZIP_EXE")) {
		exec('cd ' . $folder_path . ' & ' . SET_ZIP_EXE . ' -r ' . $zip_path . ' *');
	}
	else {
		exec('cd ' . $folder_path . '; zip -r ' . $zip_path . ' *');
	}
	//Zipファイルの存在チェック
	if (!@file_exists($zip_path)) return FALSE;
	return TRUE;
}

/**
 * CSV作成用配列を作成し戻り値として返す
 *
 * @param $tbl 対象テーブル名
 * @param $column 検索対象カラム名
 * @param $val 検索値
 * @return 作成した配列
 */
function getCsvData($tbl, $column, $val) {
	global $objCnc;
	global $objDac;
	$data = array();
	;
	
	if ($tbl == "" || $column == "" || $val == "") return "";
	
	$sql = "SELECT * FROM " . $tbl . " WHERE " . $column . "=" . $val;
	
	$objDac->execute($sql);
	
	if ($objDac->getRowCount() < 1) {
		$data[] = array(
				'message' => "情報が存在しません。"
		);
		return $data;
	}
	
	while ($objDac->fetch()) {
		$data[] = $objDac->fld;
	}
	
	return $data;
}

?>
