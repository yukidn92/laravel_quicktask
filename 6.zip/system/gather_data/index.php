<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("./.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>情報収集機能</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>

<script type="text/javascript">
<!--
// 出力実行
function cxSubmit() {
	var msg = new Array();
	
	if (!$('cms_dir').value) msg.push('ページ情報を出力するファイルパスを指定してください。');
	// エラー表示
	if (msg.length > 0 && !document.cms_gather_data.cms_log_out_y.checked){
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}
	document.cms_gather_data.submit();
	return false;
}

function cxErrorClose() {
	cxLayer('cms8341-error',0);
}

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'gather_data';
include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-gather_data">
<div><img src="images/bar_gather_data_index.jpg" alt="情報収集機能"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form name="cms_gather_data" class="cms8341-form" method="post"
	action="submit.php" enctype="multipart/form-data">

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" valign="top" scope="row"><label for="cms_dir"> ファイルパス</label></th>
		<td valign="middle"><?=HTTP_ROOT . RPW?>&nbsp;<textarea id="cms_dir"
			name="cms_dir" value="" style="width: 450px;" rows="10"></textarea> <br>
		<p><input type="checkbox" id="sub_dir" name="sub_dir" value="1"><label
			for="sub_dir">サブディレクトリを含む</label></p>
		<p><span class="cms_require"><small>※ファイルパスを複数指定する場合は改行で区切ってください。</small></span></p>
		</td>
	</tr>
	<th align="left" valign="top" nowrap scope="row"><label for="label">
	ログ出力</label></th>
	<td><input type="radio" name="cms_log_out" id="cms_log_out_y" value="1"
		checked><label for="cms_log_out_y">する</label> <input type="radio"
		name="cms_log_out" id="cms_log_out_n" value="0"><label
		for="cms_log_out_n">しない</label><br>
	</td>
</table>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="images/btn_export.jpg" alt="出力" width="100" height="20" border="0"
	style="margin-right: 10px;"></a></p>

</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="../../images/layer/bar_error.jpg" alt="エラー" width="480"
					height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxErrorClose();"><img
			src="../../images/btn/btn_ok.jpg" alt="OK" width="100" height="20"
			border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
</body>
</html>
