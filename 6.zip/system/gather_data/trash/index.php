<?php
/*
 * ゴミ箱データ収集：フォーム画面
 */
require ("../.htsetting");

$dateFrom = date('Y-m-d', strtotime("-" . DELETED_PAGE_KEEPING_TERM . "days"));
$dateFromYear = date('Y', strtotime($dateFrom));
$dateFromMonth = date('n', strtotime($dateFrom));
$dateFromDay = date('j', strtotime($dateFrom));
$dateFromJap = sprintf('%4s年%s月%s日', $dateFromYear, $dateFromMonth, $dateFromDay);

// ** HTML 出力 -----------------------------
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		<title>ゴミ箱データの収集</title>
		<link rel="stylesheet" href="<?= RPW ?>/admin/style/shared.css" type="text/css">
		<script src="<?= RPW ?>/admin/js/library/prototype.js" type="text/javascript"></script>
		<script src="<?= RPW ?>/admin/js/shared.js" type="text/javascript"></script>
		<script src="<?= RPW ?>/admin/js/calendar.js" type="text/javascript"></script>
		<script src="<?= RPW ?>/admin/js/common_action.js" type="text/javascript"></script>
		<script src="./trash.js" type="text/javascript"></script>
	</head>
	<body id="cms8341-mainbg">
		<form id="click_total_form" name="click_total_form" class="cms8341-form" method="post" action="./download.php" target="">
			<?php
			// 権限チェック
			if (ENABLE_OPTION_TRASH == FLAG_OFF) {
				user_error("不正なアクセスです。");
			}

			// ヘッダーメニュー挿入
			$headerMode = 'gather_data';
			include (APPLICATION_ROOT . "/common/inc/system_menu.inc");
			?>
			<div align="center" id="cms8341-contents">
				<div><img src="../images/title_trash_form.jpg" alt="ゴミ箱データの収集" width="920" height="30"></div>
				<div class="cms8341-area-corner">
					<p>ゴミ箱フォルダには<?= $dateFromJap ?>以降に削除したページ情報が存在します。</p>
					<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
						<tr>
							<th style="width: 100px" align="left" valign="middle" nowrap scope="row">
								<label for="cms_pdsy">期間</label>
							</th>
							<td align="left" valign="middle">
								<input type="text" maxlength="4" id="cms_pdsy" name="cms_pdsy" style="width: 50px; ime-mode: disabled"> 年
								<input type="text" maxlength="2" id="cms_pdsm" name="cms_pdsm" style="width: 25px; ime-mode: disabled"> 月
								<input type="text" maxlength="2" id="cms_pdsd" name="cms_pdsd" style="width: 25px; ime-mode: disabled"> 日
								<input type="text" maxlength="2" id="cms_pdsh" name="cms_pdsh" style="width: 25px; ime-mode: disabled"> 時
								<input type="text" maxlength="2" id="cms_pdsi" name="cms_pdsi" style="width: 25px; ime-mode: disabled"> 分
								<a href="javascript:" onClick="return cxCalendarOpen('cms_pd', 'start')"><img src="<?= RPW ?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a> から &nbsp; 
								<input type="text" maxlength="4" id="cms_pdey" name="cms_pdey" style="width: 50px; ime-mode: disabled"> 年
								<input type="text" maxlength="2" id="cms_pdem" name="cms_pdem" style="width: 25px; ime-mode: disabled"> 月
								<input type="text" maxlength="2" id="cms_pded" name="cms_pded" style="width: 25px; ime-mode: disabled"> 日
								<input type="text" maxlength="2" id="cms_pdeh" name="cms_pdeh" style="width: 25px; ime-mode: disabled"> 時
								<input type="text" maxlength="2" id="cms_pdei" name="cms_pdei" style="width: 25px; ime-mode: disabled"> 分
								<a href="javascript:" onClick="return cxCalendarOpen('cms_pd', 'end')"><img src="<?= RPW ?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a> まで
							</td>
						</tr>
					</table>
					<p align="center">
						<a href="javascript:" onClick="return cxClickErrChk('click_total_form')">
							<img src="../images/btn_export.jpg" width="100" height="20" border="0" alt="出力">
						</a>
					</p>
				</div>
				<div>
					<img src="<?= RPW ?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10">
				</div>
			</div>
			<!-- cms8341-contents -->
		</form>
		<!--***カレンダーレイヤー　　　 ここから********************************-->
		<div id="cms8341-calendar" class="cms8341-layer">
			<table width="500" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
						<table width="500" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
							<tr>
								<td align="left" valign="middle">
									<img src="<?= RPW ?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー" width="200" height="20" style="margin: 4px 10px;">
								</td>
								<td width="78" align="right" valign="middle">
									<a href="javascript:" onClick="return cxCalendarClose()">
										<img src="<?= RPW ?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin: 4px 10px;">
									</a>
								</td>
							</tr>
						</table>
						<div style="width: 100%; margin-top: 10px">
							<div id="cms8341-calbody" style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<!--***カレンダーレイヤー　　　 ここまで********************************-->
		<!--***エラーメッセージレイヤー ここから********************************-->
		<div id="cms8341-error" class="cms8341-layer">
			<table width="500" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
						<table width="500" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
							<tr>
								<td align="left" valign="middle">
									<img src="<?= RPW ?>/admin/images/layer/bar_error.jpg" alt="エラー" width="480" height="20" style="margin: 4px 10px;">
								</td>
							</tr>
						</table>
						<div style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
							<div align="center">
								<div style="width: 430px; height: 120px; padding: 5px; text-align: left" id="cms8341-errormsg">メッセージ</div>
								<div style="margin: 15px 0px;">
									<a href="javascript:" onClick="return cxCloseError()">
										<img src="<?= RPW ?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100" height="20" border="0">
									</a>
								</div>
							</div>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<!--***エラーメッセージレイヤー ここまで********************************-->
	</body>
</html>
