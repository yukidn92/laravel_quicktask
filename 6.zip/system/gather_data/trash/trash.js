/*
 * ゴミ箱データ収集用jsファイル
 */

/**
 * サブミット
 * 
 * @param string
 * form サブミットするフォームのname
 * 
 */
function cxSubmit(form) {
	$(form).submit();
	return false;
}

/**
 * エラーレイヤーのクローズ
 */
function cxCloseError() {
	cxComboVisible();
	cxLayer('cms8341-error', 0);
}

/**
 * クリック集計プログラム用エラーチェック
 * 
 * @param	string	form	サブミットするフォームのname
 * 
 *【備考】
 * エラーが存在する場合はレイヤーにエラーを表示
 * エラーチェックが正常に完了した場合はサブミット
 * 
 */
function cxClickErrChk(form) {

	// エラーチェック
	var msg = new Array();
	var sub = new Array();
	
	// 期間の開始日、終了日のチェック
	sub = cxDateCheckNew("cms_pd", "ymdhi", 1, "期間");
	if (sub.length > 0) {
		for (i = 0; i < sub.length; i++) {
			msg.push(sub[i]);
		}
	}

	// エラー表示
	if (msg.length > 0) {

		var output_msg = '<p>';
		// msg.sort();
		for (var i = 0; i < msg.length; i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';

		cxComboHidden(new Array("cms_template_id"));
		$('cms8341-errormsg').innerHTML = output_msg;
		cxLayer('cms8341-error', 1, 500, 500);
		return false;
	}

	// エラーなしなのでサブミット
	cxSubmit(form);
	return false;
}