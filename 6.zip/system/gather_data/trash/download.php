<?php
/*
 * 外部ファイル出力
 */
//外部ファイル読み込み
require ("../.htsetting");

//エラーメッセージ用変数
$errMsg = "";
$size = 0;
$folderExport = array();

//Path file trash and zipTrash
$pathTrash = DOCUMENT_ROOT . TRASH_ROOT;
$pathTrashTemp = DOCUMENT_ROOT . DIR_PATH_TEMP . TRASH_ROOT;

//Create temp/trash folder
removeZipDir($pathTrashTemp, $errMsg, true);
if (!@file_exists($pathTrashTemp) && !@mkdir($pathTrashTemp)) {
	$errMsg .= "【" . $pathTrashTemp . "】 のフォルダー作成に失敗しました。" . "<br />\n\n";
}

//Check server capacity use rate
$checkDisk = (INSTALL_DRIVE != '') ? INSTALL_DRIVE : '/';
$diskFreeSpace  = disk_free_space($checkDisk) / (1024 * 1024);

if ($diskFreeSpace <= DL_DATA_CAPACITY) {
	DispError("サーバーに十分な空き容量がありません。", "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

//Get param from_date, to_date
$fromYear = getPostParams('cms_pdsy');
$fromMonth = getPostParams('cms_pdsm');
$fromDay = getPostParams('cms_pdsd');
$fromHour = getPostParams('cms_pdsh');
$fromMin = getPostParams('cms_pdsi');

$toYear = getPostParams('cms_pdey');
$toMonth = getPostParams('cms_pdem');
$toDay = getPostParams('cms_pded');
$toHour = getPostParams('cms_pdeh');
$toMin = getPostParams('cms_pdei');

//データの取得
if (!$fromYear || !$fromMonth || !$fromDay ||
		!$toYear || !$toMonth || !$toDay
) {
	DispError("期間の指定が正しくありません。", "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

$fromDate = sprintf('%4d%02d%02d%02d%02d', $fromYear, $fromMonth, $fromDay, $fromHour, $fromMin);
$endDate = sprintf('%4d%02d%02d%02d%02d', $toYear, $toMonth, $toDay, $toHour, $toMin);

//Check size export folder.
$dirs = glob($pathTrash . '/*');
$maxSize = DL_DATA_CAPACITY * 1024 * 1024;
foreach ($dirs as $dir) {
    $nameDir = substr(basename($dir), 0, 12);
	if (!validateDate($nameDir)) {
		continue;
	}
	
    if ($fromDate <= $nameDir && $nameDir <= $endDate) {
        $size += getDirectorySize($dir);
        $folderExport[] = array(
            'path' => $dir,
            'name' => $nameDir
        );
    }
}

//The folder size more than max size
if ($size > $maxSize) {
	DispError("ダウンロードファイルの容量が大きすぎます。", "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

//No data export
if (empty($folderExport)) {
	DispError("出力対象のページ情報が存在しません。", "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

//Zipを作成
$zipNameFormat = sprintf("trash_%s_%s", $fromDate, $endDate);
$zipPath = $pathTrashTemp . '/' . $zipNameFormat . '.zip';
$pathZipFolder = $pathTrashTemp . '/' . $zipNameFormat;
foreach ($folderExport as $dir) {
	//Create folder zip
	if (!is_dir($pathZipFolder)) {
		mkdir($pathZipFolder, 0755, true);
	}
	//Copy folder
    if (!xcopy($dir['path'], $pathZipFolder . '/' . $dir['name'])) {
        $errMsg .= "【" . $dir['path'] . "】 フォルダのコピーに失敗しました。" . "\n\n";
    }
}

if (!createZip($pathZipFolder, $zipPath)) {
	$errMsg .= "Zipファイルの作成に失敗しました。【" . $zipPath . "】" . "<br />\n";
} else if (@file_exists($zipPath)) {
	if (($fp = @fopen($zipPath, 'rb')) === FALSE) {
		$errMsg .= "Zipファイルの読み込みに失敗しました。【" . $zipPath . "】" . "<br>\n";
	} else {
		//ヘッダ出力
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename=" . basename($zipPath));
		header('Content-Length: ' . @filesize($zipPath));
		while ($zipData = @fread($fp, 4096)) {
			print($zipData);
		}
	}
	if ($fp) {
		@fclose($fp);
	}
	removeZipDir($pathTrashTemp, $errMsg);
}

//エラーメッセージがある場合
if ($errMsg != "") {
	DispError($errMsg, "gather_data", "javascript:history.back()", MENU_KIND_SYSTEM);
	exit();
}

/**
 * Get param $_POST
 * 
 * @param string $param
 * @return string | null
 */
function getPostParams($param) {
	return isset($_POST[$param]) ? $_POST[$param] : null;
}

/**
 * Remove zip folder.
 * 
 * @param string $pathTrashTemp
 * @param string $errMsg
 * @param boolean $delZipFile
 */
function removeZipDir($pathTrashTemp, &$errMsg, $delZipFile=false) {
	//Delete folder and zip files
	$dirs = glob($pathTrashTemp . '/*');
	foreach ($dirs as $dir) {
		if ($delZipFile) {
			$extension = pathinfo($dir, PATHINFO_EXTENSION);
			if ($extension == 'zip') {
				unlink($dir);
			}
		}
		if (is_dir($dir) && removeDir($dir) && @file_exists($dir)) {
			$errMsg .= "<br />\nZipファイルの削除に失敗しました。【" . $dir . "】" . "<br />\n";
		}
	}
}

/**
 * Get directory size (byte)
 * 
 * @param string $path
 * @return int
 */
function getDirectorySize($path){
    $bytestotal = 0;
    $path = realpath($path);
    if($path!==false && $path!='' && file_exists($path)){
        foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $object){
            $bytestotal += $object->getSize();
        }
    }
    return $bytestotal;
}

/**
 * Copy a file, or recursively copy a folder and its contents
 * 
 * @param       string   $source    Source path
 * @param       string   $dest      Destination path
 * @param       int      $permissions New folder creation permissions
 * @return      bool     Returns true on success, false on failure
 */
function xcopy($source, $dest, $permissions = 0755)
{
    // Check for symlinks
    if (is_link($source)) {
        return symlink(readlink($source), $dest);
    }

    // Simple copy for a file
    if (is_file($source)) {
        return copy($source, $dest);
    }

    // Make destination directory
    if (!is_dir($dest)) {
        mkdir($dest, $permissions, true);
    }

    // Loop through the folder
    $dir = dir($source);
    while (false !== $entry = $dir->read()) {
        // Skip pointers
        if ($entry == '.' || $entry == '..') {
            continue;
        }

        // Deep copy directories
        xcopy("$source/$entry", "$dest/$entry", $permissions);
    }

    // Clean up
    $dir->close();
    return true;
}

?>
