<?php
/*
 * Ajax用の関数呼び出し
 */
require_once ("../../cms8341_sys/common/setting.inc");
// session
require_once (APPLICATION_ROOT . "/common/session/session.inc");
// commands
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");

// Commandが設定されていなければエラー
if (!isset($_POST['Command'])) return;

// Execute the required command.
$ret = FALSE;
switch ($_POST['Command']) {
	// ログイン認証 \admin\index.html
	case 'cxLogin' :
		if (!isset($_POST['login_id']) || !isset($_POST['password'])) return;
		$ret = cxLogin($objCnc, $_POST['login_id'], $_POST['password']);
		break;
	
	// ページプロパティ情報の取得 \admin\js\publiclist.js, workflow.js, workspace.js, workspace_wm.js
	case 'cxGetProperty' :
		if (!isset($_POST['cms_page_id']) || !isset($_POST['mode'])) return;
		$ret = cxGetProperty($objCnc, $_POST['cms_page_id'], $_POST['mode']);
		break;
	
	// 承認依頼のためのチェック \admin\js\workspace.js
	case 'cxChkApproveRequest' :
		if (!isset($_POST['cms_page_id'])) return;
		CreateXmlHeader(); // XMLではき出す
		$ret = cxChkApproveRequest($objCnc, $_POST['cms_page_id']);
		break;
	
	// 保存先ディレクトリの移動 \admin\newpage.php, \admin\js\newpage.js, siteedit.js, \inc\set_edit.inc
	case 'cxRefferMoveDir' :
		if (!isset($_POST['current_dir'])) return;
		$mode = (isset($_POST['mode'])) ? $_POST['mode'] : 'go';
		$new_file = (isset($_POST['new_file'])) ? $_POST['new_file'] : '';
		$dept_code = (isset($_POST['dept_code'])) ? $_POST['dept_code'] : '';
		$ret = cxRefferMoveDir($objCnc, $_POST['current_dir'], $new_file, $mode, $dept_code);
		break;
	
	// 保存先パスのチェック \admin\js\newpage.js, siteedit.js
	case 'cxRefferFileCheck' :
		if (!isset($_POST['file_path'])) return;
		$ret = cxRefferFileCheck($_POST['file_path']);
		break;
	
	// アップロードファイルのチェック \admin\enq\enquete_controll.js
	case 'cxRefferFileUploadCheck' :
		if (!isset($_POST['file_path'])) return;
		$ret = cxRefferFileUploadCheck($_POST['file_path']);
		break;
	
	// 保存先ディレクトリの作成 \admin\js\newpage.js, siteedit.js
	case 'cxRefferMakeDir' :
		if (!isset($_POST['new_dir'])) return;
		$ret = cxRefferMakeDir($objCnc, $_POST['new_dir']);
		break;
	
	// 自動生成リンク設定の変更 \admin\js\workflow.js
	case 'cxALinksEdit' :
		if (!isset($_POST['page_id']) || !isset($_POST['auto_links']) || !isset($_POST['index_title'])) return;
		$ret = cxALinksEdit($objCnc, $_POST['page_id'], $_POST['auto_links'], $_POST['index_title']);
		break;
	
	// ライブラリ選択プルダウンの取得 \admin\js\siteedit.js
	case 'cxGetLibraryCombo' :
		if (!isset($_POST['area'])) return;
		if (!isset($_POST['template_id'])) return;
		if (!isset($_POST['lib_area_name'])) return;
		CreateXmlHeader(); // XMLではき出す
		$ret = cxGetLibraryCombo($objCnc, $_POST['area'], $_POST['template_id'], $_POST['lib_area_name']);
		break;
	
	// ライブラリ情報の取得 \admin\js\siteedit.js
	case 'cxGetLibraryContext' :
		if (!isset($_POST['library_id'])) return;
		$e_flg = (isset($_POST['e_flg'])) ? $_POST['e_flg'] : 0;
		$l_flg = (isset($_POST['l_flg'])) ? $_POST['l_flg'] : 0;
		$ret = cxGetLibraryContext($objCnc, $_POST['library_id'], $e_flg, $l_flg);
		break;
	
	// カテゴリ選択プルダウンの取得 \admin\js\newpage.js, siteedit.js
	case 'cxGetCateCombo' :
		if (!isset($_POST['level']) || !isset($_POST['code'])) return;
		CreateXmlHeader(); // XMLではき出す
		$ret = cxGetCateCombo($objCnc, $_POST['level'], $_POST['code']);
		break;
	
	// 組織選択プルダウンの取得 \admin\js\publiclist.js, upload.js
	case 'cxGetDeptCombo' :
		if (!isset($_POST['level']) || !isset($_POST['code'])) return;
		CreateXmlHeader(); // XMLではき出す
		$ret = cxGetDeptCombo($objCnc, $_POST['level'], $_POST['code']);
		break;
	
	// ぱんくずの取得 \admin\js\siteedit.js
	case 'cxGetPankuzu' :
		if (!isset($_POST['page_id'])) return;
		$ret = cxGetPankuzu($objCnc, $_POST['page_id']);
		break;
	
	// 編集のキャンセル \admin\js\siteedit.js
	case 'cxEditCancel' :
		if (!isset($_POST['page_id'])) return;
		$ret = cxEditCancel($objCnc, $_POST['page_id']);
		break;
	
	// 作成者選択プルダウンの取得 \admin\js\outerimport.js
	case 'cxGetUserCombo' :
		if (!isset($_POST['code'])) return;
		CreateXmlHeader(); // XMLではき出す
		$ret = cxGetUserCombo($objCnc, $_POST['code']);
		break;
	// 取り戻し \admin\js\workflow.js
	case 'cxRegain' :
		if (!isset($_POST['page_id'])) return;
		$ret = cxRegain($objCnc, $_POST['page_id']);
		break;
	// ディレクトリツリーの表示 \admin\js\treelist.js
	case 'cxGetTreeList' :
		if (!isset($_POST['dir_path'])) return;
		$dir_path = ($_POST['dir_path'] == '') ? '/' : $_POST['dir_path'];
		$isAll = (isset($_POST['isAll'])) ? $_POST['isAll'] : "";
		$ret = cxGetTreeList($objCnc, $dir_path, $isAll);
		break;
	
	// ファイルの削除 \admin\js\treelist.js
	case 'cxDeleteFile' :
		if (!isset($_POST['file_path']) || $_POST['file_path'] == '') return;
		$ret = cxDeleteFile($objCnc, $_POST['file_path']);
		break;
	// フォルダの削除 \admin\js\treelist.js
	case 'cxDeleteFolder' :
		if (!isset($_POST['dir_path']) || $_POST['dir_path'] == '') return;
		$ret = cxDeleteFolder($objCnc, $_POST['dir_path']);
		break;
	// アンケート詳細 \admin\enquete_conf.php
	case 'cxEnqueteDetail' :
		if (!isset($_POST['page_id']) || $_POST['enquete_id'] == '') return;
		$ret = cxEnqueteDetail($objCnc, $_POST['page_id'], $_POST['enquete_id']);
		break;
	// フィードバック詳細 \admin\feedback_conf.php
	case 'cxFeedbackDetail' :
		if (!isset($_POST['page_id']) || $_POST['que_num'] == '') return;
		$ret = cxFeedbackDetail($_POST['page_id'], $_POST['que_num']);
		break;
	// W3Cチェック \admin\revision\w3c\index.php
	case 'cxGetAllFileList' :
		if (!isset($_POST['dir']) || !isset($_POST['sub'])) return;
		$ret = cxGetAllFileList($_POST['dir'], $_POST['sub'], (isset($_POST['mode'])) ? $_POST['mode'] : "");
		break;
	// W3Cチェック \admin\revision\w3c\index.php
	case 'cxW3cCheck' :
		if (!isset($_POST['dir'])) return;
		$ret = cxW3cCheck($objCnc, $_POST['dir']);
		break;
	// 観光meta情報取得 \admin\newpage.php
	case 'cxGetKankoMetaStr' :
		if (!isset($_POST['template_id'])) return;
		if (!isset($_POST['page_id'])) return;
		$ret = getMetaStr($_POST['template_id'], "newpage", $_POST['page_id']);
		break;
	// 問い合わせ項目チェック \admin\newpage.php
	case 'cxGetInquryDisp' :
		if (!isset($_POST['tpl_id'])) return;
		$ret = cxGetInquryDisp($_POST['tpl_id']);
		break;
	// ファイルの削除 \admin\enq\enquete_controll.js
	case 'cxDeleteFileEnq' :
		if (!isset($_POST['file_path']) || $_POST['file_path'] == '') return;
		$ret = cxDeleteFileEnq($_POST['file_path']);
		break;
	// FCKeditorファイルリンク時の情報取得 \FCKeditor\editor\dialog\fck_link\fck_link.js
	case 'cxFCKGetFileInfo' :
		if (!isset($_POST['file_path']) || $_POST['file_path'] == '') return;
		$ret = cxFCKGetFileInfo($_POST['file_path']);
		break;
	// FCKeditorリンク時のリネームチェック \FCKeditor\editor\dialog\fck_link\fck_filelink_upload.js
	case 'cxFCKRename_Check' :
		if (!isset($_POST['now_file_path']) || $_POST['now_file_path'] == '') return;
		if (!isset($_POST['new_file_name']) || $_POST['new_file_name'] == '') return;
		$ret = cxFCKRename_Check($_POST['now_file_path'], $_POST['new_file_name']);
		break;
	case 'cxFCKRenameSpecialFile_Check' :
		if (!isset($_POST['now_file_path']) || $_POST['now_file_path'] == '') return;
		if (!isset($_POST['new_file_name']) || $_POST['new_file_name'] == '') return;
		$tmp = cxFCKRename_Check($_POST['now_file_path'], $_POST['new_file_name']);
		$conf_msg = '';
		$date = date("YmdHis");
		preg_match("/^(.+)(\..+)$/", $_POST['new_file_name'], $file);
		if (preg_match('/[^\w\-_\.~]/i', $_POST['new_file_name'])) {
			$conf_msg = "ファイル名に使用できるのは半角英数字と - _ . ~ です。\n\n";
			$tmp = $_POST['now_file_path'] . "/" . $date . $file[2];
		}
		if (strpos($_POST['new_file_name'], '.') != strrpos($_POST['new_file_name'], '.')) {
			//「.」が複数含まれているかチェック
			$conf_msg = "ファイル名に「.」が二つ以上ついているファイルはアップロードすることが出来ません。\n\n";
			$tmp = $_POST['now_file_path'] . "/" . $date . $file[2];
		}
		//「.」がファイル名の先頭に含まれているかチェック
		if (strpos($_POST['new_file_name'], '.') == 0) {
			$conf_msg = "ファイル名にの先頭に「.」がついているファイルはアップロードすることが出来ません。\n\n";
			$tmp = $_POST['now_file_path'] . "/" . $date . $file[2];
		}
		$ret =  json_encode(array($tmp, $conf_msg));
		break;
	// FCKeditor画像アップロード時のリネームチェック \FCKeditor\editor\dialog\fck_image\fck_image_upload.js
	case 'cxFCKRename_Check_Image' :
		if (!isset($_POST['now_file_path']) || $_POST['now_file_path'] == '') return;
		if (!isset($_POST['new_file_name']) || $_POST['new_file_name'] == '') return;
		$ret_file_name = array();
		$ret_file_name_tmp = array();
		for($i = 0; $i < count($_POST['now_file_path']); $i++) {
			$tmp = cxFCKRename_Check($_POST['now_file_path'][$i], $_POST['new_file_name'][$i]);
			$conf_msg = '';
			if ($tmp != "" && preg_match("/^(.+)(" . IMAGE_UPLOAD . ")(\d+)(\..+)$/", $tmp, $match)) {
				while (in_array($tmp, $ret_file_name) || @file_exists($tmp)) {
					$tmp = $match[1] . $match[2] . ++$match[3] . $match[4];
				}
			} //サーバに同名のファイルが無い場合
			else if ($tmp == "" && $_POST['new_file_name'][$i] != "") {
				$tmp_tmp = $_POST['now_file_path'][$i] . "/" . $_POST['new_file_name'][$i];
				//おかしなファイル名が指定された場合
				preg_match("/^(.+)(\..+)$/", $_POST['new_file_name'][$i], $file);
				$cnt = 1;
				$date = date("YmdHis");
				if (preg_match('/[^\w\-_\.~]/i', $_POST['new_file_name'][$i])) {
					$conf_msg = "ファイル名に使用できるのは半角英数字と - _ . ~ です。\n\n";
					$tmp = $_POST['now_file_path'][$i] . "/" . $date . $file[2];
				}
				if (strpos($_POST['new_file_name'][$i], '.') != strrpos($_POST['new_file_name'][$i], '.')) {
					//「.」が複数含まれているかチェック
					$conf_msg = "ファイル名に「.」が二つ以上ついているファイルはアップロードすることが出来ません。\n\n";
					$tmp = $_POST['now_file_path'][$i] . "/" . $date . $file[2];
				}
				//「.」がファイル名の先頭に含まれているかチェック
				if (strpos($_POST['new_file_name'][$i], '.') == 0) {
					$conf_msg = "ファイル名にの先頭に「.」がついているファイルはアップロードすることが出来ません。\n\n";
					$tmp = $_POST['now_file_path'][$i] . "/" . $date . $file[2];
				}
				//サーバ上に同名のファイルが存在する OR 同時にアップロードするファイルに同名のファイルが存在する場合
				while (in_array($tmp_tmp, $ret_file_name_tmp) || @file_exists($tmp_tmp) || in_array($tmp, $ret_file_name_tmp)) {
					//リネーム
					$tmp_tmp = $_POST['now_file_path'][$i] . "/" . $file[1] . IMAGE_UPLOAD . $cnt . $file[2];
					if ($conf_msg != '') {
						$tmp_tmp = $_POST['now_file_path'][$i] . "/" . $date . IMAGE_UPLOAD . $cnt . $file[2];
					}
					$tmp = $tmp_tmp;
					$cnt++;
				}
			}
			$ret_file_name[] = array($tmp, $conf_msg);
			$ret_file_name_tmp[] = ($tmp != "" ? $tmp : ($_POST['new_file_name'][$i] != "" ? $_POST['now_file_path'][$i] . "/" . $_POST['new_file_name'][$i] : ""));
		}
		$ret = json_encode($ret_file_name);
		break;
	// 組織からお問い合わせ情報を取得 \admin\newpage.php
	case 'cxGetInquiryDeptInfo' :
		if (!isset($_POST['dept_code']) || $_POST['target'] == '') return;
		$ret = cxGetInquiryDeptInfo($_POST['dept_code'], $_POST['target']);
		break;
	// 外部出力リスト時のセッションにページIDを格納
	case 'cxOutputCheck' :
		if (!isset($_POST['page_id']) || !isset($_POST['checked'])) return;
		$ret = cxOutputCheck($_POST['page_id'], $_POST['checked']);
		break;
	// 外部出力設定時にページタイトルのリストを取得
	case 'cxGetOutputRequestPageList' :
		$ret = cxGetOutputRequestPageList();
		break;
	// テンプレートに指定された検索エンジン用キーワードを取得
	case 'cxGetTemplateKeywords' :
		if (!isset($_POST['cms_template_id'])) return;
		$template_ver = (!isset($_POST['cms_template_ver']) ? "" : $_POST['cms_template_ver']);
		$ret = cxGetTemplateKeywords($_POST['cms_template_id'], $template_ver, "head", "meta", "keywords", "content");
		break;
	case 'cxGetAutolinkName' :
		if (!isset($_POST['a_link_ids'])) return;
		$ret = cxGetAutolinkName($_POST['a_link_ids']);
		break;
	case 'cxFilesDelete' :
		$ret = cxFilesDelete($objCnc);
		break;
	case 'cxGetOutputDisp' :
		if (!isset($_POST['tpl_id'])) return;
		if (!isset($_POST['sel_op'])) return;
		$output_html_flg = (isset($_POST['output_html_flg']) ? $_POST['output_html_flg'] : OUTPUT_HTML_FLG);
		$ret = cxGetOutputDisp($_POST['tpl_id'], $_POST['sel_op'], $output_html_flg);
		break;
	// 編集領域一括置換時のセッションにページIDを格納
	case 'cxReplaceCheck' :
		if (!isset($_POST['page_id']) || !isset($_POST['checked']) || !isset($_POST['chbox_id'])) return;
		$ret = cxReplaceCheck($_POST['page_id'], $_POST['checked'], $_POST['chbox_id']);
		break;
	case 'cxGetContextFileLinks' :
		if (!isset($_POST['page_id']) || !isset($_POST['context'])) return;
		$ret = cxGetContextFileLinks($objCnc, $_POST['page_id'], $_POST['context']);
		break;
	// 外部連携データ出力：再出力
	case 'cxSetOutputHistoryToSession' :
		if (!isset($_POST['history_id'])) return;
		$ret = cxSetOutputHistoryToSession($_POST['history_id']);
		break;
	// 外部連携データ出力：再出力グループ名設定
	case 'cxGetOutputHistoryGroupName' :
		if (!isset($_POST['history_id'])) return;
		$ret = cxGetOutputHistoryGroupName($_POST['history_id']);
		break;
	// 定型情報インポート時のセッションに行数を格納
	case 'cxKankoLineCheck' :
		if (!isset($_POST['line_num']) || !isset($_POST['checked'])) return;
		$ret = cxKankoLineCheck($_POST['line_num'], $_POST['checked']);
		break;
	// 定型情報インポート時のセッションに格納されている行数を取得
	case 'cxIsKankoLineCheck' :
		$ret = cxIsKankoLineCheck();
		break;
	// ページ情報を取得
	case 'cxGetPageInfo' :
		if (!isset($_POST['page_id'])) return;
		if (!isset($_POST['target_column'])) return;
		$pTbl = (isset($_POST['pTbl'])) ? $_POST['pTbl'] : PUBLISH_TABLE;
		$ret = cxGetPageInfo($_POST['page_id'], $_POST['target_column'], $pTbl);
		break;
	// 自動リンクの親ページに指定されているかチェック
	case 'cxIsParentCondition' :
		if (!isset($_POST['page_id'])) return;
		$pTbl = (isset($_POST['pTbl'])) ? $_POST['pTbl'] : PUBLISH_TABLE;
		$ret = isParentCondition($_POST['page_id']);
		$ret = ($ret) ? "true" : "false";
		break;
	// メニュー生成順変更リスト取得
	case 'cxGetMenuGenerationOrder' :
		if (!isset($_POST['page_id'])) return;
		$ret = cxGetMenuGenerationOrder($_POST['page_id']);
		break;
	// メニュー生成順変更をセッションに格納
	case 'cxSetMenuGenerationOrder' :
		if (!isset($_POST['menu_generation_info'])) return;
		$ret = cxSetMenuGenerationOrder($_POST['menu_generation_info']);
		break;
	//前回の検索条件取得
	case 'cxGetLastSearchSessionData' :
		if (!isset($_POST['key'])) return;
		CreateXmlHeader();
		$ret = cxGetLastSearchSessionData($_POST['key']);
		break;
	// 定型情報が設定されているテンプレートかをチェック
	case 'cxisFixed' :
		if (!isset($_POST['template_id'])) return;
		if (!isset($_POST['template_kind'])) return;
		if (!isset($_POST['template_ver'])) return;
		$ary = array();
		$ary['template_id'] = $_POST['template_id'];
		$ary['template_kind'] = $_POST['template_kind'];
		$ary['template_ver'] = $_POST['template_ver'];
		$ret = isFixed($ary);
		$ret = ($ret) ? "true" : "false";
		break;
	// アップロード処理のロックファイルを削除する。
	case 'cxUploadUnlock' :
		$ret = (lock_file_management('compulsory_unlock')) ? "true" : "false";
		break;
	// 否認理由を取得する
	case 'cxGetDenialMsg' :
		if (!isset($_POST['cms_page_id'])) return;
		$ret = cxGetDenialMsg($_POST['cms_page_id']);
		break;
	// パンくず階層制限チェック
	case 'cxIsPankuzuLimitOver' :
		if (!isset($_POST['page_id'])) return;
		$ret = is_pankuzu_limit_over($_POST['page_id']);
		$ret = ($ret) ? "true" : "false";
		break;
	// 否認理由レイヤーの文字列取得
	case 'cxGetDenailPageStr' :
		if (!isset($_POST['cms_group_id'])) return;
		$ret = cxGetDenailPageStr($_POST['cms_group_id']);
		break;
	// CMS用のYouTubeタグに変換する
	case 'cxConvertYoutubeCMS' :
		if (!isset($_POST['url'])) return;
		if (!isset($_POST['title'])) return;
		if (!isset($_POST['width'])) $_POST['width'] = YOUTUBE_WIDTH;
		if (!isset($_POST['height'])) $_POST['height'] = YOUTUBE_HEIGHT;
		$ret = cxConvertYoutubeCMS($_POST['url'], $_POST['title'], $_POST['width'], $_POST['height']);
		break;
	// ページ用コンテンツメニュー作成
	case 'cxContentsMenu2' :
		if (!isset($_POST['menu_id'])) return;
		if (!isset($_POST['page_id'])) return;
		if (!isset($_POST['form'])) return;
		if (!isset($_POST['disp'])) return;
		$ret = create_context_menu($_POST['page_id'], $_POST['menu_id'], $_POST['form'], $_POST['disp']);
		break;
	// イベントカレンダー複数日
	// 開催期間を集約する
	case 'cxMergeOpenDate' :
		// 集約用の文字列配列が取得できない場合
		if (!isset($_POST['open_date_ary']) || !is_array($_POST['open_date_ary']) || count($_POST['open_date_ary']) <= 0) {
			// 処理終了
			return;
		}
		$ret_ary = cxMergeOpenDate($_POST['open_date_ary']);
		
		// 戻り値用変数初期化
		$ret = '';
		// アクセシビリティチェック処理に失敗した場合
		if ($ret_ary === FALSE) {
			$ret = 'false';
		}
		// チェック結果としてエラーが存在する場合
		else if (is_array($ret_ary) && count($ret_ary) >= 1) {
			// 戻り値の配列を「json」形式に変換し返す
			$ret = json_encode($ret_ary);
		}
		break;
	// 開催期間をフォーマットをもとに変換する
	case 'cxRreplaceEventTag' :
		// 置換用の情報が取得できない場合
		if (!isset($_POST['date']) || !isset($_POST['format']) || !isset($_POST['mode'])) {
			// 処理終了
			return;
		}
		$date = $_POST['date'];
		$format = $_POST['format'];
		$mode = $_POST['mode'];
		
		// 開催期間のフォーマット形式で指定されていない場合補完する
		if (strpos($format, 'cx_open_' . $mode) === FALSE) {
			$format = '<!--%cx_open_' . $mode . '_' . $format . '%-->';
		}
		
		$ret = replaceEventTag($date, $format, $mode);
		break;
	// オープンデータ
	// オープンデータ情報表示・設定項目作成
	case 'cxGetOpendataMetaStr' :
		if (!isset($_POST['page_id'])) return;
		$ret = getOpendataMetaStr('newpage', $_POST['page_id']);
		break;
	// アクセシビリティ強制チェック機能
	// パスワード文字列チェック
	case 'cxCheckPasswordString' :
		// チェック対象文字列情報が取得できない場合
		if (!isset($_POST['password_str']) || !isset($_POST['check_title'])) {
			// 処理終了
		return;
		}
		$password_str = $_POST['password_str'];
		// Ajax通信用に一時退避している文字をもとに戻す
		// パスワードアンエスケープ
		$password_str = getAjaxCharUnEscape($password_str);
		
		// パスワード文字列チェック実行
		$check_result_flg_ary = checkPasswordString($password_str, $_POST['check_title']);
		// チェック結果を確認
		foreach ((array) $check_result_flg_ary as $check_type => $result_ary) {
			// チェック結果フラグが有効な場合
			if ($result_ary['result_flg'] == FLAG_ON) {
				// エラーメッセージを取得
				$ret .= '・' . $result_ary['err_msg'] . "\n";
			}
		}
		break;
	// パスワード自動生成
	case 'cxCreatePasswordString' :
		$ret = createPasswordString();
		break;
            
            	// アクセシビリティチェック必須化
	case 'cxAllTotalCheck' :
		$ret = '';
		// アクセシビリティチェック
		if (!isset($_SESSION['accessibility_check_flg']['accessibility_flg']) ||
		 $_SESSION['accessibility_check_flg']['accessibility_flg'] == FLAG_OFF) {
			$ret .= '・アクセシビリティチェック' . "\n";
		}
		break;
}
if ($ret !== FALSE) print $ret;
exit();

// XML形式で返すためのヘッダ設定
function CreateXmlHeader() {
	// Prevent the browser from caching the result.
	// Date in the past
	header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
	// always modified
	header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
	// HTTP/1.1
	header('Cache-Control: no-store, no-cache, must-revalidate');
	header('Cache-Control: post-check=0, pre-check=0', false);
	// HTTP/1.0
	header('Pragma: no-cache');
	
	// Set the response format.
	header('Content-Type:text/xml; charset=utf-8');
	
	print '<?xml version="1.0" encoding="utf-8" ?>' . "\n";
	print '<!DOCTYPE DOCUMENT [' . "\n";
	// &nbsp; を &#160; に置換
	print '<!ENTITY nbsp "&#160;">' . "\n";
	print ']>' . "\n";
}
?>
