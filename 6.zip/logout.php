<?php
/*
 * ログアウト
 */
require ("./.htsetting");

// ログ登録(ログアウト)
if(WRITE_INFO_LOG_LOGOUT) set_log_data(LOG_STATUS_LOGOUT);

$objLogin->logout();

// ログイン画面に移動
header("Location: " . HTTP_ROOT . RPW . "/admin/index.html");
?>