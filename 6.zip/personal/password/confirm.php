<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	foreach ($_POST as $k => $v) {
		$v = htmlspecialchars($v);
		$$k = $v;
	}
}

$msg = "";
if (isset($password) && $password != "") {
	//	if (strcmp($_SESSION['login']['password'], $password) != 0) {
	if (strcmp($objLogin->get('password'), $password) != 0) {
		$msg .= "現パスワードが間違っています。<br>";
	}
}
else {
	$msg .= "現パスワードが入力されていません。<br>";
}

if (isset($new_password) && $new_password != "") {
	// パスワード入力内容チェック実行
	$check_result_flg_ary = checkPasswordString($new_password, '新パスワード');
	// チェック結果を確認
	foreach ((array) $check_result_flg_ary as $check_type => $result_ary) {
		// チェック結果フラグが有効な場合
		if ($result_ary['result_flg'] == FLAG_ON) {
			// エラーメッセージを取得
			$msg .= $result_ary['err_msg'] . '<br>';
		}
	}
	if ($new_password == $password) {
		$msg .= "新パスワードに現パスワードと同一のパスワードが指定されました。現パスワードとは異なるパスワードを指定してください。<br>";
	}
}
else {
	$msg .= "新パスワードが入力されていません。<br>";
}
if ($msg != "") {
	user_error($msg);
	exit();
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>パスワード変更確認</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="password.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'password';
include (APPLICATION_ROOT . "/common/inc/personal_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-password">
<div><img src="images/bar_password.jpg" alt="パスワード変更" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p>新しいパスワードに変更します。よろしいですか？</p>
<form id="form" name="form" class="cms8341-form" method="post"
	action="submit.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="middle" scope="row">新パスワード</th>
		<td align="left" valign="top"><?=$new_password?></td>
	</tr>
</table>
<p align="center" class="ctrl"><input type="image"
	src="./images/btn_change.jpg" alt="変更" width="150" height="20"
	border="0" style="margin-right: 10px"> <a
	href="javascript:history.back();"><img src="./images/btn_back.jpg"
	alt="戻る" width="150" height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" id="new_password" name="new_password"
	value="<?=$new_password?>"></form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
