<?php
/*
 *
 */
/** require **/
require ("./.htsetting");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	foreach ($_POST as $k => $v) {
		// パスワードに「"」「<」「>」などが指定されるとエスケープされ文字比較が正常に行えないためエスケープ処理をコメントアウト
		//$v = htmlspecialchars($v);
		$$k = $v;
	}
}

$msg = "";
if (isset($password) && $password != "") {
	//	if (strcmp($_SESSION['login']['password'], $password) != 0) {
	if (strcmp($objLogin->get('password'), $password) != 0) {
		$msg .= "現パスワードが間違っています。<br>";
	}
}
else {
	$msg .= "現パスワードが入力されていません。<br>";
}

if (isset($new_password) && $new_password != "") {
	// パスワード入力内容チェック実行
	$check_result_flg_ary = checkPasswordString($new_password, '新パスワード');
	// チェック結果を確認
	foreach ((array) $check_result_flg_ary as $check_type => $result_ary) {
		// チェック結果フラグが有効な場合
		if ($result_ary['result_flg'] == FLAG_ON) {
			// エラーメッセージを取得
			$msg .= $result_ary['err_msg'] . '<br>';
		}
	}
	if ($new_password == $password) {
		$msg .= "新パスワードに現パスワードと同一のパスワードが指定されました。現パスワードとは異なるパスワードを指定してください。<br>";
	}
}
else {
	$msg .= "新パスワードが入力されていません。<br>";
}

if (isset($new_password2) && $new_password2 != "") {
	if ($new_password != $new_password2) {
		$msg .= "新パスワードが新パスワード（確認用）と一致しません。<br>";
	}
}
else {
	$msg .= "新パスワード（確認用）が入力されていません。<br>";
}

if ($msg != "") {
	user_error($msg);
	exit();
}

$sql = "UPDATE tbl_user SET password = '" . gd_addslashes($new_password) . "'";
$sql .= ", pass_last_upd = '" . date("Y/m/d H:i:s") . "'";
//	$sql .= " WHERE user_id = " . $_SESSION['login']['user_id'];
$sql .= " WHERE user_id = " . $objLogin->get('user_id');

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

// トランザクション開始
//$objCnc->begin();
if ($objDac->execute($sql)) {	//		$objCnc->commit();
}
else {
	//		$objCnc->rollback();
	user_error("パスワード変更エラー");
	exit();
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>パスワード変更完了</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="password.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'password';
include (APPLICATION_ROOT . "/common/inc/personal_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-password">
<div><img src="images/bar_password.jpg" alt="パスワード変更" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<p>パスワードを変更しました。<br>
一旦、ログアウトしてから再度、新しいパスワードでログインしてください。</p>
<?php
$logout = HTTP_ROOT . RPW . "/admin/logout.php";
?>
<p class="ctrl"><a href="<?=$logout?>"><img
	src="./images/btn_logout.jpg" width="150" height="20" border="0"></a></p>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>

