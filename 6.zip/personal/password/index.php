<?php
/*
 *
 */
require ("./.htsetting"); // ログインしてないときはログイン画面にリダイレクト
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>パスワード変更</title>
<link rel="stylesheet" href="../../style/shared.css" type="text/css">
<link rel="stylesheet" href="password.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="../../js/library/prototype.js" type="text/javascript"></script>
<script src="../../js/shared.js" type="text/javascript"></script>
<script language="javascript">
<?php
	// Ajax通信用特殊置き換え文字ルール
	$AJAX_COMMAND_ESCAPE_CHAR_ARY = getDefineArray('AJAX_COMMAND_ESCAPE_CHAR_ARY');
	// Ajax通信用に特定の文字をエスケープする変換ルールを宣言
	print 'var temp_char_ary = [';
	$cnt = 0;
	foreach ((array) $AJAX_COMMAND_ESCAPE_CHAR_ARY as $target_char => $rep_char) {
		if ($cnt > 0) {
			print ',';
		}
		// エスケープ対象文字配列
		$esc_target_ary = array(
			// 「\ （円記号）」エスケープ
			"\\", 
			// 「'（シングルクォート）」エスケープ
			"'"
		);
		// エスケープ置換文字配列
		$esc_replace_ary = array(
			"\\\\", 
			"\'"
		);
		$target_char = str_replace($esc_target_ary, $esc_replace_ary, $target_char);
		$rep_char = str_replace($esc_target_ary, $esc_replace_ary, $rep_char);
		
		print "['" . $target_char . "','" . $rep_char . "']";
		$cnt++;
	}
	print '];'
?>

function ChkPwd(form) {
	var msg = "";
	var password = form.password.value;
	var new_password = form.new_password.value;
	var new_password2 = form.new_password2.value;
	
	if (password == "") {
		msg = msg + "・現パスワードが入力されていません。\n";
	}
	
	if (new_password != "") {
		// Ajax通信用に特定の文字をエスケープする
		var tmp_new_password = new_password;
		for (var i = 0; i < temp_char_ary.length; i++) {
			var regExp = new RegExp('\\' + temp_char_ary[i][0], "g");
			tmp_new_password = tmp_new_password.replace(regExp, temp_char_ary[i][1]);
		}
		
		var params = '';
		params = 'password_str=' + tmp_new_password;
		params = params + '&check_title=' + "新パスワード";
		// ajaxによるパスワード入力内容チェック実行
		rText = cxAjaxCommandAnSync('cxCheckPasswordString', params, '').transport.responseText;
		msg = msg + rText;
		
		if (new_password == password) {
			msg = msg + "・新パスワードに現パスワードと同一のパスワードが指定されました。現パスワードとは異なるパスワードを指定してください。\n";
		}
	} else {
		msg = msg + "・新パスワードが入力されていません。\n";
	}

	if (new_password2 != "") {
		if (new_password != new_password2) {
			msg = msg + "・新パスワードが新パスワード（確認用）と一致しません。\n";
		}
	} else {
		msg = msg + "・新パスワード（確認用）が入力されていません。\n";
	}
	
	if (msg != "") {
		alert(msg);
		return false;
	}

	return confirm("新しいパスワードに変更します。よろしいですか？");
}
//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
	return false;
}

</script>

</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'password';
include (APPLICATION_ROOT . "/common/inc/personal_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-password">
<div><img src="images/bar_password.jpg" alt="パスワード変更" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?php
if (isset($_GET["q"]) && $_GET["q"] == "expire") {
	?>
	<p>パスワード有効期限が切れています。新しいパスワードを設定してください。</p>
<?php
}
?>
<form id="form" name="form" class="cms8341-form" method="post"
	action="submit.php" onsubmit="return ChkPwd(this)">
<?php 
	// 使用を許可する英字大文字（配列）取得
	$PASSWORD_ALLOWED_UPPERCASE = getDefineArray('PASSWORD_ALLOWED_UPPERCASE');
	// 使用を許可する英字小文字（配列）取得
	$PASSWORD_ALLOWED_LOWERCASE = getDefineArray('PASSWORD_ALLOWED_LOWERCASE');
	// 使用を許可する数字（配列）取得
	$PASSWORD_ALLOWED_NUMBER = getDefineArray('PASSWORD_ALLOWED_NUMBER');
	// 使用を許可する記号（配列）取得
	$PASSWORD_ALLOWED_SYMBOL = getDefineArray('PASSWORD_ALLOWED_SYMBOL');
	// 紛らわしい文字として使用を禁止する文字（配列）取得
	$PASSWORD_CONFUSING_CHARACTERS = getDefineArray('PASSWORD_CONFUSING_CHARACTERS');
	
	print '<p>パスワードは以下のルールに基づき設定してください。</p>' . "\n";
	$message_str = '<ul>' . "\n";
	
	// 最小文字数表示用文言生成生成
	if (PASSWORD_MINIMUM_LENGTH > 0) {
		$message_str .= '<li>文字数：' . PASSWORD_MINIMUM_LENGTH . '文字以上</li>' . "\n";
	}
	
	// 使用可能文字および必須表記生成
	$use_char_ary = array();
	// 英字大文字文言取得
	if (count($PASSWORD_ALLOWED_UPPERCASE) > 0) {
		$use_char_ary[] = '半角英字大文字' . (PASSWORD_UPPER_REQUIRED_FLG ? '<span class="cms_require">（必須）</span>' : '');
	}
	// 英字小文字文言取得
	if (count($PASSWORD_ALLOWED_LOWERCASE) > 0) {
		$use_char_ary[] = '半角英字小文字' . (PASSWORD_LOWER_REQUIRED_FLG ? '<span class="cms_require">（必須）</span>' : '');
	}
	// 数字文言取得
	if (count($PASSWORD_ALLOWED_NUMBER) > 0) {
		$use_char_ary[] = '半角数字' . (PASSWORD_NUMBER_REQUIRED_FLG ? '<span class="cms_require">（必須）</span>' : '');
	}
	// 記号文言取得
	if (count($PASSWORD_ALLOWED_SYMBOL) > 0) {
		$use_char_ary[] = '記号【' . htmlDisplay(implode('', $PASSWORD_ALLOWED_SYMBOL)) . '】' . (PASSWORD_SYMBOL_REQUIRED_FLG ? '<span class="cms_require">（必須）</span>' : '');
	}
	
	// 最低限使用する文字種数表示用文言生成
	if (PASSWORD_MULTI_TYPE_NUM > 0) {
		$message_str .= '<li>以下の1～' . count($use_char_ary) . 'のうち、' . PASSWORD_MULTI_TYPE_NUM . '種類以上を利用' . "\n";
	}
	else {
		$message_str .= '<li>以下の1～' . count($use_char_ary) . 'を利用' . "\n";
	}
	$message_str .= '<ol>' . "\n";
	foreach ((array) $use_char_ary as $char_msg) {
		$message_str .= '<li>' . $char_msg. '</li>' . "\n";
	}
	$message_str .= '</ol>' . "\n";
	$message_str .= '※上記' . count($use_char_ary) . '種類以外の文字はパスワードに利用できません。' . "\n";
	$message_str .= '</li>' . "\n";
	
	// 使用不可文字列表示用文言生成
	if (count($PASSWORD_CONFUSING_CHARACTERS) > 0) {
		$message_str .= '<li>以下の1～' . count($PASSWORD_CONFUSING_CHARACTERS) . 'は使用不可' . "\n";
		$message_str .= '<ol>' . "\n";
		foreach ((array) $PASSWORD_CONFUSING_CHARACTERS as $char) {
			$message_str .= '<li>' . htmlDisplay($char). '</li>' . "\n";
		}
		$message_str .= '</ol>' . "\n";
		$message_str .= '</li>' . "\n";
	}
	
	$message_str .= '</ul>' . "\n";
	print $message_str;
?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="30%" align="left" valign="middle" scope="row">現パスワード</th>
		<td align="left" valign="top"><input type="password" id="password"
			name="password" maxlength="255" value="" class="ctrl"></td>
	</tr>
	<tr>
		<th width="30%" align="left" valign="middle" scope="row">新パスワード</th>
		<td align="left" valign="top"><input type="password" id="new_password"
			name="new_password" maxlength="255" value="" class="ctrl"></td>
	</tr>
	<tr>
		<th width="30%" align="left" valign="middle" scope="row">新パスワード（確認用）</th>
		<td align="left" valign="top"><input type="password"
			id="new_password2" name="new_password2" maxlength="255" value=""
			class="ctrl"></td>
	</tr>
</table>
<p align="center" class="ctrl"><input type="image"
	src="./images/btn_change.jpg" alt="変更" width="150" height="20"
	border="0" style="margin-right: 10px"> <a
	href="javascript:history.back();"><img
	src="../../images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150"
	height="20" border="0" style="margin-left: 10px"></a></p>
</form>
</div>
<div><img src="../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
