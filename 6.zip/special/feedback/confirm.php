<?php
/*
 *
 */

/** require **/
require ("../.htsetting");

if (!isset($_POST['cms_page_id'])) {
	user_error("必要なパラメーターが指定されていません。");
	exit();
}
$PID = $_POST['cms_page_id'];
$html = "";
//list format
$fmt = '<tr>' . "\n";
$fmt .= '<th id="cms_{que_num}" align="left" valign="top" width="35%">{name}</th>' . "\n";
$fmt .= '<td>' . "\n";
$fmt .= '{detail}' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '</tr>' . "\n";

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');
$objPage = new tbl_page($objCnc);
$objPage->selectFromID($PID);
$pFld = $objPage->fld;

// CSV読み込み
$cnt = 0;
$csv_file = DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV . $PID . ".csv";
if (($CsvFno = @fopen($csv_file, 'r'))) {
	$question = array();
	while ($data = cms_fgetcsv($CsvFno, 20000)) {
		//質問を取得・ページタイトル取得
		if ($cnt == 0) {
			for($i = 3; $i < count($data) - 2; $i = $i + 2) {
				$question[$i] = $data[$i];
			}
		}
		$cnt++;
	}
	
	$html = '<tr>' . "\n";
	$html .= '<th align="left" valign="top">有効回答件数</th><td>' . $cnt . '件</td>' . "\n";
	$html .= '</tr>' . "\n";
	
	fclose($CsvFno);
	if ($cnt != 0) {
		$cnt = 0;
		foreach ($question as $i => $s) {
			$tmp = $fmt;
			$tmp = str_replace('{name}', htmlDisplay($s), $tmp);
			$detail = cxfeedbackDetail($PID, $i, 5);
			$tmp = str_replace('{detail}', $detail, $tmp);
			$tmp = str_replace('{page_id}', $PID, $tmp);
			$tmp = str_replace('{que_num}', $i, $tmp);
			$html .= $tmp;
			$cnt++;
		}
	}
	else {
		$html = '<tr><td align="center" valign="top">データがありません。</td></tr>';
	}
}
else {
	$html = '<tr><td align="center" valign="top">データがありません。</td></tr>';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>フィードバック集計</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./feedback.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
//
function cxSubmit(page_id,que_num){
	args = new Array();
	args[0] = page_id;
	args[1] = que_num;
	args[2] = $('cms_'+que_num).innerHTML;
	cxIframeLayer(
		cms8341admin_path+"/special/feedback/detail.php",
		550,
		680,
		COVER_SETTING.COLOR,
		'',
		undefined,
		false,
		false,
		args
	);
}
function cxDownloadCsv(){
	$('feed_form').action = cms8341admin_path + "/special/feedback/download.php";
	$('feed_form').submit();
	return false;
}

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'feedback';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-feedtotalresult">
<div><img
	src="<?=RPW?>/admin/special/feedback/images/title_feedback_output.jpg"
	alt="フィードバック結果のダウンロード" width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td align="left" valign="top">
		<p><?=$pFld['page_title']?>ページの集計結果</p>
		</td>
		<td align="right" valign="top" width="160">
		<p>
<?php
if (isset($cnt)) {
	echo '<a href="javascript:" onclick="return cxDownloadCsv()"><img src="' . RPW . '/admin/special/feedback/images/btn_feedback_output.jpg" alt="フェードバック結果のダウンロード" width="150" height="20" border="0"></a>';
}
?>
</p>
		</td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$html?>
</table>
<p align="center" class="ctrl"><a href="javascript:history.back()"><img
	src="<?=RPW?>/admin/master/images/btn_small_back.jpg" alt="戻る"
	width="120" height="20" border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="feed_form" class="cms8341-form" name="feed_form" action=""
	method="post"><input type="hidden" id="page_id" name="page_id"
	value="<?=$PID?>"> <input type="hidden" id="page_id" name="page_title"
	value="<?=htmlspecialchars($pFld['page_title'])?>"></form>
</body>
</html>
