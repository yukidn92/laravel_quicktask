<?php
/*
 *
 */
/** require **/
require ("../.htsetting");
global $objCnc;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');
$objPage = new tbl_page($objCnc);

// ログイン情報
$login = $objLogin->login;

$TARGET_USER_ARY = array(
		"0" => "自分が作成したページ", 
		"1" => "全てのページ"
);
$TARGET_DEPT_ARY = array(
		"0" => "所属で作成したページ", 
		"1" => "全てのページ"
);
$ORDER_ARY = array(
		"0" => "公開開始日", 
		"1" => "有効回答数"
);
// タグ内検索
$TAG_SEARCH = array(
		FLAG_OFF => "HTMLのタグを対象としない", 
		FLAG_ON => "HTMLのタグを対象とする"
);
$MAXROW_LIST = getDefineArray("MAXROW_LIST");

$html = '<tr>' . "\n";
$html .= '<th align="center" valign="middle" style="font-weight:normal" scope="col">ページ情報</th>' . "\n";
$html .= '<th align="center" valign="middle" style="font-weight:normal" scope="col">集計</th>' . "\n";
$html .= '</tr>' . "\n";
//list format
$fmt = '<tr>' . "\n";
$fmt .= '<td align="left" valign="top">' . "\n";
$fmt .= '<p class="feedback-p"><strong><span id="{id}_title"><a href="javascript:" onClick="return cxPreview(\'feed_form\',\'{id}\',\'1\')">{page_title}</a></span></strong></p>' . "\n";
$fmt .= '<p class="feedback-p"><small>公開期間：{publish_date}</small></p>' . "\n";
$fmt .= '<p class="feedback-p"><small>組織：{dept_name}</small></p>' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '<td align="center" valign="middle" width="175">' . "\n";
$fmt .= '<a href="javascript:" onClick="return cxSubmit(\'{id}\')" {img_disp}><img src="' . RPW . '/admin/special/enquete/images/btn_total.jpg" width="150" height="20" border="0" alt="集計" vspace="2"></a><br>' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '</tr>' . "\n";
//CSVデータ取得
$cnt = 0;
$responses_ary = array();
$file_list = array();
$file_list = cxGetFileList(DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV, $file_list, ".csv");
if (count($file_list) == 0) {
}
foreach ($file_list as $key => $file) {
	$csv_file = str_replace(DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV, "", $file);
	$page_id = str_replace(".csv", "", $csv_file);
	if (!is_numeric($page_id)) continue;
	$cnt = 0;
	if (($CsvFno = fopen($file, 'r'))) {
		while (cms_fgetcsv($CsvFno, 20000)) {
			$cnt++;
		}
		$responses_ary[$page_id] = $cnt;
		fclose($CsvFno);
	}
}

//回答数順にソート
arsort($responses_ary, SORT_NUMERIC);

// 検索条件
$search = array(
		// ページID検索
		'page_id' => '',
		'page_title' => '', 
		'search_keywords' => '', 
		'is_tag_search' => FLAG_OFF, 
		'url' => '', 
		'publish_start' => '', 
		'publish_end' => '', 
		'pdsy' => '', 
		'pdsm' => '', 
		'pdsd' => '', 
		'pdey' => '', 
		'pdem' => '', 
		'pded' => '', 
		'order' => '0', 
		'target' => ($login['class'] == USER_CLASS_WEBMASTER) ? '1' : '0', 
		'page_limit' => '10', 
		'dept_code' => array(
				'dept1' => '', 
				'dept2' => '', 
				'dept3' => ''
		), 
		'cate_code' => array(
				'cate1' => '', 
				'cate2' => '', 
				'cate3' => '', 
				'cate4' => ''
		), 
		'p' => 1
);
$orederChecked = array(
		'0' => "", 
		'1' => ""
);

//検索ウインドウ
$btn = array(
		"dis" => "display:none", 
		"img" => "btn_open_mini.jpg", 
		"alt" => "開く"
);

$search_mode = (isset($_POST['dispMode']) && $_POST['dispMode'] != "") ? $_POST['dispMode'] : "init";
//同一ページ以外から来た場合、SESSIONを削除する
if (!isset($_SERVER['HTTP_REFERER']) || preg_replace('/\?.*$/i', '', $_SERVER['HTTP_REFERER']) != HTTP_ROOT . $_SERVER['PHP_SELF']) {
	unset($_SESSION['feedback_search']);
}

//モード
switch ($search_mode) {
	case "search" :
		$btn['dis'] = "display:block";
		$btn['img'] = "btn_close_mini.jpg";
		$btn['alt'] = "閉じる";
		$search = margePost($search);
		$_SESSION['search'] = $search;
		$_SESSION['last_search_condition']['feedback_search'] = $search;
		feedback_search($search, $responses_ary);
		break;
	case "pageset" :
		$search = $_SESSION['search'];
		$search['p'] = $_POST['p'];
		feedback_search($search, $responses_ary);
	case "init" :
		$_SESSION['search'] = $search;
		feedback_search($search, $responses_ary);
		break;
	case "disp_num" :
		$btn['dis'] = "display:none";
		$btn['img'] = "btn_open_mini.jpg";
		$btn['alt'] = "開く";
		$search = margePost($search);
		feedback_search($search, $responses_ary);
		break;
	case "last_condition" :
		$btn['dis'] = "display:block";
		$btn['img'] = "btn_close_mini.jpg";
		$btn['alt'] = "閉じる";
		$search = $_SESSION['last_search_condition']['feedback_search'];
		$_SESSION['search'] = $search;
		feedback_search($search, $responses_ary);
		break;
	default :
		break;
}
//前回の検索ボタン表示
$disp_last_condition = ""; //前回の検索ボタンHTML
if (isset($_SESSION['last_search_condition']['feedback_search'])) {
	$disp_last_condition = '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span>' . "\n";
}

//対象項目生成
// ページID検索
$search_page_id = (!empty($search['page_id'])) ? implode(' ', $search['page_id']) : '';
if ($login['class'] == USER_CLASS_WEBMASTER && $login['isOpenUser']) {
	$cms_target_radio = '';
}
else if ($login['class'] == USER_CLASS_WRITER || $login['class'] == USER_CLASS_WEBMASTER) {
	$cms_target_radio = '<p>' . mkradiobutton($TARGET_USER_ARY, "target", $search['target'], 2, '', 'cxDeptCombChange()') . '</p>';
}
else {
	$cms_target_radio = '<p>' . mkradiobutton($TARGET_DEPT_ARY, "target", $search['target'], 2, '', 'cxDeptCombChange()') . '</p>';
}
$cms_target = $cms_target_radio . create_department_list("dept", $search['dept_code'], "120");

$cms_category = create_category_list("cate", $search['cate_code'], "120");
$cms_oreder = mkradiobutton($ORDER_ARY, "order", $search['order'], 2);
$page_num = mkcombobox($MAXROW_LIST, "page_limit", $search['page_limit'], "cxDispNum(this.value)"); //ページ表示数
$cms_is_tag_search = mkradiobutton($TAG_SEARCH, "is_tag_search", $search["is_tag_search"], 2);

/** database controll **/
if (count($responses_ary) != 0) {
	if ($objPage->getRowCount() > 0) {
		while ($objPage->fetch()) {
			$page_title = $objPage->fld['page_title'];
			$publish_start = dtFormat($objPage->fld['publish_start'], 'Y年m月d日H時');
			$publish_end = get_publish_end_date($objPage->fld['publish_end']);
			$page_id = $objPage->fld['page_id'];
			$dept_name = $objPage->fld['dept_name'];
			$img_disp = "";
			
			$tmp = $fmt;
			$tmp = str_replace('{page_title}', htmlspecialchars($page_title), $tmp);
			$tmp = str_replace('{publish_date}', htmlspecialchars($publish_start) . 'から' . htmlspecialchars($publish_end) . 'まで', $tmp);
			$tmp = str_replace('{id}', $page_id, $tmp);
			$tmp = str_replace('{img_disp}', htmlspecialchars($img_disp), $tmp);
			$tmp = str_replace('{dept_name}', htmlspecialchars($dept_name), $tmp);
			$html .= $tmp;
		}
	}
}

//検索前処理
function margePost($search) {
	global $objLogin;
	$login = $objLogin->login;
	
	foreach ($search as $key => $value) {
		if (!isset($_POST[$key])) continue;
		$search[$key] = $_POST[$key];
		if ($key == "page_title" || $key == "search_keywords") {
			$search[$key] = str_replace('　', ' ', $search[$key]);
			$search[$key] = trim($search[$key]);
		}
	}
	$search['p'] = 1;
	
	// ページID検索
	if (!empty($search['page_id'])) {
		$search['page_id'] = explode(' ', preg_replace('/\s+/', ' ', $search['page_id']));
	}
	//公開開始日
	if (($search['pdsy'] != '') && ($search['pdsm'] != '') && ($search['pdsd'] != '')) {
		$search['publish_start'] = $search['pdsy'] . '-' . $search['pdsm'] . '-' . $search['pdsd'];
	}
	else
		$search['publish_start'] = "";
	if (($search['pdey'] != '') && ($search['pdem'] != '') && ($search['pded'] != '')) {
		$search['publish_end'] = $search['pdey'] . '-' . $search['pdem'] . '-' . $search['pded'] . ' 23:59:59';
	}
	else
		$search['publish_end'] = "";
		
	// -- カテゴリ
	if (isset($search['cate_code'])) {
		$search['cate_code']['cate1'] = $_POST['cate1'];
		$search['cate_code']['cate2'] = $_POST['cate2'];
		$search['cate_code']['cate3'] = $_POST['cate3'];
		$search['cate_code']['cate4'] = $_POST['cate4'];
	}
	// ---組織
	if (isset($search['dept_code'])) {
		$search['dept_code']['dept1'] = (isset($_POST['dept1']) ? $_POST['dept1'] : '');
		$search['dept_code']['dept2'] = (isset($_POST['dept2']) ? $_POST['dept2'] : '');
		$search['dept_code']['dept3'] = (isset($_POST['dept3']) ? $_POST['dept3'] : '');
	}
	$_SESSION['feedback_search'] = $search;
	
	return $search;

}

//検索
function feedback_search($pSearch, $responses_ary) {
	global $objLogin;
	global $objPage;
	$login = $objLogin->login;
	if (!$login) {
		require_once (APPLICATION_ROOT . '/common/dbcontrol/login.inc');
		$objLogin = new login();
		$login = $objLogin->login;
	}
	$table = "tbl_publish_page as p,tbl_user as u";
	$objPage->setTableName($table);
	$whereAry = array();
	// ページID検索
	// -- ページID 指定
	$where_page_id = array_keys($responses_ary);
	if (!empty($pSearch['page_id'])) {
		$where_page_id = array_intersect($pSearch['page_id'], $where_page_id);
	}
	$whereAry[] = $objPage->_addslashesC("p.page_id", implode(',', $where_page_id), "IN");
	$whereAry[] = "p.user_id = u.user_id";
	if (isset($pSearch['page_title']) && $pSearch['page_title'] != '') {
		$keyAry = explode(" ", $pSearch['page_title']);
		foreach ($keyAry as $k => $v) {
			if ($v == '') continue;
			$whereAry[] = $objPage->_addslashesC("p.page_title", "%" . $v . "%", "LIKE");
		}
	}
	if (isset($pSearch['url']) && $pSearch['url'] != '') {
		$whereAry[] = $objPage->_addslashesC("p.file_path", "%" . $pSearch['url'] . "%", "LIKE");
	}
	if (isset($pSearch['publish_start']) && $pSearch['publish_start'] != '') $whereAry[] = $objPage->_addslashesC('p.publish_start', $pSearch['publish_start'], '>=', 'DATE');
	if (isset($pSearch['publish_end']) && $pSearch['publish_end'] != '') $whereAry[] = $objPage->_addslashesC('p.publish_start', $pSearch['publish_end'], '<', 'DATE');
	
	if (isset($pSearch['target']) && $pSearch['target'] == 0) {
		// 作成者・ウェブマスター
		if ($login['class'] == USER_CLASS_WRITER || $login['class'] == USER_CLASS_WEBMASTER) {
			$whereAry[] = $objPage->_addslashesC('p.user_id', $login['user_id']);
		}
		else {
			$d_cd = $login['dept_code'];
			// 第一承認者
			if ($login['class'] == USER_CLASS_APPROVER1) {
				$whereAry[] = $objPage->_addslashesC('u.dept_code', $d_cd, '=', 'INT');
			}
			// 第二承認者
			elseif ($login['class'] == USER_CLASS_APPROVER2) {
				$digit = 2 * CODE_DIGIT_DEPT;
				$d_cd = "^" . substr($d_cd, 0, $digit);
				$whereAry[] = $objPage->_addslashesC('u.dept_code', $d_cd, 'REGEXP', 'TEXT');
			}
			// 第三承認者
			elseif ($login['class'] == USER_CLASS_APPROVER3) {
				$digit = 1 * CODE_DIGIT_DEPT;
				$d_cd = "^" . substr($d_cd, 0, $digit);
				$whereAry[] = $objPage->_addslashesC('u.dept_code', $d_cd, 'REGEXP', 'TEXT');
			}
		}
	}
	$dept1 = (isset($pSearch['dept_code']['dept1'])) ? $pSearch['dept_code']['dept1'] : '';
	$dept2 = (isset($pSearch['dept_code']['dept2'])) ? $pSearch['dept_code']['dept2'] : '';
	$dept3 = (isset($pSearch['dept_code']['dept3'])) ? $pSearch['dept_code']['dept3'] : '';
	if ($dept3 != '') {
		$whereAry[] = $objPage->_addslashesC('u.dept_code', $dept3, '=', 'INT');
	}
	elseif ($dept2 != '') {
		$digit = 2 * CODE_DIGIT_DEPT;
		$dept2 = "^" . substr($dept2, 0, $digit);
		$whereAry[] = $objPage->_addslashesC('u.dept_code', $dept2, 'REGEXP', 'TEXT');
	}
	elseif ($dept1 != '') {
		$digit = 1 * CODE_DIGIT_DEPT;
		$dept1 = "^" . substr($dept1, 0, $digit);
		$whereAry[] = $objPage->_addslashesC('u.dept_code', $dept1, 'REGEXP', 'TEXT');
	}
	
	// -- カテゴリ
	if (isset($pSearch['cate_code'])) {
		if (trim($pSearch['cate_code']['cate4']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', $pSearch['cate_code']['cate4'], "LIKE", "TEXT");
		}
		elseif (trim($pSearch['cate_code']['cate3']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', substr($pSearch['cate_code']['cate3'], 0, 9) . '%', "LIKE", "TEXT");
		}
		elseif (trim($pSearch['cate_code']['cate2']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', substr($pSearch['cate_code']['cate2'], 0, 6) . '%', "LIKE", "TEXT");
		}
		elseif (trim($pSearch['cate_code']['cate1']) != "") {
			$whereAry[] = $objPage->_addslashesC('p.cate_code', substr($pSearch['cate_code']['cate1'], 0, 3) . '%', "LIKE", "TEXT");
		}
	}
	// -- キーワード検索
	if (isset($pSearch['search_keywords']) && $pSearch['search_keywords'] != "") {
		// タグを対象にするかどうか
		$is_tag_search = (isset($pSearch['is_tag_search']) && $pSearch['is_tag_search'] == FLAG_ON) ? TRUE : FALSE;
		$keyAry = explode(" ", $pSearch['search_keywords']);
		foreach ($keyAry as $k => $v) {
			if ($v == '') continue;
			$whereAry[] = $objPage->_addslashesC('p.page_id', $objPage->mk_sql_kewords(PUBLISH_TABLE, 'DISTINCT page.page_id', $v, $is_tag_search), "IN");
		}
	}
	
	$where = implode(' AND ', $whereAry);
	$all = $objPage->getCount($where, $table);
	if (isset($pSearch['p'])) {
		$objPage->objP = new page_control();
		$objPage->objP->limit = $pSearch['page_limit'];
		$p = (isset($pSearch['p'])) ? $pSearch['p'] : 1;
		$objPage->objP->set($p, $all);
		$offset = $objPage->objP->getOffset();
		$limit = $objPage->objP->getLimit();
	}
	else {
		$offset = '';
		$limit = '';
	}
	
	if (isset($pSearch['order']) && $pSearch['order'] == '0') {
		$orderby = "p.publish_start DESC, p.publish_end DESC";
	}
	else {
		$orderby = "";
		$cnt = 1;
		foreach ($responses_ary as $pid => $num) {
			$orderby .= " when '" . $pid . "' then " . $cnt;
			$cnt++;
		}
		if ($orderby != "") {
			$orderby = "case p.page_id" . $orderby . " end";
		}
	}
	$objPage->select($where, '*', $orderby, $offset, $limit);
	$objPage->fetchrow = 0;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>フィードバック集計</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./feedback.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
var cms_prev_layer;
//
function cxSubmit(id){
	$('cms_page_id').value = id;
	$('feed_form').action = cms8341admin_path+'/special/feedback/confirm.php';
	$('feed_form').target = '_self';
	$('feed_form').submit();
	return false;
}
function cxLastSearch(){
	$('dispMode').value = "last_condition";
	document.cms_fSearch.submit();
	return false;
}

//search
function cxSearch() {
	if(!($F('pdsy') == "" && $F('pdsm') == "" && $F('pdsd') == "")){
		dc = cxDateCheckNew("pd","ymd",2,"公開開始日");
		if(!disp_date_error(dc,"pdsd")) return false;
	}
	if(!($F('pdey') == "" && $F('pdem') == "" && $F('pded') == "")){
		dc = cxDateCheckNew("pd","ymd",3,"公開開始日");
		if(!disp_date_error(dc,"pded")) return false;
	}
	if($F('pdsy') != "" && $F('pdsm') != "" && $F('pdsd') != "" &&
	   $F('pdey') != "" && $F('pdem') != "" && $F('pded') != ""){
		dc = cxDateCheckNew("pd","ymd",1,"公開開始日");
		if(!disp_date_error(dc,"pdsd")) return false;
	}
	$('dispMode').value = "search";
	document.cms_fSearch.submit();
	return false;
}
//エラーを閉じる
function cxCloseError() {
	cxLayer('cms8341-error',0);
	cxComboVisible();
}
// page sending
function cxPageSet(p) {
	document.cms_fSearch.dispMode.value = "pageset";
	document.cms_fSearch.p.value = p;
	document.cms_fSearch.submit();
	return false;
}
var cate_id;
function cxChangeCate(level, id, code) {
	cate_id = id;
	var prm = 'level='+level+'&code='+code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
	
}
function cxGetCateComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Categories') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i=level; i<=4; i++) {
        var cmb = $(cate_id+i);
        while (cmb.length > 1) {
            cmb.options[1] = null;
        }
    }
    var cmb = $(cate_id+level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        cmb.length++;
        cmb.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        cmb.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
// 組織変更プルダウン処理
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for(var i=t;i<=3;i++) {
			var obj = $('dept'+i);
			while(obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level='+lv+'&code='+val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i=level; i<=3; i++) {
        var obj = $('dept'+i);
        while (obj.length > 1) {
                obj.options[1] = null;
        }
        if(i==level) {
                obj.options[0].text = "指定なし";
        } else {
                obj.options[0].text = "";
        }
    }
    var obj = $('dept'+level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
//表示件数
function cxDispNum(max_val){
	$('dispMode').value = "disp_num";
	document.cms_fSearch.submit();
	return false;		
}
function cxDeptCombChange(){
	var disabled = ($('target_0') && $('target_0').checked) ? true : false;
	if($('dept1')) $('dept1').disabled = disabled;
	if($('dept2')) $('dept2').disabled = disabled;
	if($('dept3')) $('dept3').disabled = disabled;
}
Event.observe(window,'load',function(){
	cxDeptCombChange();
});
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'feedback';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-feedtotal">
<div><img
	src="<?=RPW?>/admin/special/feedback/images/title_feedback.jpg"
	alt="フィードバック集計" width="920" height="30"></div>
<div class="cms8341-area-corner">
<form id="cms_fSearch" name="cms_fSearch" class="cms8341-form"
	method="post" action="index.php"><input type="hidden" id="dispMode"
	name="dispMode" value=""> <input type="hidden" id="p" name="p" value="">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(images/bar_topbg.jpg); height: 31px;"><img
			src="./images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="<?=$btn['dis']?>">
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページID</th>
				<td align="left" valign="middle"><input type="text"
					id="page_id" name="page_id"
					value="<?=htmlspecialchars($search_page_id)?>"
					style="width: 250px; ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページタイトル</th>
				<td align="left" valign="middle"><input type="text" id="page_title"
					name="page_title"
					value="<?=htmlspecialchars($search['page_title'])?>"
					style="width: 500px;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">キーワード</th>
				<td align="left" valign="middle"><?=$cms_is_tag_search?><input
					type="text" id="search_keywords" name="search_keywords"
					value="<?=htmlspecialchars($search['search_keywords'])?>"
					style="width: 500px;"><br>
				<small>※大文字と小文字は区別されません。</small></td>
			</tr>
			<tr>
				<th width="80" align="left" valign="middle" nowrap scope="row">URL</th>
				<td align="left" valign="middle" nowrap><input type="text" id="url"
					name="url" value="<?=htmlspecialchars($search['url'])?>"
					style="width: 500px;"><br>
				<small>※<?=HTTP_REAL_ROOT?>/以下のパスを入力してください。部分一致します。</small></td>
			</tr>
			<tr>
				<th width="80" align="left" valign="middle" nowrap scope="row">公開開始日</th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="pdsy" name="pdsy"
					value="<?=htmlspecialchars($search['pdsy'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdsm" name="pdsm"
					value="<?=htmlspecialchars($search['pdsm'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pdsd" name="pdsd"
					value="<?=htmlspecialchars($search['pdsd'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="pdey" name="pdey"
					value="<?=htmlspecialchars($search['pdey'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdem" name="pdem"
					value="<?=htmlspecialchars($search['pdem'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pded" name="pded"
					value="<?=htmlspecialchars($search['pded'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th width="80" align="left" valign="middle" nowrap scope="row">分類</th>
				<td align="left" valign="middle"><?=$cms_category?></td>
			</tr>
			<tr>
				<th width="80" align="left" valign="middle" nowrap scope="row">対象</th>
				<td align="left" valign="middle"><?=$cms_target?></td>
			</tr>
			<tr>
				<th width="80" align="left" valign="middle" nowrap scope="row">表示順</th>
				<td align="left" valign="middle"><?=$cms_oreder?></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle"
			style="background-image: url(./images/bar_bottombg.jpg); height: 32px;"><a
			href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/<?=$btn['img']?>"
			alt="<?=$btn['alt']?>" width="80" height="15" border="0"
			style="margin-right: 10px;" id="cms-searchSwitch"></a></td>
	</tr>
</table>
</div>
<?php
if ($objPage->getRowCount() == 0) {
	?>
<?php

	if ($disp_last_condition != "") {
		?>
<div style="margin-bottom: 10px; padding: 1px" align="right"><?=$disp_last_condition?></div>
<?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当するフィードバック情報はありません。</td>
	</tr>
</table>
</form>
<?php
}
else {
	?>
<!--ページ送り-->
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr valign="top">
		<td colspan="3" align="right">
<?=$disp_last_condition?>
<?=$page_num?>
</td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink()?></td>
	</tr>
</table>
<!--ページ送り　ここまで-->
</form>

<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$html?>
</table>
<!--ページ送り-->
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objPage->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objPage->getNextLink()?></td>
	</tr>
</table>
<!--ページ送り　ここまで-->
<?php
}
?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->

<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<form id="feed_form" class="cms8341-form" name="feed_form"
	action="confirm.php" method="post"><input type="hidden"
	id="cms_page_id" name="cms_page_id" value=""> <input type="hidden"
	id="cms_dispMode" name="cms_dispMode" value=""></form>
</body>
</html>
