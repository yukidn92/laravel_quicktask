<?php
/*
 *
 */
/** require **/
require ("../.htsetting");

if (!isset($_POST['page_id']) || !isset($_POST['page_title'])) {
	user_error("必要なパラメーターが指定されていません。");
	exit();
}
$PID = $_POST['page_id'];
$csvData = "";
// CSV読み込み
$csv_file = DOCUMENT_ROOT . DIR_PATH_FEEDBACKCSV . $PID . ".csv";
//ファイルを開く
if (!($CsvFno = fopen($csv_file, 'r'))) {
	//エラーページの表示
	DispError("集計結果のダウンロードに失敗しました。", "feedback", "javascript:history.back()", MENU_KIND_SPECIAL);
	exit();
}
while ($datas = cms_fgetcsv($CsvFno, 200000)) {
	$line = "";
	foreach ($datas as $data) {
		$sep = ($line == "") ? "" : ",";
		$line .= $sep . str_replace("\\\\", "\\", csvWrite($data, "\""));
	}
	$csvData .= $line . "\n";
}

//ファイルの名前に使えない文字置き換え
$ary = array();
$ary[] = '\\';
$ary[] = '/';
$ary[] = ':';
$ary[] = '*';
$ary[] = '?';
$ary[] = '"';
$ary[] = '<';
$ary[] = '>';
$ary[] = '|';

$ary2 = array();
$ary2[] = '￥';
$ary2[] = '／';
$ary2[] = '：';
$ary2[] = '＊';
$ary2[] = '？';
$ary2[] = '”';
$ary2[] = '＜';
$ary2[] = '＞';
$ary2[] = '｜';

//SJISで文字化けする文字を置き換え
$ary3 = array();
$ary3[] = 'ℓ';
$ary3[] = '®';
$ary3[] = '㎥';
$ary3[] = '㎠';
$ary3[] = '㎤';
$ary3[] = '㎖';
$ary3[] = '㏔';
$ary3[] = '㎢';
$ary3[] = '㎳';

$ary4 = array();
$ary4[] = 'l';
$ary4[] = 'R';
$ary4[] = 'm3';
$ary4[] = 'cm2';
$ary4[] = 'cm3';
$ary4[] = 'ml';
$ary4[] = 'mb';
$ary4[] = 'km3';
$ary4[] = 'ms';

$file_name = $_POST['page_title'];
$file_name = str_replace($ary, $ary2, $file_name);
$file_name = str_replace($ary3, $ary4, $file_name);
$file_name = UTF8toSJIS($file_name) . "_" . date('Y') . date('n') . date('j') . date('H') . date('j') . date('i') . ".csv";

//CSV出力処理
header("Content-Disposition: attachment; filename=" . $file_name);
header('Content-type: text/comma-separated-values');
$csvData = str_replace($ary3, $ary4, $csvData);
print UTF8toSJIS($csvData);

?>
