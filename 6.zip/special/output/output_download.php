<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../.htsetting");
require ("./include/outputFunc.inc");
global $objCnc;
//db
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output.inc');
$objOutput = new tbl_output($objCnc);
$outputFunc = new outputFunc(OUTPUT_PAGE);

//IDの取得
if (!isset($_POST['output_id']) || $_POST['output_id'] == "") {
	$outputFunc->error("不正なパラメータです。");
}
$output_id = $_POST['output_id'];

//連携データ取得
$objOutput->selectFromID($output_id);
if ($objOutput->getRowCount() < 1) {
	$outputFunc->error("連携データの取得に失敗しました。");
}
$output_info = $objOutput->fld;

//出力ファイルパス設定
$output_file_path = $output_info['output_path'];
//パスチェック
if ($output_file_path == "") {
	$outputFunc->error("出力先パスの取得に失敗しました。");
}
if (substr($output_file_path, 0, 1) != '/') $output_file_path = '/' . $output_file_path;
$output_file_path = DOCUMENT_ROOT . RPR . $output_file_path;
//ファイルの確認
if (!@file_exists($output_file_path)) {
	$outputFunc->error("公開側にファイルが存在しません。【" . $output_info['output_path'] . "】");
}
//ファイル出力
if (($data = file_get_contents($output_file_path)) === FALSE) {
	$outputFunc->error("ファイルの読み込みに失敗しました。");
}
else {
	//ヘッダ出力
	header("Content-Type: application/octet-stream");
	header("Content-Disposition: attachment; filename=" . basename($output_file_path));
	header('Content-Length: ' . @filesize($output_file_path));
	print($data);
}
//処理終了
exit();
?>
