<?php
/*
 * 外部出力機能　設定画面
 */
/** require **/
require ("../.htsetting");
require ("./include/outputFunc.inc");
global $objCnc;
$outputFunc = new outputFunc(DISP_FORM);
$OUTPUT_ORDER_ARY = getDefineArray("OUTPUT_ORDER_ARY");

//main
$behavior = (!isset($_POST["behavior"])) ? OUTPUT_ADD : OUTPUT_UPD;

//戻り先
$back_path = ($behavior == OUTPUT_ADD) ? RPW . '/admin/special/output/index.php' : 'javascript:history.back();';

$output_id = (isset($_POST['output_id'])) ? $_POST['output_id'] : "";

$templateDat = getFixedTemplate();
$output_templateDat = getOutputTemplate($output_id);
$emptyDat = $outputFunc->craeteEmptyData();
$dat = getOutput($output_id);
$dat = array_merge($emptyDat, $dat);
$format_lbl = ($behavior == OUTPUT_UPD) ? '<br>現在のフォーマット：<a href="' . DIR_PATH_OUTPUT . $dat['output_id'] . "." . $dat['extension'] . '" target="_blank">確認する</a><br>文字コード：' . $dat['encode'] : "";
//新規登録以外の出力方法変更不可能
$kind_disabled = ($behavior != OUTPUT_ADD) ? " disabled" : "";
//変更できないテンプレートID取得
$disabled_tpl_ary = array();
if ($output_id != "" && $dat['page_output_flg'] == FLAG_ON) {
	//公開情報,編集情報
	$disabled_tpl_ary = array_merge(getOutputPageInfoFromTemplateId($output_id, $output_templateDat, 'template_id', HANDLER_OUTPUT_CLASS_PUBLISH_PAGE), getOutputPageInfoFromTemplateId($output_id, $output_templateDat, 'template_id', HANDLER_OUTPUT_CLASS_WORK_PAGE));
	//自動出力でチェックをはずすと公開しないページしか残らなくなる状況の確認▼
	if ($dat['output_kind'] == OUTPUT_KIND_AUTO) {
		//削除不可能テンプレート情報
		$disabled_tpl_ary = array_merge($disabled_tpl_ary, $outputFunc->getNotDeleteTemplateId($output_id));
	}
	//重複削除
	$disabled_tpl_ary = array_unique($disabled_tpl_ary);
}
//ページ設定変更不可能(紐付けにデータが存在したら変更不可)
$page_disabled = (count($disabled_tpl_ary) > 0) ? " disabled" : "";
//出力順カラム取得
$output_order_ary = $outputFunc->getOutputOrderBy($dat['output_order']);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部連携データ設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
//出力順の連想配列をjavascriptで出力する。
$order_obj = array();
foreach ($OUTPUT_ORDER_ARY as $column => $str)
	$order_obj[] = '"' . $column . '" : "' . $str . '"';
echo ("var order_obj = {" . implode(",", $order_obj) . "};\n");
?>
var order_cnt = 0;
function cxSubmit(){
	// 入力チェック
	if(!isEmpty('name',"名称") ) return false;
	if(isCheck('output_kind',"出力方法","radio") === false) return false;
	if(!isCheck('template_id[]',"出力条件","checkbox") ) return false;
	if($F('max_result') != "" && !isNumric('max_result','出力件数')) return false;
	if($F('behavior') == '<?=OUTPUT_ADD?>'){
		if(!isEmpty('output_format',"フォーマット") ) return false;
	}
	if(getCheckValue('output_kind','radio') == <?=OUTPUT_KIND_AUTO?>){
		if(!isEmpty('output_path',"出力先パス") ) return false;
	}
	if($('page_output_flg').checked === true){
		if(isCheck('output_default_check',"初期選択","radio") === false) return false;
	}
	$('output_form').submit();
	return false;
}
/**
*	チェックされている値の取得
*	@palam id Name
*	@palam item アイテム名　例 radio
*	return チェックされている項目が存在したらValue値、しなかったらFalse
*/
function getCheckValue(id,item){
	var ret = false;
	var nodes = Form.getInputs($('output_form'),item,id);
	$A(nodes).each( function(obj) { 
						if(obj.checked) ret = obj.value;
					} ); 
	return ret;
}
// 空チェック
function isEmpty(id,name){
	if($(id).value == ""){
		alert(name+"が入力されていません")
		$(id).focus();
		return false;
	}
	return true;
}
// 選択チェック
function isSelect(id,name){
	if($F(id) == ""){
		alert(name+"が選択されていません")
		$(id).focus();
		return false;
	}
	return true;
}
// 数字チェック
function isNumric(id,name,max){
	num = new Number($F(id));
	var msg = (max)
			? name+"は1以上"+max+"以下の数字を入力してください"
			: name+"は1以上の数字を入力してください";
	
	if(!cxDateNumeric($F(id))){
		alert(msg)
		$(id).focus();
		return false;
	}
	if(num < 1 || num > max){
		alert(msg)
		$(id).focus();
		return false;
	}
	return true;
}
// チェックされているかチェック
function isCheck(id,name,item){
	ret = getCheckValue(id,item);
	if(ret === false){
		alert(name+"が選択されていません")
	}
	return ret;
}
//テンプレートクリック時
function cxTemplateClick(){
	<?=($page_disabled != "") ? 'return;' : ''?>
	ret = false;
	var nodes = Form.getInputs($('output_form'),'checkbox','template_id[]');
	$A(nodes).each( function(obj) { 
						if(obj.checked) ret = true; 
					} ); 
	if(ret === false){
		$('page_output_flg').disabled = true;
	} else {
		$('page_output_flg').disabled = false;
	}
}
//ページ側クリック時
function cxOutputPageClick(){
	if($('page_output_flg').checked === true){
		$('output_default_check_tr').style.display = '';
	}else{
		$('output_default_check_tr').style.display = 'none';
	}
}
//チェックボックスを押せなくする
function cxTemplateUnClick(){
	var nodes = Form.getInputs($('output_form'),'hidden','template_id[]');
	var target_id = new Array();
	$A(nodes).each( function(obj) {
						target_id.push('template_id_' + obj.value)
					} );
	for(var i=0;i<target_id.length;i++){
		//if(!$(target_id[i]))continue;
		$(target_id[i]).removeAttribute("onclick");
		$(target_id[i]).disabled = true;
	}
	return;
}
//出力方法変更時
function cxChangeKind(){
	var output_kind = getCheckValue('output_kind','radio');
	if(output_kind == <?=OUTPUT_KIND_AUTO?>){
		$('output_path_tr').style.display = '';
		$('output_order_tr').style.display = '';
	}else {
		$('output_path_tr').style.display = 'none';
		$('output_order_tr').style.display = 'none';
	}
	return true;
}
//出力順領域の作成
function cxAddOrder(){
	//エレメント作成
	var order_area = document.createElement('p');
	order_area.id = 'output_area_' + order_cnt;
	//コンボボックス作成
	var comb_elem_div = document.createElement('div');	//コンボボックス
	comb_elem_div.innerHTML = '<select id="output_order_' + order_cnt + '" name="output_order[' + order_cnt + '][column]' + '"></select>';
	var comb_elem = comb_elem_div.firstChild;	//コンボボックス
	for(var name in order_obj){
		comb_elem.options[comb_elem.options.length] = new Option(order_obj[name],name);
	}
	order_area.appendChild(comb_elem);
	//ラジオボタン作成
	order_area.innerHTML += '&nbsp;<input type="radio" name="output_order['+order_cnt+'][order]" id="output_order_mode_'+order_cnt+'_ASC" value="ASC"><label for="output_order_mode_'+order_cnt+'_ASC">昇順</label>'
						　+ '&nbsp;<input type="radio" name="output_order['+order_cnt+'][order]" id="output_order_mode_'+order_cnt+'_DESC" value="DESC" checked><label for="output_order_mode_'+order_cnt+'_DESC">降順</label>';
	//削除ボタン作成
	order_area.innerHTML += '&nbsp;<span style="margin-left:10px"><a href="javascript:" onClick="return cxDelOrder('+order_cnt+');"><img src="./images/btn_del_order.jpg" alt="削除" width="57" height="20" border="0" class="cms8341-verticalMiddle"></a></span>';
	//要素追加
	$('output_order').appendChild(order_area);
	//カウントアップ
	order_cnt++;
}
//出力順領域の削除
function cxDelOrder($key){
	Element.remove($('output_area_' + $key));
	return;
}
function cxInit() {
	cxTemplateUnClick();
	cxTemplateClick();
	cxChangeKind();
	cxOutputPageClick();
	//追加されている出力順の数
	order_cnt = $('output_order').getElementsByTagName('select').length;
	cxPreImages("./images/btn_del_order.jpg");//画像先読み
}
Event.observe(window,'load',cxInit,false);
-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'output';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="./images/bar_output_form.jpg" alt="外部連携データ設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<form id="output_form" class="cms8341-form" name="ad_form" method="post"
	action="confirm.php" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th style="width: 150px">名称<span class="cms_require">（必須）</span></th>
		<td><input type="text" name="name" id="name"
			value="<?=htmlspecialchars($dat['name'])?>" style="width: 400px"></td>
	</tr>
	<tr>
		<th style="width: 150px">出力方法<span class="cms_require">（必須）</span></th>
		<td <?=$kind_disabled?>>
				<?=mkradiobutton(array(OUTPUT_KIND_MANUAL => "手動出力", OUTPUT_KIND_AUTO => "自動出力"), "output_kind", $dat["output_kind"], 2, '', 'cxChangeKind();')?>
			</td>
			<?php
			//hidden値で値を送る
			if ($kind_disabled != "") {
				echo '<input type="hidden" id="output_kind" name="output_kind" value="' . $dat["output_kind"] . '">';
			}
			?>
		</tr>
	<tr>
		<th>出力条件<span class="cms_require">（必須）</span></th>
		<td>
		<p>
				<?php
				echo mkcheckbox($templateDat, "template_id", $output_templateDat, 2, "", "return cxTemplateClick()", true);
				?>
				</p>
		<input type="checkbox" name="page_output_flg" id="page_output_flg"
			value="1" onclick="return cxOutputPageClick()" <?=$page_disabled?>
			<?=(($dat['page_output_flg'] == FLAG_ON) ? " checked" : "")?>><label
			for="page_output_flg">ページ側で出力対象を設定させる</label>
				<?php
				//変更不可時はhidden値で渡す
				//テンプレートID
				foreach ($disabled_tpl_ary as $tpl_id) {
					echo '<input type="hidden" name="template_id[]" value="' . $tpl_id . '">';
				}
				//ページフラグ
				if ($page_disabled != "") {
					echo '<input type="hidden" id="page_output_flg" name="page_output_flg" value="' . $dat['page_output_flg'] . '">';
				}
				?>
			</td>
	</tr>
	<tr>
		<th style="width: 150px">出力件数</th>
		<td><input type="text" name="max_result" id="max_result"
			value="<?=htmlspecialchars($dat['max_result'])?>"
			style="width: 100px; ime-mode: disabled;">件</td>
	</tr>
	<tr id="output_order_tr">
		<th style="width: 150px">出力順<span class="cms_require">（必須）</span></th>
		<td>
		<div id="output_order"><a href="javascript:"
			onClick="return cxAddOrder();"><img src="./images/btn_add_order.jpg"
			alt="出力順を追加する" width="125" height="20" border="0"
			class="cms8341-verticalMiddle"></a>
				<?php
				foreach ($output_order_ary as $key => $order_by) {
					echo '<p id="output_area_' . $key . '">';
					//コンボボックス作成
					$order_comb = mkcombobox($OUTPUT_ORDER_ARY, 'output_order_' . $key, $order_by['column'], '', '');
					//ラジオボタン作成
					$temp_ary = array(
							'ASC' => '昇順', 
							'DESC' => '降順'
					);
					$order_radio = mkradiobutton($temp_ary, 'output_order_mode_' . $key, $order_by['order'], FLAG_OFF);
					//NAMEを置換する。
					$order_comb = str_replace('name="output_order_' . $key . '"', 'name="output_order[' . $key . '][column]"', $order_comb);
					$order_radio = str_replace('name="output_order_mode_' . $key . '"', 'name="output_order[' . $key . '][order]"', $order_radio);
					echo $order_comb . $order_radio;
					if ($key > 0) {
						echo '<span style="margin-left:10px"><a href="javascript:" onClick="return cxDelOrder(' . $key . ');"><img src="./images/btn_del_order.jpg" alt="削除" width="57" height="20" border="0" class="cms8341-verticalMiddle"></a></span>';
					}
					echo '</p>';
				}
				?>
				</div>
		<div style="margin-bottom: 3px; position: relative;"><span
			style="font-size: 12px";>&nbsp;※出力順は、上の条件から順に優先されます。</span></div>
		</td>
	</tr>
	<tr>
		<th style="width: 150px">フォーマット<span class="cms_require">（必須）</span></th>
		<td><input type="file" name="output_format" id="output_format"
			value="" style="width: 400px">
				<?=$format_lbl?>
			</td>
	</tr>
	<tr id="output_path_tr">
		<th style="width: 150px">出力先パス<span class="cms_require">（必須）</span></th>
		<td><input type="text" name="output_path" id="output_path"
			value="<?=htmlspecialchars($dat['output_path'])?>"
			style="width: 400px; ime-mode: disabled;"></td>
	</tr>
	<tr id="output_default_check_tr">
		<th style="width: 150px">初期選択<span class="cms_require">（必須）</span></th>
		<td>
				<?=mkradiobutton(array(FLAG_ON => "チェックあり", FLAG_OFF => "チェックなし"), "output_default_check", $dat["output_default_check"], 2)?>
			</td>
	</tr>
</table>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px"></a> <a
	href="<?=$back_path?>"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" id="output_id" name="output_id"
	value="<?=$output_id?>"> <input type="hidden" id="behavior"
	name="behavior" value="<?=$behavior?>"> <input type="hidden"
	id="extension" name="extension" value="<?=$dat['extension']?>"> <input
	type="hidden" id="encode" name="encode" value="<?=$dat['encode']?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
