<?php
/*
 * 否認処理
 */
/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");
require ("./include/outputFunc.inc");
global $objCnc;

$outputFunc = new outputFunc(DISP_LIST);

if (!isset($_POST['page_id']) || $_POST['page_id'] == "") {
	return "不正なパラメータです。";
}
if (!isset($_POST['output_id']) || $_POST['output_id'] == "") {
	return "不正なパラメータです。";
}
if (!isset($_POST['reason']) || $_POST['reason'] == "") {
	return "不正なパラメータです。";
}
$output_id = $_POST['output_id'];
$page_id = $_POST['page_id'];
$reason = trim($_POST['reason']);

$objCnc->begin();
$outputFunc->entryData($output_id, array(
		$page_id
), OUTPUT_MODE_HIDDEN);
if (MAIL_FLG_OUTPUT_HIDDEN) $outputFunc->send_mail($output_id, $page_id, $reason);
$objCnc->commit();

?>