<?php
/*
 * 外部出力機能　確認画面
 */
/** require **/
require ("../.htsetting");
require ("./include/outputFunc.inc");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
global $objCnc;
$outputFunc = new outputFunc(DISP_CONFIRM);
$dac_tools = new dac_tools($objCnc);
$OUTPUT_ORDER_ARY = getDefineArray("OUTPUT_ORDER_ARY");
unset($_SESSION["hidden"]);
if (!isset($_POST['behavior']) || !in_array($_POST['behavior'], array(
		OUTPUT_ADD, 
		OUTPUT_UPD, 
		OUTPUT_DEL, 
		OUTPUT_INF
))) {
	$outputFunc->error("不正なパラメータです。");
}

$templateDat = getFixedTemplate();
$behavior = $_POST["behavior"];
switch ($behavior) {
	case OUTPUT_ADD :
	case OUTPUT_UPD :
		$emptyDat = $outputFunc->craeteEmptyData();
		$dat = $outputFunc->getPostData($_POST);
		$dat = array_merge($emptyDat, $dat);
		break;
	case OUTPUT_DEL :
	case OUTPUT_INF :
		$emptyDat = $outputFunc->craeteEmptyData();
		$dat = getOutput($_POST['output_id']);
		$dat['template_id'] = getOutputTemplate($_POST['output_id']);
		$dat['output_order'] = $outputFunc->getOutputOrderBy($dat['output_order']);
		$dat = array_merge($emptyDat, $dat);
		break;
}
//出力順の配列
$output_order_ary = array();
//削除可否フラグ
$del_flg = TRUE;
//自動出力
if ($dat['output_kind'] == OUTPUT_KIND_AUTO) {
	//出力順加工
	foreach ((array) $dat['output_order'] as $order_by) {
		$output_order_ary[] = $order_by['column'] . ' ' . $order_by['order'];
	}
	//重複削除
	$output_order_ary = array_unique($output_order_ary);
	
	//削除されると公開されていないページしか残らなくなる場合は削除できない。
	if ($dat['page_output_flg'] == FLAG_ON && $behavior == OUTPUT_INF) {
		//削除不可能テンプレート情報
		$output_tpl_ary = $outputFunc->getNotDeleteTemplateId($dat['output_id']);
		if (count($output_tpl_ary) >= 1) $del_flg = FALSE;
	}
}
//DB登録用に整形する
unset($dat['output_order']);
$dat['output_order'] = implode(",", $output_order_ary);

$outputFunc->checkOutput($dat, $_POST['behavior']);
$_SESSION["hidden"] = $dat;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部連携データ設定確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(bv){
	switch(bv) {
		// 追加から
		case <?=OUTPUT_ADD?>:
			$('behavior').value = bv;
			$('ad_form').action = 'submit.php';
			break;
		// 修正から
		case <?=OUTPUT_UPD?>:
			$('behavior').value = bv;
			$('ad_form').action = 'submit.php';
			break;
		// 削除から
		case <?=OUTPUT_DEL?>:
			if (!confirm("この外部出力情報を削除します\nよろしいですか？")) {
				return false;
			}		
			$('behavior').value = bv;
			$('ad_form').action = 'submit.php';
			break;
		// 確認から
		case <?=OUTPUT_INF?>:
			$('behavior').value = bv;
			$('ad_form').action = 'form.php';
			break;
		default:
			alert('パラメータエラー（behavior）');
			exit;
	}
	$('ad_form').submit();
	return false;
}	
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'output';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="./images/bar_output_confirm.jpg" alt="外部連携データ設定確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th style="width: 150px">名称</th>
		<td><?=htmlDisplay($dat['name'])?></td>
	</tr>
	<tr>
		<th>出力方法</th>
		<td>
			<?=($dat['output_kind'] == OUTPUT_KIND_MANUAL) ? '手動出力' : '自動出力'?>
			</td>
	</tr>
	<tr>
		<th>出力条件</th>
		<td>
			<?php
			echo '<p>';
			foreach ($dat['template_id'] as $template_id) {
				if ($dac_tools->selectTemplate($template_id) === FALSE) continue;
				echo $dac_tools->fld['name'] . "<br>";
			}
			echo '</p>';
			if ($dat['page_output_flg'] == FLAG_ON) {
				echo 'ページ側で出力対象を設定させる';
			}
			else {
				echo 'ページ側で出力対象を設定させない';
			}
			?>
			</td>
	</tr>
	<tr>
		<th>出力件数</th>
		<td>
			<?=($dat['max_result'] != "") ? htmlDisplay($dat['max_result']) . '件' : '全件'?>
			</td>
	</tr>
		<?php
		if ($dat['output_kind'] == OUTPUT_KIND_AUTO) {
			?>
		<tr>
		<th style="width: 150px">出力順</th>
		<td>
			<?php
			//カンマ区切りで分割
			$output_order_ary = $outputFunc->getOutputOrderBy($dat['output_order']);
			//配列分ループ
			foreach ($output_order_ary as $order_by) {
				//カラムとソートに分解
				$html_order_str = $OUTPUT_ORDER_ARY[$order_by['column']] . ($order_by['order'] == 'ASC' ? 'の昇順' : 'の降順');
				echo (htmlDisplay($html_order_str) . '<br>');
			}
			?>
			</td>
	</tr>
		<?php
		}
		?>
		<tr>
		<th style="width: 150px">フォーマット</th>
		<td><?php
		if (in_array($behavior, array(
				OUTPUT_ADD
		))) {
			echo $_FILES["output_format"]["name"];
		}
		else if (in_array($behavior, array(
				OUTPUT_UPD
		)) && $_FILES["output_format"]["name"] != "") {
			echo $_FILES["output_format"]["name"];
		}
		else {
			echo '<a href="' . DIR_PATH_OUTPUT . $dat['output_id'] . "." . $dat['extension'] . '" target="_blank">確認する</a>';
		}
		echo '<br>文字コード：' . $dat['encode'];
		?>
			</td>
	</tr>
		<?php
		if ($dat['output_kind'] == OUTPUT_KIND_AUTO) {
			?>
		<tr>
		<th style="width: 150px">出力先パス</th>
		<td>
			<?=htmlDisplay($dat['output_path'])?>
			</td>
	</tr>
		<?php
		}
		if ($dat['page_output_flg'] == FLAG_ON) {
			?>
		<tr>
		<th style="width: 150px">初期選択</th>
		<td>
			<?php
			if ($dat['output_default_check'] == FLAG_ON) {
				echo 'チェックあり';
			}
			else {
				echo 'チェックなし';
			}
			?>
			</td>
	</tr>
		<?php
		}
		?>
	</table>

<p align="center">
<?php
switch ($behavior) {
	case OUTPUT_ADD :
		echo '<a href="javascript:" onClick="return cxSubmit(' . OUTPUT_ADD . ')"><img src="' . RPW . '/admin/images/btn/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
	case OUTPUT_UPD :
		echo '<a href="javascript:" onClick="return cxSubmit(' . OUTPUT_UPD . ')"><img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
	case OUTPUT_DEL :
		break;
	case OUTPUT_INF :
		echo '<a href="javascript:" onClick="return cxSubmit(' . OUTPUT_INF . ')"><img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px"></a>';
		if ($objLogin->get('class') == USER_CLASS_WEBMASTER && $del_flg) {
			echo '<a href="javascript:" onClick="return cxSubmit(' . OUTPUT_DEL . ')"><img src="' . RPW . '/admin/images/btn/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px"></a>';
		}
		else {
			echo '<img src="' . RPW . '/admin/images/btn/btn_del_off.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		}
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_back.jpg" alt="戻る" width="150" height="20" border="0" style="margin-right:10px"></a>';
		break;
}
?>	
	</p>
<form id="ad_form" class="cms8341-form" name="output_form" method="post"
	action=""><input type="hidden" id="behavior" name="behavior"
	value="<?=$behavior?>"> <input type="hidden" id="output_id"
	name="output_id" value="<?=$dat['output_id']?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>