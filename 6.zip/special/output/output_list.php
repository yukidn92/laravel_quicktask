<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");
require ("./include/outputFunc.inc");

$outputFunc = new outputFunc(OUTPUT_PAGE);

// パラメータチェック
if (!isset($_POST['output_id']) || $_POST['output_id'] == "") {
	$outputFunc->error("不正なパラメータです。");
}
$output_id = $_POST['output_id'];
$search_mode = (isset($_POST['dispMode']) && $_POST['dispMode'] != "") ? $_POST['dispMode'] : "init";
if ($search_mode == "init") unset($_SESSION['output']);
$disp_order_ary = array(
		"0" => "昇順", 
		"1" => "降順"
);
$disp_num_ary = array(
		"10" => "10件", 
		"50" => "50件", 
		"100" => "100件"
);
$op_fld = getOutput($output_id);
$search = array(
		// ページID検索
		'search_page_id' => '',
		"output_id" => $_POST['output_id'], 
		'page_title' => "", 
		'search_keywords' => '', 
		'is_tag_search' => FLAG_OFF, 
		'url' => "", 
		'cate_code' => array(
				'cate1' => '', 
				'cate2' => '', 
				'cate3' => '', 
				'cate4' => ''
		), 
		'dept_code' => array(
				'dept1' => '', 
				'dept2' => '', 
				'dept3' => ''
		), 
		'pdsy' => "", 
		'pdsm' => "", 
		'pdsd' => "", 
		'pdey' => "", 
		'pdem' => "", 
		'pded' => "", 
		'disp_order' => "1", 
		'disp_num' => "10", 
		'page_no' => "1", 
		'mode' => OUTPUT_MODE_OUTPUT, 
		'page_output_flg' => $op_fld['page_output_flg']
);
switch ($search_mode) {
	case "move" :
		$search = $_SESSION['output']['search'];
		$search['page_no'] = $_POST['page_no'];
		break;
	case "search" :
		unset($_SESSION['output']['check']);
		$outputFunc->margePost($_POST, $search);
		$_SESSION['last_search_condition']['output_list'] = $search;
		break;
	case "change_num" :
		$outputFunc->margePost($_POST, $search);
		break;
	case "to_target" :
		$outputFunc->entryData($output_id, array(
				$_POST['page_id']
		), OUTPUT_MODE_TARGET);
		break;
	case "last_condition" :
		$search = $_SESSION['last_search_condition']['output_list'];
		$search_mode = "search";
		break;
	default :
		break;
}
// 前回の検索ボタン表示
$disp_last_condition = ""; //前回の検索HTML
if (isset($_SESSION['last_search_condition']['output_list'])) {
	$disp_last_condition = '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span>' . "\n";
}

$dept_str = create_department_list("dept", $search['dept_code'], "120");
$category_str = create_category_list("cate", $search['cate_code'], '120');
$disp_order_str = mkradiobutton($disp_order_ary, "disp_order", $search['disp_order'], 2);
// タグ内検索
$var = array(
		FLAG_OFF => "HTMLのタグを対象としない", 
		FLAG_ON => "HTMLのタグを対象とする"
);
$name = "is_tag_search";
$cms_is_tag_search = mkradiobutton($var, $name, $search["is_tag_search"], 2);

// ページID検索
$search_page_id = (!empty($search['search_page_id'])) ? implode(' ', $search['search_page_id']) : '';

$list_ary = $outputFunc->getList($search);

$_SESSION['output']['search'] = $search;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>データ管理／出力リスト</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./output.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="./output.js" type="text/javascript"></script>
<script type="text/javascript">
<!--

	function cxMove(page_id){
		if(!confirm("このページを出力対象リストへ移動します。\nよろしいですか？")){
			return false;
		}
		$('dispMode').value = "to_target";
		$('page_no').value = 1;
		$('page_id').value = page_id;
		$('cms_fSearch').submit();
		return false;
	}	
	
	// 出力グループ名設定画面表示
	var output_action = 0;
	function cxOutputSetting(page_id) {
		output_action = 0;
		is_output = 0;
		if(cms_prev_layer) cms_prev_layer.style.display = 'none';
		var c = $('cms8341-calendar');
		if(c.style.display=='block') c.style.display = 'none';
		$('note').value = "";
		cxComboHidden();
		cxLayer('cms8341-request',1,600,565);
		$('group_name').focus();
		prm = "";
		cxAjaxCommand('cxGetOutputRequestPageList', prm, cxGetOutputSettingSuccess);
		return false;
	}
	
	function cxGetOutputSettingSuccess(r){
		if(r.responseText == ""){
			alert("出力するページを選択してください。");
			cxLayer('cms8341-request',0);
		} else {
			$('request_page_list').innerHTML = '<ul>'+r.responseText+'</ul>';
		}
	}
	
	// 外部データ出力
	function cxOutput(){
		if (output_action == 1){
			alert('連続して出力することはできません。再度ページを選択して出力してください。');
			return false;
		}
		if (!$('group_name').value) {
			alert('出力グループ名が入力されていません。');
			$('group_name').focus();
			return false;
		} else if (!cxCheckMachineCode($('group_name').value)) {
			alert('出力グループ名に機種依存文字が含まれています。');
			$('reason').focus();
			return false;
		}
		if (!cxCheckMachineCode($('note').value)) {
			alert('備考に機種依存文字が含まれています。');
			$('note').focus();
			return false;
		}
		//main
		cxComboVisible();
		output_action = 1;
		$('output_form').submit();
		return false;
	}

	function cxOutputClose(){
		cxComboVisible();
		if(output_action == 1){
			$('cms_fSearch').submit();
		} else {
			cxLayer('cms8341-request',0);
		}
		return false;
	}

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'output';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-log">
<div
	style="width: 920px; text-align: left; background: url(images/tab_bg.jpg) bottom repeat-x;">
<table border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td width="226"><a href="javascript:"
			onClick="return cxMoveList('target_list')"><img
			src="./images/<?=(($outputFunc->disp == OUTPUT_TARGET) ? "tab_target_list_on.jpg" : "tab_target_list_off.jpg")?>"
			alt="出力対象リスト" width="226" height="25" border="0"></a></td>
		<td width="2"><img src="images/tab_bg.jpg" alt="" width="5"
			height="25"></td>
		<td width="226"><a href="javascript:"
			onClick="return cxMoveList('output_list')"><img
			src="images/<?=(($outputFunc->disp == OUTPUT_PAGE) ? "tab_output_list_on.jpg" : "tab_output_list_off.jpg")?>"
			alt="出力リスト" width="226" height="25" border="0"></a></td>
		<td width="2"><img src="images/tab_bg.jpg" alt="" width="5"
			height="25"></td>
		<td width="226"><a href="javascript:"
			onClick="return cxMoveList('history_list')"><img
			src="images/<?=(($outputFunc->disp == OUTPUT_HISTORY) ? "tab_history_list_on.jpg" : "tab_history_list_off.jpg")?>"
			alt="出力履歴" width="226" height="25" border="0"></a></td>
		<td width="2"><img src="images/tab_bg.jpg" alt="" width="5"
			height="25"></td>
		<td width="226"><a href="javascript:"
			onClick="return cxMoveList('hidden_list')"><img
			src="images/<?=(($outputFunc->disp == OUTPUT_HIDDEN) ? "tab_hidden_list_on.jpg" : "tab_hidden_list_off.jpg")?>"
			alt="非表示リスト" width="226" height="25" border="0"></a></td>
	</tr>
</table>
</div>
<div
	style="width: 918px; border: solid 1px #CCCCCC; border-top: none; background-color: #78C1F8;"><img
	src="<?=RPW?>/admin/images/spacer.gif" width="1" height="8" alt=""></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(images/bar_topbg.jpg); height: 31px;"><img
			src="images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<form name="cms_fSearch" id="cms_fSearch" class="cms8341-form"
	method="post" action=""><input type="hidden" name="dispMode"
	id="dispMode" value=""> <input type="hidden" id="page_no"
	name="page_no" value=""> <input type="hidden" id="page_id"
	name="page_id" value=""> <input type="hidden" id="output_id"
	name="output_id" value="<?=$_POST['output_id']?>">
<div id="cms8341-search" style="display:<?=(($search_mode != "search") ? "none" : "block")?>">
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページID</th>
				<td align="left" valign="middle"><input type="text"
					id="search_page_id" name="search_page_id"
					value="<?=htmlspecialchars($search_page_id)?>"
					style="width: 185px; ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページタイトル</th>
				<td align="left" valign="middle"><input type="text"
					name="page_title" id="page_title"
					value="<?=htmlspecialchars($search['page_title'])?>"
					style="width: 370px;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">キーワード</th>
				<td align="left" valign="middle"><?=$cms_is_tag_search?><input
					type="text" id="search_keywords" name="search_keywords"
					value="<?=htmlspecialchars($search['search_keywords'])?>"
					style="width: 370px;"><br>
				<small>※大文字と小文字は区別されません。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">URL</th>
				<td align="left" valign="middle"><input type="text" name="url"
					id="url" value="<?=htmlspecialchars($search['url'])?>"
					style="width: 370px;"></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">分類</th>
				<td align="left" valign="middle"><?=$category_str?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">組織</th>
				<td align="left" valign="middle"><?=$dept_str?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="log_range">公開開始日</label></th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="pdsy" name="pdsy" value="<?=$search['pdsy']?>"
					style="width: 50px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdsm" name="pdsm" value="<?=$search['pdsm']?>"
					style="width: 30px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pdsd" name="pdsd" value="<?=$search['pdsd']?>"
					style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から &nbsp;
				<input type="text" maxlength="4" id="pdey" name="pdey"
					value="<?=$search['pdey']?>"
					style="width: 50px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdem" name="pdem" value="<?=$search['pdem']?>"
					style="width: 30px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pded" name="pded" value="<?=$search['pded']?>"
					style="width: 30px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> まで</td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">表示順</th>
				<td align="left" valign="middle">公開開始日<?=$disp_order_str?></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;">
				<?php
				if ($search_mode != "search") {
					?>
				<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_open_mini.jpg" alt="開く" width="80"
			height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a>
				<?php
				}
				else {
					?>
				<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる"
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a>
				<?php
				}
				?>
			</td>
	</tr>
</table>

</div>
<?php
if (count($list_ary) > 0) {
	?>
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr valign="top">
		<td colspan="3" scope="row"><span style="float: left;"> <a
			href="javascript:" onClick="return cxCheckAll();"><img
			src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
			width="120" height="20" border="0"></a> <a href="javascript:"
			onClick="return cxReleaseAll();"><img
			src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
			width="120" height="20" hspace="20" border="0"></a> </span> <span
			style="float: right;">
				<?=$disp_last_condition?>
				<?=mkcombobox($MAXROW_LIST, "disp_num", $search['disp_num'], "cxDispNum(this.value)")?>
			</span></td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$outputFunc->objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$outputFunc->objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$outputFunc->objP->getNextLink()?></td>
	</tr>
</table>
<?php
}
elseif ($disp_last_condition != "") {
	?>
<div style="margin-bottom: 10px; padding: 1px" align="right"><?=$disp_last_condition?></div>
<?php
}
?>
</form>
<form id="_form" name="_form" class="cms8341-form" method="post"
	action=""><input type="hidden" id="cms_dispMode" name="cms_dispMode"
	value=""> <input type="hidden" id="cms_page_id" name="cms_page_id"
	value=""> <input type="hidden" id="cms_output_id" name="cms_output_id"
	value="<?=$output_id?>">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
<?php
echo '<tr><th colspan="2" align="center">' . htmlDisplay($op_fld['name']) . "出力対象リスト" . '</th><th align="center">設定</th></tr>' . "\n";
if (count($list_ary) == 0) {
	echo '<tr>' . "\n";
	echo '<td align="left" valign="top" colspan="3">' . "\n";
	echo '<table width="100%" border="0" cellpadding="0" cellspacing="0" style="margin:0px" class="cms8341-noneBorder">' . "\n";
	echo '<tr>' . "\n";
	echo '<td align="center" valign="middle" width="5%">対象のページはありません。</td>' . "\n";
	echo '</table>' . "\n";
	echo '</td>' . "\n";
	echo '</tr>' . "\n";
}
foreach ($list_ary as $list) {
	$tbl = ($list['status'] == STATUS_PUBLISH_WAIT) ? WORK_TABLE : PUBLISH_TABLE;
	$checked = (isset($_SESSION['output']['check']) && in_array($list['page_id'], array_keys($_SESSION['output']['check']))) ? " checked" : "";
	$icon = "";
	$icon_alt = "";
	$outputFunc->getListIcon($list, $icon, $icon_alt);
	echo '<tr>' . "\n";
	echo '<td width="5%" align="center" style="border-right:0px">';
	echo '<input type="checkbox" name="page_id[]" id="page_id_' . $list['page_id'] . '" value="' . $list['page_id'] . '" onClick="return cxCheck(\'' . $list['page_id'] . '\')" ' . $checked . '>' . "\n";
	echo '</td>' . "\n";
	echo '<td width="75%" style="border-left:0px">';
	echo '<p class="list-check-p"><image src="./images/' . $icon . '" alt="' . $icon_alt . '" class="cms8341-verticalMiddle">';
	echo '&nbsp;<strong><a href="javascript:" onClick="return cxPreview(\'_form\',\'' . $list['page_id'] . '\',\'' . $tbl . '\');">' . htmlDisplay($list['page_title']) . '</a></strong></p>';
	echo '<p class="list-check-p"><small>公開期間：' . dtFormat($list['publish_start']) . 'から' . get_publish_end_date($list['publish_end']) . 'まで</small></p>';
	echo '</td>' . "\n";
	echo '<td width="20%">' . "\n";
	echo '<p style="margin:3px"><a href="javascript:" onClick="return cxHistory(\'' . $list['page_id'] . '\')"><image src="./images/btn_history.jpg" alt="出力履歴を見る" width="150" height="20" border="0"></a></p>' . "\n";
	echo '<p style="margin:3px"><a href="javascript:" onClick="return cxMove(\'' . $list['page_id'] . '\')"><image src="./images/btn_target.jpg" alt="対象リストへ移動" width="150" height="20" border="0"></a></p>' . "\n";
	echo '</td>' . "\n";
	echo '</tr>' . "\n";
}
?>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$outputFunc->objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$outputFunc->objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$outputFunc->objP->getNextLink()?></td>
	</tr>
</table>
</form>

<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:"
	onClick="return cxOutputSetting()"><img src="images/btn_output.jpg"
	alt="出力する" width="150" height="20" border="0"
	style="margin-right: 20px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!-- ** 出力グループ名設定レイヤー　ここから *************************************** -->
<form name="output_form" class="cms8341-form" id="output_form"
	method="post" action="output_exec.php"><input type="hidden"
	id="cms_output_id" name="cms_output_id" value="<?=$output_id?>">
<div id="cms8341-request" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="./images/title_output.jpg" alt="出力グループ名設定" width="200"
					height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxOutputClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 370px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="440" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable"
			style="border-collapse: collapse; border: solid 1px #CCCCCC;">
			<tr>
				<th width="110" align="left" valign="top" nowrap scope="row"><label
					for="cms_group_name">出力グループ名<br>
				<span class="cms_require">（必須）</span></label></th>
				<td align="left" valign="middle"><input type="text"
					name="group_name" id="group_name" style="width: 300px;"></td>
			</tr>
			<tr>
				<th width="110" align="left" valign="top" nowrap scope="row"><label
					for="note">備考</label></th>
				<td align="left" valign="top"><textarea name="note" rows="5"
					id="note" style="width: 300px;"></textarea></td>
			</tr>
			<tr>
				<th width="110" align="left" valign="top" nowrap scope="row"><label
					for="note">選択ページ</label></th>
				<td align="left" valign="top">
				<p><a href="javascript:" onClick="return cxOutputSortOrder()"><img
					src="./images/btn_output_sort_order.jpg" alt="出力順変更" border="0"></a></p>
				<div style="overflow: scroll; height: 180px;" id="request_page_list"></div>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<p align="center" style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxOutput()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
</form>
<!-- ** 出力グループ名設定レイヤー　ここまで *************************************** -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>
