<?php
/*
 *
 */
/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");
require ("./include/outputFunc.inc");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_history.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');

$outputFunc = new outputFunc(OUTPUT_HISTORY_PREV);
$objOpHty = new tbl_output_history($objCnc);
$objPage = new tbl_page($objCnc);
// パラメータチェック
if (!isset($_POST['cms_output_id']) || $_POST['cms_output_id'] == "") {
	$outputFunc->error("不正なパラメータです。");
}
if (!isset($_POST['cms_page_id']) || $_POST['cms_page_id'] == "") {
	$outputFunc->error("不正なパラメータです。");
}
$output_id = $_POST['cms_output_id'];
$page_id = $_POST['cms_page_id'];

$history_hndl_ary = getOutputHistoryFromPageId($page_id);
$objPage->selectFromID($page_id);
$op_fld = getOutput($output_id);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>データ管理／出力履歴</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="./output.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">

<div id="cms8341-property" style="font-size: 14px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="100%" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle">
				<div align="left"><img src="./images/title_history.jpg" alt="出力履歴"
					width="200" height="20" style="margin: 4px 10px;"></div>
				</td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="cxIframeLayerCallback(); return false;"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 95%; height: 475px; overflow: scroll; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="95%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable"
			style="border-collapse: collapse; border: solid 1px #CCCCCC; border-top: none">
						<?php
						echo '<tr><th>' . htmlDisplay($op_fld['name']) . "履歴リスト" . '</th></tr>' . "\n";
						if (count($history_hndl_ary) == 0) {
							echo '<tr>' . "\n";
							echo '<td align="center" valign="middle" width="5%">対象の履歴はありません。</td>' . "\n";
							echo '</tr>' . "\n";
						}
						for($i = count($history_hndl_ary) - 1; $i >= 0; $i--) {
							$history_hndl_fld = $history_hndl_ary[$i];
							if ($objOpHty->selectFromID($history_hndl_fld['history_id']) === FALSE) continue;
							$history_fld = $objOpHty->fld;
							echo '<tr align="left">' . "\n";
							echo '<td>' . "\n";
							echo '<p class="list-p"><strong>' . htmlDisplay($history_fld['name']) . '</strong></p>';
							echo '<p class="list-p"><small>出力日 ' . dtFormat($history_fld['output_datetime'], "Y年m月d日 H時i分s秒") . '</small></p>';
							if (trim($history_fld['note']) != "") {
								echo '<p class="cms8341-notearea-detail">' . htmlDisplay($history_fld['note']) . '</p>';
							}
							echo '</td>' . "\n";
							echo '</tr>' . "\n";
						}
						?>	
						</table>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
</body>
</html>

