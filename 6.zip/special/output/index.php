<?php
/*
 * 外部出力機能　初期表示画面
 */
/** require **/
require ("../.htsetting");
require ("./include/outputFunc.inc");
global $objCnc;
global $objLogin;
unset($_SESSION['output']);
$outputFunc = new outputFunc(DISP_INDEX);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output.inc');
$objOp = new tbl_output($objCnc);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部連携データ管理リスト</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<link rel="stylesheet" href="./output.css" type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(bv,output_id) {
	switch(bv) {
		// 名称クリック
		case 1:
			$('output_id').value = output_id;
			$('behavior').value = <?=OUTPUT_INF?>;
			$('output_form').action = 'confirm.php';
			break;
		// データ管理
		case 2:
			$('output_id').value = output_id;
			$('behavior').value = <?=OUTPUT_INF?>;
			$('output_form').action = 'target_list.php';
			break;
		// ダウンロード
		case 3:
			$('output_id').value = output_id;
			$('output_form').action = 'output_download.php';
			break;
		default:
			alert('パラメータエラー（behavior）');
			return false;
	}
	$('output_form').submit();
	return false;
}
//小窓表示
function showWindow(id){
	var Open_URL = "./output_page_list.php?output_id=" + id;
	var Open_Title = "対象ページリスト";
	var Open_Status = 'width=500,height=500,status=no,menubar=no,toolbar=no,scrollbars=no,resizable=no';
	cxIframeLayer(
		Open_URL,
		500,
		500,
		COVER_SETTING.COLOR,
		'',
		undefined,
		false
	);
	return false;
}

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'output';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="./images/bar_output_index.jpg" alt="外部連携データ管理リスト"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<?php
//手動
$where_ary[OUTPUT_KIND_MANUAL] = $objOp->_addslashesC('output_kind', OUTPUT_KIND_MANUAL, '=', 'INT');
//自動
$where_ary[OUTPUT_KIND_AUTO] = $objOp->_addslashesC('output_kind', OUTPUT_KIND_AUTO, '=', 'INT');
foreach ($where_ary as $output_kind => $where) {
	echo '<div class="cms8341-output-area">' . ($output_kind == OUTPUT_KIND_MANUAL ? '手動出力' : '自動出力') . '</div>' . "\n";
	echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . "\n";
	echo '<tr><th align="center">データ管理名称</th><th align="center">出力情報</th></tr>' . "\n";
	$objOp->select($where);
	if ($objOp->getRowCount() == 0) {
		echo '<tr><td colspan="2">現在登録されている外部出力はありません。</td></tr>' . "\n";
	}
	while ($objOp->fetch()) {
		$output_id = $objOp->fld['output_id'];
		$outputFld = $objOp->fld;
		if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
			$isFind = FALSE;
			$op_hndl_ary = getOutputTemplateFromDeptCode($objLogin->get('dept_code'));
			foreach ($op_hndl_ary as $op_hndl_fld) {
				if ($outputFld['output_id'] == $op_hndl_fld['output_id']) $isFind = true;
			}
			if ($isFind === FALSE) continue;
		}
		echo '<tr>' . "\n";
		echo '<td align="left" valign="top" width="65%">' . "\n";
		echo '<p class="list-p"><a href="javascript:" onClick="return cxSubmit(1,\'' . $outputFld['output_id'] . '\');">' . htmlDisplay($outputFld['name']) . '</a></p>' . "\n";
		echo '</td>' . "\n";
		echo '<td align="center" valign="top">' . "\n";
		//手動->データ管理　自動->ダウンロード
		if ($output_kind == OUTPUT_KIND_MANUAL) {
			echo '<p class="list-p"><a href="javascript:" onClick="return cxSubmit(2,\'' . $outputFld['output_id'] . '\');"><img src="./images/btn_data.jpg" alt="データ管理" width="120" height="20" border="0"></a></p>' . "\n";
		}
		else {
			echo '<p class="list-p"><a href="javascript:" onClick="return cxSubmit(3,\'' . $outputFld['output_id'] . '\');"><img src="./images/btn_download.jpg" alt="ダウンロード" width="120" height="20" border="0"></a>';
			echo '&nbsp;<a href="javascript:" onClick="return showWindow(\'' . $outputFld['output_id'] . '\');"><img src="./images/btn_list.jpg" alt="対象ページリスト" width="120" height="20" border="0"></a></p>' . "\n";
		}
		echo '</td>' . "\n";
		echo '</tr>' . "\n";
	}
	echo '</table>' . "\n";
}
?>
</table>
<form id="output_form" class="cms8341-form" name="output_form"
	method="post" action=""><input type="hidden" name="behavior"
	id="behavior" value=""> <input type="hidden" name="output_id"
	id="output_id" value=""></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
