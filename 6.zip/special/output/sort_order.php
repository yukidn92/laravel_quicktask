<?php
/*
 *
 */
/** require **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
global $objCnc;

foreach ($_POST as $key => $value) {
	if (!preg_match('/^cms_sort_order_/i', $key)) continue;
	$page_id = str_replace("cms_sort_order_", "", $key);
	setOutputPageFromSession($page_id, "sort_order", $value);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>出力順変更</title>
<base target="_self">
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<style type="text/css">
#cms8341-sortorderarea {
	width: 485px;
	height: 565px;
	overflow: scroll;
	margin: 10px 0px;
	background-color: #FFFFFF;
	padding: 9px 19px 0px 19px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
// 更新ボタン
function cxUpdate() {
	if(!cxInputCheck()) return false;
	$('cms_close_flg').value = 0;
	$('_form').submit();
	return false;
}
// 決定ボタン
function cxSubmit() {
	if(!cxInputCheck()) return false;
	$('cms_close_flg').value = 1;
	$('_form').submit();
	return false;
}
// 入力チェック
function cxInputCheck(){
	var err_msg = "";
	var elems = Form.getInputs('_form', 'text');
	elems.each( 
		function(val,idx) { 
			if(!cxDateNumeric(val.value)){
				err_msg += "数字以外の値が入っています。【"+val.value+"】\n"
			} 
		} 
	);	 
	if(err_msg != ""){
		alert(err_msg);
		return false;
	}
	return true;
}
<?php
// 決定ボタンが押された場合ウィンドウを閉じる処理
if (isset($_POST['cms_close_flg']) && $_POST['cms_close_flg'] == FLAG_ON) {
	echo 'var retObj = new Object();' . "\n";
	echo 'cxIframeLayerCallback(retObj);' . "\n";
}
?>

//-->
</script>
</head>

<body id="cms8341-mainbg">
<table width="542" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="542" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="542" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/special/output/images/title_sort_order.jpg"
					alt="出力順変更" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="#"
					id="header_close" onclick="cxIframeLayerCallback()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<form name="_form" id="_form" action="" method="post"><input
			type="hidden" id="cms_close_flg" name="cms_close_flg" value="0">
		<div id="cms8341-sortorderarea">
		<p id="cms_title"></p>
		<table width="100%" border="0" cellpadding="5" cellspacing="0"
			class="cms8341-dataTable">
			<tr>
				<th width="10%">表示順</th>
				<th>ページタイトル</th>
			</tr>
<?php
$objPage = new tbl_page($objCnc);
$history_id = "";
foreach ($_SESSION['output']['check'] as $key => $value) {
	$key_page_id[$key] = $value["page_id"];
	$key_publish_date[$key] = $value["publish_start"];
	$key_sort_order[$key] = $value["sort_order"];
}
array_multisort($key_sort_order, SORT_ASC, $key_publish_date, SORT_DESC, $key_page_id, SORT_DESC, $_SESSION['output']['check']);

foreach ($_SESSION['output']['check'] as $ary) {
	
	$objPage->selectFromID($ary["page_id"]);
	echo '<tr>' . "\n";
	echo '<td align="center" valign="middle"><input type="text" id="cms_sort_order_' . $ary["page_id"] . '" name="cms_sort_order_' . $ary["page_id"] . '" value="' . $ary["sort_order"] . '" size="2" maxlength="3" style="ime-mode:disabled;"></td>' . "\n";
	echo '<td align="left" valign="top">' . htmlDisplay($objPage->fld['page_title']) . '</td>' . "\n";
	echo '</tr>' . "\n";
}
?>	
	</table>

		<p align="center"><a href="javascript:" onClick="return cxUpdate()"><img
			src="./images/btn_update.jpg" alt="更新" width="100" height="20"
			border="0" style="margin-left: 10px"></a> <a href="javascript:"
			onClick="return cxSubmit()"><img src="./images/btn_submit.jpg"
			alt="決定" width="100" height="20" border="0"
			style="margin-right: 10px"></a></p>
		</div>
		</form>

</body>
</html>
