/*
 *
 */
function cxMoveList(disp) {
	switch (disp) {
	case "target_list":
		$('cms_fSearch').action = "target_list.php";
		break;
	case "output_list":
		$('cms_fSearch').action = "output_list.php";
		break;
	case "history_list":
		$('cms_fSearch').action = "history_list.php";
		break;
	case "hidden_list":
		$('cms_fSearch').action = "hidden_list.php";
		break;
	}
	$('cms_fSearch').submit();
	return false;
}

function cxCheckAll() {
	var alElem = document['_form']['page_id[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
			cxCheck(alElem.value);
			// some checkboxes
		} else {
			for ( var i = 0; i < alElem.length; i++) {
				alElem[i].checked = true;
				cxCheck(alElem[i].value);
			}
		}
	}
}
function cxReleaseAll() {
	var alElem = document['_form']['page_id[]'];
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
			cxCheck(alElem.value);
			// some checkboxes
		} else {
			for ( var i = 0; i < alElem.length; i++) {
				alElem[i].checked = false;
				cxCheck(alElem[i].value);
			}
		}
	}
}

var cate_id;
function cxChangeCate(level, id, code) {
	cate_id = id;
	var prm = 'level=' + level + '&code=' + code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);

}
function cxGetCateComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Categories') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 4; i++) {
        var cmb = $(cate_id + i);
        while (cmb.length > 1) {
            cmb.options[1] = null;
        }
    }
    var cmb = $(cate_id + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        cmb.length++;
        cmb.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        cmb.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
// 組織変更プルダウン処理
function cxChangeDept(lv, val) {
	//reset
	if (val == "") {
		var t = lv + 1;
		for ( var i = t; i <= 3; i++) {
			var obj = $('dept' + i);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level=' + lv + '&code=' + val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 3; i++) {
        var obj = $('dept' + i);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        if (i == level) {
            obj.options[0].text = "指定なし";
        } else {
            obj.options[0].text = "";
        }
    }
    var obj = $('dept' + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i = 0; i < xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i + 1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i + 1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
// page sending
function cxPageSet(page_no) {
	$('dispMode').value = "move";
	$('page_no').value = page_no;
	document.cms_fSearch.submit();
	return false;
}

function cxSearch() {
	if ($('pdsy')) {
		if (!($F('pdsy') == "" && $F('pdsm') == "" && $F('pdsd') == "")) {
			dc = cxDateCheckNew("pd", "ymd", 2, "公開開始日");
			if (!disp_date_error(dc, "pdsd"))
				return false;
		}
		if (!($F('pdey') == "" && $F('pdem') == "" && $F('pded') == "")) {
			dc = cxDateCheckNew("pd", "ymd", 3, "公開開始日");
			if (!disp_date_error(dc, "pded"))
				return false;
		}
		if ($F('pdsy') != "" && $F('pdsm') != "" && $F('pdsd') != ""
				&& $F('pdey') != "" && $F('pdem') != "" && $F('pded') != "") {
			dc = cxDateCheckNew("pd", "ymd", 1, "公開開始日");
			if (!disp_date_error(dc, "pdsd"))
				return false;
		}
	}
	if ($('odsy')) {
		if (!($F('odsy') == "" && $F('odsm') == "" && $F('odsd') == "")) {
			dc = cxDateCheckNew("od", "ymd", 2, "公開開始日");
			if (!disp_date_error(dc, "odsd"))
				return false;
		}
		if (!($F('odey') == "" && $F('odem') == "" && $F('oded') == "")) {
			dc = cxDateCheckNew("od", "ymd", 3, "公開開始日");
			if (!disp_date_error(dc, "oded"))
				return false;
		}
		if ($F('odsy') != "" && $F('odsm') != "" && $F('odsd') != ""
				&& $F('odey') != "" && $F('odem') != "" && $F('oded') != "") {
			dc = cxDateCheckNew("od", "ymd", 1, "公開開始日");
			if (!disp_date_error(dc, "odsd"))
				return false;
		}
	}
	$('dispMode').value = "search";
	document.cms_fSearch.submit();
	return false;
}
function cxLastSearch() {
	$('dispMode').value = "last_condition";
	document.cms_fSearch.submit();
	return false;
}

function cxDispNum(max_val) {
	$('dispMode').value = "change_num";
	document.cms_fSearch.submit();
	return false;
}

function cxCheck(page_id) {
	if ($('page_id_' + page_id).checked) {
		checked = 1;
	} else {
		checked = 0;
	}
	var prm = 'page_id=' + page_id + '&checked=' + checked;
	cxAjaxCommand('cxOutputCheck', prm, cxCheckSuccess);
}

function cxCheckSuccess(r) {
}

function cxHistory(page_id) {
	if (cms_prev_layer)
		cms_prev_layer.style.display = 'none';

	cxIframeLayer(cms8341admin_path + '/special/output/history.php', 600, 550, COVER_SETTING.COLOR, '_new');
	$('_form').target = '_new';
	$('_form').action = cms8341admin_path + '/special/output/history.php';
	$('_form').cms_page_id.value = page_id;
	$('_form').submit();
	return false;
}

// 表示順変更画面表示
function cxOutputSortOrder() {
	if (output_action == 1) {
		alert('表示順を変更することはできません。再度ページを選択して出力してください。');
		return false;
	}
	cxIframeLayer(
		cms8341admin_path + '/special/output/sort_order.php',
		560,
		520,
		COVER_SETTING.COLOR,
		'',
		function (retObj) {
			if (retObj) {
				prm = "";
				$('request_page_list').innerHTML = "";
				cxAjaxCommand('cxGetOutputRequestPageList', prm,
						cxGetOutputSettingSuccess);
			}
		}
	);
}
