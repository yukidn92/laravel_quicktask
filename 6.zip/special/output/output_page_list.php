<?php
/*
 *
 */
//設定ファイル
require ("../.htsetting");
global $objCnc;
//db
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

//ログイン情報
$login = $objLogin->login;

// エラー出力を別ウィンドウ用に設定
gd_errorhandler_ini_set("template_user_error", "template_user_error_win");
gd_errorhandler_ini_set("template_system_error", "template_system_error_win");

//変数初期化
$output_id = '';
$disp = '10';
$page_no = '1';

//post
if (isset($_GET['output_id'])) $output_id = $_GET['output_id'];
else if (isset($_POST['output_id'])) $output_id = $_POST['output_id'];

if (isset($_POST['disp_num'])) $disp = $_POST['disp_num'];
if (isset($_POST['page_no'])) $page_no = $_POST['page_no'];

//連携データ情報
$output_dat_ary = getOutput($output_id);
$output_tpl_ary = getOutputTemplate($output_id);

//html
$html_str = '';

//SQL作成
$fld = 'p.*';
$table = 'tbl_publish_page AS p INNER JOIN tbl_user AS u ON (p.user_id = u.user_id)';
$where = $objPage->_addslashesC('p.template_id', implode(',', $output_tpl_ary), 'IN');
$where .= ' AND ' . $objPage->_addslashesC('p.work_class', WORK_CLASS_PUBLISH . ',' . WORK_CLASS_DELETE, 'IN');
$where .= ' AND ' . $objPage->_addslashesC('p.close_flg', FLAG_OFF, '=', 'INT');

if ($output_dat_ary['page_output_flg'] == FLAG_ON) {
	$table .= ' INNER JOIN tbl_output_handler AS oh ON (p.page_id = oh.item2)';
	$where .= ' AND ' . $objPage->_addslashesC('oh.class', HANDLER_OUTPUT_CLASS_PUBLISH_PAGE, '=');
	$where .= ' AND ' . $objPage->_addslashesC('oh.item1', $output_id, '=', 'INT');
}
$where .= " AND " . createNotDisasterPagesOnlySql('p');

$orderby = '';
$objPage->select($where, $fld, "", "", "", $table);
$cnt = $objPage->getRowCount();
$objPage->objP = new page_control();
$objPage->objP->limit = $disp;
$objPage->objP->set($page_no, $cnt);
$offset = $objPage->objP->getOffset();
$limit = $objPage->objP->getLimit();
$objPage->select($where, $fld, $orderby, $offset, $limit, $table);

while ($objPage->fetch()) {
	//ページ情報
	$fld = $objPage->fld;
	//プレビューモード
	$p_mode = 1;
	
	$html_str .= '<tr>' . "\n";
	$html_str .= '<td style="padding:5px;layout-grid-line:9px;"><strong><a href="javascript:" onClick="return cxPreview(\'cms_CPreview\',\'' . $objPage->fld['page_id'] . '\',\'' . $p_mode . '\');">' . htmlDisplay($objPage->fld['page_title']) . '</strong></a>&nbsp;(' . $objPage->fld['page_id'] . ')' . "\n";
	$html_str .= '<br>ファイルパス：' . htmlDisplay($objPage->fld['file_path']) . "\n";
	$html_str .= '</tr>';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>対象ページリスト</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="./output.js" type="text/javascript"></script>
<style type="text/css">
<!--
#cms8341-listarea {
	width: 480px;
	height: 450px;
	overflow: auto;
	margin: 10px 0px;
	background-color: #FFFFFF;
	padding: 0px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}
-->
</style>
</head>
<body>
<form id="cms_CPreview" name="cms_CPreview" class="cms8341-form"
	method="post" action="preview.php" target="_new"><input type="hidden"
	id="cms_dispMode" name="cms_dispMode" value="2"> <input type="hidden"
	id="cms_page_id" name="cms_page_id" value=""></form>
<form name="cms_fSearch" id="cms_fSearch" class="cms8341-form"
	method="post" action="output_page_list.php"><input type="hidden"
	name="dispMode" id="dispMode" value=""> <input type="hidden"
	id="page_no" name="page_no" value=""> <input type="hidden"
	id="output_id" name="output_id" value="<?=$output_id?>">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="./images/title_page_list.jpg" alt="対象ページリスト" width="200"
					height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="cxIframeLayerCallback(); return false;"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div id="cms8341-listarea">
			<?php
			if ($html_str == "") {
				?>
				<table width="95%" align="center" border="0" cellpadding="0"
			cellspacing="0" class="cms8341-dataTable"
			style="margin: 10px; font-size: 12px;">
			<tr>
				<td style="padding: 5px; layout-grid-line: 9px;">該当するページはありません。</td>
			</tr>
		</table>
			<?php
			}
			else {
				?>
			<table width="100%" border="0" cellspacing="0" cellpadding="5"
			style="margin-bottom: 10px;">
			<tr valign="top">
				<td colspan="3" align="right">
						<?=mkcombobox($MAXROW_LIST, "disp_num", $disp, "cxDispNum(this.value)")?>
					</td>
			</tr>
			<tr>
				<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->objP->getBackLink()?></td>
				<td width="40%" align="center" valign="middle"><?=$objPage->objP->getViewCount()?></td>
				<td width="30%" align="right" valign="middle"><?=$objPage->objP->getNextLink()?></td>
			</tr>
		</table>
		<table width="95%" align="center" border="0" cellpadding="0"
			cellspacing="0" class="cms8341-dataTable"
			style="margin: 10px; font-size: 12px;">
			<?=$html_str?>
			</table>
		<table width="100%" border="0" cellspacing="0" cellpadding="5"
			style="margin-top: 10px;">
			<tr>
				<td width="30%" align="left" valign="middle" scope="row"><?=$objPage->objP->getBackLink()?></td>
				<td width="40%" align="center" valign="middle"><?=$objPage->objP->getViewCount()?></td>
				<td width="30%" align="right" valign="middle"><?=$objPage->objP->getNextLink()?></td>
			</tr>
		</table>
			<?php
			}
			?>
			</div>
		</td>
	</tr>
</table>
</form>
</body>
</html>