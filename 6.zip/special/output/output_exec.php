<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../.htsetting");
require ("./include/outputFunc.inc");
global $objCnc;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output.inc');
$objOutput = new tbl_output($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOutHandler = new tbl_output_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_history.inc');
$objOutHistory = new tbl_output_history($objCnc);

$outputFunc = new outputFunc(OUTPUT_PAGE);

$page_id_ary = array();
$file_data_ary = array();

//SESSION値の取得
//	$page_id_ary = $_SESSION['output']['check'];
$page_id_ary = getOutputPageListFromSession();
$search_info = $_SESSION['output']['search'];
//POST値取得
$output_upd_flg = (isset($_POST['cms_output_mode']) && $_POST['cms_output_mode'] == 'rewrite') ? FALSE : TRUE;

//ページIDエラーチェック
if (count($page_id_ary) < 1) {
	$outputFunc->error("不正なパラメータです。");
}
//output_idエラーチェック
if (!isset($search_info['output_id']) || $search_info['output_id'] == "") {
	$outputFunc->error("不正なパラメータです。");
}

//「tbl_output_history」登録用配列
$tbl_output_history = array(
		"history_id" => "", 
		"name" => (isset($_POST['group_name']) ? trim($_POST['group_name']) : ""), 
		"output_datetime" => "", 
		"note" => (isset($_POST['note']) ? trim($_POST['note']) : " "), 
		"output_id" => (isset($_POST['cms_output_id']) ? $_POST['cms_output_id'] : "")
);

if ($tbl_output_history["name"] == "" || $tbl_output_history["output_id"] == "") {
	$outputFunc->error("不正なパラメータです。");
}

//出力フォーマット情報取得
$objOutput->selectFromID($search_info['output_id']);
if ($objOutput->getRowCount() < 1) {
	$outputFunc->error("出力フォーマット情報の取得に失敗しました。");
}
$output_info = $objOutput->fld;
//フォーマットファイル名
$format_file_name = $output_info['output_id'] . '.' . $output_info['extension'];

$date = date("YmdHis");
$file_path = $objLogin->login['user_id'] . '/output';

//DB登録
$objCnc->begin();

//tbl_output_historyへの出力情報登録
$history_id = $objOutHistory->getNextID("history_id");
$tbl_output_history['history_id'] = $history_id;
$tbl_output_history['output_datetime'] = date("Y-m-d H:i:s");
$tbl_output_history['disp_flg'] = FLAG_ON;
if ($objOutHistory->insert($tbl_output_history) === FALSE) {
	$objCnc->rollback();
	$outputFunc->error("DB登録に失敗しました。【tbl_output_history】");
}

//tbl_output_handlerへの出力情報登録
foreach ((array) $page_id_ary as $page_id) {
	//テンプレート取得
	$template_ary = getOutputTemplate($search_info['output_id']);
	//ページ情報取得
	if (!$objPage->selectFromID($page_id)) {
		$objCnc->rollback();
		$outputFunc->error("ページ情報の取得に失敗しました。【ページID:" . $page_id . "】");
	}
	if ($objPage->fld['status'] != STATUS_PUBLISH) {
		if (!$objPage->selectFromID($page_id, WORK_TABLE)) {
			$objCnc->rollback();
			$outputFunc->error("ページ情報の取得に失敗しました。【ページID:" . $page_id . "】");
		}
	}
	//登録されていないテンプレート
	if (!in_array($objPage->fld['template_id'], $template_ary)) {
		continue;
	}
	
	$ary = array();
	$ary['class'] = HANDLER_OUTPUT_CLASS_HISTORY;
	$ary['item1'] = $search_info['output_id'];
	$ary['item2'] = $history_id;
	$ary['item3'] = $page_id;
	$ary['item4'] = $objPage->fld['page_title'];
	$ary['item5'] = getOutputPageFromSession($page_id, "sort_order");
	if ($objOutHandler->insert($ary) === FALSE) {
		$objCnc->rollback();
		$outputFunc->error("DB登録に失敗しました。【tbl_output_handler】");
	}
}
//再出力の場合はステータスを変えない
if ($output_upd_flg) {
	//tbl_output_handlerの出力リストステータスになっている情報を出力対象ステータスに変更する
	$outputFunc->entryData($search_info['output_id'], $page_id_ary, OUTPUT_MODE_TARGET);
}

//出力文字列取得
$msg = "";
$out_put_str = get_output_str($msg, $output_info['output_id'], $file_data_ary, $page_id_ary);
//エラー
if ($msg != "") {
	$objCnc->rollback();
	$outputFunc->error($msg);
}

//作成しようとしているフォルダの初期化
$tmp_path = DOCUMENT_ROOT . DIR_PATH_TEMP . $file_path;
removeDir($tmp_path);

if (!mkNewDirectory($tmp_path . '/dammy.txt')) {
	$objCnc->rollback();
	$outputFunc->error("フォルダの作成に失敗しました。");
}

//連携ファイル出力
//文字コード取得
$code = mb_detect_encoding($out_put_str);
//文字コード変換
$out_put_str = mb_convert_encoding($out_put_str, $output_info['encode'], $code);
$fp = fopen($tmp_path . '/' . $format_file_name, "w", 0777);
fwrite($fp, $out_put_str);
fclose($fp);

//ファイルコピー
foreach ((array) $file_data_ary as $file_data) {
	if (@file_exists(DOCUMENT_ROOT . RPW . $file_data)) {
		if (!mkNewDirectory($tmp_path . '/' . $file_data)) {
			$objCnc->rollback();
			$outputFunc->error("フォルダ作成に失敗しました。");
		}
		// コピー先ファイルの削除
		if (@file_exists($tmp_path . '/' . $file_data)) {
			if (@unlink($tmp_path . '/' . $file_data)) {
				$objCnc->rollback();
				$outputFunc->error("既に存在するファイルの削除に失敗しました。");
			}
		}
		// コピー
		if (!@copy(DOCUMENT_ROOT . RPW . $file_data, $tmp_path . '/' . $file_data)) {
			$objCnc->rollback();
			$outputFunc->error("ファイルのコピーに失敗しました。");
		}
	}
}

$zip_path = DOCUMENT_ROOT . DIR_PATH_TEMP . $file_path . '/' . $date . ".zip";
//Zipの作成に失敗
if (!create_Zip($tmp_path, $zip_path)) {
	$objCnc->rollback();
	$outputFunc->error("Zipファイルの作成に失敗しました。【" . $tmp_path . "】");
} //Zipの作成に成功
else if (@file_exists($zip_path)) {
	if (($fp = @fopen($zip_path, 'rb')) === FALSE) {
		$objCnc->rollback();
		$outputFunc->error("Zipファイルの読み込みに失敗しました。【" . $zip_path . "】");
	}
	else {
		//ヘッダ出力
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename=" . basename($zip_path));
		header('Content-Length: ' . @filesize($zip_path));
		while ($zip_data = @fread($fp, 4096)) {
			print($zip_data);
		}
	}
	if ($fp) @fclose($fp);
}

$objCnc->commit();
unset($_SESSION['output']);

//プログラム終了
exit();

/**
 * Zip圧縮を行う
 *
 * @param $folder_path 圧縮対象フォルダパス
 * @param $zip_path 圧縮後Zipパス
 * @return 作成に成功した場合は、TRUE。そうでない場合は、FALSEを返す。
 */
function create_Zip($folder_path, $zip_path) {
	//引数のチェック
	if ($folder_path == "" || $zip_path == "") return FALSE;
	//フォルダの存在チェック
	if (!@file_exists($folder_path)) return TRUE;
	
	//実際に圧縮する
	if (defined("SET_ZIP_EXE")) {
		exec('cd ' . $folder_path . ' & ' . SET_ZIP_EXE . ' -r ' . $zip_path . ' *');
	}
	else {
		exec('cd ' . $folder_path . '; zip -r ' . $zip_path . ' *');
	}
	
	//Zipファイルの存在チェック
	if (!@file_exists($zip_path)) return FALSE;
	return TRUE;
}
?>
