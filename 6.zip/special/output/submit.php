<?php
/*
 * 広告掲載機能　広告エリア設定完了画面
 */
/** require **/
require ("../.htsetting");
require ("./include/outputFunc.inc");
$outputFunc = new outputFunc(DISP_SUBMIT);
if (!isset($_POST['behavior']) || !in_array($_POST['behavior'], array(
		OUTPUT_ADD, 
		OUTPUT_UPD, 
		OUTPUT_DEL
))) {
	$outputFunc->error("不正なパラメータです。");
}
//セッションを取得できなかったら一覧ページに移動
if (!isset($_SESSION["hidden"])) {
	header("Location: " . HTTP_ROOT . RPW . "/admin/special/output/index.php");
	exit();
}
$dat = $_SESSION["hidden"];
unset($_SESSION["hidden"]);
$msg = "";
$outputFunc->checkOutput($dat, $_POST['behavior']);
//フォーマットを更新したかどうか。
if (isset($dat['file_update']) && $dat['file_update']) $file_copy_flg = TRUE;
else $file_copy_flg = FALSE;
unset($dat['file_update']);
$objCnc->begin();

switch ($_POST['behavior']) {
	// 追加
	case OUTPUT_ADD :
		$dat = insertOutput($dat, $msg);
		if ($dat === FALSE) $outputFunc->error($msg);
		if ($file_copy_flg) $outputFunc->format_file_copy($dat);
		//公開側アップロード
		if (!upload_output_file($msg, $dat['output_id'])) $outputFunc->error($msg);
		break;
	// 修正
	case OUTPUT_UPD :
		//更新前の連携データを保持
		$old_dat = getOutput($dat['output_id']);
		//更新
		$dat = updateOutput($dat, $msg);
		if ($dat === FALSE) $outputFunc->error($msg);
		if ($file_copy_flg) $outputFunc->format_file_copy($dat);
		//公開側、アップロード
		if (!upload_output_file($msg, $dat['output_id'])) $outputFunc->error($msg);
		//ファイルパスが変更されていた場合前のファイルを削除
		if ($old_dat['output_path'] != $dat['output_path']) {
			if (!delete_output_file($msg, $old_dat)) $outputFunc->error($msg);
		}
		break;
	// 削除
	case OUTPUT_DEL :
		$dat = getOutput($dat['output_id']);
		if (deleteOutput($dat['output_id'], $msg) === FALSE) $outputFunc->error($msg);
		//ファイル削除
		if (!delete_output_file($msg, $dat)) $outputFunc->error($msg);
		break;
}
$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部連携データ設定完了</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'output';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="./images/bar_output_submit.jpg" alt="外部連携データ設定完了"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<p align="center">処理が完了しました。</p>
<p align="center"><a href="index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-right: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
