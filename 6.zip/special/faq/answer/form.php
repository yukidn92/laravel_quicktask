<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

//	ステータス判定用フラグ
$status_flg = FLAG_OFF;

// ** URLよりID取得
if (!isset($_POST['cms_faq_id'])) {
	faqError("IDが存在しません");
}
$faq_id = $_POST['cms_faq_id'];

// 検索
if ($objFaq->selectFromID($faq_id) !== FALSE) {
	// DB内容取得
	$regist_datatime = $objFaq->fld['regist_datatime'];
	$cate_code = $objFaq->fld['cate_code'];
	$question_title = $objFaq->fld['question_title'];
	$question_context = $objFaq->fld['question_context'];
	$status = $objFaq->fld['status'];
	$answer_context = $objFaq->fld['answer_context'];
	$create_cls = $objFaq->fld['create_cls'];
	$charge = $objFaq->fld['charge'];
}
else {
	faqError("問い合わせが存在しません。削除された可能性があります。");
}

// ステータス判定
if ($status != FAQ_STATUS_NOT_READ && $status != FAQ_STATUS_END_ANSWER) {
	faqError("ステータスが不正です");
}
else if ($status == FAQ_STATUS_END_ANSWER && $answer_context != "") {
	if ($answer_context != "") {
		$status_flg = FLAG_ON;
	}
	else {
		faqError("回答取得エラーです");
	}

}

// ログインユーザーの組織コード
$myDeptCode = $objLogin->get('dept_code');

// ログインしている組織コードとFAQ情報の組織コードの比較
if ($charge != $myDeptCode) {
	faqError("この組織ではこのFAQに対して回答を行えません");
}

// FAQの作成方法が新規作成からだった場合エラー
if ($create_cls == FAQ_CREATE_CLASS_NEW_PAGE) {
	faqError("新規作成より作成されたページに対しての回答は行えません");
}

//	カテゴリ初期値設定
$cint = pow(10, (CODE_DIGIT_CATE * 3));
$cate_code_bak = $cate_code;
$cate_code = (int) $cate_code;
$cate_code1 = (int) ($cate_code / $cint);
$cate_code1 *= $cint;
$cate_code = $cate_code - $cate_code1;

$cint = pow(10, (CODE_DIGIT_CATE * 2));
$cate_code2 = (int) ($cate_code / $cint);
$cate_code2 *= $cint;
$cate_code = $cate_code - $cate_code2;
$cate_code2 = $cate_code1 + $cate_code2;

$cint = pow(10, CODE_DIGIT_CATE);
$cate_code3 = (int) ($cate_code / $cint);
$cate_code3 *= $cint;
$cate_code = $cate_code - $cate_code3;
$cate_code3 = $cate_code2 + $cate_code3;

$cate_code4 = $cate_code;
$cate_code4 = $cate_code3 + $cate_code4;

//桁数分０埋め
$cate_length = CODE_DIGIT_CATE * 4;
$cate_code1 = sprintf("%0" . $cate_length . "s", $cate_code1);
$cate_code2 = sprintf("%0" . $cate_length . "s", $cate_code2);
$cate_code3 = sprintf("%0" . $cate_length . "s", $cate_code3);
$cate_code4 = sprintf("%0" . $cate_length . "s", $cate_code4);

// 初期表示値
$def = array();
if (isset($_GET['bak']) && $_GET['bak'] == 1 && isset($_SESSION['post']) && is_array($_SESSION['post'])) {
	$def = $_SESSION['post'];
}
elseif (isset($_SESSION['post'])) {
	unset($_SESSION['post']);
}

if (!isset($def['cms_cate1'])) $def['cms_cate1'] = '';
if (!isset($def['cms_cate2'])) $def['cms_cate2'] = '';
if (!isset($def['cms_cate3'])) $def['cms_cate3'] = '';
if (!isset($def['cms_cate4'])) $def['cms_cate4'] = '';

$cateAry = array(
		1 => $cate_code1, 
		2 => $cate_code2, 
		3 => $cate_code3, 
		4 => $cate_code4
);
$combo_cate = "";
//	$combo_cate = cateListCreate($objDac, $objCate, $cateAry );


//	DB(publish)よりfaq_id検索
$where = $objPage->_addslashesC('faq_id', $faq_id);
$hit_cnt = $objPage->getCount($where, PUBLISH_TABLE);
if ($hit_cnt > 0) {
	//	カテゴリ内容取得
	$arr_cate = $objCate->getCategoryInfo($cate_code_bak, ' > ');
}

// DB内容取得
$strHTML = "";
$strHTML .= '	<div id="cms_search_html">' . PHP_EOL;
$strHTML .= '		<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-uploadlist">' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">質問タイトル</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($question_title) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">質問本文</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($question_context) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center" id="cms_cate">カテゴリ</th>' . PHP_EOL;
if ($hit_cnt > 0) {
	$strHTML .= '				<td>' . htmlDisplay($arr_cate['name']) . '</td>' . PHP_EOL;
	$strHTML .= '<input type="hidden" name="cms_cate1" id="cms_cate1" value="' . $cate_code1 . '">' . PHP_EOL;
	$strHTML .= '<input type="hidden" name="cms_cate2" id="cms_cate2" value="' . $cate_code2 . '">' . PHP_EOL;
	$strHTML .= '<input type="hidden" name="cms_cate3" id="cms_cate3" value="' . $cate_code3 . '">' . PHP_EOL;
	$strHTML .= '<input type="hidden" name="cms_cate4" id="cms_cate4" value="' . $cate_code4 . '">' . PHP_EOL;
}
else {
	$strHTML .= '				<td id="cms_cate_select_tr">' . $combo_cate . '</td>' . PHP_EOL;
}
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center" id="cms_user_tr">回答</th>' . PHP_EOL;
$strHTML .= '				<td><textarea name="cms_answer" rows="5" id="cms_answer" style="width:540px;">' . htmlspecialchars($answer_context) . '</textarea></td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '		</table>' . PHP_EOL;
$strHTML .= '	</div>' . PHP_EOL;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>問い合わせ回答</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

	function cxSubmit() {
		var info = new Array();
		if ( !$('cms_cate1') || ! $('cms_cate1').value ) {
			alert( "不正なカテゴリ設定です" );
		} else if(!$('cms_answer') || !$('cms_answer').value) {
			alert( "回答本文が入力されていません" );
		} else if (trim($('cms_answer').value) == "") {
		 	alert("回答本文に有効な文字が入力されていません。")
		} else {
			// -- アクセシビリティ
			info = fckCheck('回答',$('cms_answer').value,info);
			if ( ! info ) return false;
			if ( info.length > 0 ) {
				var msg = info.join('\n') + '\nよろしいですか？';
				if ( ! confirm( msg ) ) {
					return false;
				}
			}
			$('cms_answer_form').submit();
		}
		return false;	
	}

	function cxFormInit() {

		if ( $('cms_cate_select_tr') ) {
			var cms_cate_select_tr = "";
<?php
$innerHtml = explode("\n", cateListCreate($objDac, $objCate, $cateAry));
for($i = 0; $i < count($innerHtml); $i++) {
	?>
			cms_cate_select_tr += '<?=javaStringEscape($innerHtml[$i])?>'+"\n";
<?php
}
?>
			$('cms_cate_select_tr').innerHTML = cms_cate_select_tr;
		}
	
		return false;
	}
	
// 初期化
Event.observe(window,'load',cxFormInit,false);	

//-->
</script>
</head>


<body id="cms8341-mainbg">
<form name="cms_answer_form" id="cms_answer_form" method="post"
	action="confirm.php">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>

	<div align="center" id="cms8341-contents">
<div><img src="../images/bar_faq_answer.jpg" alt="問い合わせ回答" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
	
<?php
echo ($strHTML);
?>	
	
	<input type="hidden" id="cms_faq_id" name="cms_faq_id"
	value="<?=$faq_id?>">
<p align="center" style="margin-top: 20px;"><a href="javascript:"
	onClick="return cxSubmit()"><img src="../images/btn_conf.jpg" alt="確認"
	width="100" height="20" border="0" style="margin: 10px"></a> <a
	href="javascript:history.back();"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel.jpg" width="101" height="21"
	alt="キャンセル" border="0" style="margin: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
<?php
// ** アクセシビリティチェック用 ------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);

echo $objTool->setAccessibility();

function cateListCreate($objDac, $objCate, $cateAry) {
	
	$cate_code1 = (isset($cateAry[1])) ? $cateAry[1] : "";
	$cate_code2 = (isset($cateAry[2])) ? $cateAry[2] : "";
	$cate_code3 = (isset($cateAry[3])) ? $cateAry[3] : "";
	$cate_code4 = (isset($cateAry[4])) ? $cateAry[4] : "";
	
	// カテゴリプルダウン生成
	$combo_cate = '';
	$cate_s1 = '<select id="cms_cate1" name="cms_cate1" onChange="javascript:cxChangeCate(2, this.value)" style="width:120px;">' . "\n";
	$cate_s2 = '<select id="cms_cate2" name="cms_cate2" onChange="javascript:cxChangeCate(3, this.value)" style="width:120px;">' . "\n";
	$cate_s3 = '<select id="cms_cate3" name="cms_cate3" onChange="javascript:cxChangeCate(4, this.value)" style="width:120px;">' . "\n";
	$cate_s4 = '<select id="cms_cate4" name="cms_cate4" onChange="javascript:cxChangeCate(5, this.value)" style="width:120px;">' . "\n";
	$cate_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
	$cate_e = '</select>&nbsp;&nbsp;';
	$cate_op1 = $cate_opn;
	$cate_op2 = $cate_opn;
	$cate_op3 = $cate_opn;
	$cate_op4 = $cate_opn;
	// 第一カテゴリプルダウンの生成
	$sql = "SELECT level,cate_code,name FROM tbl_category WHERE level = 1 ORDER BY sort_order, cate_code";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$selected = ($objDac->fld['cate_code'] == $cate_code1) ? ' selected' : '';
		$cate_op1 .= '<option value="' . $objDac->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
	// 第二カテゴリプルダウンの生成（第一カテゴリが指定されている場合）
	if ($cate_code1 != '') {
		$objCate->selectChildren($cate_code1);
		while ($objCate->fetch()) {
			$selected = ($objCate->fld['cate_code'] == $cate_code2) ? ' selected' : '';
			$cate_op2 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
		}
	}
	// 第三カテゴリプルダウンの生成（第二カテゴリが指定されている場合）
	if ($cate_code2 != '') {
		$objCate->selectChildren($cate_code2);
		while ($objCate->fetch()) {
			$selected = ($objCate->fld['cate_code'] == $cate_code3) ? ' selected' : '';
			$cate_op3 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
		}
	}
	// 第四カテゴリプルダウンの生成（第三カテゴリが指定されている場合）
	if ($cate_code3 != '') {
		$objCate->selectChildren($cate_code3);
		while ($objCate->fetch()) {
			$selected = ($objCate->fld['cate_code'] == $cate_code4) ? ' selected' : '';
			$cate_op4 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
		}
	}
	$cate1 = $cate_s1 . $cate_op1 . $cate_e;
	$cate2 = $cate_s2 . $cate_op2 . $cate_e;
	$cate3 = $cate_s3 . $cate_op3 . $cate_e;
	$cate4 = $cate_s4 . $cate_op4 . $cate_e;
	$combo_cate = $cate1 . $cate2 . $cate3 . $cate4;
	
	return $combo_cate;
}
?>
