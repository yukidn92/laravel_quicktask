<?php
/*
 * FAQ機能：問い合わせ・回答確認画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

//定数の宣言
$FAQ_ANSWER_LABEL = getDefineArray("FAQ_ANSWER_LABEL");

// ID取得
if (!isset($_POST['cms_faq_id'])) {
	faqError("IDが存在しません");
}
$faq_id = $_POST['cms_faq_id'];

// DBデータ取得
if ($objFaq->selectFromID($faq_id) !== FALSE) {
	$question_title = $objFaq->fld['question_title'];
	$question_context = $objFaq->fld['question_context'];
	$answer_context = $objFaq->fld['answer_context'];
	$answer_datetime = $objFaq->fld['answer_datetime'];
	$status = $objFaq->fld['status'];
	$create_cls = $objFaq->fld['create_cls'];
	$charge = $objFaq->fld['charge'];
	
	$regist_datatime = $objFaq->fld['regist_datatime'];
	$publish_cls = $objFaq->fld['publish_cls'];
}
else {
	faqError("問い合わせが存在しません。削除された可能性があります。");
}

// ログインユーザーの組織コード
$myDeptCode = $objLogin->get('dept_code');

$template_cnt = 0;
if ($charge == $myDeptCode && $objLogin->get('class') != USER_CLASS_WEBMASTER) {
	$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN tbl_handler AS h ON (h.item2 = t.template_id)" . " WHERE h.class = " . HANDLER_CLASS_TEMPLATE . " AND h.item1 = '" . $objLogin->get('dept_code') . "'" . " AND t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND t.template_kind = '" . TEMPLATE_KIND_FIXED . "'" . " AND t.kanko_type = '" . KANKO_TYPE_FAQ . "'" . " ORDER BY t.sort_order,t.template_id";
	if ($objDac->execute($sql) !== FALSE) {
		$template_cnt = $objDac->getRowCount();
	}
}

$dept_name = "";
if ($objDept->selectFromCode($charge)) {
	$dept_name = $objDept->fld['dept_name'];
}

// DB内容取得
$strHTML = "";
$strHTML .= '	<div id="cms_search_html">' . PHP_EOL;

$strHTML .= '		<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-uploadlist-dept" style="background-color:#FFFFCC;">' . PHP_EOL;
$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<td>担当組織：' . htmlDisplay($dept_name) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;
$strHTML .= '		</table>' . PHP_EOL;

$strHTML .= '		<br>' . PHP_EOL;

$strHTML .= '		<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-uploadlist">' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="20%" align="center">状態</th>' . PHP_EOL;
if ($status == FAQ_STATUS_END_ANSWER) {
	$strHTML .= '				<td>回答済み</td>' . PHP_EOL;
}
else {
	$strHTML .= '				<td>未回答</td>' . PHP_EOL;
}
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="20%" align="center">問い合わせ内容</th>' . PHP_EOL;
$strHTML .= '				<td>' . PHP_EOL;
$strHTML .= '					以下が問い合わせの内容となります。' . PHP_EOL;
$strHTML .= '					<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . PHP_EOL;

$strHTML .= '						<tr>' . PHP_EOL;
$strHTML .= '							<th width="20%" align="center">問い合わせ日</th>' . PHP_EOL;
$strHTML .= '							<td>' . dtFormat($regist_datatime, 'Y年m月d日 H時i分s秒') . '</td>' . PHP_EOL;
$strHTML .= '						</tr>' . PHP_EOL;

if (isset($objFaq->fld['referrer_url']) && $objFaq->fld['referrer_url'] != "") {
	$strHTML .= '						<tr>' . PHP_EOL;
	$strHTML .= '							<th width="20%" align="center">問い合わせ元</th>' . PHP_EOL;
	$strHTML .= '							<td><a href="' . HTTP_REAL_ROOT . $objFaq->fld['referrer_url'] . '" target="_brank">ここをクリックすると確認できます。</a></td>' . PHP_EOL;
	$strHTML .= '						</tr>' . PHP_EOL;
}

$strHTML .= '						<tr>' . PHP_EOL;
$strHTML .= '							<th width="20%" align="center">タイトル</th>' . PHP_EOL;
$strHTML .= '							<td>' . htmlDisplay($question_title) . '</td>' . PHP_EOL;
$strHTML .= '						</tr>' . PHP_EOL;

$strHTML .= '						<tr>' . PHP_EOL;
$strHTML .= '							<th width="20%" align="center">内容</th>' . PHP_EOL;
$strHTML .= '							<td>' . htmlDisplay($question_context) . '</td>' . PHP_EOL;
$strHTML .= '						</tr>' . PHP_EOL;

//メールアドレス
if (isset($objFaq->fld['email']) && $objFaq->fld['email'] != "") {
	$strHTML .= '						<tr>' . PHP_EOL;
	$strHTML .= '							<th width="20%" align="center">メールアドレス</th>' . PHP_EOL;
	$strHTML .= '							<td>' . htmlDisplay($objFaq->fld['email']) . '</td>' . PHP_EOL;
	$strHTML .= '						</tr>' . PHP_EOL;
}

//氏名
if (isset($objFaq->fld['name']) && $objFaq->fld['name'] != "") {
	$strHTML .= '						<tr>' . PHP_EOL;
	$strHTML .= '							<th width="20%" align="center">氏名</th>' . PHP_EOL;
	$strHTML .= '							<td>' . htmlDisplay($objFaq->fld['name']) . '</td>' . PHP_EOL;
	$strHTML .= '						</tr>' . PHP_EOL;
}

//配列に存在するカラムの数分ループ
foreach ((array) $FAQ_ANSWER_LABEL as $column => $label) {
	//カラムが存在しない or データが空白ならばスキップ
	if (!isset($objFaq->fld[$column]) || $objFaq->fld[$column] == "" || $label == "") continue;
	$strHTML .= '						<tr>' . PHP_EOL;
	$strHTML .= '							<th width="20%" align="center">' . $label . '</th>' . PHP_EOL;
	$strHTML .= '							<td>' . htmlDisplay($objFaq->fld[$column]) . '</td>' . PHP_EOL;
	$strHTML .= '						</tr>' . PHP_EOL;
}

$strHTML .= '					</table>' . PHP_EOL;
$strHTML .= '				</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="20%" align="center">回答内容</th>' . PHP_EOL;
$strHTML .= '				<td>' . PHP_EOL;
$strHTML .= '					以下が回答の内容となります。' . PHP_EOL;
$strHTML .= '					<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . PHP_EOL;

$strHTML .= '						<tr>' . PHP_EOL;
$strHTML .= '							<th width="20%" align="center">回答日</th>' . PHP_EOL;
$strHTML .= '							<td>' . dtFormat($answer_datetime, 'Y年m月d日 H時i分s秒') . '</td>' . PHP_EOL;
$strHTML .= '						</tr>' . PHP_EOL;

$strHTML .= '						<tr>' . PHP_EOL;
$strHTML .= '							<th width="20%" align="center">内容</th>' . PHP_EOL;
$strHTML .= '							<td>' . htmlDisplay($answer_context) . '</td>' . PHP_EOL;
$strHTML .= '						</tr>' . PHP_EOL;

$strHTML .= '					</table>' . PHP_EOL;
$strHTML .= '				</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '		</table>' . PHP_EOL;
$strHTML .= '	</div>' . PHP_EOL;

$pageID = "";

$pageWhere = $objPage->_addslashesC('faq_id', $faq_id);
$objPage->select($pageWhere, "*");
if ($objPage->fetch() !== FALSE) {
	$pageID = (isset($objPage->fld['page_id'])) ? $objPage->fld['page_id'] : "";
}

//	DB(publish)よりfaq_id検索
$where = $objPage->_addslashesC('faq_id', $faq_id);
$hit_cnt = $objPage->getCount($where, PUBLISH_TABLE);

$strHTML2 = "";
$strHTML2 .= '	<div id="cms_search_html2">' . PHP_EOL;
$strHTML2 .= '		<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-uploadlist">' . PHP_EOL;

$strHTML2 .= '			<tr>' . PHP_EOL;

if ($pageID != "" && $publish_cls == FAQ_PUBLISH_CLASS_END) {
	$strHTML2 .= '			<th>' . PHP_EOL;
	$strHTML2 .= '				掲載されています。<br>「プレビュー」ボタンから公開中ページのプレビューを見ることができます。<br>' . PHP_EOL;
	$strHTML2 .= '				<p align="center"><a href="javascript:" onClick="return cxPreview(\'cms_answer_form\',' . $pageID . ',1)"><img src="../images/btn_preview_on_150.jpg" alt="プレビュー" width="150" height="20" border="0"></a>' . PHP_EOL;
	$strHTML2 .= '			</th>' . PHP_EOL;
}
else {
	$strHTML2 .= '			<th>' . PHP_EOL;
	$strHTML2 .= '				掲載されていません。<br>' . PHP_EOL;
	if ($hit_cnt <= 0) {
		if ($template_cnt <= 0 || $objLogin->get('class') != USER_CLASS_WRITER || $objLogin->get('isRegain')) {
			$strHTML2 .= '		ログインされているこのユーザではページを作成できません。<br>' . PHP_EOL;
			$strHTML2 .= '		<p align="center"><img src="../images/btn_create_page_off.jpg" alt="FAQページ作成" width="150" height="20" border="0"></a></p>' . PHP_EOL;
		}
		else {
			$strHTML2 .= '		「FAQページ作成」ボタンからページを作成してください。<br>' . PHP_EOL;
			$strHTML2 .= '		<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img src="../images/btn_create_page_on.jpg" alt="FAQページ作成" width="150" height="20" border="0"></a></p>' . PHP_EOL;
		}
	}
	else {
		$strHTML2 .= '			既にページが作成されています。<br>' . PHP_EOL;
		$strHTML2 .= '			<p align="center"><img src="../images/btn_create_page_off.jpg" alt="FAQページ作成" width="150" height="20" border="0"></a></p>' . PHP_EOL;
	}
	$strHTML2 .= '			</th>' . PHP_EOL;
}

$strHTML2 .= '			</tr>' . PHP_EOL;

$strHTML2 .= '		</table>' . PHP_EOL;
$strHTML2 .= '	</div>' . PHP_EOL;

$objPage->selectFromPath(SITE_TOP_PAGE);
$site_top_page_id = $objPage->fld['page_id'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>問い合わせ情報</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

	function cxSubmit() {
		if (confirm( "新規FAQページ作成を行います。\nよろしいですか？" ) ) {
			$('cms_answer_form').target = '_self';
			$('cms_answer_form').submit();
		}
		return false;	
	}
	
	/*  回答画面へ */
	function cxAnswer(){	
		$('cms_answer_form').action = 'form.php';
		$('cms_answer_form').target = '_self';
		$('cms_answer_form').submit();
	
		return false;
	}

	/*  問い合わせ削除 */
	function cxDelete(){
		if ( confirm( "問い合わせ情報を削除します。\nよろしいですか？" ) ) {
			$('cms_answer_form').action = 'delete.php';
			$('cms_answer_form').target = '_self';
			$('cms_answer_form').submit();
		}
		return false;
	}
//-->
</script>
</head>


<body id="cms8341-mainbg">
<form name="cms_answer_form" id="cms_answer_form" method="post"
	action="<?=RPW?>/admin/page/common/newpage.php">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
	<input type="hidden" id="cms_faq_id" name="cms_faq_id"
	value="<?=$faq_id?>"> <input type="hidden" id="cms_page_id"
	name="cms_page_id" value="<?=$site_top_page_id?>"> <input type="hidden"
	id="cms_dispMode" name="cms_dispMode" value="faq"> <input type="hidden"
	id="cms_faq_charge" name="cms_faq_charge" value="<?=$charge?>">

<div align="center" id="cms8341-contents">
<div><img src="../images/bar_faq_confirm.jpg" alt="問い合わせ情報" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
	
<?php
echo ($strHTML);
?>	

<?php
if ($charge == $myDeptCode && $create_cls != FAQ_CREATE_CLASS_NEW_PAGE && $objLogin->get('class') != USER_CLASS_WEBMASTER && in_array($status, array(
		FAQ_STATUS_NOT_READ, 
		FAQ_STATUS_END_ANSWER
))) {
	?>
			<p align="center"><a href="javascript:" onClick="return cxAnswer()"><img
	src="../images/btn_answer_on.jpg" alt="回答する" width="150" height="20"
	border="0" align="absmiddle"></a>
<?php
}
else {
	?>
			








<p align="center"><img src="../images/btn_answer_off.jpg" alt="回答する"
	width="150" height="20" border="0" align="absmiddle">
<?php
}
?>
		








<p align="center"><img src="../images/faq_border.jpg" width="820"
	height="2" border="0" align="absmiddle"></p>
<?php
echo ($strHTML2);
?>
		<p align="center"><img src="../images/faq_border.jpg" width="820"
	height="2" border="0" align="absmiddle"></p>
<?php
if ($hit_cnt <= 0) {
	?>
			<p align="center"><a href="javascript:" onClick="return cxDelete()"><img
	src="../images/btn_faq_delete_on.jpg" alt="この情報を削除" width="150"
	height="20" border="0" align="absmiddle"></a></p>
<?php
}
else {
	?>
			<p align="center"><img src="../images/btn_faq_delete_off.jpg"
	alt="この情報を削除" width="150" height="20" border="0" align="absmiddle"></p>
<?php
}
?>


	<p><a href=./index.php><img src="../images/btn_faq_bak.jpg" alt="戻る"
	width="100" height="20" border="0" align="absmiddle"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
