<?php
/*
 *
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

//	メール送信判定フラグ
$mail_flg = FLAG_ON;

//	変更用配列
$arrAry = "";
$arrAry = array(
		"faq_id" => (isset($_POST['cms_faq_id'])) ? $_POST['cms_faq_id'] : "", 
		"answer_context" => (isset($_POST['cms_answer_context'])) ? $_POST['cms_answer_context'] : "", 
		"cate_code" => (isset($_POST['cms_cate_code'])) ? $_POST['cms_cate_code'] : "", 
		"status" => FAQ_STATUS_END_ANSWER, 
		"answer_datetime" => "NOW"
);

//	引数チェック
if (in_array("", $arrAry)) {
	faqError("パラメータが不正です");
}

// DBデータ取得
if ($objFaq->selectFromID($arrAry['faq_id']) !== FALSE) {
	$regist_datatime = $objFaq->fld['regist_datatime'];
	$charge = $objFaq->fld['charge'];
	$status = $objFaq->fld['status'];
	$question_context = $objFaq->fld['question_context'];
	$questioner_name = $objFaq->fld['name'];
	$questioner_email_TO = $objFaq->fld['email'];
	$create_cls = $objFaq->fld['create_cls'];
}
else {
	faqError("問い合わせが存在しません。削除された可能性があります。");
}

// ステータス判定
if ($status != FAQ_STATUS_NOT_READ && $status != FAQ_STATUS_END_ANSWER) {
	faqError("ステータスが不正です");
}

// ログインユーザーの組織コード
$myDeptCode = $objLogin->get('dept_code');

// ログインしている組織コードとFAQ情報の組織コードの比較
if ($charge != $myDeptCode) {
	faqError("この組織ではこのFAQに対して回答を行えません");
}

// FAQの作成方法が新規作成からだった場合エラー
if ($create_cls == FAQ_CREATE_CLASS_NEW_PAGE) {
	faqError("新規作成より作成されたページに対しての回答は行えません");
}

//	あて先ドレスチェック
if ($questioner_email_TO != "") {
	
	//	DB取得
	if ($objDept->selectFromCode($charge) !== FALSE) {
		$dept_name = $objDept->fld['dept_name'];
		$dept_tel = $objDept->fld['tel'];
		$dept_email_FROM = $objDept->fld['email'];
	}
	
	//	送信元メールアドレス有無チェック
	if ($dept_email_FROM == "") {
		faqError("メールアドレスが存在しません");
		$mail_flg = FLAG_OFF;
	}
	//メール本文作成
	$mail_fld = array();
	$mail_fld['cms_url'] = HTTP_ROOT . RPW;
	$mail_fld['url'] = HTTP_REAL_ROOT;
	$mail_fld['now_date'] = date('Y-m-d H:i:s');
	$mail_fld['dept_name'] = $dept_name;
	$mail_fld['dept_tel'] = $dept_tel;
	$mail_fld['questioner_name'] = $questioner_name; //質問者
	$mail_fld['question_context'] = $question_context; //質問内容
	$mail_fld['answer_context'] = $arrAry['answer_context']; //回答
	

	$head = get_mail_str($mail_fld, MAIL_SUBJECT_FAQ_ANSWER);
	$body = get_mail_str($mail_fld, MAIL_BODY_FAQ_ANSWER);
	
	$objCnc->begin();
	
	//	DB登録
	tbl_faqUpdate($arrAry);
	
	//	メール送信
	if ($mail_flg == FLAG_ON) {
		if (!send_mail($questioner_email_TO, $dept_email_FROM, $head, $body)) {
			faqError("メールの送信に失敗しました");
		}
	}
	
	$objCnc->commit();

}
else {
	faqError("メールアドレスが不明です");
}

$Template_flg = FLAG_ON;
// 作成者にテンプレートの使用権限がなければエラー
$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN tbl_handler AS h ON (h.item2 = t.template_id)" . " WHERE h.class = " . HANDLER_CLASS_TEMPLATE . " AND h.item1 = '" . $objLogin->get('dept_code') . "'" . " AND t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND t.template_kind = '" . TEMPLATE_KIND_FIXED . "'" . " AND t.kanko_type = '" . KANKO_TYPE_FAQ . "'" . " ORDER BY t.sort_order,t.template_id";
$objDac->execute($sql);
if (!$objDac->fetch()) {
	$Template_flg = FLAG_OFF;
}

//	DB(publish)よりfaq_id検索
$where = $objPage->_addslashesC('faq_id', $arrAry['faq_id']);
if ($objPage->getCount($where, PUBLISH_TABLE) > 0) {
	$Template_flg = FLAG_OFF;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>問い合わせ回答完了</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

	function cxSubmit() {
		if (confirm( "新規ページ作成を行います。\nよろしいですか?" ) ) {
			$('cms_submit_form').submit();
		}
		return false;
	}

//-->
</script>
</head>


<body id="cms8341-mainbg">
<form name="cms_submit_form" id="cms_submit_form" method="post"
	action="<?=RPW?>/admin/page/common/newpage.php">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");

$objPage->selectFromPath(SITE_TOP_PAGE);
$site_top_page_id = $objPage->fld['page_id'];
?>

	<div align="center" id="cms8341-contents">
<div><img src="../images/bar_faq_answer_conp.jpg" alt="問い合わせ回答完了"
	width="920" height="30"></div>
<div class="cms8341-area-corner">


<p align="center">問い合わせ回答が完了しました</p>

<input type="hidden" id="cms_faq_id" name="cms_faq_id"
	value="<?=$arrAry['faq_id']?>"> <input type="hidden" id="cms_page_id"
	name="cms_page_id" value="<?=$site_top_page_id?>"> <input type="hidden"
	id="cms_dispMode" name="cms_dispMode" value="faq">
<?php
if ($Template_flg == FLAG_ON && $objLogin->get('class') == USER_CLASS_WRITER && !$objLogin->get('isRegain')) {
	?>
	<p align="center"><a href=./index.php><img
	src="../images/btn_faq_bak_150.jpg" alt="戻る" width="150" height="20"
	border="0" align="middle"></a> <a href="javascript:"
	onClick="return cxSubmit()"><img src="../images/btn_create_page_on.jpg"
	alt="FAQページ作成" width="150" height="20" border="0" align="middle"></a></p>
<?php
}
else {
	?>
	<p align="center"><a href=./index.php><img
	src="../images/btn_faq_bak_150.jpg" alt="戻る" width="150" height="20"
	border="0" align="middle"></a> <img
	src="../images/btn_create_page_off.jpg" alt="FAQページ作成" width="150"
	height="20" border="0" align="middle"></p>
<?php
}
?>

	</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
