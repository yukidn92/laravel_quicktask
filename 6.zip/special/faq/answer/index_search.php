<?php
/*
 * FAQ機能：担当者振り分け 一覧画面(検索PHP)
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

$objPage->setTableName(PUBLISH_TABLE);
$pageWhere = "";
$pageFiled = "page_id";

// ** 変数 ----------------------------------
$where = "";
$filed = "";
$sortOrder = "";

// ページ遷移
$backFlg = FLAG_OFF;
$nextFlg = FLAG_OFF;

// ログインユーザーの組織コード
$myDeptCode = $objLogin->get('dept_code');

$CMS_FAQ_TARGET = array(
		"0" => "自分の組織", 
		"1" => "全ての組織"
);

// -- POST を格納する配列
$postValue = array(
		// ステータス
		"status" => array(
				FAQ_STATUS_NOT_READ => "checked", 
				FAQ_STATUS_END_ANSWER => ""
		),
		// カテゴリ
		"cate_code" => array(
				'cms_cate1' => '', 
				'cms_cate2' => '', 
				'cms_cate3' => '', 
				'cms_cate4' => ''
		),
		// キーワード
		"keyword" => "",
		// 掲載区分
		"publish_cls" => "",
		// 登録日
		"regist_datatime" => array(
				'sy' => '', 
				'sm' => '', 
				'sd' => '', 
				'ey' => '', 
				'em' => '', 
				'ed' => ''
		),
		// 登録日
		"answer_datatime" => array(
				'sy' => '', 
				'sm' => '', 
				'sd' => '', 
				'ey' => '', 
				'em' => '', 
				'ed' => ''
		),
		// 登録日
		"publish_datatime" => array(
				'sy' => '', 
				'sm' => '', 
				'sd' => '', 
				'ey' => '', 
				'em' => '', 
				'ed' => ''
		),
		// 対象
		"target" => ($objLogin->get('class') == USER_CLASS_WEBMASTER) ? 1 : 0,
		// 作業区分
		"create_cls" => "",
		// ページ
		"page" => 0,
		// 検索条件持続フラグ
		"search" => FLAG_OFF
);

// -- 検索部分HTML配列
$searchHtml = array(
		"status" => "",  // ステータス
		"category" => "",  // カテゴリ
		"keyword" => "",  // キーワード
		"publish_cls" => "",  // 掲載区分
		"regist_datatime" => "",  // 登録日
		"answer_datetime" => "",  // 回答日
		"publish_datetime" => "",  // 掲載日
		"target" => "",  // 対象
		"create_cls" => "" // 作業区分
);


// FAQ情報の削除
if (isset($_POST['delFaqID'])) {
	$temp_ary = array(
			'faq_id' => $_POST['delFaqID']
	);
	tbl_faqDelete($temp_ary);
}
// 差し戻し処理
if (isset($_POST['sbFaqID']) && isset($_POST['distribute'])) {
	$sbAry = array(
			'faq_id' => $_POST['sbFaqID'],  // FAQ ID
			'send_back' => trim($_POST['distribute']),  // 差し戻し内容
			'status' => FAQ_STATUS_ADMIN_CONTROL,  // ステータス 管理者管理に戻す
			'charge' => "" // 組織コード初期化
	);
	

	// 更新
	tbl_faqUpdate($sbAry);
}
// ** POSTの取得 ------------------------- //
getPOST($_POST, $postValue);

//同一ページ以外から来た場合、SESSIONを削除する
if (!isset($_SERVER['HTTP_REFERER']) || cms_dirname($_SERVER['HTTP_REFERER']) != cms_dirname(HTTP_ROOT . $_SERVER['PHP_SELF'])) unset($_SESSION['faq_answer_index']);

if ($postValue['search'] == FLAG_ON) {
	// 検索ボタンを押した場合は $_SESSION をセット
	$_SESSION['faq_answer_index']['status'] = $postValue['status'];
	$_SESSION['faq_answer_index']['cate_code'] = $postValue['cate_code'];
	$_SESSION['faq_answer_index']['keyword'] = $postValue['keyword'];
	$_SESSION['faq_answer_index']['publish_cls'] = $postValue['publish_cls'];
	$_SESSION['faq_answer_index']['regist_datatime'] = $postValue['regist_datatime'];
	$_SESSION['faq_answer_index']['answer_datatime'] = $postValue['answer_datatime'];
	$_SESSION['faq_answer_index']['publish_datatime'] = $postValue['publish_datatime'];
	$_SESSION['faq_answer_index']['target'] = $postValue['target'];
	$_SESSION['faq_answer_index']['create_cls'] = $postValue['create_cls'];
	$_SESSION['faq_answer_index']['page'] = (isset($_POST['cms_page'])) ? $_POST['cms_page'] : 0;
}

// ページ遷移の場合は $_SESSIONから検索条件取得
if (isset($_SESSION['faq_answer_index']['status'])) $postValue['status'] = $_SESSION['faq_answer_index']['status'];
if (isset($_SESSION['faq_answer_index']['cate_code'])) $postValue['cate_code'] = $_SESSION['faq_answer_index']['cate_code'];
if (isset($_SESSION['faq_answer_index']['keyword'])) $postValue['keyword'] = $_SESSION['faq_answer_index']['keyword'];
if (isset($_SESSION['faq_answer_index']['publish_cls'])) $postValue['publish_cls'] = $_SESSION['faq_answer_index']['publish_cls'];
if (isset($_SESSION['faq_answer_index']['regist_datatime'])) $postValue['regist_datatime'] = $_SESSION['faq_answer_index']['regist_datatime'];
if (isset($_SESSION['faq_answer_index']['answer_datatime'])) $postValue['answer_datatime'] = $_SESSION['faq_answer_index']['answer_datatime'];
if (isset($_SESSION['faq_answer_index']['publish_datatime'])) $postValue['publish_datatime'] = $_SESSION['faq_answer_index']['publish_datatime'];
if (isset($_SESSION['faq_answer_index']['target'])) $postValue['target'] = $_SESSION['faq_answer_index']['target'];
if (isset($_SESSION['faq_answer_index']['create_cls'])) $postValue['create_cls'] = $_SESSION['faq_answer_index']['create_cls'];
if (isset($_POST['cms_page'])) {
	$_SESSION['faq_answer_index']['page'] = $_POST['cms_page'];
}
$postValue['page'] = (isset($_SESSION['faq_answer_index']['page'])) ? $_SESSION['faq_answer_index']['page'] : 0;

// ** 検索用HTML作成 --------------------- //
$FAQ_STATUS = getDefineArray('FAQ_STATUS');
$FAQ_PUBLISH_CLASS = getDefineArray('FAQ_PUBLISH_CLASS');
$FAQ_CREATE_CLASS = getDefineArray('FAQ_CREATE_CLASS');
$FAQ_STATUS_IMAGE = getDefineArray('FAQ_STATUS_IMAGE');

// ステータス ---------------------------------------------------------- //
$FAQ_STATUS_CHKBOX = $FAQ_STATUS; // チェックボックスに不要(非表示)なステータスはアンセットする
foreach ($FAQ_STATUS_CHKBOX as $_k => $_v) {
	if (!isset($postValue['status'][$_k])) {
		unset($FAQ_STATUS_CHKBOX[$_k]);
	}
}
$searchHtml['status'] = checkBoxCreate($FAQ_STATUS_CHKBOX, "cms_status", $postValue['status']);

// -- カテゴリ --------------------------------------------------------- //
$searchHtml['category'] = catePullDownCreate($objDac, $objCate, "cms_cate", $postValue['cate_code']);

// -- キーワード ------------------------------------------------------- //
$searchHtml['keyword'] = '<input type="text" id="cms_keyword" name="cms_keyword" value="' . htmlspecialchars($postValue['keyword']) . '" size="70">';

// -- 掲載区分 --------------------------------------------------------- //
$searchHtml['publish_cls'] = mkradiobutton($FAQ_PUBLISH_CLASS, "cms_publish_cls", $postValue['publish_cls'], "");

// -- 登録日 ----------------------------------------------------------- //
$searchHtml['regist_datatime'] = calendarBoxCreate("regist_datatime", "登録日", $postValue['regist_datatime']);

// -- 回答日 ----------------------------------------------------------- //
$searchHtml['answer_datatime'] = calendarBoxCreate("answer_datatime", "回答日", $postValue['answer_datatime']);

// -- 掲載日 ----------------------------------------------------------- //
$searchHtml['publish_datatime'] = calendarBoxCreate("publish_datatime", "掲載日", $postValue['publish_datatime']);

// -- ターゲット ------------------------------------------------------- //
$searchHtml['target'] = mkradiobutton($CMS_FAQ_TARGET, "cms_target", $postValue['target'], "");

// -- 作業区分 --------------------------------------------------------- //
$searchHtml['create_cls'] = mkradiobutton($FAQ_CREATE_CLASS, "cms_create_cls", $postValue['create_cls'], "");

// ** 変数 ----------------------------------
$where = "";
$whereAry = array();

// ** 条件作成 ------------------------------


// -- ステータス
$statusWhere = "";
$statusAry = array();
foreach ($postValue['status'] as $column => $checked) {
	if (in_array($column, array(
			FAQ_STATUS_NOT_READ, 
			FAQ_STATUS_END_ANSWER
	)) && $checked != "") {
		array_push($statusAry, $objFAQ->_addslashesC('f.status', $column));
	}
}
if (count($statusAry) > 0) {
	$statusWhere = implode(" OR ", $statusAry);
	array_push($whereAry, "(" . $statusWhere . ")");
}
unset($statusWhere);
unset($statusAry);

// -- カテゴリ
if (trim($postValue['cate_code']['cms_cate4']) != "") {
	array_push($whereAry, $objFAQ->_addslashesC('f.cate_code', $postValue['cate_code']['cms_cate4'], "LIKE", "TEXT"));
}
elseif (trim($postValue['cate_code']['cms_cate3']) != "") {
	array_push($whereAry, $objFAQ->_addslashesC('f.cate_code', substr($postValue['cate_code']['cms_cate3'], 0, 9) . '%', "LIKE", "TEXT"));
}
elseif (trim($postValue['cate_code']['cms_cate2']) != "") {
	array_push($whereAry, $objFAQ->_addslashesC('f.cate_code', substr($postValue['cate_code']['cms_cate2'], 0, 6) . '%', "LIKE", "TEXT"));
}
elseif (trim($postValue['cate_code']['cms_cate1']) != "") {
	array_push($whereAry, $objFAQ->_addslashesC('f.cate_code', substr($postValue['cate_code']['cms_cate1'], 0, 3) . '%', "LIKE", "TEXT"));
}

// -- キーワード
// -- タイトル 質問内容 回答内容 質問者 ハンドルネーム メールアドレス 住所の部分一致
$keyWhere = "";
$keyword = explode(" ", trim(str_replace("　", " ", $postValue['keyword'])));

foreach ($keyword as $key) {
	if ($key != "") {
		$keywordAry = array();
		array_push($keywordAry, $objFAQ->_addslashesC('f.question_title', "%" . $key . "%", "LIKE", "TEXT"));
		array_push($keywordAry, $objFAQ->_addslashesC('f.question_context', "%" . $key . "%", "LIKE", "TEXT"));
		array_push($keywordAry, $objFAQ->_addslashesC('f.answer_context', "%" . $key . "%", "LIKE", "TEXT"));
		array_push($keywordAry, $objFAQ->_addslashesC('f.name', "%" . $key . "%", "LIKE", "TEXT"));
		array_push($keywordAry, $objFAQ->_addslashesC('f.email', "%" . $key . "%", "LIKE", "TEXT"));
		$keyWhere .= ($keyWhere != "") ? " OR " : "";
		$keyWhere .= implode(" OR ", $keywordAry);
	}
}
if ($keyWhere != "") {
	array_push($whereAry, "(" . $keyWhere . ")");
}
unset($keyWhere);
unset($keyword);

// -- 掲載区分
if ($postValue['publish_cls'] != "" && in_array($postValue['publish_cls'], array(
		FAQ_PUBLISH_CLASS_NOT, 
		FAQ_PUBLISH_CLASS_END
))) {
	array_push($whereAry, $objFAQ->_addslashesC('f.publish_cls', $postValue['publish_cls'], 'IN', 'INT'));
}

// -- 登録日
if ($postValue['regist_datatime']['sy'] != "" && $postValue['regist_datatime']['sm'] != "" && $postValue['regist_datatime']['sd'] != "") {
	$date = sprintf("%04d", $postValue['regist_datatime']['sy']) . "-" . sprintf("%02d", $postValue['regist_datatime']['sm']) . "-" . sprintf("%02d", $postValue['regist_datatime']['sd']) . " 00:00:00";
	array_push($whereAry, $objFAQ->_addslashesC('f.regist_datatime', $date, ">=", "TEXT"));
}
if ($postValue['regist_datatime']['ey'] != "" && $postValue['regist_datatime']['em'] != "" && $postValue['regist_datatime']['ed'] != "") {
	$date = sprintf("%04d", $postValue['regist_datatime']['ey']) . "-" . sprintf("%02d", $postValue['regist_datatime']['em']) . "-" . sprintf("%02d", $postValue['regist_datatime']['ed']) . " 23:59:59";
	array_push($whereAry, $objFAQ->_addslashesC('f.regist_datatime', $date, "<=", "TEXT"));
}

// -- 回答日
if ($postValue['answer_datatime']['sy'] != "" && $postValue['answer_datatime']['sm'] != "" && $postValue['answer_datatime']['sd'] != "") {
	$date = sprintf("%04d", $postValue['answer_datatime']['sy']) . "-" . sprintf("%02d", $postValue['answer_datatime']['sm']) . "-" . sprintf("%02d", $postValue['answer_datatime']['sd']) . " 00:00:00";
	array_push($whereAry, $objFAQ->_addslashesC('f.answer_datetime', $date, ">=", "TEXT"));
}
if ($postValue['answer_datatime']['ey'] != "" && $postValue['answer_datatime']['em'] != "" && $postValue['answer_datatime']['ed'] != "") {
	$date = sprintf("%04d", $postValue['answer_datatime']['ey']) . "-" . sprintf("%02d", $postValue['answer_datatime']['em']) . "-" . sprintf("%02d", $postValue['answer_datatime']['ed']) . " 23:59:59";
	array_push($whereAry, $objFAQ->_addslashesC('f.answer_datetime', $date, "<=", "TEXT"));
}

// -- 掲載日
if ($postValue['publish_datatime']['sy'] != "" && $postValue['publish_datatime']['sm'] != "" && $postValue['publish_datatime']['sd'] != "") {
	$date = sprintf("%04d", $postValue['publish_datatime']['sy']) . "-" . sprintf("%02d", $postValue['publish_datatime']['sm']) . "-" . sprintf("%02d", $postValue['publish_datatime']['sd']) . " 00:00:00";
	array_push($whereAry, $objFAQ->_addslashesC('f.publish_datetime', $date, ">=", "TEXT"));
}
if ($postValue['publish_datatime']['ey'] != "" && $postValue['publish_datatime']['em'] != "" && $postValue['publish_datatime']['ed'] != "") {
	$date = sprintf("%04d", $postValue['publish_datatime']['ey']) . "-" . sprintf("%02d", $postValue['publish_datatime']['em']) . "-" . sprintf("%02d", $postValue['publish_datatime']['ed']) . " 23:59:59";
	array_push($whereAry, $objFAQ->_addslashesC('f.publish_datetime', $date, "<=", "TEXT"));
}

// -- 作業区分
if ($postValue['create_cls'] != "" && in_array($postValue['create_cls'], array(
		FAQ_CREATE_CLASS_INQUIURY, 
		FAQ_CREATE_CLASS_NEW_PAGE
))) {
	array_push($whereAry, $objFAQ->_addslashesC('f.create_cls', $postValue['create_cls'], 'IN', 'INT'));
}

// -- 対象
if (isset($postValue['target'])) {
	// 自分の組織
	if ($postValue['target'] == 0) {
		array_push($whereAry, $objFAQ->_addslashesC('f.charge', $objLogin->get('dept_code'), "LIKE", "TEXT"));
	}
}

// -- ページ
if ($postValue['page'] == "") $postValue['page'] = 0;

// 取得項目
$filed = "f.status, f.faq_id, f.create_cls, f.distribute, f.charge, f.publish_cls, f.question_title,f.regist_datatime";
// ソート
$sortOrder = "faq_id DESC";
// 取得開始位置
$offset = FAQ_SEARCH_LIMIT * $postValue['page'];
// 取得数
$limit = FAQ_SEARCH_LIMIT + 1; // 次ページフラグ確認のため+1取得


// DB内容取得
$objFAQ->setTableName($objFAQ->table_name . " AS f");
$where = implode($whereAry, " AND ");
$objFAQ->select($where, $filed, $sortOrder, $offset, $limit);

$strHTML = "";
$strHTML .= "		<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"cms8341-dataTable\" id=\"cms8341-uploadlist\">" . PHP_EOL;
if ($objFAQ->getRowCount() == 0) {
	$strHTML .= "			<tr>" . PHP_EOL;
	$strHTML .= '				<td>データがありません。</td>';
	$strHTML .= "			</tr>" . PHP_EOL;
}
else {
	$strHTML .= "			<tr>" . PHP_EOL;
	$strHTML .= "				<th width=\"80px\" align=\"center\">状態</th>" . PHP_EOL;
	$strHTML .= "				<th width=\"80px\" align=\"center\">掲載区分</th>" . PHP_EOL;
	$strHTML .= "				<th width=\"100%\" align=\"center\" colspan=\"2\">問い合わせ情報</th>" . PHP_EOL;
	$strHTML .= "			</tr>" . PHP_EOL;
	
	$count = 0;
	
	while ($objFAQ->fetch()) {
		if ($count < FAQ_SEARCH_LIMIT) {
			// 値の取得
			$status = $objFAQ->fld['status'];
			$faqID = $objFAQ->fld['faq_id'];
			$create_cls = $objFAQ->fld['create_cls'];
			$pageID = "";
			$distribute = $objFAQ->fld['distribute'];
			$charge = $objFAQ->fld['charge'];
			$publish_cls = $objFAQ->fld['publish_cls'];
			
			$pageWhere = $objPage->_addslashesC('faq_id', $faqID);
			$objPage->select($pageWhere, "page_id");
			if ($objPage->fetch() !== FALSE) {
				$pageID = (isset($objPage->fld['page_id'])) ? $objPage->fld['page_id'] : "";
			}
			
			// htmlの作成
			$strHTML .= "<tr>" . PHP_EOL;
			
			// アイコン(状態)
			$strHTML .= "	<td align=\"center\" width=\"80px\">" . PHP_EOL;
			if ($status == FAQ_STATUS_END_ANSWER) {
				$strHTML .= '		<img src="' . RPW . '/admin/special/faq/images/icon_status_answer.jpg" alt="回答済み" width="70" height="25">&nbsp;';
			}
			else {
				$strHTML .= '		<img src="' . RPW . '/admin/special/faq/images/icon_status_not_answer.jpg" alt="未回答" width="70" height="25">&nbsp;';
			}
			$strHTML .= "	</td>" . PHP_EOL;
			
			// アイコン(掲載区分)								
			$strHTML .= "	<td align=\"center\" width=\"80px\">" . PHP_EOL;
			if ($pageID != "" && $publish_cls == FAQ_PUBLISH_CLASS_END) {
				$strHTML .= '		<img src="' . RPW . '/admin/special/faq/images/icon_status_pub.jpg" alt="掲載済み" width="70" height="25">&nbsp;';
			}
			else {
				$strHTML .= '		<img src="' . RPW . '/admin/special/faq/images/icon_status_not_pub.jpg" alt="未掲載" width="70" height="25">&nbsp;';
			}
			$strHTML .= "	</td>" . PHP_EOL;
			
			$strHTML .= "	<td>" . PHP_EOL;
			
			//2008/12/08 登録情報確認画面form作成
			$strHTML .= '<form name="cms_confirm_' . $faqID . '" id="cms_confirm_' . $faqID . '" method="post" action="answer_confirm.php">' . PHP_EOL;
			
			$strHTML .= '	<input type="hidden" id="cms_faq_id" name="cms_faq_id" value="' . $faqID . '">' . PHP_EOL;
			$strHTML .= '	<a href="javascript:" onClick="return cxSubmit(' . $faqID . ')">';
			$strHTML .= ($objFAQ->fld['question_title'] != "") ? htmlDisplay($objFAQ->fld['question_title']) : "（タイトルなし）";
			$strHTML .= '</a><br>' . PHP_EOL;
			
			$regist_datatime = "";
			if (isset($objFAQ->fld['regist_datatime'])) {
				$regist_datatime = $objFAQ->fld['regist_datatime'];
			}
			$strHTML .= "	<small>問い合わせ日：" . dtFormat($regist_datatime, "Y年n月j日") . "</small><br>"; // H時i分s秒
			

			$dept_name = "";
			if ($objDept->selectFromCode($charge)) {
				$dept_name = $objDept->fld['dept_name'];
			}
			$strHTML .= "	<small>担当：" . $dept_name . "</small>";
			
			$strHTML .= '</form>' . PHP_EOL;
			
			if (($myDeptCode == $objFAQ->fld['charge'] && $pageID == "") && $distribute == FAQ_DISTRIBUTE_CHANGE && $status != FAQ_STATUS_END_ANSWER) {
				$strHTML .= '	<p><a href="javascript:" onClick="return cxSendBack(' . $faqID . ',\'cms_send_back_' . $count . '\');"><img src="' . RPW . '/admin/special/faq/images/btn_sendback.jpg" alt="差し戻し" width="80" height="20" border="0" align="absmiddle"></a></p>';
				$strHTML .= '	<div class="cms8341-denailarea">';
				$strHTML .= '	<span><label for="cms_send_back_' . $count . '"><img src="' . RPW . '/admin/special/faq/images/label_sendback.jpg" alt="差し戻し理由" width="80" height="25"></label></span><br>';
				$strHTML .= '	<span><textarea name="cms_send_back_' . $count . '" rows="5" id="cms_send_back_' . $count . '" style="width:630px;"></textarea></span>';
				$strHTML .= '	</div>';
			}
			
			$strHTML .= "				</td>" . PHP_EOL;
			$strHTML .= "			</tr>" . PHP_EOL;
		}
		else {
			// FAQ 表示件数に達したら次ページフラグのオン
			$nextFlg = FLAG_ON;
			break;
		}
		
		$count++;
	}
	
	// ページ遷移を行っていれば前ページフラグオン
	if ($postValue['page'] > 0) {
		$backFlg = FLAG_ON;
	}
}
$strHTML .= "		</table>" . PHP_EOL;

// 前ページ、次ページ
$strHTML .= "		<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\" style=\"margin-top:10px;\">" . PHP_EOL;
$strHTML .= "			<tr>" . PHP_EOL;
$strHTML .= "<td width=\"30%\" align=\"left\" valign=\"middle\" scope=\"row\">";
if ($backFlg == FLAG_ON) {
	$strHTML .= "<a href=\"javascript:\" onClick=\"return cxSearch(" . ($postValue['page'] - 1) . ", " . FLAG_OFF . " )\"><img src=\"" . RPW . "/admin/images/btn/btn_prev.gif\" alt=\"\" width=\"50\" height=\"16\" align=\"absmiddle\" border=\"0\"></a>";
}
$strHTML .= "</td>" . PHP_EOL;
$strHTML .= "<td width=\"40%\" align=\"center\" valign=\"middle\">&nbsp;</td>" . PHP_EOL;
$strHTML .= "<td width=\"30%\" align=\"right\" valign=\"middle\">";
if ($nextFlg == FLAG_ON) {
	$strHTML .= "<a href=\"javascript:\" onClick=\"return cxSearch(" . ($postValue['page'] + 1) . ", " . FLAG_OFF . " )\"><img src=\"" . RPW . "/admin/images/btn/btn_next.gif\" alt=\"\" width=\"50\" height=\"16\" align=\"absmiddle\" border=\"0\"></a>";
}
$strHTML .= "</td>" . PHP_EOL;
$strHTML .= "</tr>" . PHP_EOL;
$strHTML .= "</table>" . PHP_EOL;

if (isset($_POST['AjaxPost'])) {
	print_r($strHTML);
}

// 関数 // ------------------------------- //
function getPOST($post, &$ret) {
	// hiddenが存在すればPOSTを受け取る
	if (isset($post['FormPost']) || isset($post['AjaxPost'])) {
		// -- ステータス
		$ret['status'][FAQ_STATUS_NOT_READ] = (isset($post['cms_status_' . FAQ_STATUS_NOT_READ]) && $post['cms_status_' . FAQ_STATUS_NOT_READ] != "") ? "checked" : "";
		$ret['status'][FAQ_STATUS_END_ANSWER] = (isset($post['cms_status_' . FAQ_STATUS_END_ANSWER]) && $post['cms_status_' . FAQ_STATUS_END_ANSWER] != "") ? "checked" : "";
		
		// -- カテゴリ
		$ret['cate_code']["cms_cate1"] = (isset($post['cms_cate1'])) ? $post['cms_cate1'] : "";
		$ret['cate_code']["cms_cate2"] = (isset($post['cms_cate2'])) ? $post['cms_cate2'] : "";
		$ret['cate_code']["cms_cate3"] = (isset($post['cms_cate3'])) ? $post['cms_cate3'] : "";
		$ret['cate_code']["cms_cate4"] = (isset($post['cms_cate4'])) ? $post['cms_cate4'] : "";
		
		// -- キーワード
		$ret['keyword'] = (isset($post['cms_keyword'])) ? $post['cms_keyword'] : "";
		
		// -- 掲載区分
		$ret['publish_cls'] = (isset($post['cms_publish_cls'])) ? $post['cms_publish_cls'] : "";
		
		// -- 登録日
		$ret['regist_datatime']['sy'] = (isset($post['cms_regist_datatime_sy'])) ? $post['cms_regist_datatime_sy'] : "";
		$ret['regist_datatime']['sm'] = (isset($post['cms_regist_datatime_sm'])) ? $post['cms_regist_datatime_sm'] : "";
		$ret['regist_datatime']['sd'] = (isset($post['cms_regist_datatime_sd'])) ? $post['cms_regist_datatime_sd'] : "";
		$ret['regist_datatime']['ey'] = (isset($post['cms_regist_datatime_ey'])) ? $post['cms_regist_datatime_ey'] : "";
		$ret['regist_datatime']['em'] = (isset($post['cms_regist_datatime_em'])) ? $post['cms_regist_datatime_em'] : "";
		$ret['regist_datatime']['ed'] = (isset($post['cms_regist_datatime_ed'])) ? $post['cms_regist_datatime_ed'] : "";
		
		// -- 回答日
		$ret['answer_datatime']['sy'] = (isset($post['cms_answer_datatime_sy'])) ? $post['cms_answer_datatime_sy'] : "";
		$ret['answer_datatime']['sm'] = (isset($post['cms_answer_datatime_sm'])) ? $post['cms_answer_datatime_sm'] : "";
		$ret['answer_datatime']['sd'] = (isset($post['cms_answer_datatime_sd'])) ? $post['cms_answer_datatime_sd'] : "";
		$ret['answer_datatime']['ey'] = (isset($post['cms_answer_datatime_ey'])) ? $post['cms_answer_datatime_ey'] : "";
		$ret['answer_datatime']['em'] = (isset($post['cms_answer_datatime_em'])) ? $post['cms_answer_datatime_em'] : "";
		$ret['answer_datatime']['ed'] = (isset($post['cms_answer_datatime_ed'])) ? $post['cms_answer_datatime_ed'] : "";
		
		// -- 掲載日
		$ret['publish_datatime']['sy'] = (isset($post['cms_publish_datatime_sy'])) ? $post['cms_publish_datatime_sy'] : "";
		$ret['publish_datatime']['sm'] = (isset($post['cms_publish_datatime_sm'])) ? $post['cms_publish_datatime_sm'] : "";
		$ret['publish_datatime']['sd'] = (isset($post['cms_publish_datatime_sd'])) ? $post['cms_publish_datatime_sd'] : "";
		$ret['publish_datatime']['ey'] = (isset($post['cms_publish_datatime_ey'])) ? $post['cms_publish_datatime_ey'] : "";
		$ret['publish_datatime']['em'] = (isset($post['cms_publish_datatime_em'])) ? $post['cms_publish_datatime_em'] : "";
		$ret['publish_datatime']['ed'] = (isset($post['cms_publish_datatime_ed'])) ? $post['cms_publish_datatime_ed'] : "";
		
		// -- ターゲット
		$ret['target'] = (isset($post['cms_target'])) ? $post['cms_target'] : "";
		
		// -- 作業区分
		$ret['create_cls'] = (isset($post['cms_create_cls'])) ? $post['cms_create_cls'] : "";
		
		// -- ページ情報
		$ret['page'] = (isset($post['cms_page'])) ? $post['cms_page'] : "";
		
		// -- 検索実行フラグ
		if (isset($post['AjaxSearch'])) $ret['search'] = $post['AjaxSearch'];
	
	}
}

// カテゴリプルダウン作成
function catePullDownCreate($objDac, $objCate, $name, $selectValue) {
	
	$combo_cate = '';
	
	$cate_s1 = '<select id="cms_cate1" name="' . $name . '1" onChange="javascript:cxChangeCate(2, this.value)" style="width:120px;">' . "\n";
	$cate_s2 = '<select id="cms_cate2" name="' . $name . '2" onChange="javascript:cxChangeCate(3, this.value)" style="width:120px;">' . "\n";
	$cate_s3 = '<select id="cms_cate3" name="' . $name . '3" onChange="javascript:cxChangeCate(4, this.value)" style="width:120px;">' . "\n";
	$cate_s4 = '<select id="cms_cate4" name="' . $name . '4" onChange="javascript:cxChangeCate(5, this.value)" style="width:120px;">' . "\n";
	$cate_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
	$cate_e = '</select>&nbsp;&nbsp;';
	$cate_op1 = $cate_opn;
	$cate_op2 = $cate_opn;
	$cate_op3 = $cate_opn;
	$cate_op4 = $cate_opn;
	// 第一カテゴリプルダウンの生成
	$sql = "SELECT level,cate_code,name FROM tbl_category WHERE level = 1 ORDER BY sort_order, cate_code";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$selected = ($objDac->fld['cate_code'] == $selectValue[$name . '1']) ? ' selected' : '';
		$cate_op1 .= '<option value="' . $objDac->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
	// 第二カテゴリプルダウンの生成（第一カテゴリが指定されている場合）
	if ($selectValue[$name . '1'] != '') {
		$objCate->selectChildren($selectValue[$name . '1']);
		while ($objCate->fetch()) {
			$selected = ($objCate->fld['cate_code'] == $selectValue[$name . '2']) ? ' selected' : '';
			$cate_op2 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
		}
	}
	// 第三カテゴリプルダウンの生成（第二カテゴリが指定されている場合）
	if ($selectValue[$name . '2'] != '') {
		$objCate->selectChildren($selectValue[$name . '2']);
		while ($objCate->fetch()) {
			$selected = ($objCate->fld['cate_code'] == $selectValue[$name . '3']) ? ' selected' : '';
			$cate_op3 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
		}
	}
	// 第四カテゴリプルダウンの生成（第三カテゴリが指定されている場合）
	if ($selectValue[$name . '3'] != '') {
		$objCate->selectChildren($selectValue[$name . '3']);
		while ($objCate->fetch()) {
			$selected = ($objCate->fld['cate_code'] == $selectValue[$name . '4']) ? ' selected' : '';
			$cate_op4 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
		}
	}
	
	$cate1 = $cate_s1 . $cate_op1 . $cate_e;
	$cate2 = $cate_s2 . $cate_op2 . $cate_e;
	$cate3 = $cate_s3 . $cate_op3 . $cate_e;
	$cate4 = $cate_s4 . $cate_op4 . $cate_e;
	
	$combo_cate = $cate1 . $cate2 . $cate3 . $cate4;
	
	return $combo_cate;

}

// カレンダー付きテキストボックス作成 // ----------- //
function calendarBoxCreate($id, $name, $selectValue) {
	
	$calendar = '' . PHP_EOL;
	$calendar .= '<th width="120" align="left" valign="middle" nowrap scope="row"><label for="log_range">' . $name . '</label></th>' . PHP_EOL;
	$calendar .= '<td align="left" valign="middle">' . PHP_EOL;
	$calendar .= '	<input type="text" maxlength="4" id="cms_' . $id . '_sy" name="cms_' . $id . '_sy" value="' . htmlspecialchars($selectValue['sy']) . '" style="width:50px;ime-mode:disabled"> 年' . PHP_EOL;
	$calendar .= '	<input type="text" maxlength="2" id="cms_' . $id . '_sm" name="cms_' . $id . '_sm" value="' . htmlspecialchars($selectValue['sm']) . '" style="width:30px;ime-mode:disabled"> 月' . PHP_EOL;
	$calendar .= '	<input type="text" maxlength="2" id="cms_' . $id . '_sd" name="cms_' . $id . '_sd" value="' . htmlspecialchars($selectValue['sd']) . '" style="width:30px;ime-mode:disabled"> 日' . PHP_EOL;
	$calendar .= '	<a href="javascript:" onClick="return cxCalendarOpen(\'cms_' . $id . '_\',\'start\')"><img src="' . RPW . '/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a>　から' . PHP_EOL;
	$calendar .= '	&nbsp;' . PHP_EOL;
	$calendar .= '	<input type="text" maxlength="4" id="cms_' . $id . '_ey" name="cms_' . $id . '_ey" value="' . htmlspecialchars($selectValue['ey']) . '" style="width:50px;ime-mode:disabled"> 年' . PHP_EOL;
	$calendar .= '	<input type="text" maxlength="2" id="cms_' . $id . '_em" name="cms_' . $id . '_em" value="' . htmlspecialchars($selectValue['em']) . '" style="width:30px;ime-mode:disabled"> 月' . PHP_EOL;
	$calendar .= '	<input type="text" maxlength="2" id="cms_' . $id . '_ed" name="cms_' . $id . '_ed" value="' . htmlspecialchars($selectValue['ed']) . '" style="width:30px;ime-mode:disabled"> 日' . PHP_EOL;
	$calendar .= '	<a href="javascript:" onClick="return cxCalendarOpen(\'cms_' . $id . '_\',\'end\')"><img src="' . RPW . '/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a>　まで' . PHP_EOL;
	$calendar .= '</td>' . PHP_EOL;
	$calendar .= '' . PHP_EOL;
	
	return $calendar;
}

// チェックボックス作成
function checkBoxCreate($idAry, $id, $selectValue) {
	
	$chkhtml = "";
	$i = 1;
	
	foreach ($idAry as $value => $name) {
		$chkhtml .= '<input type="checkbox" name="' . $id . '_' . $value . '" id="' . $id . '_' . $value . '" value="' . $value . '" ' . $selectValue[$value] . '>' . PHP_EOL;
		$chkhtml .= '<label for="' . $id . '_' . $value . '">' . $name . '</label>';
		$i++;
	}
	
	return $chkhtml;
}

?>
