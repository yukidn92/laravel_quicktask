<?php
/*
 * FAQ機能：セッションクリアPHP
 */
// ** require -------------------------------
require ("../.htsetting");

// FAQ一覧画面で使うセッションをクリアする


// ステータス
if (isset($_SESSION['faq_answer_index'])) unset($_SESSION['faq_answer_index']);

$_SESSION['faq_answer_index'] = array( // ステータス
		"status" => array(
				FAQ_STATUS_NOT_READ => "checked", 
				FAQ_STATUS_END_ANSWER => ""
		),  // カテゴリ
		"cate_code" => array(
				'cms_cate1' => '', 
				'cms_cate2' => '', 
				'cms_cate3' => '', 
				'cms_cate4' => ''
		),  // キーワード
		"keyword" => "",  // 掲載区分
		"publish_cls" => "",  // 登録日
		"regist_datatime" => array(
				'sy' => '', 
				'sm' => '', 
				'sd' => '', 
				'ey' => '', 
				'em' => '', 
				'ed' => ''
		),  // 登録日
		"answer_datatime" => array(
				'sy' => '', 
				'sm' => '', 
				'sd' => '', 
				'ey' => '', 
				'em' => '', 
				'ed' => ''
		),  // 登録日
		"publish_datatime" => array(
				'sy' => '', 
				'sm' => '', 
				'sd' => '', 
				'ey' => '', 
				'em' => '', 
				'ed' => ''
		),  // 対象
		"target" => ($objLogin->get('class') == USER_CLASS_WEBMASTER) ? 1 : 0,  // 作業区分
		"create_cls" => "",  // ページ
		"page" => 0
);

header("location: index.php");

?>
