<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);

//	ステータス判定用フラグ
$status_flg = FLAG_OFF;

// ID取得
if (!isset($_POST['cms_faq_id'])) {
	faqError("IDが存在しません");
}
$faq_id = $_POST['cms_faq_id'];

//	カテゴリ取得
if (!isset($_POST['cms_cate1']) || $_POST['cms_cate1'] == '') {
	faqError("カテゴリが設定されていません。");
}
$cate_code = $_POST['cms_cate1'];
if (isset($_POST['cms_cate2']) && $_POST['cms_cate2']) $cate_code = $_POST['cms_cate2'];
if (isset($_POST['cms_cate3']) && $_POST['cms_cate3']) $cate_code = $_POST['cms_cate3'];
if (isset($_POST['cms_cate4']) && $_POST['cms_cate4']) $cate_code = $_POST['cms_cate4'];

if ($objCate->selectFromCode($cate_code) === FALSE) {
	faqError("不正なカテゴリが設定されています。");
}

//	回答本文取得
if (!isset($_POST['cms_answer']) || $_POST['cms_answer'] == "") {
	faqError("回答本文の取得に失敗しました");
}
$answer_context = trim($_POST['cms_answer']);

// DBデータ取得
if ($objFaq->selectFromID($faq_id) !== FALSE) {
	$question_title = $objFaq->fld['question_title'];
	$question_context = $objFaq->fld['question_context'];
	$status = $objFaq->fld['status'];
	$create_cls = $objFaq->fld['create_cls'];
	$charge = $objFaq->fld['charge'];
}
else {
	faqError("問い合わせが存在しません。削除された可能性があります。");
}

// ステータス判定
if ($status != FAQ_STATUS_NOT_READ && $status != FAQ_STATUS_END_ANSWER) {
	faqError("ステータスが不正です");
}
else if ($status == FAQ_STATUS_END_ANSWER) {
	$status_flg = FLAG_ON;
}

// ログインユーザーの組織コード
$myDeptCode = $objLogin->get('dept_code');

// ログインしている組織コードとFAQ情報の組織コードの比較
if ($charge != $myDeptCode) {
	faqError("この組織ではこのFAQに対して回答を行えません");
}

// FAQの作成方法が新規作成からだった場合エラー
if ($create_cls == FAQ_CREATE_CLASS_NEW_PAGE) {
	faqError("新規作成より作成されたページに対しての回答は行えません");
}

//	カテゴリ内容取得
$arr_cate = $objCate->getCategoryInfo($cate_code, ' > ');

// DB内容取得
$strHTML = "";
$strHTML .= '	<div id="cms_search_html">' . PHP_EOL;
$strHTML .= '		<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-uploadlist">' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">質問タイトル</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($question_title) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">質問本文</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($question_context) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center" id="cms_cate">カテゴリ</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($arr_cate['name']) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center" id="cms_user_tr">回答</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($answer_context) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '		</table>' . PHP_EOL;
$strHTML .= '	</div>' . PHP_EOL;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>問い合わせ回答確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

	function cxSubmit() {
		if (<?=$status_flg?> == FLAG_ON){
			if ( confirm( "このお問い合わせは既に回答しています。\n再度回答を行いますか?" ) ) {
				$('cms_answer_form').submit();
			}
		}
		else if (confirm( "問い合わせ回答を行います。\nよろしいですか?" ) ) {
			$('cms_answer_form').submit();
		}
		return false;	
	}

//-->
</script>
</head>


<body id="cms8341-mainbg">
<form name="cms_answer_form" id="cms_answer_form" method="post"
	action="submit.php">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>

	<div align="center" id="cms8341-contents">
<div><img src="../images/bar_faq_answer_confirm.jpg" alt="問い合わせ回答確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
	
<?php
echo ($strHTML);
?>	
	
	<input type="hidden" id="cms_faq_id" name="cms_faq_id"
	value="<?=$faq_id?>"> <input type="hidden" id="cms_answer_context"
	name="cms_answer_context"
	value="<?=htmlspecialchars($answer_context)?>"> <input type="hidden"
	id="cms_cate_code" name="cms_cate_code" value="<?=$cate_code?>">
<p align="center" style="margin-top: 20px;"><a href="javascript:"
	onClick="return cxSubmit()"><img src="../images/btn_answer_100.jpg"
	alt="回答" width="100" height="20" border="0" style="margin: 10px"></a> <a
	href="javascript:history.back();"><img src="../images/btn_faq_bak.jpg"
	width="100" height="20" alt="戻る" border="0" style="margin: 10px"></a></p>


</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
