<?php
/*
 * FAQ機能：担当者振り分け 問い合わせ情報の削除
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ウェブマスターではない場合はエラー
if ($_POST['cms_faq_charge'] != $objLogin->get('dept_code') && $objLogin->get('class') != USER_CLASS_WEBMASTER) {
	faqError("不正なアクセスです。");
}

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

if (isset($_POST['cms_faq_id'])) {
	$temp_ary = array(
			'faq_id' => $_POST['cms_faq_id']
	);
	tbl_faqDelete($temp_ary);
}

header("Location: " . HTTP_ROOT . RPW . "/admin/special/faq/answer/index.php");
?>