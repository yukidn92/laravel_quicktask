<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
require ("./index_search.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>問い合わせ一覧</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/workflow.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/term.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<style>
<!--
body {
	padding-bottom: 10px;
}

#cms8341-log p {
	margin: 12px 0px;
}

#cms8341-searcharea {
	padding: 0px;
	margin-bottom: 20px;
	border-top: none;
	border-left: solid 1px #CCCCCC;
	border-right: solid 1px #CCCCCC;
	border-bottom: none;
}
//
-->
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

FAQ_STATUS_NOT_READ   = "<?=FAQ_STATUS_NOT_READ?>";
FAQ_STATUS_END_ANSWER = "<?=FAQ_STATUS_END_ANSWER?>";

//contentsmenu preload images
cxPreImages(cms8341admin_path+'/images/btn/btn_close_mini.jpg',
			cms8341admin_path+'/images/btn/btn_open_mini.jpg',
		    cms8341admin_path+'/images/btn/btn_search.jpg',
		    cms8341admin_path+'/images/icon/icon_calendar.jpg',
		    cms8341admin_path+'/images/layer/bar_progress.jpg'
);

/* 検索エリアの開閉 */
function cxBlind(t,btn) {
	Effect.toggle(t,'blind',{duration:0.5});
	var alt = $(btn).alt;
	if(alt=='開く') {
		$(btn).src = cms8341admin_path+'/images/btn/btn_close_mini.jpg';
		$(btn).alt = '閉じる';
	} else {
		$(btn).src = cms8341admin_path+'/images/btn/btn_open_mini.jpg';
		$(btn).alt = '開く';
	}
}

/*  検索処理 */
function cxSearch( page, search, faqID, nonlayer ) {

	if ( search == <?=FLAG_ON?> ) {
		// 検索前チェック
		if(cxSearchCheck() == false){
			return false;
		}
	}

	// パラメータ作成
	var prmAry = new Array();
		
	// -- ステータス
	if ( $('cms_status_' + FAQ_STATUS_NOT_READ) && $('cms_status_' + FAQ_STATUS_NOT_READ).checked == true ) {
		prmAry.push( 'cms_status_' + FAQ_STATUS_NOT_READ + '=' + encodeURIComponent( $F('cms_status_' + FAQ_STATUS_NOT_READ) ) );
	}
	if ( $('cms_status_' + FAQ_STATUS_END_ANSWER) && $('cms_status_' + FAQ_STATUS_END_ANSWER).checked == true ) {
		prmAry.push( 'cms_status_' + FAQ_STATUS_END_ANSWER + '=' + encodeURIComponent( $F('cms_status_' + FAQ_STATUS_END_ANSWER) ) );
	}
	// -- カテゴリ
	if ( $('cms_cate1') && Number($F('cms_cate1')) ) prmAry.push( 'cms_cate1=' + encodeURIComponent( $F('cms_cate1') ) );
	if ( $('cms_cate1') && Number($F('cms_cate2')) ) prmAry.push( 'cms_cate2=' + encodeURIComponent( $F('cms_cate2') ) );
	if ( $('cms_cate1') && Number($F('cms_cate3')) ) prmAry.push( 'cms_cate3=' + encodeURIComponent( $F('cms_cate3') ) );
	if ( $('cms_cate1') && Number($F('cms_cate4')) ) prmAry.push( 'cms_cate4=' + encodeURIComponent( $F('cms_cate4') ) );
	// -- キーワード
	if ( $('cms_keyword') && $F('cms_keyword') != "" ) prmAry.push( 'cms_keyword=' + encodeURIComponent( $F('cms_keyword') ) );
	// -- 掲載区分
	if( $('cms_publish_cls_0') && $('cms_publish_cls_0').checked == true ){
		prmAry.push( 'cms_publish_cls='+$F('cms_publish_cls_0') );
	} else if ( $('cms_publish_cls_1') && $('cms_publish_cls_1').checked == true ) {
		prmAry.push( 'cms_publish_cls='+$F('cms_publish_cls_1') );
	}
	// -- 登録日
	if ( $('cms_regist_datatime_sy')  && $F('cms_regist_datatime_sy') != "" ) prmAry.push( 'cms_regist_datatime_sy=' + encodeURIComponent( $F('cms_regist_datatime_sy') ) );
	if ( $('cms_regist_datatime_sm')  && $F('cms_regist_datatime_sm') != "" ) prmAry.push( 'cms_regist_datatime_sm=' + encodeURIComponent( $F('cms_regist_datatime_sm') ) );
	if ( $('cms_regist_datatime_sd')  && $F('cms_regist_datatime_sd') != "" ) prmAry.push( 'cms_regist_datatime_sd=' + encodeURIComponent( $F('cms_regist_datatime_sd') ) );
	if ( $('cms_regist_datatime_ey')  && $F('cms_regist_datatime_ey') != "" ) prmAry.push( 'cms_regist_datatime_ey=' + encodeURIComponent( $F('cms_regist_datatime_ey') ) );
	if ( $('cms_regist_datatime_em')  && $F('cms_regist_datatime_em') != "" ) prmAry.push( 'cms_regist_datatime_em=' + encodeURIComponent( $F('cms_regist_datatime_em') ) );
	if ( $('cms_regist_datatime_ed')  && $F('cms_regist_datatime_ed') != "" ) prmAry.push( 'cms_regist_datatime_ed=' + encodeURIComponent( $F('cms_regist_datatime_ed') ) );
	// -- 回答日
	if ( $('cms_answer_datatime_sy')  && $F('cms_answer_datatime_sy') != "" ) prmAry.push( 'cms_answer_datatime_sy=' + encodeURIComponent( $F('cms_answer_datatime_sy') ) );
	if ( $('cms_answer_datatime_sm')  && $F('cms_answer_datatime_sm') != "" ) prmAry.push( 'cms_answer_datatime_sm=' + encodeURIComponent( $F('cms_answer_datatime_sm') ) );
	if ( $('cms_answer_datatime_sd')  && $F('cms_answer_datatime_sd') != "" ) prmAry.push( 'cms_answer_datatime_sd=' + encodeURIComponent( $F('cms_answer_datatime_sd') ) );
	if ( $('cms_answer_datatime_ey')  && $F('cms_answer_datatime_ey') != "" ) prmAry.push( 'cms_answer_datatime_ey=' + encodeURIComponent( $F('cms_answer_datatime_ey') ) );
	if ( $('cms_answer_datatime_em')  && $F('cms_answer_datatime_em') != "" ) prmAry.push( 'cms_answer_datatime_em=' + encodeURIComponent( $F('cms_answer_datatime_em') ) );
	if ( $('cms_answer_datatime_ed')  && $F('cms_answer_datatime_ed') != "" ) prmAry.push( 'cms_answer_datatime_ed=' + encodeURIComponent( $F('cms_answer_datatime_ed') ) );
	// -- 掲載日
	if ( $('cms_publish_datatime_sy') && $F('cms_publish_datatime_sy') != "" ) prmAry.push( 'cms_publish_datatime_sy=' + encodeURIComponent( $F('cms_publish_datatime_sy') ) );
	if ( $('cms_publish_datatime_sm') && $F('cms_publish_datatime_sm') != "" ) prmAry.push( 'cms_publish_datatime_sm=' + encodeURIComponent( $F('cms_publish_datatime_sm') ) );
	if ( $('cms_publish_datatime_sd') && $F('cms_publish_datatime_sd') != "" ) prmAry.push( 'cms_publish_datatime_sd=' + encodeURIComponent( $F('cms_publish_datatime_sd') ) );
	if ( $('cms_publish_datatime_ey') && $F('cms_publish_datatime_ey') != "" ) prmAry.push( 'cms_publish_datatime_ey=' + encodeURIComponent( $F('cms_publish_datatime_ey') ) );
	if ( $('cms_publish_datatime_em') && $F('cms_publish_datatime_em') != "" ) prmAry.push( 'cms_publish_datatime_em=' + encodeURIComponent( $F('cms_publish_datatime_em') ) );
	if ( $('cms_publish_datatime_ed') && $F('cms_publish_datatime_ed') != "" ) prmAry.push( 'cms_publish_datatime_ed=' + encodeURIComponent( $F('cms_publish_datatime_ed') ) );
	// -- ターゲット
	if( $('cms_target_0') ){
		if( $('cms_target_0').checked == true ){
			prmAry.push( 'cms_target='+$F('cms_target_0') );
		} else if ( $('cms_target_1').checked == true ) {
			prmAry.push( 'cms_target='+$F('cms_target_1') );
		}
	}
	// -- 作業区分
	if( $('cms_create_cls_0') ){
		if( $('cms_create_cls_0').checked == true ){
			prmAry.push( 'cms_create_cls='+$F('cms_create_cls_0') );
		} else if ( $('cms_create_cls_1').checked == true ) {
			prmAry.push( 'cms_create_cls='+$F('cms_create_cls_1') );
		}
	}
	
	// -- ページ情報
	if ( page !== "" ) {
		prmAry.push( 'cms_page=' + page );
	}
	// -- Hidden
	prmAry.push( 'AjaxPost=<?=FLAG_ON?>' );

	if ( search == <?=FLAG_ON?> ) {
		prmAry.push( 'AjaxSearch=' + search );
		Element.hide("cms_search_result");
	}

	if ( faqID && faqID > 0 ) {
		prmAry.push( 'delFaqID=' + faqID );
	}

	// -- パラメーター作成
	prm = "";
	for ( i = 0 ; i < prmAry.length ; i ++ ) {
		if ( prm != "" ) prm += "&";
		prm += prmAry[i];
	}
	
	cxAjaxSearch( prm, nonlayer );
	
}

function cxAjaxSearch( prm, nonlayer ) {
	
	// 検索実行PHPの呼び出し(Ajax)
	var a = new Ajax.Updater(
		'cms_search_result',
		cms8341admin_path+'/special/faq/answer/index_search.php',
		{
			method: 'post',
			postBody: prm,
			// 成功した場合
			onSuccess: function( r ) {
				Element.show("cms_search_result");
				// 書き換え前のhtmlの高さ取得
				var DocSize1 = $("cms_search_result").offsetHeight;
				// htmlの書き換え
				$('cms_search_result').innerHTML = r.responseText;
				// ヘッダーメニューの位置が崩れる場合の対応
				if ( DocSize1 > $("cms_search_result").offsetHeight ) {
					if ( document.documentElement.scrollTop ) document.documentElement.scrollTop --;
					else document.body.scrollTop --;
				}
			},
			// 失敗した場合
			onFailure: function(request) {
				alert('検索に失敗しました');
			}
		}
	);

	return false;
	
}

// 検索前チェック
function cxSearchCheck(){

	// 日付チェック
	var msg = new Array();

	dc = faqDateCheck( "登録期間", "cms_regist_datatime"  )
	msg = msg.concat(dc);
	dc = faqDateCheck( "回答期間", "cms_answer_datatime"  )
	msg = msg.concat(dc);
	dc = faqDateCheck( "掲載期間", "cms_publish_datatime" )
	msg = msg.concat(dc);

	// エラー表示
	if (msg.length > 0) {
		cxComboHidden();
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}

	return true;
}

// 日付チェック
function faqDateCheck( name, id ) {

	isEmptyS = false;
	isEmptyE = false;

	// 開始：空の場合はtrueをセット
	if($F(id + '_sy') == "" && $F(id + '_sm') == "" && $F(id + '_sd') == ""){
		isEmptyS = true;
	}
	// 終了：空の場合はtrueをセット
	if($F(id + '_ey') == "" && $F(id + '_em') == "" && $F(id + '_ed') == ""){
		isEmptyE = true;
	}
	
	var dc = new Array();
	if(isEmptyS == false && isEmptyE == false){
		dc = cxDateCheckNew(id+"_", 'ymd', 1, name);
	} else if (isEmptyS == false && isEmptyE == true){
		dc = cxDateCheckNew(id+"_", 'ymd', 2, name);
	} else if (isEmptyS == true && isEmptyE == false){
		dc = cxDateCheckNew(id+"_", 'ymd', 3, name);
	}

	return dc;
}

/*  回答画面へ */
function cxAnswer( faq_id ){

	$('cms_faq_id').value   = faq_id;
	$('cms_fSearch').action = 'form.php';
	$('cms_fSearch').target = '_self';
	$('cms_fSearch').submit();

	return false;
}

/*  再回答の確認 */
function cxReAnswer( faq_id ){
	return cxAnswer( faq_id );
}

/*  回答内容画面へ */
function cxContents( faq_id ){

	$('cms_faq_id').value   = faq_id;
	$('cms_fSearch').action = 'answer_confirm.php';
	$('cms_fSearch').target = '_self';
	$('cms_fSearch').submit();

	return false;
}

/*  問い合わせ削除 */
function cxDelete( page, search, faqID ){

	if(cms_prev_layer) cms_prev_layer.style.display = 'none';
	
	if ( confirm( "問い合わせ情報を削除します。\nよろしいですか？" ) ) {
		cxSearch( page, search, faqID );
	}
	return true;
}

function loadAction( ) {
	cxSearch( 0, <?=FLAG_ON?> );
	return false;
}

function cxSendBack( faq_id, elm ) {

	if ( ! $(elm) || $(elm).value == "" ) {
		alert( "差し戻し理由が入力されていません。" );
		return false;
	}

	if ( confirm( "問い合わせを差し戻します。\nよろしいですか？" ) ) {
	
		var prm = "";
		prm  = "sbFaqID="+faq_id;
		prm += "&distribute="+encodeURIComponent( $(elm).value );
		prm += "&AjaxPost=<?=FLAG_ON?>";
		
		cxAjaxSearch( prm, 1 );
	}
	return false;
}

function cxSubmit(faq_id) {
	$('cms_confirm_'+faq_id).submit();
	return false;
}

/* オンロード で検索PHPを呼ぶ */
Event.observe( window, 'load', loadAction, false );

//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
	<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/special/faq/images/bar_faq_list.jpg"
	alt="問い合わせ一覧" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_topbg.jpg);height:31px;">
		<img src="<?=RPW?>/admin/page/publiclist/images/bar_search.jpg"
			alt="検索" width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search"><!-- Search Area _ Start -->
<form id="cms_fSearch" name="cms_fSearch" class="cms8341-form"
	method="post" action="">
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td><input type="hidden" id="FormPost" name="FormPost" value="1"> <input
			type="hidden" id="cms_faq_id" name="cms_faq_id" value=""> <input
			type="hidden" name="cms_dispMode" id="cms_dispMode" value=""> <input
			type="hidden" name="cms_page_id" id="cms_page_id" value="">
		<table border="0" cellspacing="0" cellpadding="5" align="center"
			width="100%">
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ステータス</th>
				<td align="left" valign="middle"><?=$searchHtml['status']?></td>
			</tr>
			<tr id="cms_cate_tr">
				<th width="120" align="left" valign="middle" nowrap scope="row">カテゴリ</th>
				<td><?=$searchHtml['category']?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><labelfor"cms_keyword">キーワード</label></th>
				<td align="left" valign="middle"><?=$searchHtml['keyword']?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">掲載区分</th>
				<td align="left" valign="middle"><?=$searchHtml['publish_cls']?></td>
			</tr>
			<tr><?=$searchHtml['regist_datatime']?></tr>
			<tr><?=$searchHtml['answer_datatime']?></tr>
			<tr><?=$searchHtml['publish_datatime']?></tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">作業区分</th>
				<td align="left" valign="middle"><?=$searchHtml['create_cls']?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">対象</th>
				<td align="left" valign="middle"><?=$searchHtml['target']?></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch( 0, <?=FLAG_ON?> )"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</form>
<!-- Search Area _ End --></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;">
		<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる"
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a></td>
	</tr>
</table>
</div>
<div id="cms_search_result">
<?php
print($strHTML);
?>
			</div>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->

<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<?php
// 処理進捗用レイヤー
$filename = APPLICATION_ROOT . '/common/templates/l_progress.txt';
$fp = fopen($filename, "r");
$progressStr = fread($fp, filesize($filename));
fclose($fp);
$progressStr = str_replace('src="/admin/', 'src="' . RPW . "/admin/", $progressStr);
print $progressStr;
?>
</body>
</html>