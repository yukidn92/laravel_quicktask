<?php
/*
 * FAQ機能：新規登録
 */
global $objCnc;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

// DB登録
if ($objFaq->insert($arrAry) === FALSE) {
	// エラー処理
	faqError("FAQ情報の登録に失敗しました。");
}

?>