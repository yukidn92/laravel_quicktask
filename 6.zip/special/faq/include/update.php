<?php
/*
 * FAQ機能：更新登録
 */
global $objCnc;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

// IDチェック
if (!isset($arrAry['faq_id'])) {
	// エラー処理
	faqError("FAQ情報の更新に失敗しました。");
}

// DB登録
if ($objFaq->update($arrAry) === FALSE) {
	// エラー処理
	faqError("FAQ情報の更新に失敗しました。");
}

?>