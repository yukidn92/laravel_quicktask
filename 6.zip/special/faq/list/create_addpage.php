<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	faqError("不正なアクセスです。");
}

$errFlg = FLAG_OFF;

// 親ページIDが渡されなければエラー
if (!isset($_POST['cms_parent_id'])) {
	$errFlg = FLAG_ON;
}
// テンプレート種類が渡されなければエラー
if ((!isset($_POST['cms_template_kind'])) || ($_POST['cms_template_kind'] == '')) {
	$errFlg = FLAG_ON;
}
// カテゴリーコードが渡されなければエラー
if (!isset($_POST['cms_cate_code'])) {
	$errFlg = FLAG_ON;
}
// 保存先が渡されなければエラー
if (!isset($_POST['cms_dir_path']) || !isset($_POST['cms_filename'])) {
	$errFlg = FLAG_ON;
}

// エラー表示
if ($errFlg == FLAG_ON) {
	faqError("パラメータが不正です。");
}

// 保存先の存在チェック
$filename = DOCUMENT_ROOT . RPW . $_POST['cms_dir_path'] . $_POST['cms_filename'];
if (@file_exists($filename)) {
	faqError($filename . ' は既に存在します。');
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);

// 新しいページIDの取得
$PID = $objPage->getSeqNextval();

$tpl_kind = $_POST['cms_template_kind'];
$cate_code = $_POST['cms_cate_code'];
$template_ver = "";
$context = "";
$inquiry_id = $objInquiry->getSeqNextval();
$inquiry_flg = FLAG_ON;

// テンプレート読み込み
if ($objTool->selectTemplate($_POST['cms_template_id']) === FALSE) {
	user_error("Can't find template data.<br>dac_tools selectTemplate(" . $_POST['cms_template_id'] . ")", E_USER_ERROR);
}
$template_path = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
if (!file_exists($template_path)) {
	user_error("The template file doesn't exist.<br>temp_txt[" . $objTool->fld['temp_txt'] . "]", E_USER_ERROR);
}
// テンプレートのバージョン（最新バージョン）
$template_ver = $objTool->fld['template_ver'];

// テンプレートの読み込み
$fp = fopen($template_path, "r");
$htmlStr = fread($fp, filesize($template_path));
fclose($fp);

// FAQ一覧用テンプレート(txt)の読み込み
// $context = getMidString($htmlStr, '<!-- InstanceBeginEditable name="contents" -->', '<!-- InstanceEndEditable -->');
$fp = fopen(APPLICATION_ROOT . "/common/templates/faq_list_body.txt", "r");
$context = fread($fp, filesize(APPLICATION_ROOT . "/common/templates/faq_list_body.txt"));
fclose($fp);

// 編集領域へ自動挿入
$context = str_replace("<!-- page_title area -->", $_POST['cms_page_title'], $context);

// ぱんくずパス
$ancestor_path = "";
$parent_id = "";
// 親ページIDに空白以外が渡された場合
if (isset($_POST['cms_parent_id']) && $_POST['cms_parent_id'] != "") {
	// 親ページ情報（tbl_publish_pageから）の取得配列$parent_fldに格納
	if ($objPage->selectFromID($_POST['cms_parent_id'], 1) === FALSE) {
		user_error("Can't find parent page data.<br>cms_parent_id[" . $_POST['cms_parent_id'] . "]", E_USER_ERROR);
	}
	$ancestor_path = ($objPage->fld['ancestor_path'] != '') ? $objPage->fld['ancestor_path'] . ',' : '';
	$ancestor_path .= $objPage->fld['file_path'];
	$parent_id = $_POST['cms_parent_id'];
}

// 登録情報のセット
$ary1 = array(
		'page_id' => $PID, 
		'cate_code' => $cate_code, 
		'template_id' => $_POST['cms_template_id'], 
		'template_ver' => $template_ver, 
		'parent_id' => $parent_id, 
		'ancestor_path' => $ancestor_path, 
		'user_id' => $objLogin->get('user_id'), 
		'dir_path' => $_POST['cms_dir_path'], 
		'filename' => $_POST['cms_filename'], 
		'file_path' => $_POST['cms_dir_path'] . $_POST['cms_filename'], 
		'page_title' => $_POST['cms_page_title'], 
		'header' => $_POST['cms_page_title'], 
		'context' => $context, 
		'keywords' => "", 
		'description' => "", 
		'summary' => "", 
		'index_title' => "", 
		'contents_top_flg' => 0, 
		'status' => STATUS_PUBLISH_WAIT, 
		'template_kind' => $_POST['cms_template_kind'], 
		'faq_id' => ""
);
$ary1['menu_generation_order'] = $objPage->getNextMenuGenerationOrder($parent_id);


$Y = date('Y');
$n = date('n');
$j = date('j');
$H = date('H');
$ary1['publish_start'] = $Y . '-' . $n . '-' . $j . ' ' . $H . ':00:00';

$Y = date('Y', strtotime("+" . PUBLISH_END_MONTH . " month"));
$n = date('n', strtotime("+" . PUBLISH_END_MONTH . " month"));
$j = date('j', strtotime("+" . PUBLISH_END_MONTH . " month"));
$ary1['publish_end'] = $Y . '-' . $n . '-' . $j . ' ' . $H . ':00:00';

$objCnc->begin();

// 公開情報の登録
if ($objPage->insert($ary1, PUBLISH_TABLE) === FALSE) {
	faqError("新規ページの作成に失敗しました。");
}

// 問い合わせの登録
$ary1['inquiry_memo'] = "";
$ary1['inquiry_id'] = $inquiry_id;
$ary1['inquiry_flg'] = $inquiry_flg;

// 問い合わせの登録 (INSERT INTO tbl_publish_inquiry)
$no = 1;
for($i = 1; $i < $_POST['cms_inquiry_cnt'] + 1; $i++) {
	if (!isset($_POST['cms_inquiry_dept1_' . $i])) continue;
	$dept_code = "";
	$inq_ary = array();
	$inq_ary['inquiry_id'] = $inquiry_id;
	$inq_ary['inquiry_no'] = $no;
	if ($_POST['cms_inquiry_dept3_' . $i]) {
		$dept_code = $_POST['cms_inquiry_dept3_' . $i];
	}
	else if ($_POST['cms_inquiry_dept2_' . $i]) {
		$dept_code = $_POST['cms_inquiry_dept2_' . $i];
	}
	else if ($_POST['cms_inquiry_dept1_' . $i]) {
		$dept_code = $_POST['cms_inquiry_dept1_' . $i];
	}
	$inq_ary['dept_code'] = $dept_code;
	$inq_ary['name'] = $_POST['cms_inquiry_charge_' . $i];
	$inq_ary['anex_number'] = $_POST['cms_inquiry_anExtensionNumber_' . $i];
	$inq_ary['drxt_number'] = $_POST['cms_inquiry_directNumber_' . $i];
	$inq_ary['fax'] = $_POST['cms_inquiry_fax_' . $i];
	$inq_ary['email'] = $_POST['cms_inquiry_email_' . $i];
	if ($inq_ary['dept_code'] == "" && $inq_ary['name'] == "" && $inq_ary['anex_number'] == "" && $inq_ary['drxt_number'] == "" && $inq_ary['fax'] == "") {
		continue;
	}
	$objInquiry->insert($inq_ary, WORK_TABLE);
	$no++;
}
if ($objInquiry->insertWorkFromPublish($inquiry_id) === FALSE) {
	faqError("新規ページの作成に失敗しました。");
}

// 編集情報の登録（INSERT INTO tbl_work_page SELECT FROM tbl_work_page）


if ($objPage->insertWorkFromPublish($PID, $objLogin->login) === FALSE) {
	faqError("新規ページの作成に失敗しました。");
}

// カテゴリーテーブルの faqpage_id 更新
$aryCate = array(
		"cate_code" => $cate_code, 
		"faqpage_id" => $PID
);
if ($objCate->update($aryCate) === FALSE) {
	faqError("新規ページの作成に失敗しました。");
}

// デフォルトライブラリを設定
$libHtmlStr = $htmlStr;
$libAry = array();
// ライブラリ領域を検索
while (getLibraryArea($libAry, $libHtmlStr, 0)) {
	// ライブラリ情報を登録
	if (isset($libAry["id"]) && $libAry["id"] != "" && $objLibrary->selectFromID($libAry["id"]) !== FALSE) {
		// 登録情報の作成
		$db_ary = array();
		$db_ary['page_id'] = $PID;
		$db_ary['area'] = $libAry["area"];
		$db_ary['library_id'] = $libAry["id"];
		$db_ary['library_ver'] = $objLibrary->fld['library_ver'];
		// DBに登録
		if ($objHandler->insertLibrary($db_ary, WORK_TABLE) === FALSE) faqError('ライブラリ設定の登録に失敗しました。', E_USER_ERROR);
	}
	// 登録したエリア情報を対象から除外
	$libHtmlStr = str_replace($libAry["match"], "", $libHtmlStr);
}

// 生成HTMLの内容
mkNewPage($PID, $_POST['cms_dir_path'] . $_POST['cms_filename']);

$objCnc->commit();

// FAQインデックス新規作成完了画面へ
header("Location: " . HTTP_ROOT . RPW . "/admin/special/faq/list/create_complete.php");
// 作成したページ（編集モード）に移動
// header("Location: ".HTTP_ROOT.RPW.$ary1['file_path']."?edit=1")


?>
