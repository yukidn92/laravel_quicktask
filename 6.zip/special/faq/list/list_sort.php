<?php
/*
 * FAQ機能：カテゴリ別表示順設定画面
 */
//外部ファイル読み込み
require_once ("../.htsetting");
require_once ("../include/common.inc");

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);

//変数の指定
$CATEGORY_CODE = ""; //カテゴリコード
$strHTML = ""; //HTML表示用文字列
$data_Ary = array(); //データ用配列
$search_code = ""; //検索カテゴリコード
$is_lock = lock_file_management('check'); // アップロード処理中か確認


//POST値の取得
$CATEGORY_CODE = (isset($_POST['cms_cate_code']) ? $_POST['cms_cate_code'] : "");

//引数のチェック
if ($CATEGORY_CODE == "") {
	//エラー
	faqError("不正なパラメータです。");
	exit();
}

//カテゴリの情報を取得
if (!$objCate->selectFromCode($CATEGORY_CODE)) {
	//エラー
	faqError("カテゴリ情報の取得に失敗しました。");
	exit();
}
//検索用のカテゴリコードを作成
if ($objCate->fld['faq_children_flg'] == FLAG_ON) {
	$cate_ary = getCateCode($CATEGORY_CODE);
	for($i = 1; $i <= $cate_ary['level']; $i++) {
		$search_code .= $cate_ary['cate' . $i];
	}
	$search_code .= "%";
}
else
	$search_code = $CATEGORY_CODE;
	
//カテゴリコードによって、FAQテーブルから公開されているデータを抽出
$sql = "SELECT t.*,p.file_path FROM " . $objFAQ->table_name . " as t LEFT JOIN tbl_publish_page AS p ON t.faq_id = p.faq_id" . " WHERE ( " . $objFAQ->_addslashesC('t.cate_code', $search_code, 'LIKE') . " AND " . $objFAQ->_addslashesC('t.publish_cls', FAQ_PUBLISH_CLASS_END, '=', 'INT') . " )" . " AND " . createNotDisasterPagesOnlySql("p") . " ORDER BY sort_order";
$objFAQ->execute($sql);

//抽出した条件から、配列を作成
while ($objFAQ->fetch()) {
	$fld = $objFAQ->fld;
	$data_Ary[(isset($fld['special_out_flg']) ? $fld['special_out_flg'] : 0)][] = array(
			'faq_id' => $fld['faq_id'], 
			'question_title' => $fld['question_title'], 
			'file_path' => $fld['file_path']
	);
}

//抽出した条件から、リストを作成
for($sp_out_flg = 1; $sp_out_flg >= 0; $sp_out_flg--) {
	$strHTML .= '<div style="margin-bottom:20px;">' . ($sp_out_flg == FLAG_ON ? '<img src="' . RPW . '/admin/special/faq/images/title_special_out.jpg" width="430" height="20" alt="特だし" border="0">' : '<img src="' . RPW . '/admin/special/faq/images/title_normal.jpg" width="430" height="20" alt="通常" border="0">') . '</div>';
	$strHTML .= '<table border="0" id="sp_out_flg_' . $sp_out_flg . '" width="100%" class="cms8341-dataTable" style="margin-bottom:20px;">';
	$strHTML .= '<tbody>';
	$strHTML .= '<tr align="center" valign="middle">';
	$strHTML .= '<th width="20%" style="padding:5px;background-color:#F0F0F0;">表示順</td>';
	$strHTML .= '<th width="70%" style="padding:5px;background-color:#F0F0F0;">問い合わせタイトル</td>';
	$strHTML .= '<th width="10%" style="padding:5px;background-color:#F0F0F0;">特だし</td>';
	$strHTML .= '</tr>';
	$strHTML .= '</tbody>';
	$strHTML .= '<tbody id="tbody_' . $sp_out_flg . '">';
	//データがある場合
	if (isset($data_Ary[$sp_out_flg])) {
		foreach ($data_Ary[$sp_out_flg] as $key => $value) {
			$strHTML .= '<tr id="faq_id_' . $value['faq_id'] . '_tr" valign="middle" style="padding:10px;">';
			//表示順
			$strHTML .= '<td id="faq_id_' . $value['faq_id'] . '_td_sort_order" align="center">';
			//「上へ」ボタン
			$strHTML .= '<a href="javascript:void(0)" id="faq_id_' . $value['faq_id'] . '_a_up" onClick="cx_Shift_Tr(\'faq_id_' . $value['faq_id'] . '_tr\',\'UP\')">';
			$strHTML .= '<img id="faq_id_' . $value['faq_id'] . '_img_up" src="' . RPW . '/admin/images/btn/btn_up_on.jpg" width="61" height="20" alt="上へ" border="0" style="margin:0px;padding:0px;vertical-align:middle;">';
			$strHTML .= '</a>';
			$strHTML .= '&nbsp;&nbsp;&nbsp;';
			//「下へ」ボタン
			$strHTML .= '<a href="javascript:void(0)" id="faq_id_' . $value['faq_id'] . '_a_dn" onClick="cx_Shift_Tr(\'faq_id_' . $value['faq_id'] . '_tr\',\'DN\')">';
			$strHTML .= '<img id="faq_id_' . $value['faq_id'] . '_img_dn" src="' . RPW . '/admin/images/btn/btn_down_on.jpg" width="61" height="20" alt="下へ" border="0" style="margin:0px;padding:0px;vertical-align:middle;">';
			$strHTML .= '</a>';
			$strHTML .= '</td>';
			//FAQ名称
			$strHTML .= '<td id="faq_id_' . $value['faq_id'] . '_td_question_title" align="left" style="padding:5px;">';
			$strHTML .= '<a href="' . HTTP_REAL_ROOT . $value['file_path'] . '" target="_blank">' . htmlDisplay($value['question_title']) . '</a>';
			$strHTML .= '</td>';
			//特だし
			$strHTML .= '<td id="faq_id_' . $value['faq_id'] . '_td_special_out_flg" align="center">';
			$strHTML .= '<input name="faq_id_' . $value['faq_id'] . '_chk" id="faq_id_' . $value['faq_id'] . '_chk" type="checkbox" value="' . FLAG_ON . '" onClick="return cx_ChangeSP(' . $value['faq_id'] . ');"' . ($sp_out_flg == FLAG_ON ? ' checked' : '') . '>';
			$strHTML .= '</td>';
			$strHTML .= '</tr>';
		}
	}
	$strHTML .= '</tbody>';
	$strHTML .= '</table>';
	$strHTML .= '<br><br>';
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>カテゴリ別表示順設定画面</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/list_sort.js"
	type="text/javascript"></script>
<script type="text/javascript">
			<!--
				<?php
				echo loadSettingVars();
				?>
			//-->
		</script>
</head>
<body id="cms8341-mainbg">
		<?php
		//ヘッダーメニュー挿入
		$headerMode = 'faq';
		include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
		?>
		<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/special/faq/images/bar_list_sort.jpg"
	alt="カテゴリ別表示順設定" width="920" height="30"></div>
<?php
if ($is_lock) {
	?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
現在アップロード処理中のため一覧ページの再公開を行うことができません。<br>
一覧ページの再公開を行う場合はしばらく時間をおいてから再度お試しください。</div>
<?php
}
?>
<div class="cms8341-area-corner">
				<?=$strHTML?>
				<?php
				//一覧ページが存在する場合
				if ($objCate->fld['faqpage_id'] != "") {
					print('<div style="margin-top:10px;margin-bottom:30px;border:solid 1px #CCCCCC;background-color:#FFFFCC;padding:8px;">');
					print('<input type="checkbox" name="cms_public_page_flg" id="cms_public_page_flg" value="' . $CATEGORY_CODE . '"' . ($is_lock ? " disabled" : '') . '><label for="cms_public_page_flg">一覧ページの再公開を行う</label>');
					print('</div>');
				}
				?>
				<div align="center"><a href="javascript:void(0)"
	onClick="return cx_Submit()"><img
	src="<?=RPW?>/admin/images/btn/btn_set.jpg" width="100" height="20"
	alt="設定する" border="0" style="margin: 10px"></a> <a href="index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel.jpg" width="101" height="21"
	alt="キャンセル" border="0" style="margin: 10px"></a></div>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
<!--***処理メッセージレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div align="center"
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理メッセージレイヤー ここまで********************************--></div>
<!-- cms8341-contents -->
<script type="text/javascript">
			<!--
				cx_ChangeShiftButton();
			-->
		</script>
</body>
</html>
