<?php
/*
 * FAQ機能：カテゴリ別表示順設定登録処理
 */
//外部ファイル読み込み
require_once ("../.htsetting");

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);

//ページ内定数


//変数の指定
$faq_id_ary = array(); //FAQID配列
$sp_out_flg_ary = array(); //特だしフラグ配列
$public_page_cate_code = ""; //一覧ページ再公開フラグ

//POST値の取得
$tmp_faq_id = (isset($_POST['cms_faq_id_ary']) ? $_POST['cms_faq_id_ary'] : "");
$tmp_sp_out_flg = (isset($_POST['cms_sp_out_flg_ary']) ? $_POST['cms_sp_out_flg_ary'] : "");
$public_page_cate_code = (isset($_POST['cms_public_page_flg']) ? $_POST['cms_public_page_flg'] : "");

// 即公開を行う場合は排他制御を行う
if ($public_page_cate_code != "") {
	if (lock_file_management('lock') === FALSE) {
		//エラー
		print("現在アップロード処理中のため一覧ページの再公開を行うことができません。\nしばらく時間をおいてから再度お試しください。");
		exit();
	}
}

//POSTより取得したデータを配列化
$faq_id_ary = explode(',', $tmp_faq_id);
$sp_out_flg_ary = explode(',', $tmp_sp_out_flg);

//トランザクション開始
$objCnc->begin();
//DB登録処理
foreach ($faq_id_ary as $key => $val) {
	$temp_ary = array(
			'faq_id' => $val, 
			'sort_order' => $key, 
			' special_out_flg' => $sp_out_flg_ary[$key]
	);
	if (!$objFAQ->update($temp_ary)) {
		//エラー
		print("設定に失敗しました。");
		$objCnc->rollback();
		lock_file_management('unlock');
		exit();
	}
}

//一覧ページ再公開処理
if ($public_page_cate_code != "") {
	if (!faq_Re_Public_Page($public_page_cate_code)) {
		//エラー
		print("一覧ページの再公開に失敗しました。");
		$objCnc->rollback();
		lock_file_management('unlock');
		exit();
	}
}
//トランザクション終了
$objCnc->commit();
lock_file_management('unlock');
exit();
?>
