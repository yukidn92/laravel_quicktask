<?php
/*
 * FAQ機能：下位分類リスト対象設定画面
 */
//外部ファイル読み込み
require_once ("../.htsetting");
require_once ("../include/common.inc");

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);

//変数の指定
$CATEGORY_CODE = ""; //カテゴリコード
$parent_category_name = ""; //親カテゴリ名称
$category_name = ""; //カテゴリ名称


//POST値の取得
$CATEGORY_CODE = (isset($_POST['cms_cate_code']) ? $_POST['cms_cate_code'] : "");

//引数のチェック
if ($CATEGORY_CODE == "") {
	//エラー
	faqError("不正なパラメータです。");
	exit();
}

//カテゴリコードから分類名を取得
$cate_ary = getCateCode($CATEGORY_CODE);
for($i = 1; $i <= $cate_ary['level']; $i++) {
	$objCate->selectFromCode($cate_ary['cate' . $i . '_code']);
	if ($i > 1) $parent_category_name .= CATE_NAME_DELIMITER;
	$parent_category_name .= $objCate->fld['name'];
	if ($i == $cate_ary['level']) $category_name = $objCate->fld['name'];
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>リスト対象設定画面</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
			<!--
				/**
				 * 設定ボタンを押した時の処理
				 * @return 登録処理に成功した場合は、true。それ以外の場合はfalseを返す
				 */
				function cx_Submit(){
					//設定中レイヤー表示
					$('cms8341-progressmsg').innerHTML = '設定中．．．';
					cxLayer('cms8341-progress',1,500,500);
					//変数の宣言
					var faq_cate_code = $('cms_faq_cate_code').value;
					var children_category_flg = ($('cms_children_category_flg').checked ? $('cms_children_category_flg').value : '');

					//登録処理用PHPを呼び出す(Ajax)
					var a = new Ajax.Request(
						baseUrl + 'admin/special/faq/list/prev_pageinfo_complete.php',
						{
							method: 'post',
							postBody: 'cms_faq_cate_code=' + faq_cate_code + '&cms_children_category_flg=' + children_category_flg,
							//成功した場合
							onComplete: function(originalRequest){
								//設定中レイヤーを閉じる
								cxLayer('cms8341-progress',0);
								//エラーがあった場合
								if(originalRequest.responseText != "") alert(originalRequest.responseText);
								//正常終了した場合
								else{
									<?php
									//決定後の遷移先を変える
									//下階層にFAQページがあるかチェック
									$cate_code = htmlspecialchars($objCate->fld['cate_code']);
									$prev_sortlist_btn = FLAG_OFF;
									$search_code = "";
									$cate_ary = getCateCode($cate_code);
									for($i = 1; $i <= $cate_ary['level']; $i++) {
										$search_code .= $cate_ary['cate' . $i];
									}
									$search_code .= "%";
									$sql = "SELECT * FROM " . $objFAQ->table_name . " WHERE ( " . $objFAQ->_addslashesC('cate_code', $search_code, 'LIKE') . " AND " . $objFAQ->_addslashesC('publish_cls', FAQ_PUBLISH_CLASS_END, '=', 'INT') . ")";
									$objFAQ->execute($sql);
									if ($objFAQ->getRowCount() > 0) $prev_sortlist_btn = FLAG_ON;
									//ソート
									if (isset($objCate->fld['faqpage_id']) && $objCate->fld['faqpage_id'] != "" && $prev_sortlist_btn == FLAG_ON) {
										print("$('list_sort_form').target = '_self';");
										print("$('list_sort_form').submit();");
										print("return false;");
									} //一覧
									else
										print("location.replace('index.php');");
									?>
								}
							},
							//失敗した場合
							onFailure: function(request){
								//設定中レイヤーを閉じる
								cxLayer('cms8341-progress',0);
								alert('登録処理に失敗しました');   
							}
						}   
					);
					return false;
				}
			-->
		</script>
</head>
<body id="cms8341-mainbg">
		<?php
		//ヘッダーメニュー挿入
		$headerMode = 'faq';
		include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
		?>
		<div align="center" id="cms8341-contents">
<div><img
	src="<?=RPW?>/admin/special/faq/images/bar_faq_listsetting.jpg"
	alt="リスト対象設定" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div
	style="margin-top: 10px; margin-bottom: 30px; border: solid 1px #CCCCCC; background-color: #FFFFCC; padding: 8px;">
					<?=$parent_category_name?>
				</div>
<strong><?=$category_name?></strong>
<p>下記のチェックボックスをチェック状態にすることにより、下位の分類で設定されている「<?=FAQ_CONTENT_NAME?>」を含めることが出来ます。</p>
<div align="center" style="margin-top: 40px; margin-bottom: 40px;"><input
	type="checkbox" name="cms_children_category_flg"
	id="cms_children_category_flg" value="<?=FLAG_ON?>"
	<?=(isset($objCate->fld['faq_children_flg']) && $objCate->fld['faq_children_flg'] == FLAG_ON ? " checked" : "")?>><label
	for="cms_children_category_flg">分類の下の階層を含める</label> <input
	type="hidden" name="cms_faq_cate_code" id="cms_faq_cate_code"
	value="<?=$CATEGORY_CODE?>"></div>
<div align="center" style="margin-top: 20px;"><a
	href="javascript:void(0)" onClick="return cx_Submit()"><img
	src="<?=RPW?>/admin/images/btn/btn_set.jpg" width="100" height="20"
	alt="設定する" border="0" style="margin: 10px"></a> <a href="index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel.jpg" width="101" height="21"
	alt="キャンセル" border="0" style="margin: 10px"></a></div>
<form id="list_sort_form" name="list_sort_form" method="POST"
	action="./list_sort.php"><input type="hidden" id="cms_cate_code"
	name="cms_cate_code" value="<?=$CATEGORY_CODE?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
<!--***処理メッセージレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div align="center"
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理メッセージレイヤー ここまで********************************--></div>
<!-- cms8341-contents -->
</body>
</html>
