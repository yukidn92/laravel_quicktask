<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// ** 定数 ----------------------------------
define("G_CATE_LEVEL01", 1); //第1分類
define("G_CATE_LEVEL02", 2); //第2分類
define("G_CATE_LEVEL03", 3); //第3分類
define("G_CATE_LEVEL04", 4); //第4分類


//TOPページID
$page_id = 1;

// スタイル
$CATE_CSS_CLASS = array(
		G_CATE_LEVEL01 => "dir_first", 
		G_CATE_LEVEL02 => "dir_second", 
		G_CATE_LEVEL03 => "dir_third", 
		G_CATE_LEVEL04 => "dir_fourth"
);

// POST
$CATE_SELECT = (isset($_POST['cms_cate_code'])) ? $_POST['cms_cate_code'] : "";
$CATE_SELECT_LEVEL = (isset($_POST['cms_cate_level'])) ? $_POST['cms_cate_level'] : 1;

// 画像
$CATE_PLUS_IMG = RPW . "/admin/master/images/dir_plus.jpg";
$CATE_MINUS_IMG = RPW . "/admin/master/images/dir_minus.jpg";

// 開く、閉じるのモード
define("PLUS_MODE", FLAG_ON);
define("MINUS_MODE", FLAG_OFF);

// カテゴリ一覧を取得
$where = "";
$filed = "c.cate_code, c.name, c.level, c.faqpage_id, c.faq_children_flg, f.publish_cls, p.work_class, p.file_path";
$sortOrder = "c.cate_code ASC";
$table = " tbl_category AS c LEFT JOIN (" . " SELECT MAX(publish_cls) AS publish_cls, cate_code FROM tbl_faq WHERE 1 GROUP BY cate_code" . " ) AS f ON ( c.cate_code = f.cate_code )" . " LEFT JOIN tbl_publish_page AS p ON ( c.faqpage_id = p.page_id ) GROUP BY c.cate_code";
$objDac->select($where, $filed, $sortOrder, "", "", $table);

// DB内容取得
$strHTML = "";
if ($objDac->getRowCount() > 0) {
	while ($objDac->fetch()) {
		
		// DB値
		$level = $objDac->fld['level'];
		$cate_code = htmlspecialchars($objDac->fld['cate_code']);
		$name = htmlDisplay($objDac->fld['name']);
		$publish_cls = $objDac->fld['publish_cls'];
		$faqpage_id = $objDac->fld['faqpage_id'];
		$faq_children_flg = $objDac->fld['faq_children_flg'];
		$work_class = $objDac->fld['work_class'];
		$file_path = $objDac->fld['file_path'];
		$prev_sortlist_btn = FLAG_OFF;
		
		if ($CATE_SELECT_LEVEL < $level) continue;
		if ($CATE_SELECT != "") {
			if (substr($CATE_SELECT, 0, 3 * ($level - 1)) != substr($cate_code, 0, 3 * ($level - 1))) continue;
		}
		
		// style
		$css_cls = (isset($CATE_CSS_CLASS[$level])) ? $CATE_CSS_CLASS[$level] : "dir_first";
		$css_disp = ($level <= $CATE_SELECT_LEVEL) ? $css_disp = "display:block;" : "display:none;";
		// image
		$img = $CATE_PLUS_IMG;
		$mode = PLUS_MODE;
		
		if ($level < $CATE_SELECT_LEVEL && substr($CATE_SELECT, 0, 3 * $level) == substr($cate_code, 0, 3 * $level)) {
			$img = $CATE_MINUS_IMG;
			$mode = MINUS_MODE;
		}
		
		// 余分に表示される項目の削除
		if ($level > G_CATE_LEVEL01 && $level <= $CATE_SELECT_LEVEL && substr($CATE_SELECT, 0, 3 * ($level - 1)) != substr($cate_code, 0, 3 * ($level - 1))) $css_disp = "display:none;";
		if ($level <= $CATE_SELECT_LEVEL && substr($CATE_SELECT, 0, 3 * ($level - 1)) != substr($cate_code, 0, 3 * ($level - 1))) $css_disp = "display:none;";
		
		// html表記の作成
		$strHTML .= "<p align=\"left\" class=\"" . $css_cls . "\" style=\"" . $css_disp . "\">";
		
		if ($level < G_CATE_LEVEL04) {
			$strHTML .= "<a href=\"javascript:\" onClick=\"return cxShow('" . $cate_code . "'," . $level . ",'" . $mode . "')\">";
			$strHTML .= "<img src=\"" . $img . "\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
			$strHTML .= "</a>";
		}
		else {
			$strHTML .= "<img src=\"" . RPW . "/admin/master/images/dir_none.jpg\" alt=\"\" width=\"60\" height=\"20\" border=\"0\">";
		}
		
		// 分類名
		if ($faqpage_id != "" && $work_class == WORK_CLASS_PUBLISH) {
			$strHTML .= "<a href=\"javascript:\" onClick=\"return cxPreview('cms_fCateList', " . $faqpage_id . ", 1)\">" . $name . "</a>";
		}
		elseif ($faqpage_id != "" && $work_class == WORK_CLASS_NEW) {
			$strHTML .= "<a href=\"javascript:\" onClick=\"return cxPreview('cms_fCateList', " . $faqpage_id . ", 2)\">" . $name . "</a>";
		}
		else {
			$strHTML .= $name;
		}
		
		// 一覧ページ作成へのボタン
		if ($objLogin->get('class') == USER_CLASS_WEBMASTER && $faqpage_id == "") {
			$strHTML .= "　<a href=\"javascript:\" onClick=\"return cxCreate('" . $cate_code . "')\"><img src=\"" . RPW . "/admin/special/faq/images/btn_newpage_create.jpg\" alt=\"新規作成\"width=\"100\" height=\"20\" border=\"0\"></a>";
		}
		else {
			// 一覧ページがある場合はパス表示
			if ($faqpage_id != "") {
				$strHTML .= "&nbsp;（" . $file_path . "）";
			}
		}
		//下階層にFAQページが存在するかチェック
		$search_code = "";
		$cate_ary = getCateCode($cate_code);
		for($i = 1; $i <= $cate_ary['level']; $i++) {
			$search_code .= $cate_ary['cate' . $i];
		}
		$search_code .= "%";
		$sql = "SELECT * FROM " . $objFAQ->table_name . " WHERE ( " . $objFAQ->_addslashesC('cate_code', $search_code, 'LIKE') . " AND " . $objFAQ->_addslashesC('publish_cls', FAQ_PUBLISH_CLASS_END, '=', 'INT') . ")";
		$objFAQ->execute($sql);
		if ($objFAQ->getRowCount() > 0) $prev_sortlist_btn = FLAG_ON;
		// 並び替えへのボタン
		if ($publish_cls == FAQ_PUBLISH_CLASS_END || $faq_children_flg == FLAG_ON && $prev_sortlist_btn == FLAG_ON) {
			$strHTML .= "　<a href=\"javascript:\" onClick=\"return cxSort('" . $cate_code . "')\"><img src=\"" . RPW . "/admin/special/faq/images/btn_list.jpg\" alt=\"表示順変更\" width=\"101\" height=\"21\" border=\"0\"></a>";
		}
		//情報の表示+下の階層を表示するかどうか
		if ($level < G_CATE_LEVEL04 && $prev_sortlist_btn == FLAG_ON) {
			$strHTML .= "　<a href=\"javascript:\" onClick=\"return cxPrev('" . $cate_code . "')\"><img src=\"" . RPW . "/admin/special/faq/images/btn_faq_listsetting.jpg\" alt=\"リスト対象設定\" width=\"120\" height=\"20\" border=\"0\"></a>";
		}
		
		$strHTML .= "</p>" . PHP_EOL;
	}
}

//TOPページのページIDを取得
if ($objPage->selectFromPath(SITE_TOP_PAGE, PUBLISH_TABLE, 'page_id')) $page_id = $objPage->fld['page_id'];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>分類一覧</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<style>
<!--
#cms8341-categories p {
	margin: 12px 0px;
}

.dir_first {
	padding-left: 5px;
}

.dir_second {
	padding-left: 65px;
}

.dir_third {
	padding-left: 125px;
}

.dir_fourth {
	padding-left: 150px;
}
//
-->
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

function cxCreate( cate_code ) {

	$('cms_cate_code').value  = cate_code;
	$('cms_fCateList').action = 'create_form.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;

}

function cxSort( cate_code ) {

	$('cms_cate_code').value = cate_code;
	$('cms_fCateList').action = 'list_sort.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;

}

PLUS_MODE  = "<?=PLUS_MODE?>";
MINUS_MODE = "<?=MINUS_MODE?>";
function cxShow( cate_code, level, mode ) {

	$('cms_cate_code').value  = cate_code;
	if ( mode == PLUS_MODE ) {
		$('cms_cate_level').value = level + 1;
	} else if ( mode == MINUS_MODE ) {
		$('cms_cate_level').value = level;
	}
	$('cms_fCateList').action = 'index.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;

}

/**
 * 下階層表示設定画面へ遷移
 * @cate_code カテゴリコード
 * @return false
 */
function cxPrev(cate_code){
	$('cms_cate_code').value = cate_code;
	$('cms_fCateList').action = 'prev_pageinfo.php';
	$('cms_fCateList').target = '_self';
	$('cms_fCateList').submit();

	return false;
}


//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
	<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/special/faq/images/bar_category_list.jpg"
	alt="分類一覧" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div class="cms8341-categories">
<form id="cms_fCateList" name="cms_fCateList" class="cms8341-form"
	method="post" action=""><input type="hidden" id="cms_cate_code"
	name="cms_cate_code" value=""> <input type="hidden" id="cms_cate_level"
	name="cms_cate_level" value=""> <input type="hidden"
	name="cms_dispMode" id="cms_dispMode" value=""> <input type="hidden"
	id="cms_page_id" name="cms_page_id" value="<?=$page_id?>">
<?=$strHTML?>
				</form>
</div>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->
</body>
</html>