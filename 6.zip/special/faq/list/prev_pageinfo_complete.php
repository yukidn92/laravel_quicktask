<?php
/*
 * FAQ機能：下位分類リスト対象登録処理
 */
//外部ファイル読み込み
require_once ("../.htsetting");

//DBアクセス用ファイルの読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);

//変数の指定
$cate_code = ""; //カテゴリコード
$children_category_flg = FLAG_OFF; //下階層を表示するフラグ


//POST値の取得
$cate_code = (isset($_POST['cms_faq_cate_code']) ? $_POST['cms_faq_cate_code'] : "");
$children_category_flg = (isset($_POST['cms_children_category_flg']) && $_POST['cms_children_category_flg'] == FLAG_ON ? FLAG_ON : FLAG_OFF);

//引数のチェック
if ($cate_code == "") {
	print('不正なパラメータです。');
	exit();
}

//トランザクション開始
$objCnc->begin();
//カテゴリーテーブルの faqpage_id 更新
$aryCate = array(
		"cate_code" => $cate_code, 
		"faq_children_flg" => $children_category_flg
);
//DB登録処理
if (!$objCate->update($aryCate)) {
	$objCnc->rollback();
	print('情報の登録に失敗しました。');
	exit();
}
//トランザクション終了
$objCnc->commit();
exit();
?>
