<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	faqError("不正なアクセスです。");
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>一覧ページ作成完了</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

/*  振分画面へ */
function cxSubmit( ){

	$('cms_fSearch').action = 'index.php';
	$('cms_fSearch').submit();

	return false;
}

//-->
</script>
</head>
<body id="cms8341-mainbg">
<form id="cms_fSearch" name="cms_fSearch" class="cms8341-form"
	method="post" action="">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
		<div align="center" id="cms8341-contents">
<div><img
	src="<?=RPW?>/admin/special/faq/images/bar_complete_faq_list.jpg"
	alt="FAQ一覧ページ作成完了" width="920" height="30"></div>
<div class="cms8341-area-corner">

<div id="cms_search_html">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-complete">
	<tr>
		<td align="center">FAQ一覧ページの作成が完了しました。</td>
	</tr>
</table>
</div>

<p align="center"><a href="javascript:" onClick="return cxSubmit( )"><img
	src="<?=RPW?>/admin/special/faq/images/btn_back_list.jpg"
	alt="一覧ページに戻る" border="0"></a></p>

</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>