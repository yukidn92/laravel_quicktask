<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser')) {
	faqError("不正なアクセスです。");
}

// 親ページID（cms_page_id）が渡されなければエラー
if (!isset($_POST['cms_page_id'])) {
	faqError("パラメータが不正です。");
}
// 分類が(cms_cate_code)渡さなければエラー
if (!isset($_POST['cms_cate_code'])) {
	faqError("パラメータが不正です。");
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_auto_link.inc');
$objAutoLink = new tbl_auto_link($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);

// 新規作成するページID( 仮 )
$_SESSION['cms_page_id'] = -1;
$_SESSION['cms_pankuzu_id'] = -1;
// 親ページ ID
$objPage->selectFromPath(SITE_TOP_PAGE);
$PID = $objPage->fld['page_id']; // $_POST['cms_page_id'];
// テンプレート
$template_name = "";
$template_id = "";
$template_kind = "";
// ページタイトル
$page_title_from = "";
// カテゴリコード
$cate_code = $_POST['cms_cate_code'];
$cate_str = showCate($objCate, $_POST['cms_cate_code']);

$page_title_from = '';
$keywords = '';
$description = '';
$summary = "";
$autoLinks = "";
$autoLinks_title = '';
$autoLInks_title_l = '';
$template_name = '';
$template_id = '';
$template_kind = '';
$inquiry_memo = '';
$inquiry_cnt = 1;
$outline = '';
$publish_to = '';
$contents_top_flg_checked = '';
$isChecked = array(
		ENQ_KIND_CGI => "", 
		ENQ_KIND_MAIL => ""
);
$link_str = "";
$pdsy = $pdsm = $pdsd = $pdey = $pdem = $pded = "";
$enq_kind = "";
$enq_email = "";
$file_name = "";

function showCate($objCate, $cate_code, $deml = ' &gt; ') {
	
	if (substr($cate_code, 0, 3) == "000") return "";
	
	$_cate[0] = substr($cate_code, 0, 3) . "000000000";
	
	if (substr($cate_code, 3, 3) != "000") {
		$_cate[1] = substr($cate_code, 0, 6) . "000000";
	}
	if (substr($cate_code, 6, 3) != "000") {
		$_cate[2] = substr($cate_code, 0, 9) . "000";
	}
	if (substr($cate_code, 9, 3) != "000") {
		$_cate[3] = substr($cate_code, 0, 12);
	}
	
	$ret = "";
	
	for($_i = 0; $_i < count($_cate); $_i++) {
		if ($objCate->selectFromCode($_cate[$_i]) !== FALSE) {
			$ret .= ($_i > 0) ? $deml : "";
			$ret .= $objCate->fld['name'];
		}
		else {
			break;
		}
	}
	return $ret;
}

// 親ページの公開情報を取得
if ($objPage->selectFromID($PID, 1) === FALSE) {
	user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 1);", E_USER_ERROR);
}
$pub_fld = $objPage->fld;

// 親ページのページタイトルを取得
// 自分が作業中のページの場合は編集情報から取得
if ($pub_fld['status'] < 402 && $pub_fld['user_id'] == $objLogin->get('user_id')) {
	if ($objPage->selectFromID($PID, 2, 'page_title, cate_code') === FALSE) {
		user_error("dac execute error. <br>tbl_page->selectFromID(" . $PID . ", 2, 'page_title');", E_USER_ERROR);
	}
	$page_title = $objPage->fld['page_title'];
	// 自分が作業中のページじゃなければ公開情報から取得
}
else {
	$page_title = $pub_fld['page_title'];
}

// ぱんくずのセット
$pankuzu = $objTool->getPankuzu(FLAG_OFF, $template_kind, 0, $pub_fld['ancestor_path'], $page_title, $objLogin->get('user_id'), FALSE);
$pankuzu = setRootPath($pankuzu); // ルートからのパスにする


// テンプレート（最新バージョン）情報を取得
$sql = "SELECT t.* FROM tbl_template AS t" . " WHERE t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)" . " AND t.disp_flg = '" . FLAG_ON . "'" . " AND t.template_kind = '" . TEMPLATE_KIND_FREE . "'" . " ORDER BY t.sort_order,t.template_id";
$objTool->execute($sql);

// ファイル保存先設定レイヤーの表示取得
if (isset($_SESSION['reffer'])) unset($_SESSION['reffer']);
$_SESSION['reffer'] = array();
require_once (APPLICATION_ROOT . "/common/dbcontrol/commands.inc");
$where = " class ='" . HANDLER_CLASS_DEF_DIR1 . "'";
$where .= " AND item1 ='" . $objLogin->get('dept_code') . "'";
$objDac->setTableName("tbl_handler");
$objDac->select($where);
$objDac->fetch();
if ($objDac->getRowCount() == 0) {
	$defFolder = "";
}
else {
	$defFolder = $objDac->fld['item2'];
}
$refferStr = cxRefferMoveDir($objCnc, $defFolder);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>新規ページの作成</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/newpage.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/reffer.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/create.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>

</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-newpage">
<form id="cms_fAddpage" name="cms_fAddpage" class="cms8341-form"
	method="post" action="" onSubmit="return false;"><input type="hidden"
	name="cms_parent_id" id="cms_parent_id" value="<?=$PID?>"> <input
	type="hidden" name="cms_page_id" id="cms_page_id" value="<?=$PID?>"> <input
	type="hidden" name="cms_dir_path" id="cms_dir_path" value=""> <input
	type="hidden" name="cms_filename" id="cms_filename" value=""> <input
	type="hidden" name="cms_template_kind" id="cms_template_kind"
	value="<?=$template_kind?>"> <input type="hidden"
	name="cms_inquiry_cnt" id="cms_inquiry_cnt" value="<?=$inquiry_cnt?>">
<input type="hidden" name="cms_dispMode" id="cms_dispMode" value=""> <input
	type="hidden" name="cms_copy_page_id" id="cms_copy_page_id"
	value="<?=$_POST['cms_page_id']?>"> <input type="hidden"
	name="cms_user_class" id="cms_user_class"
	value="<?=$objLogin->get('class')?>"> <input type="hidden"
	name="cms_cate_code" id="cms_cate_code" value="<?=$cate_code?>">


<div><img
	src="<?=RPW?>/admin/special/faq/images/bar_create_faq_list.jpg"
	alt="FAQ一覧ページ作成" width="920" height="30"></div>
<div class="cms8341-area-corner">
<p id="cms8341-pankuzu"><?=$pankuzu?> &gt; </p>

<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">

	<tr>
		<th width="170" align="left" valign="top" scope="row">テンプレート <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
		<p id="cms-template-selected"><?=$template_name?></p>
		<p><a href="javascript:" onClick="return cxTemplateSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0"></a></p>
		</td>
	</tr>

	<tr id="cms_page_title_tr">
		<th width="150" align="left" valign="top" scope="row"><label
			for="cms_page_title">タイトル <span class="cms_require">（必須）</span></label>
		<div class="cms_recommend"></div>
		</th>
		<td><input type="text" maxlength="255" name="cms_page_title"
			id="cms_page_title" style="width: 240px;"
			value="<?=htmlspecialchars($page_title_from)?>"></td>
	</tr>

	<tr>
		<th width="170" align="left" valign="top" nowrap scope="row">親ページ</th>
		<td align="left" valign="top">
		<div align="left">
		<div><a href="javascript:" onClick="return cxOpenPanset()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0"></a> <a href="javascript:"
			onClick="return cxParentDel()"><img
			src="<?=RPW?>/admin/images/btn/btn_parent_unset.jpg" alt="親ページなしにする"
			width="150" height="20" border="0"></a></div>
		</div>
		</td>
	</tr>

	<tr id="cms_cate_tr">
		<th align="left" valign="top" nowrap scope="row">分類</th>
		<td><?=$cate_str?></td>
	</tr>

	<tr id="cms_reffer_tr">
		<th align="left" valign="top" scope="row">ファイル保存先 <span
			class="cms_require">（必須）</span></th>
		<td align="left" valign="top">
		<p id="cms_file_path"></p>
		<p><a href="javascript:" onClick="return cxRefferSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0"></a></p>
		</td>
	</tr>

</table>

<br>
<div id="cms_kanko_area"></div>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center" id="cms_submit"><a href="javascript:"
	onClick="return cxSubmit('<?=$objLogin->get('class')?>')"><img
	src="<?=RPW?>/admin/images/btn/btn_submit_large.jpg" alt="作成"
	width="150" height="20" border="0" style="margin-right: 10px;"></a><a
	href="javascript:" onClick="return cxPageCancel()"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>

<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
					alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxTemplateClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 560px; height: 235px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="540" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list"><label for="cms_template_id">テンプレートリスト</label>
				<select name="cms_template_id" id="cms_template_id" size="12"
					style="width: 250px;" onChange="cxSelectTemplate()">
<?php
// テンプレート選択フォームの生成＋表示
$def_src = "javascript:''";
while ($objTool->fetch()) {
	$src = DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
	if ($template_id != "" && $template_id == $objTool->fld['template_id']) {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '" selected>' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
	else {
		print '<option value="' . $objTool->fld['template_id'] . '" id="' . $src . '" _kind="' . $objTool->fld['template_kind'] . '">' . htmlDisplay($objTool->fld['name']) . '</option>' . "\n";
	}
}
?>
</select></div>
				</td>
				<td width="275" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 275px; height: 215px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?=$def_src?>" name="cms_thumb" id="cms_thumb"
					width="270" height="210" frameborder="0" scrolling="no"
					style="border: solid 1px #666"></iframe></td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxTemplateSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* --></form>
</div>
</div>
<!-- cms8341-contents -->
<!--***ファイル保存先設定レイヤー　ここから***********-->
<div id="cms8341-reffer" class="cms8341-layer">
<?=$refferStr?>
</div>
<!--***ファイル保存先設定レイヤー　ここまで***********-->
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxLayer('cms8341-error',0);"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
<?php
echo $objTool->setAccessibility();
?>
</body>
</html>
