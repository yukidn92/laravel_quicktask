/*
 *
 */

// カテゴリ
var cms_CateBack = false;
var xmlDoc;
function cxChangeCate(level, code) {

	var prm = 'level=' + level + '&code=' + code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);

}
function cxGetCateComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Categories') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 4; i++) {
        var cmb = $('cms_cate' + i);
        while (cmb.length > 1) {
            cmb.options[1] = null;
        }
    }
    var cmb = $('cms_cate' + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i = 0; i < xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        cmb.length++;
        cmb.options[i + 1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        cmb.options[i + 1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}

// 組織変更プルダウン処理
var faqNum;
function cxChangeDept(lv, val, num) {
	faqNum = num;
	// reset
	if (val == "") {
		var t = lv + 1;
		for ( var i = t; i <= 3; i++) {
			var obj = $('cms_faq_dept' + i + '_' + faqNum);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level=' + lv + '&code=' + val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Department') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 3; i++) {
        var obj = $('cms_faq_dept' + i + '_' + faqNum);
        while (obj.length > 1) {
            obj.options[1] = null;
        }
        obj.options[0].text = "";
    }
    var obj = $('cms_faq_dept' + level + '_' + faqNum);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        obj.length++;
        obj.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        obj.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}

//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}

/**
 * エラーレイヤーのクローズ
 */
function cxCloseError() {
	cxComboVisible();
	cxLayer('cms8341-error', 0);
}

// 振分先追加
function cxAddFaq() {
	$('cms_faq_cnt').value = Number($('cms_faq_cnt').value) + 1;
	no = $('cms_faq_cnt').value;
	var faqStr = '<div id="cms_faq_'
			+ no
			+ '">'
			+ '振分先'
			+ no
			+ '&nbsp;'
			+ '<select name="cms_faq_dept1_'
			+ no
			+ '" id="cms_faq_dept1_'
			+ no
			+ '" onChange="javascript:cxChangeDept(1, this.value, '
			+ no
			+ ')" style="width:150px;">'
			+ $('cms_faq_dept_def_sel').innerHTML
			+ '</select>&nbsp;&nbsp;&nbsp;'
			+ '<select name="cms_faq_dept2_'
			+ no
			+ '" id="cms_faq_dept2_'
			+ no
			+ '" onChange="javascript:cxChangeDept(2, this.value, '
			+ no
			+ ')" style="width:150px;"><option value=""></option></select>&nbsp;&nbsp;&nbsp;'
			+ '<select name="cms_faq_dept3_'
			+ no
			+ '" id="cms_faq_dept3_'
			+ no
			+ '" onChange="javascript:cxChangeDept(3, this.value, '
			+ no
			+ ')" style="width:150px;"><option value=""></option></select>&nbsp;&nbsp;&nbsp;</td>'
			+ '<td  align="right"><a href="javascript:" onClick="return cxFaqDel('
			+ no
			+ ')"><img src="'
			+ cms8341admin_path
			+ '/images/btn/btn_del_mini.jpg" alt="削除する" width="60" height="20" border="0"></a></td>'
			+ '</div>';
	new Insertion.Before('cms_faq_add', faqStr);
}

function cxFaqDel(no) {
	if (!confirm("追加振分先" + no + "を削除します。\nよろしいですか？")) {
		return false;
	}
	Element.remove($('cms_faq_' + no));
}
