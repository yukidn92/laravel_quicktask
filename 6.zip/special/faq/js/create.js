/*
 *
 */
//contentsmenu preload images
cxPreImages(cms8341admin_path+'/images/icon/icon-list-green.jpg',
			cms8341admin_path+'/images/btn/btn_del.jpg');

// **
// テンプレート選択処理
function cxSelectTemplate(v) {
	var t_id = 'cms_template_' + v;
	$('cms_template_image').src = $(t_id).src;
}
//決定処理
var cmsCateTop = '';
function cxSubmit(uc) {
	var info = new Array();
	var kind = $F('cms_template_kind');
	// 入力チェック
	if(!$('cms_page_title').value) {
		alert('タイトルが入力されていません。');
		$('cms_page_title').focus();
		return false;
	}
	if(!$('cms_template_id').value) {
		alert('テンプレートが選択されていません。');
		cxTemplateSet();
		return false;
	}
	if(!$('cms_template_kind').value) {
		alert('テンプレートの選択が完了されていません。');
		cxTemplateSet();
		return false;
	}
	if(!$('cms_dir_path').value || !$('cms_filename').value) {
		alert('ファイルの保存先が設定されていません。');
		cxRefferSet();
		return false;
	}
	info = fckCheck('タイトル',$('cms_page_title').value,info);
	if(!info)return false;
	if (info.length > 0) {
		var msg = info.join('\n') + '\nよろしいですか？';
		if (!confirm(msg)) {
			return false;
		}
	}
	//main
	$('cms_fAddpage').action = 'create_addpage.php';
	$('cms_fAddpage').submit();
	return false;
}

// ** テンプレート選択処理 ********************************************************************* //
var cmsTemplate = null;
function cxTemplateSet() {
	cmsTemplate = $('cms_template_id').options.selectedIndex;
	// close
	cxLayer('cms8341-reffer',0);
	// hidden
	cxComboHidden(new Array("cms_template_id"));
	$('cms_thumb').contentWindow.document.body.style.zoom = 0.3;
	$('cms_thumb').contentWindow.document.body.style.position = "relative";
	cxLayer('cms8341-template-select',1,600,340);
}
//
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;
function cxSelectTemplate() {
	var si,src;
	si = $('cms_template_id').options.selectedIndex;
	if(si >= 0) {
		src = $('cms_template_id').options[si].id;
		//
		// テンプレート選択画面のプレビューでレスポンシブをOFF
		$('cms_thumb').src = cms8341admin_path + "/page/common/tplview.php?path=" + encodeURI(src) + '&thum=1';
		if(cms_sid) clearInterval(cms_sid);
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom,cms_inv_tim);
	} else {
		$('cms_thumb').src = 'javascript:';
	}
}
function cxIFrameZoom() {
	if($('cms_thumb').contentWindow.document.body){
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.3)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.3)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	//
	cms_inv_cnt++;
	if(cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}
function cxTemplateSubmit() {
	var si,label,cate;
	si = $('cms_template_id').options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		label = $('cms_template_id').options[si].text;
		cate = 'テンプレート';
		$('cms-template-selected').innerHTML = cate + '：' + label + ' が選択されています。';
		$('cms_template_kind').value = $('cms_template_id').options[si].getAttribute('_kind');
	}
	//
	cxLayer('cms8341-template-select',0);
	// visible
	cxComboVisible();
}
function cxTemplateClose() {
	//close
	cxLayer('cms8341-template-select',0);
	// visible
	cxComboVisible();
	if (cmsTemplate != null) {
		$('cms_template_id').options.selectedIndex = cmsTemplate;
		// re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}
//通信失敗処理
function cxFailure() {
	$('cms8341-reffer').innerHTML = '<p align="center">情報取得中に通信エラーが発生しました</p>';
}
//cancel
function cxPageCancel() {
	if (!confirm("作成を行わないと現在の内容は保存されません。\nキャンセルしてもよろしいですか？")) {
		return false;
	}
	$('cms_fAddpage').action = 'index.php';
	$('cms_fAddpage').submit();
	return false;
}

function cxFileSubmit(event){
	var item = Event.element(event);
	if($('cms_file_submit') && item.id == "cms_new_file" && event.keyCode == 13){
		cxRefferSubmit();
	}
}

function cxInit() {
	Event.observe(document,'keypress',cxFileSubmit,false);
}
Event.observe(window,'load',cxInit,false);

// パンくず（親ページ）の変更
function cxOpenPanset() {
	var pid = $('cms_parent_id').value;
	if (pid == '') pid = $F('cms_page_id');
	var uri = cms8341admin_path+'/page/common/pankuzu_set.php?pid='+pid;
	window.name='win_cms8341Main';
		cxIframeLayer(
			uri,
			800,
			600,
			COVER_SETTING.COLOR,
			'panset'
		);
	return false;
}
function cxPankuzuSet(pid) {
	$('cms_parent_id').value = pid;
	var prm = 'page_id='+pid;
	cxAjaxCommand('cxGetPankuzu', prm, cxPankuzuSetSubmit);
}
function cxPankuzuSetSubmit(r) {
	var rText = r.responseText;
	cmsPanAncestor = rText.replace(/<(a|area)( [^>]*)?>/ig, '<$1 href="#">');
	if ($('cms8341-pankuzu')) $('cms8341-pankuzu').innerHTML = rText.replace(/<\/?(a|area)( [^>]*)?>/ig, '');
}

//親ページを削除する
function cxParentDel(){
	//ダイアログで確認
	if(!confirm("現在設定されている親ページ情報を削除します。\n本当によろしいですか？")) return false;
	// 親ページのvalueを消す
	$('cms_parent_id').value = "";
	// パンくず表示を消す
	$('cms8341-pankuzu').innerHTML = "&nbsp;";
	cmsPanAncestor = "";
	return false;
}
