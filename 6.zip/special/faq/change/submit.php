<?php
/*
 *
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

// FAQ振分権限のないユーザーはアクセス不可
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && !$objLogin->get('isFAQanswer')) {
	faqError("不正なアクセスです。");
}

// 個人宛メール送信判定フラグ
$mail_flg = FLAG_ON;

//	変更用配列
$arrAry = "";
$arrAry = array(
		"faq_id" => (isset($_POST['cms_faq_id'])) ? $_POST['cms_faq_id'] : "", 
		"charge" => (isset($_POST['cms_faq_dept3_1'])) ? $_POST['cms_faq_dept3_1'] : "", 
		"status" => FAQ_STATUS_NOT_READ, 
		"distribute" => FAQ_DISTRIBUTE_CHANGE
);

//	引数チェック
if (in_array("", $arrAry)) {
	faqError("パラメータの取得に失敗しました。");
}

$charge = array();
for($i = 1; $i <= $_POST['cms_faq_cnt']; $i++) {
	if (isset($_POST['cms_faq_dept1_' . $i])) {
		if (!isset($_POST['cms_faq_dept3_' . $i]) || $_POST['cms_faq_dept3_' . $i] == "") {
			faqError("振分先組織情報の取得に失敗しました。");
		}
		else {
			$charge[$_POST['cms_faq_dept3_' . $i]] = $_POST['cms_faq_dept3_' . $i];
		}
	}
}

$faq_id = $arrAry['faq_id'];

// DBデータ取得
if ($objFaq->selectFromID($faq_id) !== FALSE) {
	$question_title = $objFaq->fld['question_title'];
	$status = $objFaq->fld['status'];
	$regist_datatime = $objFaq->fld['regist_datatime'];
}
else {
	faqError("問い合わせが存在しません。削除された可能性があります。");
}

//	statusチェック
if ($status != FAQ_STATUS_ADMIN_CONTROL) {
	faqError("すでに振分設定は行われています。");
}

$arr_mail_data = array();
foreach ((array) $charge as $keys => $code) {
	$mail_data = array();
	$msg = "";
	if ($objDept->selectFromCode($code) !== FALSE) {
		//組織情報取得
		$mail_data['code'] = $code;
		$mail_data['email'] = $objDept->fld['email'];
		$mail_data['dept_name'] = $objDept->fld['dept_name'];
		//取得情報チェック
		if (!isset($mail_data['email']) || $mail_data['email'] == "") {
			$msg .= "組織情報よりE-mailアドレスの取得に失敗しました。\n";
		}
		if (!isset($mail_data['dept_name']) || $mail_data['dept_name'] == "") {
			$msg .= "組織情報より組織名称の取得に失敗しました。";
		}
		//エラーメッセージが存在したなら表示
		if ($msg != "") {
			faqError($msg);
		}
		
		//	メール本文作成
		$mail_fld = array();
		$mail_fld['cms_url'] = HTTP_ROOT . RPW;
		$mail_fld['url'] = HTTP_REAL_ROOT;
		$mail_fld['now_date'] = date('Y-m-d H:i:s');
		$mail_fld['dept_name'] = $mail_data['dept_name'];
		$mail_fld['faq_regist_datatime'] = $regist_datatime;
		$mail_fld['question_title'] = $question_title;
		$mail_fld['faq_comment'] = trim($_POST['cms_comment']);
		$head = get_mail_str($mail_fld, MAIL_SUBJECT_FAQ_CHANGE_TO_DEPT);
		$body = get_mail_str($mail_fld, MAIL_BODY_FAQ_CHANGE_TO_DEPT);
		
		$mail_data['body'] = $body;
		
		$arr_mail_data[] = $mail_data;
	}
	else {
		faqError("組織情報の取得に失敗しました。");
	}
}

//個人宛のE-mailの重複チェック ※重複したならメールは送信しない
if (isset($_POST['cms_email_to']) && $_POST['cms_email_to'] != "") {
	foreach ((array) $arr_mail_data as $key => $mail_data) {
		if ($mail_data['email'] == $_POST['cms_email_to']) {
			$mail_flg = FLAG_OFF;
		}
	}
}
else {
	$mail_flg = FLAG_OFF;
}

if ($mail_flg == FLAG_ON) {
	// 個人宛メール本分作成
	$mail_fld = array();
	$mail_fld['cms_url'] = HTTP_ROOT . RPW;
	$mail_fld['url'] = HTTP_REAL_ROOT;
	$mail_fld['now_date'] = date('Y-m-d H:i:s');
	$mail_fld['faq_regist_datatime'] = $regist_datatime;
	$mail_fld['question_title'] = $question_title;
	$mail_fld['faq_comment'] = trim($_POST['cms_comment']);
	$head2 = get_mail_str($mail_fld, MAIL_SUBJECT_FAQ_CHANGE_TO_USER);
	$body2 = get_mail_str($mail_fld, MAIL_BODY_FAQ_CHANGE_TO_USER);
}

//複数振分DB登録用配列作成
$arrFaqAry = array();
$insertFaqAry = array();
foreach ((array) $arr_mail_data as $key => $mail_data) {
	if ($arrAry['charge'] != $mail_data['code']) {
		$faqAry = $arrAry;
		$faqAry['charge'] = $mail_data['code'];
		$insertFaqAry[] = $faqAry;
	}
}

$objCnc->begin();

// DB登録
// FAQ情報新規追加登録処理
foreach ((array) $insertFaqAry as $key => $faqAry) {
	if (!$objFaq->copy($faq_id, $faqAry)) {
		$objCnc->rollback();
		faqError("DB情報の登録に失敗しました。");
	}
}
// FAQ情報更新処理
tbl_faqUpdate($arrAry);

// メール送信
foreach ((array) $arr_mail_data as $key => $mail_data) {
	send_mail($mail_data['email'], MAIL_ADDR_FROM, $head, $mail_data['body']);
}
// 個人宛メール送信
if ($mail_flg == FLAG_ON) {
	send_mail($_POST['cms_email_to'], MAIL_ADDR_FROM, $head2, $body2);
}

$objCnc->commit();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>担当振分完了</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>


//-->
</script>
</head>


<body id="cms8341-mainbg">
<form name="cms_submit_form" id="cms_submit_form" method="post">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>

	<div align="center" id="cms8341-contents">
<div><img src="../images/bar_faq_change_comp.jpg" alt="担当振分完了"
	width="920" height="30"></div>
<div class="cms8341-area-corner">


<p align="center">担当振分が完了しました</p>
<p align="center"><a href=./index.php><img
	src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
	height="20" border="0"></a></p>

</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
