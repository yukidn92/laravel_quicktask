<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFaq = new tbl_faq($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

$faq_cnt = 1;

// FAQ振分権限のないユーザーはアクセス不可
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && !$objLogin->get('isFAQanswer')) {
	faqError("不正なアクセスです。");
}

// ** URLよりID取得
if (!isset($_POST['cms_faq_id'])) {
	faqError("IDが存在しません");
}
$faq_id = $_POST['cms_faq_id'];

// 検索
if ($objFaq->selectFromID($faq_id) !== FALSE) {
	// DB内容取得
	$regist_datatime = $objFaq->fld['regist_datatime'];
	$question_title = $objFaq->fld['question_title'];
	$question_context = $objFaq->fld['question_context'];
	$status = $objFaq->fld['status'];
}
else {
	faqError("問い合わせが存在しません。削除された可能性があります。");
}

// ステータス判定
if ($status != FAQ_STATUS_ADMIN_CONTROL) {
	faqError("ステータスが不正です");
}

//組織プルダウン作成
$combo_dept = createFaqDeptCombo($objDac, "", 1, "cms_faq_dept");
//	$combo_dept = createFaqDeptCombo($objDac, $objLogin->get('dept_code'), 1, "cms_faq_dept");


// DB内容取得
$strHTML = "";
$strHTML .= '	<div id="cms_search_html">' . PHP_EOL;
$strHTML .= '		<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable" id="cms8341-uploadlist">' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">登録日</th>' . PHP_EOL;
$strHTML .= '				<td>' . dtFormat($regist_datatime) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">質問タイトル</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($question_title) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">質問本文</th>' . PHP_EOL;
$strHTML .= '				<td>' . htmlDisplay($question_context) . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center" id="cms_user_tr">振分先　<span class="cms_require">（必須）</span></th>' . PHP_EOL;
$strHTML .= '				<td>振分先1&nbsp;' . $combo_dept . '</td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center" id="cms_user_tr">追加振分先' . PHP_EOL;
$strHTML .= '				<td><div id="cms_faq_add"><p>追加振分先&nbsp;<a href="javascript:" onClick="return cxAddFaq()"><img src="' . RPW . '/admin/images/btn/btn_set.jpg" alt="設定する" width="100" height="20" border="0" class="cms8341-verticalMiddle"></a></p></div></td>' . PHP_EOL;
$strHTML .= '				</th>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">個人宛E-mailアドレス</th>' . PHP_EOL;
$strHTML .= '				<td><input type="text" id="cms_email_to" name="cms_email_to" size="100"></td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '			<tr>' . PHP_EOL;
$strHTML .= '				<th width="30%" align="center">コメント</th>' . PHP_EOL;
$strHTML .= '				<td><textarea name="cms_comment" rows="5" id="cms_comment" style="width:630px;"></textarea></td>' . PHP_EOL;
$strHTML .= '			</tr>' . PHP_EOL;

$strHTML .= '		</table>' . PHP_EOL;
$strHTML .= '	</div>' . PHP_EOL;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>振分設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/faq/js/common.js"
	type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
	function cxSubmit() {
		var info = new Array();
		var msg = "";
		for (i = 1; i <= $('cms_faq_cnt').value; i++) {
			if ( $('cms_faq_dept1_'+i)) {
				if ( !$('cms_faq_dept3_'+i) || ! $('cms_faq_dept3_'+i).value) {
					msg += "振分先"+i+"の振分先設定が不正です。\n";
				}
			}
		}
		if (msg != "") {
			alert(msg);
		}else if ($F('cms_email_to') != '' && $F('cms_email_to').match(/[!#-9A-~]+@+[a-z0-9]+.+[^.]$/) == null) {
			alert( "個人宛E-mailアドレスは正しい値ではありません。" );
		}else {
			// -- アクセシビリティ
			info = fckCheck('コメント',$('cms_comment').value,info);
			if ( ! info ) return false;
			if ( info.length > 0 ) {
				var msg = info.join('\n') + '\nよろしいですか？';
				if ( ! confirm( msg ) ) {
					return false;
				}
			}
			$('cms_change_form').submit();
		}
		return false;
	}
	
	function cxDelete(){
	
		if ( confirm( "問い合わせ情報を削除します。\nよろしいですか？" ) ) {
			$('cms_change_form').action = 'delete.php';
			$('cms_change_form').submit();
		}
		return false;
	}
	
//-->
</script>
<style type="text/css">
@-moz-document url-prefix() {
	#cms8341-uploadlist input[type=text][size] {
		font-family: 'Meiryo UI', 'Times New Roman', Arial;
	}
}
</style>
</head>


<body id="cms8341-mainbg">
<form name="cms_change_form" id="cms_change_form" method="post"
	action="submit.php">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<input type="hidden" name="cms_faq_cnt" id="cms_faq_cnt"
	value="<?=$faq_cnt?>">

<div align="center" id="cms8341-contents">
<div><img src="../images/bar_faq_change.jpg" alt="振分設定" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
	
<?php
echo ($strHTML);
?>	
	
	<input type="hidden" id="cms_faq_id" name="cms_faq_id"
	value="<?=$faq_id?>">
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
	height="20" border="0" align="middle"></a>&nbsp;<a href="javascript:"
	onClick="return cxDelete()"><img src="../images/btn_faq_delete_on.jpg"
	alt="この情報を削除" width="150" height="20" border="0" align="middle"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
<?php
// ** アクセシビリティチェック用 ------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
echo $objTool->setAccessibility();
?>
