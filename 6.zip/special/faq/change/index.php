<?php
/*
 * FAQ機能：担当者振り分け 一覧画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/common.inc");

// ** global 宣言 ---------------------------
global $objCnc;
global $objLogin;

// ウェブマスターではない場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && !$objLogin->get('isFAQanswer')) {
	faqError("不正なアクセスです。");
}

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_faq.inc');
$objFAQ = new tbl_faq($objCnc);

// ** 定数 ----------------------------------
$where = $objFAQ->_addslashesC('status', FAQ_STATUS_ADMIN_CONTROL);
$filed = "*";
$sortOrder = "regist_datatime DESC";

// DB内容取得
$strHTML = "";
$objFAQ->select($where, $filed, $sortOrder);
$strHTML .= "	<div id=\"cms_search_html\">" . PHP_EOL;
$strHTML .= "		<table width=\"100%\" border=\"0\" cellpadding=\"5\" cellspacing=\"0\" class=\"cms8341-dataTable\" id=\"cms8341-uploadlist\">" . PHP_EOL;
$strHTML .= "			<tr>" . PHP_EOL;
if ($objFAQ->getRowCount() <= 0) {
	$strHTML .= '				<td align="center">データがありません。</td>';
	$strHTML .= "			</tr>" . PHP_EOL;
}
else {
	$strHTML .= "				<th width=\"100%\" align=\"center\" colspan=\"2\">問い合わせタイトル</th>" . PHP_EOL;
	$strHTML .= "			</tr>" . PHP_EOL;
	while ($objFAQ->fetch()) {
		// htmlの作成
		$strHTML .= "			<tr>";
		$strHTML .= '				<td width="80%">';
		
		$strHTML .= $objFAQ->fld['question_title'] . "<br>" . PHP_EOL;
		$strHTML .= "<small>" . dtFormat($objFAQ->fld['regist_datatime'], "Y年n月j日") . "</small>"; // H時i分s秒
		

		if (strlen($objFAQ->fld['send_back']) > 0) {
			$strHTML .= '<div class="cms8341-denailarea">' . PHP_EOL;
			$strHTML .= '<img src="' . RPW . '/admin/special/faq/images/label_sendback.jpg" alt="差し戻し理由" width="80" height="25"></br>' . PHP_EOL;
			$strHTML .= htmlDisplay($objFAQ->fld['send_back']);
			$strHTML .= '</div>';
		}
		
		$strHTML .= "</td>";
		$strHTML .= '<td width="20%" height="100%" align="center" valign="middle">';
		
		$strHTML .= '				<a href="javascript:" onClick="return cxAnswer(' . $objFAQ->fld['faq_id'] . ')"><img src="' . RPW . '/admin/special/faq/images/btn_change.jpg" alt="振分設定" border="0" width="120" height="20"></a>' . PHP_EOL;
		$strHTML .= '				<br><a href="javascript:" onClick="return cxDelete(' . $objFAQ->fld['faq_id'] . ')"><img src="' . RPW . '/admin/special/faq/images/btn_delete.jpg" alt="削除する" border="0" width="120" height="20">' . PHP_EOL;
		
		$strHTML .= "				</td>" . PHP_EOL;
		$strHTML .= "			</tr>" . PHP_EOL;
	
	}
}
$strHTML .= "		</table>" . PHP_EOL;
$strHTML .= "	</div>" . PHP_EOL;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>問い合わせ振分一覧</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/workflow.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/term.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

/*  振分画面へ */
function cxAnswer( faq_id ){

	$('cms_faq_id').value = faq_id;
	$('cms_fSearch').action = 'form.php';
	$('cms_fSearch').submit();

	return false;
}

/*  振分画面へ */
function cxDelete( faq_id ){

	if ( confirm( "問い合わせ情報を削除します。\nよろしいですか？" ) ) {
		$('cms_faq_id').value = faq_id;
		$('cms_fSearch').action = 'delete.php';
		$('cms_fSearch').submit();
	}
	return false;
}

//-->
</script>
</head>
<body id="cms8341-mainbg">
<form id="cms_fSearch" name="cms_fSearch" class="cms8341-form"
	method="post" action=""><input type="hidden" id="cms_faq_id"
	name="cms_faq_id" value="">
<?php
// ヘッダーメニュー挿入
$headerMode = 'faq';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
		<div align="center" id="cms8341-contents">
<div><img src="<?=RPW?>/admin/special/faq/images/bar_change_list.jpg"
	alt="問い合わせ振分一覧" width="920" height="30"></div>
<div class="cms8341-area-corner">

<?php
echo ($strHTML);
?>

			</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents --></form>
</body>
</html>
