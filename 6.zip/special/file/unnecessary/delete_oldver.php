<?php
/*
 * テンプレート、ライブラリの旧バージョン削除
 */
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac1 = new dac($objCnc);
$objDac2 = new dac($objCnc);

//ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser') == TRUE) user_error('不正アクセスです。');

//$t1 = time()+microtime();
$aryUsingTmp = array();
$aryUsingCss = array();
$aryUsingXml = array();

// テンプレートの最新バージョン情報を取得
$aryMaxVerT = array();
$sql = "SELECT t.* FROM tbl_template AS t" . " INNER JOIN (" . " SELECT template_id, MAX(template_ver) AS template_ver" . " FROM tbl_template GROUP BY template_id" . " ) AS s" . " ON (s.template_id = t.template_id AND s.template_ver = t.template_ver)" . " ORDER BY t.template_id";
$objDac1->execute($sql);
while ($objDac1->fetch()) {
	$aryMaxVerT[$objDac1->fld['template_id']] = $objDac1->fld['template_ver'];
	if ($objDac1->fld['temp_txt'] != '') $aryUsingTmp[] = $objDac1->fld['temp_txt'];
	if ($objDac1->fld['edit_css'] != '') $aryUsingCss[] = $objDac1->fld['edit_css'];
	if ($objDac1->fld['style_xml'] != '') $aryUsingXml[] = $objDac1->fld['style_xml'];
}
// 使用されているテンプレートの情報抽出
$sql = "SELECT DISTINCT t.temp_txt, t.edit_css, t.style_xml FROM tbl_template AS t" . " INNER JOIN (" . "(SELECT template_id, template_ver FROM tbl_publish_page GROUP BY template_id, template_ver)" . " UNION" . "(SELECT template_id, template_ver FROM tbl_work_page GROUP BY template_id, template_ver)" . " ) AS p ON (p.template_id = t.template_id AND p.template_ver = t.template_ver)";
$objDac1->execute($sql);
while ($objDac1->fetch()) {
	if ($objDac1->fld['temp_txt'] != '') $aryUsingTmp[] = $objDac1->fld['temp_txt'];
	if ($objDac1->fld['edit_css'] != '') $aryUsingCss[] = $objDac1->fld['edit_css'];
	if ($objDac1->fld['style_xml'] != '') $aryUsingXml[] = $objDac1->fld['style_xml'];
}
$aryUsingTmp = array_unique($aryUsingTmp);
$aryUsingCss = array_unique($aryUsingCss);
$aryUsingXml = array_unique($aryUsingXml);

//使用されているテンプレートファイル名の先頭に「mobile_」をつけることにより携帯用テンプレートも使用中とする
$TemparyUsingTmp = array();
foreach ((array) $aryUsingTmp as $file_name) {
	$TemparyUsingTmp[] = $file_name;
	$TemparyUsingTmp[] = 'mobile_' . $file_name;
}
if (count($TemparyUsingTmp) > 0) {
	$aryUsingTmp = $TemparyUsingTmp;
}
// 使用されていないテンプレートの抽出
$sql = "SELECT t.* FROM tbl_template AS t" . " LEFT JOIN (" . "(SELECT template_id, template_ver FROM tbl_publish_page GROUP BY template_id, template_ver)" . " UNION" . "(SELECT template_id, template_ver FROM tbl_work_page GROUP BY template_id, template_ver)" . " ) AS p ON (p.template_id = t.template_id AND p.template_ver = t.template_ver)" . " WHERE p.template_id IS NULL" . " ORDER BY t.template_id, t.template_ver";
$objDac1->execute($sql);
while ($objDac1->fetch()) {
	$fld = $objDac1->fld;
	// 最新バージョンは削除しない
	if ($aryMaxVerT[$fld['template_id']] == $fld['template_ver']) continue;
	// データの削除
	$sql = "DELETE FROM tbl_template" . " WHERE template_id = " . $fld['template_id'] . " AND template_ver = " . $fld['template_ver'];
	$objDac2->execute($sql);
	// ファイルの削除
	if ($fld['temp_txt'] != '') @unlink(DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $fld['temp_txt']);
	//		if (($fld['edit_css'] != '') && !in_array($fld['edit_css'], $aryUsingCss)) 
	//			@unlink(DOCUMENT_ROOT.DIR_PATH_EDITCSS.$fld['edit_css']);
	if (($fld['style_xml'] != '') && !in_array($fld['style_xml'], $aryUsingXml)) @unlink(DOCUMENT_ROOT . DIR_PATH_STYLEXML . $fld['style_xml']);
}

// ライブラリの最新バージョン取得
$aryMaxVerL = array();
$sql = "SELECT library_id, MAX(library_ver) AS library_ver" . " FROM tbl_library" . " GROUP BY library_id" . " ORDER BY library_id";
$objDac1->execute($sql);
while ($objDac1->fetch()) {
	$aryMaxVerL[$objDac1->fld['library_id']] = $objDac1->fld['library_ver'];
}
// 使用されていないライブラリの抽出
$sql = "SELECT l.library_id, l.library_ver" . " FROM tbl_library AS l" . " LEFT JOIN (" . " SELECT item3 AS library_id, item4 AS library_ver FROM tbl_handler WHERE class IN (4,5)" . " ) AS h ON (h.library_id = l.library_id AND h.library_ver = l.library_ver)" . " WHERE h.library_id IS NULL" . " ORDER BY l.library_id, l.library_ver";
$objDac1->execute($sql);
while ($objDac1->fetch()) {
	$fld = $objDac1->fld;
	// 最新バージョンは削除しない
	if ($aryMaxVerL[$fld['library_id']] == $fld['library_ver']) continue;
	// データの削除
	$sql = "DELETE FROM tbl_library" . " WHERE library_id = " . $fld['library_id'] . " AND library_ver = " . $fld['library_ver'];
	$objDac2->execute($sql);
}

// 使用されていないテンプレートファイルを削除する
if ($dh = @opendir(DOCUMENT_ROOT . DIR_PATH_TEMPLATE)) {
	while (($entry = @readdir($dh)) !== false) {
		if ($entry == "." || $entry == "..") continue;
		if (!in_array($entry, $aryUsingTmp)) {
			@unlink(DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $entry);
		}
	}
	closedir($dh);
}
if ($dh = @opendir(DOCUMENT_ROOT . DIR_PATH_STYLEXML)) {
	while (($entry = @readdir($dh)) !== false) {
		if ($entry == "." || $entry == "..") continue;
		if (!in_array($entry, $aryUsingXml)) {
			@unlink(DOCUMENT_ROOT . DIR_PATH_STYLEXML . $entry);
		}
	}
	closedir($dh);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>旧バージョン削除</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/special/file/unnecessary/unnecessary.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div align="center" id="cms8341-contents">
<div><img src="images/bar_unnecessary02.jpg" alt="不要ファイル削除" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th align="center" valign="middle">&nbsp;</th>
	</tr>
	<tr>
		<td align="left" valign="top" nowrap>
		<p>テンプレートとライブラリから、使用されていない旧バージョンを削除しました。</p>
		</td>
	</tr>
</table>
<p align="center"><a href="index.php"><img
	src="<?=RPW?>/admin/master/images/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->
</body>
</html>
