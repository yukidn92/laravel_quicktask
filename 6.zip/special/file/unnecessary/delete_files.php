<?php
/*
 * 不要ファイルの削除
 */
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);

//ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser') == TRUE) user_error('不正アクセスです。');

require_once ("./include/is_abled_dir.inc");
require_once ("./include/is_unnecessary_file.inc");

// 対象ディレクトリ
if (!isset($_POST['cms_dir'])) {
	user_error('不正アクセスです。');
}
$cms_dir = $_POST['cms_dir'];
$cms_dir = preg_replace('/(^\/?|\/?$)/', '/', $cms_dir);
$cms_dir = preg_replace('/\/+/', '/', $cms_dir);
if (!@file_exists(DOCUMENT_ROOT . RPW . $cms_dir)) {
	user_error('指定したフォルダは存在しません。');
}
if (!is_abled_dir($cms_dir)) {
	user_error('指定したフォルダは削除することができません。');
}

// 対象ファイル（配列）
if (!isset($_POST['del_file']) || !is_array($_POST['del_file']) || count($_POST['del_file']) == 0) {
	user_error('削除するファイルを選択してください。');
}
$aryFiles = $_POST['del_file'];
$aryFiles = array_unique($aryFiles);

foreach ($aryFiles as $filename) {
	if (($filename == '.htsetting') || ($filename == '.htaccess') || !is_unnecessary_file($objDac, $cms_dir . $filename)) {
		$msg[] = 'ファイルは削除できません。[' . RPW . $cms_dir . $filename . ']';
		continue;
	}
	//トランザクションON
	$objCnc->begin();
	//「tbl_fck_images」「tbl_fck_links」にファイルが含まれていれば削除
	if ($objFCKImages->deleteFromImagePath($cms_dir . $filename) === FALSE) {
		$msg[] = '画像情報の削除に失敗しました。[' . RPW . $cms_dir . $filename . ']';
		$objCnc->rollback();
	}
	if ($objFCKLinks->deleteFromPageID($cms_dir . $filename) === FALSE) {
		$msg[] = 'ファイル情報の削除に失敗しました。[' . RPW . $cms_dir . $filename . ']';
		$objCnc->rollback();
	}
	// 作業サーバから削除
	if (@file_exists(DOCUMENT_ROOT . RPW . $cms_dir . $filename)) {
		@chmod(DOCUMENT_ROOT . RPW . $cms_dir . $filename, 0777);
		if (@unlink(DOCUMENT_ROOT . RPW . $cms_dir . $filename)) {
			$msg[] = '作業ディレクトリから削除しました。[' . RPW . $cms_dir . $filename . ']';
		}
		else {
			$msg[] = '作業ディレクトリからの削除に失敗しました。[' . RPW . $cms_dir . $filename . ']';
			$objCnc->rollback();
		}
	}
	// 本サーバから削除
	if (@file_exists(DOCUMENT_ROOT . RPR . $cms_dir . $filename)) {
		@chmod(DOCUMENT_ROOT . RPR . $cms_dir . $filename, 0777);
		if (@unlink(DOCUMENT_ROOT . RPR . $cms_dir . $filename)) $msg[] = '一時保存ディレクトリから削除しました。[' . RPR . $cms_dir . $filename . ']';
		else $msg[] = '一時保存ディレクトリからの削除に失敗しました。[' . RPR . $cms_dir . $filename . ']';
	}
	// FTPからの削除
	$ftpCnc = connectFTP("cms");
	if (FTP_UPLOAD_FLG) {
		$ftp_path = FTP_ROOT_DIR . $cms_dir . $filename;
		if (cx_ftp_delete($ftpCnc, $ftp_path)) {
			$msg[] = '公開サーバから削除しました。[' . $ftp_path . ']';
		}
		else {
			$msg[] = '公開サーバには存在しませんでした。[' . $ftp_path . ']';
		}
	}
	//コミット
	$objCnc->commit();
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>不要ファイル削除</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet"
	href="<?=RPW?>/admin/special/file/unnecessary/unnecessary.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div align="center" id="cms8341-contents">
<div><img src="images/bar_unnecessary02.jpg" alt="不要ファイル削除" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-directoryarea">
<table width="100%" border="0" cellpadding="10" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<th width="120" align="left" valign="middle" nowrap scope="row">対象フォルダ</th>
		<td align="left" valign="middle"><?=HTTP_ROOT . RPW . $cms_dir?></td>
	</tr>
</table>
</div>
<form name="fDelFiles" class="cms8341-form" method="post"
	action="index.php"><input type="hidden" name="cms_dispMode"
	value="search"> <input type="hidden" name="del_dir"
	value="<?=htmlspecialchars($cms_dir)?>">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable" id="cms8341-uploadlist">
	<tr>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">削除結果</th>
	</tr>
<?php
if (count($msg) <= 0) {
	print '<tr><td align="left" valign="top" nowrap><p>不要ファイルの削除処理を完了しました。</p></td></tr>' . "\n";
}
else {
	foreach ($msg as $m) {
		print '<tr><td align="left" valign="top" nowrap><p>' . $m . '</p></td></tr>' . "\n";
	}
}
?>
</table>
<p align="center"><a href="javascript:"
	onClick="document.fDelFiles.submit();return false;"><img
	src="<?=RPW?>/admin/master/images/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0"></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->
</body>
</html>
