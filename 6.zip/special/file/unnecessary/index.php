<?php
/*
 *
 */
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);

//ウェブマスター以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER || $objLogin->get('isOpenUser') == TRUE) user_error('不正アクセスです。');

require_once ("./include/is_abled_dir.inc");
require_once ("./include/is_unnecessary_file.inc");

// 不要ファイルの検索
$del_display1 = false;
$del_cnt = 0;
$html_delfiles = '';
$del_dir = "/";
if (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] == 'search') {
//	$t1 = time() + microtime();
	$del_display1 = true;
	$del_dir = $_POST['del_dir'];
	$del_dir = preg_replace('/(^\/?|\/?$)/', '/', $del_dir);
	$del_dir = preg_replace('/\/+/', '/', $del_dir);
	if (!@file_exists(DOCUMENT_ROOT . RPW . $del_dir)) {
		$html_delfiles .= '<tr><td><p align="center">指定したフォルダは存在しません。</p></td></tr>' . "\n";
	}
	elseif (!is_abled_dir($del_dir)) {
		$html_delfiles .= '<tr><td><p align="center">指定したフォルダは削除することができません。</p></td></tr>' . "\n";
	}
	else {
		$html_delfiles .= '<tr><th width="80" align="center" valign="middle" style="font-weight:normal" scope="col">選択</th>' . "\n";
		$html_delfiles .= '<th align="center" valign="middle" style="font-weight:normal" scope="col">ファイル</th></tr>';
		$list_dirs = '';
		$list_files = '';
		if ($dh = @opendir(DOCUMENT_ROOT . RPW . $del_dir)) {
			$up_dir = preg_replace('/[^\/]+\/$/', '', $del_dir);
			while (($entry = @readdir($dh)) !== false) {
				if ($entry == ".") continue;
				if ($entry == "..") {
					if ($up_dir == $del_dir) continue;
					$list_dirs = '<tr><td>&nbsp;</td><td><a href="javascript:" onClick="return cxSearchDir(\'' . $up_dir . '\');">' . $entry . '</a></td></tr>' . "\n" . $list_dirs;
				}
				elseif (is_dir(DOCUMENT_ROOT . RPW . $del_dir . $entry)) {
					$entry .= '/';
					if (!is_abled_dir($del_dir . $entry)) continue;
					$list_dirs .= '<tr><td>&nbsp;</td><td><a href="javascript:" onClick="return cxSearchDir(\'' . $del_dir . $entry . '\');">' . $entry . '</a></td></tr>' . "\n";
				}
				elseif (is_file(DOCUMENT_ROOT . RPW . $del_dir . $entry)) {
					if (($entry == '.htsetting') || ($entry == '.htaccess')) continue;
					if (!is_unnecessary_file($objDac, $del_dir . $entry)) continue;
					$del_cnt++;
					$list_files .= '<tr><td align="center"><input type="checkbox" name="del_file[]" id="del_file_' . $del_cnt . '" value="' . $entry . '"></td>' . "\n";
					$list_files .= '<td><a href="' . RPW . $del_dir . $entry . '" target="_blank">' . $entry . '</a></td>' . "\n";
				}
			}
			closedir($dh);
		}
		if (($list_dirs == '') && ($list_files == '')) {
			$html_delfiles .= '<tr><td colspan="0"><p align="center">指定したフォルダに不要ファイルはありません。</p></td></tr>' . "\n";
		}
		else {
			$html_delfiles .= $list_dirs . $list_files;
		}
	}
//	$t2 = time() + microtime();
	//print_dp('time['.($t2-$t1).']');
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>不要ファイル削除</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="unnecessary.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSearchDir(dir) {
	fSearchDir.del_dir.value = dir;
	fSearchDir.submit();
	return false;
}
function cxDelFiles(dir) {
	var df = document['fDelFiles']['del_file[]'];
	var flg = false;
	if (df) {
		if (!df.length && df.value) {
			if (df.checked) {
				flg = true;
			}
		} else {
			for(var i=0;i<df.length;i++) {
				if(df[i].checked) {
					flg = true;
					break;
				}
			}
		}
	}
	if (!flg) {
		alert('削除するファイルを選択してください。');
	} else {
		fDelFiles.submit();
	}
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div align="center" id="cms8341-contents">
<div><img src="images/bar_unnecessary01.jpg" alt="旧バージョン削除" width="920"
	height="30"></div>
<div class="cms8341-area-box" style="margin-bottom: 20px;">
<p align="center">テンプレートとライブラリから、使用されていない旧バージョンを削除します。</p>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="delete_oldver.php"><img
	src="<?=RPW?>/admin/master/images/btn_del.jpg" alt="削除" width="150"
	height="20" border="0"></a></p>
</div>

<div><img src="images/bar_unnecessary02.jpg" alt="不要ファイル削除" width="920"
	height="30"></div>
<div class="cms8341-area-box">
<form name="fSearchDir" class="cms8341-form" method="post"
	action="index.php"><input type="hidden" name="cms_dispMode"
	value="search"> <input type="hidden" name="cms_dir"
	value="<?=htmlspecialchars($del_dir)?>">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(images/bar_topbg.jpg); height: 31px;"><img
			src="images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row"><label
					for="del_dir">対象フォルダ</label></th>
				<td align="left" valign="middle"><?=HTTP_ROOT . RPW?>&nbsp;<input
					type="text" id="del_dir" name="del_dir" value="<?=$del_dir?>"
					style="width: 300px;"></td>
			</tr>
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearchDir(fSearchDir.del_dir.value);"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
</form>
<form name="fDelFiles" class="cms8341-form" method="post"
	action="delete_files.php"><input type="hidden" name="cms_dir"
	value="<?=htmlspecialchars($del_dir)?>">
<?php
if ($del_display1) {
	print '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . "\n";
	print $html_delfiles . "\n";
	print '</table>' . "\n";
	print '<p align="center"><img src="' . RPW . '/admin/images/icon/icon-flow.jpg" alt="" width="36" height="26"></p>' . "\n";
	if ($del_cnt > 0) {
		print '<p align="center">選択したページを作業サーバおよび本サーバから削除します。</p>' . "\n";
		print '<p align="center"><a href="javascript:" onClick="return cxDelFiles();"><img src="' . RPW . '/admin/master/images/btn_del.jpg" alt="削除" width="150" height="20" border="0"></a></p>' . "\n";
	}
	else {
		print '<p align="center"><img src="' . RPW . '/admin/master/images/btn_del_off.jpg" alt="削除" width="150" height="20" border="0"></p>' . "\n";
	}
}
else {
	print '<p>指定したフォルダの不要ファイルを検索します。</p>' . "\n";
}
?>
</form>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
