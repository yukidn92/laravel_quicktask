/**
 * 定型情報エクスポート機能
 */
// -----------------------------------------------
// テンプレート
// -----------------------------------------------
// 初期化
var cmsTemplate = null;
var cms_sid;
var cms_inv_cnt = 0;
var cms_inv_tim = 200;
var cms_inv_max = 25;

/**
 * テンプレートの選択
 */
function cxSelectTemplate(v) {
	var t_id = 'cms_template_' + v;
	$('cms_template_image').src = $(t_id).src;
}

/**
 * テンプレート設定レイヤーの表示
 */
function cxTemplateSet() {
	cmsTemplate = $('cms_template_id').options.selectedIndex;
	// close
	cxLayer('cms8341-template-select',0);
	// hidden
	cxComboHidden(new Array('cms_template_id'));
	$('cms_thumb').contentWindow.document.body.style.zoom = 0.3;
	$('cms_thumb').contentWindow.document.body.style.position = 'relative';
	cxLayer('cms8341-template-select',1,600,340);
}

/**
 * テンプレートの選択
 */
function cxSelectTemplate() {
	var si,src;
	si = $('cms_template_id').options.selectedIndex;
	if (si >= 0) {
		src = $('cms_template_id').options[si].id;
		//
		$('cms_thumb').src = cms8341admin_path + '/page/common/tplview.php?path=' + encodeURI(src) + '&thum=1';
		if (cms_sid) {
			clearInterval(cms_sid);
		}
		cms_sid = 0;
		cms_inv_cnt = 0;
		cms_sid = setInterval(cxIFrameZoom,cms_inv_tim);
	}
	else {
		$('cms_thumb').src = 'javascript:';
	}
}

/**
 * テンプレートプレビューの表示調整
 */
function cxIFrameZoom() {
	if ($('cms_thumb').contentWindow.document.body) {
		var thumb_body = $('cms_thumb').contentWindow.document.body;
		thumb_body.style.position = "relative";
		thumb_body.style.transform = "scale(0.3)";
		thumb_body.style.transformOrigin = "0 0";
		thumb_body.style.webkitTransform = "scale(0.3)";
		thumb_body.style.webkitTransformOrigin = "0 0";
	}
	cms_inv_cnt++;
	if (cms_inv_cnt > cms_inv_max) {
		clearInterval(cms_sid);
		cms_inv_cnt = 0;
	}
}

/**
 * テンプレート決定
 */
function cxTemplateSubmit() {
	var si,label,cate;
	si = $('cms_template_id').options.selectedIndex;
	cmsTemplate = si;
	if (si >= 0) {
		label = $('cms_template_id').options[si].text;
		cate  = 'テンプレート';
		$('cms-template-selected').innerHTML = cate + '：' + label + ' が選択されています。';
		$('cms_template_kind').value = $('cms_template_id').options[si].getAttribute('_kind');
		$('cms_template_kanko_type').value = $('cms_template_id').options[si].getAttribute('_kanko_type');
		$('cms_filename').value = $('cms_template_id').options[si].getAttribute('_xml');
	}
	cxLayer('cms8341-template-select',0);
	// visible
	cxComboVisible();
}

/**
 * テンプレート設定レイヤーを閉じる
 */
function cxTemplateClose() {
	// close
	cxLayer('cms8341-template-select',0);
	// visible
	cxComboVisible();
	if (cmsTemplate != null) {
		$('cms_template_id').options.selectedIndex = cmsTemplate;
		// re select
		cxSelectTemplate();
	}
	cmsTemplate = null;
}

/**
 * エクスポート
 */
function cxSubmit() {
	var msg = new Array();
	if (!$('cms_template_id').value) {
		msg.push('テンプレートを選択してください。');
	}
	// 公開期間入力チェック
	if ($('cms_pdsy').value || $('cms_pdsm').value || $('cms_pdsd').value || $('cms_pdsh').value) {
		dc = cxDateCheckNew('cms_pd', 'ymdh', 2, '公開期間');
		msg = msg.concat(dc);
	}
	if ($('cms_pdey').value || $('cms_pdem').value || $('cms_pded').value || $('cms_pdeh').value) {
		dc = cxDateCheckNew('cms_pd', 'ymdh', 3, '公開期間');
		msg = msg.concat(dc);
	}
	// エラー表示
	if (msg.length > 0) {
		cxComboHidden(new Array('cms_template_id'));
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}
	document.cms_fixed_export.submit();
	return false;
}

/**
 * エラー画面を閉じる
 */
function cxErrorClose() {
	cxComboVisible();
	cxLayer('cms8341-error',0);
}

/**
 * 組織・ユーザのセレクトボックスの値を設定
 */
function cxChangeDept(lv, val) {
	// reset
	if (val == '') {
		var t = lv + 1;
		for (var i=t; i<=3; i++) {
			var obj = $('cms_target'+i);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "                ";
		}
		var obj = $('cms_user_id');
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "                ";
	}
	else {
		if (lv < 3) {
			//get data
			lv++;
			var prm = 'level=' + lv + '&code=' + val;
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
		}
		else {
			var prm = 'code=' + val;
			cxAjaxCommand('cxGetUserCombo', prm, cxGetUserComboOK);
		}
	}
}

/**
 * 組織選択時
 */
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i=level; i<=3; i++) {
		var obj = $('cms_target' + i);
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "                ";
	}
	var obj = $('cms_user_id');
	while (obj.length>1) {
		obj.options[1] = null;
	}
	obj.options[0].text = "                ";
	var obj = $('cms_target'+level);
	for (var i=0; i<xmlDoc.childNodes.length; i++) {
		var nodeL = xmlDoc.childNodes.item(i);
		if (nodeL.nodeType == 1){
			obj.length++;
			obj.options[obj.length - 1].text = nodeL.text || nodeL.textContent || '指定なし';
			var val = nodeL.attributes.getNamedItem('value').value;
			obj.options[obj.length - 1].value = val;
		}
	}
}

/**
 * ユーザ情報選択時
 */
function cxGetUserComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'User') {
		cxFailure();
		return;
	}
	var obj = $('cms_user_id');
	while (obj.length > 1) {
		obj.options[1] = null;
	}
	obj.options[0].text = '------- 未選択 -------';
	for (var i=0; i<xmlDoc.childNodes.length; i++) {
		var nodeL = xmlDoc.childNodes.item(i);
		if (nodeL.nodeType == 1){
			obj.length++;
			obj.options[obj.length - 1].text = nodeL.text || nodeL.textContent;
			var val = nodeL.attributes.getNamedItem('value').value;
			obj.options[obj.length - 1].value = val;
		}
	}
}