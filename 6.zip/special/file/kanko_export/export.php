<?php
/**
 * 定型情報のエクスポート
 */
// 設定ファイル読み込み
require ('../.htsetting');

// DBクラス読み込み
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$obj_dept = new tbl_department($objCnc);

$objLogin = new login();
$login = $objLogin->login;

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// 定数・初期化

$def = array();
if (isset($_GET['bak']) && $_GET['bak'] == 1 && isset($_SESSION['post']) && is_array($_SESSION['post'])) {
	$def = $_SESSION['post'];
}
else if (isset($_SESSION['post'])) {
	unset($_SESSION['post']);
}

if (!isset($def['cms_template_id'])) $def['cms_template_id'] = '';
if (!isset($def['cms_template_kind'])) $def['cms_template_kind'] = '';

// 非公開中情報「含まない」を設定
if (!isset($def['open_status'])) $def['open_status'] = 'public';

// 依存ファイル「含まない」を設定
if (!isset($def['file_status'])) $def['file_status'] = 'out';

// 組織選択のプルダウン初期設定値
if (!isset($def['cms_target1'])) $def['cms_target1'] = '';
if (!isset($def['cms_target2'])) $def['cms_target2'] = '';
if (!isset($def['cms_target3'])) $def['cms_target3'] = '';
if (!isset($def['cms_user_id'])) $def['cms_user_id'] = '';

// カレンダーの初期設定値
if (!isset($def['cms_pdsy'])) $def['cms_pdsy'] = '';
if (!isset($def['cms_pdsm'])) $def['cms_pdsm'] = '';
if (!isset($def['cms_pdsd'])) $def['cms_pdsd'] = '';
if (!isset($def['cms_pdsh'])) $def['cms_pdsh'] = '';
if (!isset($def['cms_pdey'])) $def['cms_pdey'] = '';
if (!isset($def['cms_pdem'])) $def['cms_pdem'] = '';
if (!isset($def['cms_pded'])) $def['cms_pded'] = '';
if (!isset($def['cms_pdeh'])) $def['cms_pdeh'] = '';

$def['template_src'] = "javascript:''";
$def['template_name'] = '';

// 非公開中情報の初期選択
$def_checked['public'] = '';
$def_checked['close'] = '';
$def_checked[$def['open_status']] = ' checked';

// 依存ファイル情報の初期選択
$def_checked['in'] = '';
$def_checked['out'] = '';
$def_checked[$def['file_status']] = ' checked';

// テンプレート選択フォームの生成
$fields = 't.template_id, t.template_ver, t.temp_txt, t.name, t.template_kind, t.kanko_type , t.kanko_xml';
$where = 't.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)';
if ($objLogin->get('class') != USER_CLASS_WEBMASTER) {
	$where .= ' AND ' . $obj_dac->_addslashesC('h.class', HANDLER_CLASS_TEMPLATE);
	$where .= ' AND t.template_id=h.item2';
	$where .= ' AND ' . $obj_dac->_addslashesC('h.item1', $objLogin->get('dept_code'));
	$obj_dac->setTableName('tbl_template AS t, tbl_handler AS h');
}
else {
	// ウェブマスターは tbl_handler を見ない
	$obj_dac->setTableName('tbl_template AS t');
}
//定型項目を持つテンプレートのみ表示する（定型項目を持つフリーテンプレート含む）
$where .= ' AND ' . $obj_dac->_addslashesC('t.disp_flg', FLAG_ON);
$where .= ' AND ' . $obj_dac->_addslashesC('t.kanko_xml', '', '!=', 'TEXT', FLAG_ON);
$orderBy = 't.sort_order,t.template_id';
$obj_dac->select($where, $fields, $orderBy);
$combo_template = '<select name="cms_template_id" id="cms_template_id" size="12" style="width:250px;" onChange="cxSelectTemplate()">' . "\n";
while ($obj_dac->fetch()) {
	if ($obj_dac->fld['template_id'] == TEMPLATE_ID_NONE) {
		continue;
	}
	$src = DIR_PATH_TEMPLATE . $obj_dac->fld['temp_txt'];
	$xmlSrc = DIR_PATH_KANKOXML . $obj_dac->fld['kanko_xml'];
	$selected = '';
	if ($obj_dac->fld['template_id'] == $def['cms_template_id']) {
		$def['template_src'] = RPW . '/admin/page/common/tplview.php?path=' . $src;
		$def['template_name'] = 'テンプレート：' . htmlDisplay($obj_dac->fld['name']) . ' が選択されています。';
		$selected = ' selected';
	}
	$combo_template .= '<option value="' . $obj_dac->fld['template_id'] . '" id="' . $src . '"' . $selected;
	$combo_template .= ' _kind="' . $obj_dac->fld['template_kind'] . '"  _kanko_type="' . $obj_dac->fld['kanko_type'] . '" _xml="' . $xmlSrc .'">';
	$combo_template .= htmlDisplay($obj_dac->fld['name']);
	$combo_template .= '</option>' . "\n";
}
$combo_template .= '</select>' . "\n";

//組織プルダウン生成
$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;">' . "\n";
$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;">' . "\n";
$dept_s3 = '<select id="cms_target3" name="cms_target3" onChange="javascript:cxChangeDept(3, this.value)" style="width:150px;">' . "\n";
$dept_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
$dept_e = '</select>&nbsp;&nbsp;';
$dept_op1 = $dept_opn;
$dept_op2 = $dept_opn;
$dept_op3 = $dept_opn;
// ウェブマスターのときはすべての組織のプルダウンを作成する
if ($objLogin->get('class') == USER_CLASS_WEBMASTER) {
	//第一組織プルダウンの生成
	$sql = 'SELECT level,dept_code,name FROM tbl_department WHERE level=1 ORDER BY sort_order, dept_code';
	$obj_dac->execute($sql);
	while ($obj_dac->fetch()) {
		$selected = ($obj_dac->fld['dept_code'] == $def['cms_target1']) ? ' selected' : '';
		$dept_op1 .= '<option value="' . $obj_dac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($obj_dac->fld['name']) . '</option>' . "\n";
	}
	//第二組織プルダウンの生成（第一組織が指定されている場合）
	if ($def['cms_target1'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=2 AND dept_code REGEXP '^" . substr($def['cms_target1'], 0, CODE_DIGIT_DEPT) . "' ORDER BY sort_order, dept_code";
		$obj_dac->execute($sql);
		while ($obj_dac->fetch()) {
			$selected = ($obj_dac->fld['dept_code'] == $def['cms_target2']) ? ' selected' : '';
			$dept_op2 .= '<option value="' . $obj_dac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($obj_dac->fld['name']) . '</option>' . "\n";
		}
	}
	//第三組織プルダウンの生成（第二組織が指定されている場合）
	if ($def['cms_target2'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=3 AND dept_code REGEXP '^" . substr($def['cms_target2'], 0, (CODE_DIGIT_DEPT * 2)) . "' ORDER BY sort_order, dept_code";
		$obj_dac->execute($sql);
		while ($obj_dac->fetch()) {
			$selected = ($obj_dac->fld['dept_code'] == $def['cms_target3']) ? ' selected' : '';
			$name = ($obj_dac->fld['name'] == " " || $obj_dac->fld['name'] == "　") ? "指定なし" : $obj_dac->fld['name'];
			$dept_op3 .= '<option value="' . $obj_dac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($name) . '</option>' . "\n";
		}
	}
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
	//ユーザプルダウンの生成（第三組織が指定されている場合）
	if ($def['cms_target3'] != '') {
		$sql = 'SELECT user_id,name FROM tbl_user WHERE class = ' . USER_CLASS_WRITER . " AND dept_code = '" . $def['cms_target3'] . "' ORDER BY user_id";
		$obj_dac->execute($sql);
		while ($obj_dac->fetch()) {
			$selected = ($obj_dac->fld['user_id'] == $def['cms_user_id']) ? ' selected' : '';
			$user_op .= '<option value="' . $obj_dac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($obj_dac->fld['name']) . '</option>' . "\n";
		}
	}
}
else {
	//外部ファイル取り込みを許可されている組織の場合は、組織プルダウンは自分の組織しか表示しない
	$deptAry = getDeptCode($objLogin->get('dept_code'));
	//第一組織プルダウンの生成
	$obj_dept->selectFromCode($deptAry['dept1_code']);
	$dept_op1 = '<option value="' . $obj_dept->fld['dept_code'] . '" selected>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
	//第二組織プルダウンの生成
	$obj_dept->selectFromCode($deptAry['dept2_code']);
	$dept_op2 = '<option value="' . $obj_dept->fld['dept_code'] . '" selected>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
	//第三組織プルダウンの生成
	$obj_dept->selectFromCode($deptAry['dept3_code']);
	$dept_op3 = '<option value="' . $obj_dept->fld['dept_code'] . '" selected>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
	
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '';
	//ユーザプルダウンの生成
	$sql = 'SELECT user_id,name FROM tbl_user WHERE class = ' . USER_CLASS_WRITER . " AND dept_code = '" . $objLogin->get('dept_code') . "' ORDER BY user_id";
	$obj_dac->execute($sql);
	while ($obj_dac->fetch()) {
		$selected = ($obj_dac->fld['user_id'] == $objLogin->get('user_id')) ? ' selected' : '';
		$user_op .= '<option value="' . $obj_dac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($obj_dac->fld['name']) . '</option>' . "\n";
	}
}
$combo_user = $user_s1 . $user_op . $dept_e;


// エラーより戻ってきた場合の処理
if (isset($_GET['err']) && $_GET['err'] == 1) {
	// SESSION の値を取得
	if (isset($_SESSION['kanko_exprot']['cms_cate2'])) $def['cms_cate2'] = $_SESSION['kanko_exprot']['cms_cate2']; // カテゴリ
	if (isset($_SESSION['kanko_exprot']['cms_cate3'])) $def['cms_cate3'] = $_SESSION['kanko_exprot']['cms_cate3']; // カテゴリ
	if (isset($_SESSION['kanko_exprot']['cms_cate4'])) $def['cms_cate4'] = $_SESSION['kanko_exprot']['cms_cate4']; // カテゴリ
	if (isset($_SESSION['kanko_exprot']['city_code'])) $def['city_code'] = $_SESSION['kanko_exprot']['city_code']; // 市町村
	if (isset($_SESSION['kanko_exprot']['cms_pdsy'])) $search['pdsy'] = $_SESSION['kanko_exprot']['cms_pdsy']; // 更新日
	if (isset($_SESSION['kanko_exprot']['cms_pdsm'])) $search['pdsm'] = $_SESSION['kanko_exprot']['cms_pdsm']; // 更新日
	if (isset($_SESSION['kanko_exprot']['cms_pdsd'])) $search['pdsd'] = $_SESSION['kanko_exprot']['cms_pdsd']; // 更新日
	if (isset($_SESSION['kanko_exprot']['cms_pdey'])) $search['pdey'] = $_SESSION['kanko_exprot']['cms_pdey']; // 更新日
	if (isset($_SESSION['kanko_exprot']['cms_pdem'])) $search['pdem'] = $_SESSION['kanko_exprot']['cms_pdem']; // 更新日
	if (isset($_SESSION['kanko_exprot']['cms_pded'])) $search['pded'] = $_SESSION['kanko_exprot']['cms_pded']; // 更新日
}
else {
	// SESSION 削除
	if (isset($_SESSION['kanko_exprot'])) unset($_SESSION['kanko_exprot']);
}

// HTML 作成
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>定型情報エクスポート</title>
<link rel="stylesheet" href="<?php echo(RPW); ?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="kanko_export.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?php echo(RPW); ?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/common_action.js" type="text/javascript"></script>		
<script src="<?php echo(RPW); ?>/admin/js/shared.js" type="text/javascript"></script>	
<script src="<?php echo(RPW); ?>/admin/js/library/scriptaculous.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/special/file/kanko_export/js/export.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . '/common/inc/special_menu.inc');
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-log">
<div><img src="images/bar_kankoexport.jpg" alt="定型情報エクスポート" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<form id="cms_fixed_export" name="cms_fixed_export" class="cms8341-form" method="post" action="execution.php" enctype="multipart/form-data">
<input type="hidden" name="cms_dispMode" value="">
<div id="cms8341-search">
<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable">
	<tr>
		<th align="left" valign="top" nowrap scope="row" width="170"><label for="">テンプレート<br><span class="cms_require">（必須）</span></label></th>
		<td>
			<p id="cms-template-selected"><?php echo($def['template_name']); ?></p>
			<p><span id="cms_template_setting_btn">
			<a href="javascript:" onClick="return cxTemplateSet()">
			<img src="<?php echo(RPW); ?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100" height="20" border="0"></a>
			</span></p>
		</td>
	</tr>
	<tr id="cms_pd_tr">
		<th align="left" valign="top" nowrap scope="row"><label for="cms_pdsy">公開期間</label></th>
		<td>
			<input type="text" maxlength="4" id="cms_pdsy" name="cms_pdsy" value="<?php echo($def['cms_pdsy']); ?>" style="width: 50px; ime-mode: disabled"> 年
			<input type="text" maxlength="2" id="cms_pdsm" name="cms_pdsm" value="<?php echo($def['cms_pdsm']); ?>" style="width: 30px; ime-mode: disabled"> 月
			<input type="text" maxlength="2" id="cms_pdsd" name="cms_pdsd" value="<?php echo($def['cms_pdsd']); ?>" style="width: 30px; ime-mode: disabled"> 日
			<input type="text" maxlength="2" id="cms_pdsh" name="cms_pdsh" value="<?php echo($def['cms_pdsh']); ?>" style="width: 30px; ime-mode: disabled"> 時
			<a href="javascript:" onClick="return cxCalendarOpen('cms_pd','start')"><img src="<?php echo(RPW); ?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a>
			から &nbsp;
			<input type="text" maxlength="4" id="cms_pdey" name="cms_pdey" value="<?php echo($def['cms_pdey']); ?>" style="width: 50px; ime-mode: disabled"> 年
			<input type="text" maxlength="2" id="cms_pdem" name="cms_pdem" value="<?php echo($def['cms_pdem']); ?>" style="width: 30px; ime-mode: disabled"> 月
			<input type="text" maxlength="2" id="cms_pded" name="cms_pded" value="<?php echo($def['cms_pded']); ?>" style="width: 30px; ime-mode: disabled"> 日
			<input type="text" maxlength="2" id="cms_pdeh" name="cms_pdeh" value="<?php echo($def['cms_pdeh']); ?>" style="width: 30px; ime-mode: disabled"> 時
			<a href="javascript:" onClick="return cxCalendarOpen('cms_pd','end')"><img src="<?php echo(RPW); ?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a>
			まで
		</td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">ページ作成者</th>
		<td><?php echo($combo_dept); ?><?php echo($combo_user); ?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">非公開情報<br></th>
		<td>
			<input type="radio" name="open_status" id="open_status_1" value="1" <?php echo($def_checked['close']); ?>>&nbsp;<label for="open_status_1">含む</label>&nbsp;&nbsp;
			<input name="open_status" id="open_status_2" value="2" type="radio" <?php echo($def_checked['public']); ?>>&nbsp;<label for="open_status_2">含まない</label>
		</td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">依存ファイル情報<br></th>
		<td>
			<input type="radio" name="file_status" id="file_status_1" value="1" <?php echo($def_checked['in']); ?>>&nbsp;<label for="file_status_1">含む</label>&nbsp;&nbsp;
			<input name="file_status" id="file_status_2" value="2" type="radio" <?php echo($def_checked['out']); ?>>&nbsp;<label for="file_status_2">含まない</label>
		</td>
	</tr>	
</table>
</div>
<input type="hidden" name="cms_k_expotMode" value="">
<input type="hidden" name="cms_template_kind" id="cms_template_kind" value="<?php echo($def['cms_template_kind']); ?>">
<input type="hidden" name="cms_template_kanko_type" id="cms_template_kanko_type" value="">
<input type="hidden" id="cms_filename" name="cms_filename" value="">
</div>
<p align="center"><img src="<?php echo(RPW); ?>/admin/images/icon/icon-flow.jpg" alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img src="images/btn_kankoexport.jpg" alt="定型情報エクスポート" width="150" height="20" border="0"></a></p>
</div>
<div><img src="<?php echo(RPW); ?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!-- ** テンプレート設定レイヤーここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle">
				<img src="<?php echo(RPW); ?>/admin/images/template_select/title_template_select.jpg" alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;">
				</td>
				<td width="78" align="right" valign="middle">
				<a href="javascript:" onClick="return cxTemplateClose()"><img src="<?php echo(RPW); ?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin: 4px 10px;"></a>
				</td>
			</tr>
		</table>
		<div style="width: 560px; height: 235px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="540" border="0" cellpadding="0" cellspacing="0" class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list"><label for="cms_template_id">テンプレートリスト</label>
				<?php echo($combo_template); ?>
				</div>
				</td>
				<td width="275" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 275px; height: 215px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?php echo($def['template_src']); ?>" name="cms_thumb" id="cms_thumb" width="270" height="210" frameborder="0" scrolling="no" style="border: solid 1px #666"></iframe>
				</td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;">
		<a href="javascript:" onClick="return cxTemplateSubmit()"><img src="<?php echo(RPW); ?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102" height="21" border="0"></a>
		</p>
		</td>
	</tr>
</table>
</div>
</form>
<!-- ** テンプレート設定レイヤーここまで ************************************* -->
<!-- ** カレンダーレイヤーここから ******************************** -->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle">
				<img src="<?php echo(RPW); ?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー" width="200" height="20" style="margin: 4px 10px;">
				</td>
				<td width="78" align="right" valign="middle">
				<a href="javascript:" onClick="return cxCalendarClose()">
				<img src="<?php echo(RPW); ?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin: 4px 10px;"></a>
				</td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody" style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!-- **カレンダーレイヤーここまで ******************************** -->
<!-- **エラーメッセージレイヤーここから ******************************** -->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle">
				<img src="<?php echo(RPW); ?>/admin/images/layer/bar_error.jpg" alt="エラー" width="480" height="20" style="margin: 4px 10px;">
				</td>
			</tr>
		</table>
		<div style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div style="width: 430px; height: 120px; padding: 5px; text-align: left" id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;">
		<a href="javascript:" onClick="return cxErrorClose();"><img src="<?php echo(RPW); ?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100" height="20" border="0"></a>
		</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!-- **エラーメッセージレイヤーここまで******************************** -->
</body>
</html>