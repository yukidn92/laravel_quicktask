/*
 *
 */

//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}

//
function cxSubmit() {

	var msg = new Array();
	var sub = new Array();
	var pdsy = $('cms_pdsy');
	var pdsm = $('cms_pdsm');
	var pdsd = $('cms_pdsd');
	var pdey = $('cms_pdey');
	var pdem = $('cms_pdem');
	var pded = $('cms_pded');

	// 更新日(年月日全て)に入力があるかチェック
	if (pdsy.value || pdsm.value || pdsd.value) {
		if (!pdsy.value || !pdsm.value || !pdsd.value) {
			msg.push('更新日の指定をする場合は、年月日すべてを指定してください。');
		}
	}

	if (msg.length <= 0) {
		if (pdey.value || pdem.value || pded.value) {
			if (!pdey.value || !pdem.value || !pded.value) {
				msg.push('更新日の指定をする場合は、年月日すべてを指定してください。');
			}
		}
	}

	if (msg.length <= 0) {

		// 更新日(左右)に入力がある場合
		if (pdsy.value && pdey.value) {
			sub = cxDateCheckNew("cms_pd", "ymd", 1, "更新");
			if (sub.length > 0) {
				for (i = 0; i < sub.length; i++) {
					msg.push(sub[i]);
				}
			}
		} else {
			// 更新日(左)に入力がある場合
			if (pdsy.value) {
				sub = cxDateCheckNew("cms_pd", "ymd", 2, "更新開始");
				if (sub.length > 0) {
					for (i = 0; i < sub.length; i++) {
						msg.push(sub[i]);
					}
				}
			}
			// 更新日(右)に入力がある場合
			if (pdey.value) {
				sub = cxDateCheckNew("cms_pd", "ymd", 3, "更新終了");
				if (sub.length > 0) {
					for (i = 0; i < sub.length; i++) {
						msg.push(sub[i]);
					}
				}
			}
		}

	}

	// エラー表示
	if (msg.length > 0) {

		var output_msg = '<p>';
		// msg.sort();
		for ( var i = 0; i < msg.length; i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';

		cxComboHidden(new Array("cms_template_id"));
		$('cms8341-errormsg').innerHTML = output_msg;
		cxLayer('cms8341-error', 1, 500, 500);
		return false;
	}

	document.cms_kexport.action = "execution.php";
	document.cms_kexport.cms_k_expotMode.value = 1;
	document.cms_kexport.submit();
	return false;
}

//
function cxCloseError() {
	cxComboVisible();
	cxLayer('cms8341-error', 0);
}

// カテゴリ
var cms_CateBack = false;
var xmlDoc;
function cxChangeCate(level, code) {

	if (level == 2) {
		$('cms_cate_' + KANKO_CATE_CODE + '000000000').selected = true;
		alert("観光カテゴリから変更できません。");
		return false;
	}

	var prm = 'level=' + level + '&code=' + code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);

}
function cxGetCateComboOK(r) {
    //PHPから処理終了を受信
    var xmlDoc = r.responseXML.documentElement;
    if (xmlDoc.nodeName != 'Categories') {
        cxFailure();
        return;
    }
    var level = xmlDoc.attributes.getNamedItem('level').value;
    for (var i = level; i <= 4; i++) {
        var cmb = $('cms_cate' + i);
        while (cmb.length > 1) {
            cmb.options[1] = null;
        }
    }
    var cmb = $('cms_cate' + level);
    var xmlDocfix = xmlDoc.childElementCount;
    for (var i=0; i<xmlDocfix; i++) {
        nodeL = xmlDoc.firstElementChild;
        cmb.length++;
        cmb.options[i+1].text = nodeL.textContent;
        var val = nodeL.attributes.getNamedItem('value').value;
        cmb.options[i+1].value = val;
        xmlDoc.removeChild(xmlDoc.firstElementChild);
    }
}
