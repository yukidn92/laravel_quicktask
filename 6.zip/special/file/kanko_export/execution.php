<?php
/**
 * 定型情報のエクスポート CSV出力
 */

// 設定ファイル読み込み
require ('../.htsetting');

// 定型情報エクスポート用関数ファイル
require_once ('./include/common.inc');
// 定型情報インポート・エクスポート用定数ファイル
require_once (APPLICATION_ROOT . '/common/setting_fixed.inc');
// DBクラス読み込み
// 定型項目
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$obj_kanko = new tbl_kanko($objCnc);
// 地図情報
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_map.inc');
$obj_map = new tbl_map($objCnc);
// リンク情報
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$obj_links = new tbl_links($objCnc);
// 問い合わせ先情報検索用
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$obj_inq = new dac($objCnc);
// イベント開催期間情報
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);

$obj_login = new login();
$login = $obj_login->login;

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($obj_login->get('class') != USER_CLASS_WEBMASTER && $obj_login->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}
//エラーの戻り先を指定
gd_errorhandler_ini_set('html0', RPW . '/admin/special/file/kanko_export/export.php?bak=1');

// 定数・初期化 -------------------------------------------------
//検索カラム
$SERARCH_C = 'template_id';
// 初期化
$def['cms_template_id'] = '';
// ページID
$page_id = '';
// 基本情報取得用配列
$page_fld = array();
// 定型項目取得用配列
$fixed_fld_ary = array();
// 依存ファイル用配列
$link_file = array();
// 編集中情報配列
$work_ids = array();
// 公開中情報配列
$pubIDs = array();
// ページ情報ID配列
$page_ids = array();
// CSV和名ヘッダ
$csv_header = array();
// CSVカラム名ヘッダ
$csv_header_cols = array();
// 圧縮フォルダパス
$zip_path = KANKO_EXPORT_ZIP_DIR . KANKO_EXPORT_ZIP;

// SESSION ------------------------------------------------------
// 初期化
if (isset($_SESSION['kanko_export'])) {
	unset($_SESSION['kanko_export']);
}
// POST を代入
// テンプレートID
$_SESSION['kanko_export']['cms_template_id'] = (isset($_POST['cms_template_id'])) ? $_POST['cms_template_id'] : '';
// 定型XML情報
$_SESSION['kanko_export']['cms_filename'] = (isset($_POST['cms_filename'])) ? $_POST['cms_filename'] : '';
// 期間指定
$_SESSION['kanko_export']['cms_pdsy'] = (isset($_POST['cms_pdsy'])) ? $_POST['cms_pdsy'] : '';
$_SESSION['kanko_export']['cms_pdsm'] = (isset($_POST['cms_pdsm'])) ? $_POST['cms_pdsm'] : '';
$_SESSION['kanko_export']['cms_pdsd'] = (isset($_POST['cms_pdsd'])) ? $_POST['cms_pdsd'] : '';
$_SESSION['kanko_export']['cms_pdsh'] = (isset($_POST['cms_pdsh'])) ? $_POST['cms_pdsh'] : '';
$_SESSION['kanko_export']['cms_pdey'] = (isset($_POST['cms_pdey'])) ? $_POST['cms_pdey'] : '';
$_SESSION['kanko_export']['cms_pdem'] = (isset($_POST['cms_pdem'])) ? $_POST['cms_pdem'] : '';
$_SESSION['kanko_export']['cms_pded'] = (isset($_POST['cms_pded'])) ? $_POST['cms_pded'] : '';
$_SESSION['kanko_export']['cms_pdeh'] = (isset($_POST['cms_pdeh'])) ? $_POST['cms_pdeh'] : '';
// 非公開情報出力
$_SESSION['kanko_export']['open_status'] = (isset($_POST['open_status'])) ? $_POST['open_status'] : '';
// 依存ファイル出力
$_SESSION['kanko_export']['file_status'] = (isset($_POST['file_status'])) ? $_POST['file_status'] : '';

// $_POST の値を取得 ----------------------------------------
// 指定のテンプレート
$def['cms_template_id'] = (isset($_POST['cms_template_id']) && strlen($_POST['cms_template_id']) > 0) ? (int) $_POST['cms_template_id'] : '';
// 指定のテンプレートの定型XML
$def['cms_filename'] = (isset($_POST['cms_filename']) && strlen($_POST['cms_filename']) > 0) ? $_POST['cms_filename'] : '';
// 指定のテンプレートのタイプ 施設 イベントなど
$def['cms_template_kanko_type'] = (isset($_POST['cms_template_kanko_type']) && strlen($_POST['cms_template_kanko_type']) > 0) ? (int) $_POST['cms_template_kanko_type'] : '';
// 期間
$def['pdsy'] = (isset($_POST['cms_pdsy'])) ? $_POST['cms_pdsy'] : '';
$def['pdsm'] = (isset($_POST['cms_pdsm'])) ? $_POST['cms_pdsm'] : '';
$def['pdsd'] = (isset($_POST['cms_pdsd'])) ? $_POST['cms_pdsd'] : '';
$def['pdsh'] = (isset($_POST['cms_pdsh'])) ? $_POST['cms_pdsh'] : '';
$def['pdey'] = (isset($_POST['cms_pdey'])) ? $_POST['cms_pdey'] : '';
$def['pdem'] = (isset($_POST['cms_pdem'])) ? $_POST['cms_pdem'] : '';
$def['pded'] = (isset($_POST['cms_pded'])) ? $_POST['cms_pded'] : '';
$def['pdeh'] = (isset($_POST['cms_pdeh'])) ? $_POST['cms_pdeh'] : '';
// 期間開始日時の設定
if (($def['pdsy'] != '') && ($def['pdsm'] != '') && ($def['pdsd'] != '')) {
	$def['publish_start'] = $def['pdsy'] . '-' . $def['pdsm'] . '-' . $def['pdsd'];
	// 時間の設定 開始日が入力されている場合のみ設定
	if ($def['pdsh'] != '') {
		$def['publish_start'] .= ' ' . $def['pdsh'] . FIXED_START_TIME02;
	}
	else {
		$def['publish_start'] .= FIXED_START_TIME;
	}
}
// 期間終了日時の設定
if (($def['pdey'] != '') && ($def['pdem'] != '') && ($def['pded'] != '')) {
	$def['publish_end'] = $def['pdey'] . '-' . $def['pdem'] . '-' . $def['pded'];
	// 時間の設定 終了日が入力されている場合のみ設定
	if ($def['pdeh'] != '') {
		$def['publish_end'] .= ' ' . $def['pdeh'] . FIXED_START_TIME02;
	}
	else {
		$def['publish_end'] .= FIXED_END_TIME;
	}
}
// 作成者
$def['user_id'] = (isset($_POST['cms_user_id'])) ? $_POST['cms_user_id'] : '';
// 非公開情報
$def['open_status'] = (isset($_POST['open_status']) && strlen($_POST['open_status'] > 0)) ? (int) $_POST['open_status'] : '';
// 依存ファイル
$def['file_status'] = (isset($_POST['file_status']) && strlen($_POST['file_status'] > 0)) ? (int) $_POST['file_status'] : '';

// 基本データの取得------------------------------------------------------------------------------------
// 編集中情報を取得------------------------------------------------------------------------------------
$table = '';
$table_ary = array();
$table_ary[] = 'tbl_work_page AS w_page';
$table_ary[] = 'tbl_publish_page AS p_parent ON w_page.parent_id = p_parent.page_id';
// 編集情報のユーザー情報取得
$table_ary[] = 'tbl_user AS t_user ON w_page.user_id = t_user.user_id';
// 編集情報のカテゴリー名取得
$table_ary[] = 'tbl_category AS t_cate ON w_page.cate_code = t_cate.cate_code';
$table = implode(' LEFT JOIN ', $table_ary);

$where = '';
$where_ary = array();
$obj_dac = new dac($objCnc);
// 指定のテンプレート
if (strlen($def['cms_template_id']) > 0) {
	$where_ary[] = 'w_page.template_id = ' . $def['cms_template_id'];
}
// 期間指定
if (isset($def['publish_start']) && $def['publish_start'] != '') {
	$where_ary[] = '(w_page.publish_start >= \'' . $def['publish_start'] . '\' OR w_page.publish_end >= \'' . $def['publish_start'] . '\')';
}
if (isset($def['publish_end']) && $def['publish_end'] != '') {
	$where_ary[] = '(w_page.publish_end <= \'' . $def['publish_end'] . '\' OR w_page.publish_start <= \'' . $def['publish_end'] . '\')';
}
// 作成者の条件
if ($def['user_id'] != '') {
	$where_ary[] = '(w_page.user_id = ' . $def['user_id'] . ')';
}
$where = implode(' AND ', $where_ary);
// ソート順 ページIDの昇順
$orderBy = 'w_page.page_id asc';

// 取得する項目を指定
// 編集中ページ情報
$fields = '';
$field_ary = array();
// ページID
$field_ary[] = 'w_page.page_id as page_id';
// 状態
$field_ary[] = 'w_page.work_class as work_class';
// ページタイトル
$field_ary[] = 'w_page.page_title as page_title';
// ファイルパス
$field_ary[] = 'w_page.file_path as file_path';
// 親ページパス
$field_ary[] = 'w_page.parent_id as paretn_id';
$field_ary[] = 'p_parent.file_path as parent_path';
// 分類コード
$field_ary[] = 'w_page.cate_code as cate_code';
$field_ary[] = 't_cate.name as cate_name';
// テンプレートID
$field_ary[] = 'w_page.template_id as template_id';
// 検索キーワード
$field_ary[] = 'w_page.keywords as keywords';
// 説明文
$field_ary[] = 'w_page.description as description';
// 要約文
$field_ary[] = 'w_page.summary as summary';
// 公開開始日
$field_ary[] = 'w_page.publish_start as publish_start';
// 公開終了日
$field_ary[] = 'w_page.publish_end as publish_end';
// 作成者情報
// 組織情報
$field_ary[] = 't_user.dept_code as dept_code';
$field_ary[] = 't_user.dept_name as dept_name';
// 作成者
$field_ary[] = 'w_page.user_id as user_id';
$field_ary[] = 't_user.name as user_name';
// ページステータス
$field_ary[] = 'w_page.status as status';
// 非公開フラグ
$field_ary[] = 'w_page.close_flg as close_flg';
// 問い合わせ先備考
$field_ary[] = 'w_page.inquiry_memo as inquiry_memo';
// 問い合わせ先ID
$field_ary[] = 'w_page.inquiry_id as inquiry_id';

// イベントカレンダー単一日の場合
if (!EVENT_CAL_MULTI_FLAG) {
	// 開催開始日
	$field_ary[] = 'w_page.open_start as open_start';
	// 開催終了日
	$field_ary[] = 'w_page.open_end as open_end';
}

$fields = implode(' , ', $field_ary);

$obj_dac->setTableName($table);
// SQL実行
$obj_dac->select($where, $fields, $orderBy);

// 編集中のデータを取得する
while ($obj_dac->fetch()) {
	$page_id = $obj_dac->fld['page_id'];
	$work_ids[] = $page_id;
	$page_ids[] = $page_id;
	// ページ基本情報取得
	$page_fld[$page_id] = $obj_dac->fld;
	// 情報取得対象テーブル初期化
	$page_fld[$page_id]['table'] = WORK_TABLE;
}

// 公開中の情報を取得する------------------------------------------------------------------------------------
$table = '';
$table_ary = array();
$table_ary[] = 'tbl_publish_page AS p_page';
// 公開情報の親ページパス取得
$table_ary[] = 'tbl_publish_page AS p_parent ON p_page.parent_id = p_parent.page_id';
// 公開情報のユーザー情報取得
$table_ary[] = 'tbl_user AS t_user ON p_page.user_id = t_user.user_id';
// 公開情報のカテゴリー名取得
$table_ary[] = 'tbl_category AS t_cate ON p_page.cate_code = t_cate.cate_code';
$table = implode(' LEFT JOIN ', $table_ary);

$where = '';
$where_ary = array();
$obj_dac = new dac($objCnc);
// 指定のテンプレート
if (strlen($def['cms_template_id']) > 0) {
	$where_ary[] = 'p_page.template_id = ' . $def['cms_template_id'];
}
// 期間指定
if (isset($def['publish_start']) && $def['publish_start'] != '') {
	$where_ary[] = '(p_page.publish_start >= \'' . $def['publish_start'] . '\' OR p_page.publish_end >= \'' . $def['publish_start'] . '\')';
}
if (isset($def['publish_end']) && $def['publish_end'] != '') {
	$where_ary[] = '(p_page.publish_end <= \'' . $def['publish_end'] . '\' OR p_page.publish_start <= \'' . $def['publish_end'] . '\')';
}
// 作成者の条件
if ($def['user_id'] != '') {
	$where_ary[] = '(p_page.user_id = ' . $def['user_id'] . ')';
}
//非公開中ページを含まない場合は公開中のもののみを指定する
if ($def['open_status'] == 2) {
	$where_ary[] = 'p_page.close_flg = ' . FLAG_OFF;
}
// 編集中情報のページIDを除外する
if (!empty($work_ids)) {
	$work_id = implode(',', $work_ids);
	$where_ary[] = 'NOT p_page.page_id IN (' . $work_id . ')';
}
$where = implode(' AND ', $where_ary);
// ソート順 ページIDの昇順
$orderBy = 'p_page.page_id asc';

// 取得する項目を指定
// 公開中ページ情報
$fields = '';
$field_ary = array();
// ページID
$field_ary[] = 'p_page.page_id as page_id';
// 状態
$field_ary[] = 'p_page.work_class as work_class';
// ページタイトル
$field_ary[] = 'p_page.page_title as page_title';
// ファイルパス
$field_ary[] = 'p_page.file_path as file_path';
// 親ページパス
$field_ary[] = 'p_page.parent_id as paretn_id';
$field_ary[] = 'p_parent.file_path as parent_path';
// 分類コード
$field_ary[] = 'p_page.cate_code as cate_code';
$field_ary[] = 't_cate.name as cate_name';
// テンプレートID
$field_ary[] = 'p_page.template_id as template_id';
// 検索キーワード
$field_ary[] = 'p_page.keywords as keywords';
// 説明文
$field_ary[] = 'p_page.description as description';
// 要約文
$field_ary[] = 'p_page.summary as summary';
// 公開開始日
$field_ary[] = 'p_page.publish_start as publish_start';
// 公開終了日
$field_ary[] = 'p_page.publish_end as publish_end';
// 作成者情報
// 組織情報
$field_ary[] = 't_user.dept_code as dept_code';
$field_ary[] = 't_user.dept_name as dept_name';
// 作成者
$field_ary[] = 'p_page.user_id as user_id';
$field_ary[] = 't_user.name as user_name';
// ページのステータス
$field_ary[] = 'p_page.status as status';
// 公開・非公開フラグ
$field_ary[] = 'p_page.close_flg as close_flg';
// 問い合わせ先備考
$field_ary[] = 'p_page.inquiry_memo as inquiry_memo';
// 問い合わせ先ID
$field_ary[] = 'p_page.inquiry_id as inquiry_id';

// イベントカレンダー単一日の場合
if (!EVENT_CAL_MULTI_FLAG) {
	// 開催開始日
	$field_ary[] = 'p_page.open_start as open_start';
	// 開催終了日
	$field_ary[] = 'p_page.open_end as open_end';
}

$fields = implode(' , ', $field_ary);
$obj_dac->setTableName($table);
// SQL実行
$obj_dac->select($where, $fields, $orderBy);

// 公開中のデータを取得する
while ($obj_dac->fetch()) {
	$page_id = $obj_dac->fld['page_id'];
	$page_ids[] = $page_id;
	// ページ基本情報取得
	$page_fld[$page_id] = $obj_dac->fld;
	// 情報取得対象テーブル初期化
	$page_fld[$page_id]['table'] = PUBLISH_TABLE;
}
// 検索結果件数取得
$exportCnt = count($page_fld);

if (EXPORTMAX > 0 && $exportCnt > EXPORTMAX) {
	exportError('該当するページ情報が出力可能件数を超えています。抽出範囲を調整してください。');
}

// イベント開催期間ヘッダ作成数
$open_date_count = 0;
// 問い合わせ先ヘッダ作成数
$inquiry_count = 0;
// 地図情報カラム取得
$map_name = '';
$map_header = '';
$map_format = '';
// データを取得する
foreach ($page_ids as $page_id) {
	// テーブル情報の指定 公開テーブルか編集テーブルか
	$table = $page_fld[$page_id]['table'];
	// 問い合わせ情報検索用ID初期化
	$inqID = $page_fld[$page_id]['inquiry_id'];
	
	// 定型情報取得
	// 検索条件指定
	$fixed_where = $obj_kanko->_addslashesC('page_id', $page_id);
	// テーブルセット
	$obj_kanko->setTableName($table);
	// 検索実行
	$obj_kanko->select($fixed_where);
	// 検索結果取得
	while ($obj_kanko->fetch()) {
		$fixed_fld = $obj_kanko->fld;
		$fixed_fld_ary[$page_id][$fixed_fld['item']] = $fixed_fld['context'];
		// 依存ファイルを取得する設定でtypeが画像の場合、画像パスを取得
		if ($def['file_status'] == 1 && $fixed_fld['type'] === 'image') {
			$link_file[] = array_shift(explode(KANKO_ITEM_DELIMITER, $fixed_fld['context']));
		}
	}
	// 該当ページIDの依存ファイル抽出（画像以外）
	// 依存ファイル取得設定の場合のみ実行
	if ($def['file_status'] == 1) {
		$obj_links->selectRelated($page_id, $table);
		while ($obj_links->fetch()) {
			if ($obj_links->fld['path'] == '') {
				continue;
			}
			// 空フォルダは生成しない
			if ($obj_links->fld['file_size'] == '') {
				continue;
			}
			// 依存ファイルのパスを取得
			$link_file[] = $obj_links->fld['path'];
		}
	}
	
	// イベント開催期間情報取得------------------------------------------------------------------------------------
	if (EVENT_CAL_MULTI_FLAG) {
		// 検索条件指定
		$event_where = $obj_event->_addslashesC('page_id', $page_id);
		// テーブルセット
		$obj_event->setTableName($table);
		// 検索実行
		$obj_event->select($event_where);
		// 検索結果取得
		$open_date_cnt = 1;
		while ($obj_event->fetch()) {
			// イベントカレンダーの複数期間設定の上限を超える情報は出力しない
			if ($open_date_cnt > EVENT_SET_LIMIT) {
				break;
			}
			$event_fld = $obj_event->fld;
			$no = $open_date_cnt;
			// 開催開始日取得
			$open_start = '';
			if (!empty($event_fld['open_start']) && preg_match('/(\d{4}\-\d{1,2}\-\d{1,2}) (\d{1,2}:\d{1,2}:\d{1,2})/', $event_fld['open_start'], $match)) {
				$open_start = str_replace('-', '/', $match[1]);
				if ($match[2] != '00:00:00') {
					$open_start .= ' ' . $match[2];
				}
			}
			// 開催終了日取得
			$open_end = '';
			if (!empty($event_fld['open_end']) && preg_match('/(\d{4}\-\d{1,2}\-\d{1,2}) (\d{1,2}:\d{1,2}:\d{1,2})/', $event_fld['open_end'], $match)) {
				$open_end = str_replace('-', '/', $match[1]);
				if ($match[2] != '00:00:00') {
					$open_end .= ' ' . $match[2];
				}
			}
			
			$page_fld[$page_id][KANKO_IMP_PAGE_OPEN_START . $no] = $open_start;
			$page_fld[$page_id][KANKO_IMP_PAGE_OPEN_END . $no] = $open_end;
			
			// 開催期間個数の比較
			if ($open_date_count < $no) {
				// 開催期間最大個数を更新
				$open_date_count = $no;
			}
			$open_date_cnt++;
		}
	}
	
	// 地図情報取得------------------------------------------------------------------------------------
	// 検索条件指定
	$map_where = $obj_map->_addslashesC('page_id', $page_id);
	// テーブルセット
	$obj_map->setTableName($table);
	// 検索実行
	$obj_map->select($map_where);
	// 検索結果取得
	while ($obj_map->fetch()) {
		$map_fld = $obj_map->fld;
		// 地図情報保持
		$fixed_fld_ary[$page_id][$map_fld['map_name']] = $map_fld['map_url'];
		// 地図エリア名の取得
		if (empty($map_name) && empty($map_header)) {
			// ヘッダに追加
			$map_name = $map_fld['map_name'];
			$map_header = '緯度経度情報';
		}
	}
	
	// 問い合わせ情報取得（問い合わせ情報がある場合のみ----------------------------------------------
	if (empty($inqID)) {
		continue;
	}
	// テーブルセット
	$inq_table = '';
	$inq_table_ary = array();
	if ($table == WORK_TABLE) {
		$inq_table_ary[] = 'tbl_work_inquiry as t_inq';
	}
	else {
		$inq_table_ary[] = 'tbl_publish_inquiry as t_inq';
	}
	$inq_table_ary[] = 'tbl_department AS t_dept ON ' . 't_inq.dept_code = t_dept.dept_code';
	$inq_table = implode(' LEFT JOIN ', $inq_table_ary);
	$inq_where = 't_inq.inquiry_id=' . $inqID;
	// 問い合わせ先情報の出力数分の条件を追加
	$inq_where_no = array();
	for($i = 1; $i <= KANKO_INQUIRY_EXPORT_CNT; $i++) {
		$inq_where_no[] = 't_inq.inquiry_no=' . $i;
	}
	$inq_where_no = implode(' OR ', $inq_where_no);
	$inq_where .= ' AND (' . $inq_where_no . ')';
	
	$inq_fields = '';
	$inq_fields_ary = array();
	// 問い合わせ先番号
	$inq_fields_ary[] = 't_inq.inquiry_no as inquiry_no';
	// 問い合わせ先
	$inq_fields_ary[] = 't_inq.dept_code as inquiry_dept';
	// 問い合わせ先組織名称
	$inq_fields_ary[] = 't_dept.dept_name as inquiry_dept_name';
	// 問い合わせ先名称
	$inq_fields_ary[] = 't_inq.name as inquiry_name';
	// 問い合わせ先電話番号
	$inq_fields_ary[] = 't_inq.drxt_number as inquiry_tel';
	// 問い合わせ先内線番号
	$inq_fields_ary[] = 't_inq.anex_number as inquiry_ext';
	// 問い合わせ先ファックス番号
	$inq_fields_ary[] = 't_inq.fax as inquiry_fax';
	// 問い合わせ先メールアドレス
	$inq_fields_ary[] = 't_inq.email as inquiry_mail';
	$inq_fields = implode(', ', $inq_fields_ary);
	$obj_inq->setTableName($inq_table);
	$obj_inq->select($inq_where, $inq_fields);
	
	// 検索結果取得
	while ($obj_inq->fetch()) {
		$inq_fld = $obj_inq->fld;
		$no = $inq_fld['inquiry_no'];
		$page_fld[$page_id]['dept_code' . $no] = $inq_fld['inquiry_dept'];
		$page_fld[$page_id]['name' . $no] = $inq_fld['inquiry_name'];
		$page_fld[$page_id]['drxt_number' . $no] = $inq_fld['inquiry_tel'];
		$page_fld[$page_id]['anex_number' . $no] = $inq_fld['inquiry_ext'];
		$page_fld[$page_id]['fax' . $no] = $inq_fld['inquiry_fax'];
		$page_fld[$page_id]['email' . $no] = $inq_fld['inquiry_mail'];
		if ($inquiry_count < $no) {
			$inquiry_count = $no;
		}
	}
}

// CSVヘッダの作成------------------------------------------------------------------------------------
$fixed_header = getDefineArray('FIXED_EXPORT_CSV_FORMAT');
foreach ($fixed_header as $header => $colum) {
	// データフォーマット情報セット
	$csv_data_format[$header] = '';
	// ヘッダー情報セット
	// カテゴリーコード（識別用）はヘッダから除外
	if ($header === 'cate_code') {
		continue;
	}
	// カラム名ヘッダ
	$csv_header_cols[] = $header;
	// 和名ヘッダ
	$csv_header[] = $colum;
}
// 開催期間ヘッダ作成
for($i = 1; $i <= $open_date_count; $i++) {
	// フォーマット
	$csv_data_format[KANKO_IMP_PAGE_OPEN_START . $i] = '';
	$csv_data_format[KANKO_IMP_PAGE_OPEN_END . $i] = '';
	// カラム名ヘッダ
	$csv_header_cols[] = KANKO_IMP_PAGE_OPEN_START . $i;
	$csv_header_cols[] = KANKO_IMP_PAGE_OPEN_END . $i;
	// 和名ヘッダ
	$csv_header[] = '開催期間【開始日】' . $i;
	$csv_header[] = '開催期間【終了日】' . $i;
}

// 問い合わせ先ヘッダ作成
for($i = 1; $i <= $inquiry_count; $i++) {
	// フォーマット
	$csv_data_format['dept_code' . $i] = '';
	$csv_data_format['name' . $i] = '';
	$csv_data_format['drxt_number' . $i] = '';
	$csv_data_format['anex_number' . $i] = '';
	$csv_data_format['fax' . $i] = '';
	$csv_data_format['email' . $i] = '';
	// カラム名ヘッダ
	$csv_header_cols[] = 'dept_code' . $i;
	$csv_header_cols[] = 'name' . $i;
	$csv_header_cols[] = 'drxt_number' . $i;
	$csv_header_cols[] = 'anex_number' . $i;
	$csv_header_cols[] = 'fax' . $i;
	$csv_header_cols[] = 'email' . $i;
	// 和名ヘッダ
	$csv_header[] = '問い合わせ先組織' . $i;
	$csv_header[] = '問い合わせ先名称' . $i;
	$csv_header[] = '問い合わせ先電話番号' . $i;
	$csv_header[] = '問い合わせ先内線番号' . $i;
	$csv_header[] = '問い合わせ先ファックス番号' . $i;
	$csv_header[] = '問い合わせ先メールアドレス' . $i;
}

// 定型項目のCSVヘッダ用情報取得
$items = getItem($def['cms_template_id'], '', 'all');
foreach ((array) $items as $item) {
	// グループはスキップ
	if (isset($item['group'])) {
		continue;
	}
	// CSVヘッダー情報に定型項目名と和名を追加
	$csv_header_cols[] = $item['id'];
	$csv_header[] = $item['name'];
	// CSVデータフォーマットに定型項目を追加
	// 定型項目カラム名 = 項目タイプ
	foreach ($item['ctrl'] as $system) {
		$csv_data_format[$item['id']] = $system['type'];
	}
}
// 地図情報のヘッダ
if (!empty($map_name) && !empty($map_header)) {
	$csv_data_format[$map_name] = 'map';
	$csv_header_cols[] = $map_name;
	$csv_header[] = '緯度経度情報';
}

// 出力情報を作成------------------------------------------------------------------------------------
// 出力情報のヘッダから情報を順番に取得していく
// tbl_pageのデータ（定型項目が空だった場合でも出力するため）
if (!ksort($page_fld)) {
	exportError('ページデータのソートに失敗しました。');
}

foreach ($page_fld as $page_id => $page_data) {
	$csv_data = array();
	foreach ($csv_data_format as $column => $data) {
		// カテゴリーコード分割処理の項目は以下の処理をしないで続行
		if ($column == 'cate_1' || $column == 'cate_2' || $column == 'cate_3' || $column == 'cate_4') {
			continue;
		}
		$csv_data[$column] = '';
		if (isset($fixed_fld_ary[$page_id][$column])) {
			// 値が空の場合は続行
			if (empty($fixed_fld_ary[$page_id][$column])) {
				continue;
			}
			// 定型情報取得
			$fixed_data = $fixed_fld_ary[$page_id][$column];
			if ($data === 'link' || $data === 'image' || $data === 'mail' || $data === 'file') {
				$link_ary = array();
				$link_ary = explode(KANKO_ITEM_DELIMITER, str_replace(KANKO_LINK_DELIMITER, KANKO_ITEM_DELIMITER, $fixed_data));
				// パス内に「/cms8341」が存在していた場合、「/cms8341」を削除
				$link_ary[0] = str_replace(RPW, '', $link_ary[0]);
				// 再格納
				$fixed_data = implode(KANKO_ITEM_DELIMITER, $link_ary);
			}
			else if ($data === 'youtube') {
				// 区切り文字で分解し、配列に格納
				$youtube_data_ary = explode(KANKO_LINK_DELIMITER, $fixed_data);
				//定数の読み込み
				$YOUTUBE_PATTERN_ARY = getDefineArray('YOUTUBE_PATTERN_ARY');
				// YoutubeURLの正規表現パターン
				$youtube_pattern = '[' . implode('|', $YOUTUBE_PATTERN_ARY) . ']';
				// 分解処理結果格納用配列の定義
				$result_ary = array();
				// 各パラメータを格納する変数の定義
				$param = '';
				foreach ($youtube_data_ary as $youtube_key => $youtube_data) {
					// youtube URLが存在する場合、以下を処理
					if ($youtube_key == 0 && preg_match('{' . $youtube_pattern . '}i', $youtube_data)) {
						// ビデオIDまでのYoutubeURLを抜き出す
						$result_ary[] = preg_replace('/(.*v=([-\w]+))(\&*.*)/i', '$1', $youtube_data);
						// 各パラメータを抜き出す
						$param = preg_replace('/(.*v=([-\w]+))(\&*.*)/i', '$3', $youtube_data);
					}
					// youtube URLが存在しない場合、以下を処理
					else {
						// 配列の2要素目：タイトル
						if ($youtube_key == 1) {
							$result_ary[] = 'title=' . $youtube_data;
						}
						// 配列の3要素目：横幅
						else if ($youtube_key == 2) {
							$result_ary[] = 'width=' . $youtube_data;
						}
						// 配列の4要素目：縦幅
						else if ($youtube_key == 3) {
							$result_ary[] = 'height=' . $youtube_data;
						}
					}
				}
				// 各パラメータが空ではない場合、以下を処理
				if (!empty($param)) {
					// 各パラメータ格納
					foreach (explode('&', $param) as $youtube_param) {
						if (!empty($youtube_param)) {
							$result_ary[] = $youtube_param;
						}
					}
				}
				// 定型情報に格納
				$fixed_data = implode(KANKO_ITEM_DELIMITER, $result_ary);
			}
			// 情報セット
			$csv_data[$column] = $fixed_data;
		}
		else {
			// 基本の情報
			// $dataにtype情報が入っている場合は空の定型項目なので続行
			if (!empty($data)) {
				continue;
			}
			// 値が空の場合は続行
			if (empty($page_fld[$page_id][$column])) {
				continue;
			}
			if ($column == 'cate_code') {
				// カテゴリーコードの分割処理を追加する
				$cate_codes = str_split($page_fld[$page_id][$column], 3);
				for($i = 1; $i < 5; $i++) {
					$csv_data['cate_' . $i] = $cate_codes[$i - 1];
				}
				unset($csv_data[$column]);
			}
			else if ($column == 'status') {
				// ステータスの設定
				$csv_data[$column] = getExportStatus($page_fld[$page_id]);
			}
			else {
				$csv_data[$column] = $page_fld[$page_id][$column];
			}
		}
	}
	// CSV出力情報を保持
	unset($page_fld[$page_id]);
	unset($fixed_fld_ary[$page_id]);
	$csv_data_ary[$page_id] = $csv_data;
}

// 依存ファイル情報の取得------------------------------------------------------------------------------------
// 依存ファイルを取得する設定で依存ファイルがあるとき、ファイルをコピーする
if ($def['file_status'] == 1 && !empty($link_file)) {
	$check_size = 0;
	foreach ($link_file as $link_data) {
		$copy_path = DOCUMENT_ROOT . KANKO_COPY_DIR_FILES . $link_data;
		$old_path = DOCUMENT_ROOT . RPW . $link_data;
		// フォルダ作成
		if (!mkNewDirectory($copy_path)) {
			exportError('依存ファイルのコピー先フォルダの作成に失敗しました。：' . $link_data);
		}
		// ファイルコピー
		if (file_exists($old_path) && is_file($old_path)) {
			if (!@copy($old_path, $copy_path)) {
				exportError('一時ファイルのアップロードに失敗しました。：' . $link_data);
			}
			// パーミッションの変更
			if (!@chmod($copy_path, 0777)) {
				exportError('パーミッションの変更に失敗しました。：' . $link_data);
			}
			// ファイルの存在チェック
			if (!file_exists($copy_path)) {
				exportError('一時ファイルが存在しません。：' . $link_data);
			}
			// 指定フォルダ内の容量チェック
			$file_size = filesize($copy_path);
			$check_size = $check_size + $file_size;
			if ($check_size > EXPORT_FILE_MAX) {
				exportError('依存ファイルの容量が設定値' . EXPORT_FILE_MAX . 'byteを超えました。検索範囲を絞り込み、再度エクスポートを行ってください。');
			}
		}
	}
}

// CSV出力------------------------------------------------------------------------------------
// カラム名ヘッダを先頭に追加
if (!empty($csv_data_ary)) {
	array_unshift($csv_data_ary, $csv_header);
}
else {
	// 出力する情報がないときはヘッダ部分のみ出力する
	$csv_data_ary[] = $csv_header;
}
if (!create_Csv(KANKO_EXPORT_CSV, $csv_data_ary, $csv_header_cols, 1, KANKO_EXPORT_DIR_DATA, 'SJIS', "\"")) {
	exportError('定型情報(CSVファイル)の出力に失敗しました。');
}
// CSVファイルの権限変更
if (!@chmod(DOCUMENT_ROOT . KANKO_EXPORT_DIR_DATA . '/' . KANKO_EXPORT_CSV, 0777)) {
	exportError('定型情報(CSVファイル)の権限設定に失敗しました。');
}

//Zipを作成------------------------------------------------------------------------------------
// 保存先フォルダの作成
if (!is_dir(KANKO_EXPORT_ZIP_DIR)) {
	if (!@mkdir(KANKO_EXPORT_ZIP_DIR, 0777)) {
		exportError('圧縮先フォルダの作成に失敗しました。');
	}
}
//Zipの作成に失敗
if (create_Zip(DOCUMENT_ROOT . KANKO_EXPORT_DIR, $zip_path) === FALSE) {
	exportError('Zipファイルの作成に失敗しました。');
}
//Zipの作成に成功
else if (@file_exists($zip_path)) {
	if (($fp = @fopen($zip_path, 'rb')) === FALSE) {
		exportError('Zipファイルの読み込みに失敗しました。【' . $zip_path . '】' . "<br>\n");
	}
	else {
		//ヘッダ出力
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename=' . basename($zip_path));
		header('Content-Length: ' . @filesize($zip_path));
		while ($zip_data = @fread($fp, 4096)) {
			print($zip_data);
		}
	}
	if ($fp) {
		@fclose($fp);
	}
}

// 事後処理------------------------------------------------------------------------------------
// CSV出力後 SESSIONを削除
if (isset($_SESSION['kanko_export'])) {
	unset($_SESSION['kanko_export']);
}
// ZIPファイルと一時ファイルを削除
deleteZip($zip_path);
deleteTempDir();

exit();
?>