<?php
/**
 * 定型情報インポート実行画面
 */

//外部ファイルの読み込み
require ('../.htsetting');
//DB用定義ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
//DB用追加定義ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
//ページ情報テーブル用定義ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
//リンクテーブル用定義ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
//イメージテーブル用定義ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
//観光情報テーブル用定義ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);
// 紐付けクラス用設定ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
// カテゴリテーブル用定義ファイル
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);
// 問い合わせ先
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);

// 定型情報インポート・エクスポート用定数ファイル
require_once (APPLICATION_ROOT . '/common/setting_fixed.inc');
// 定型情報エクスポート用関数ファイル
require_once ('./include/common.inc');

// エラーの戻り先を指定
gd_errorhandler_ini_set('html0', RPW . '/admin/special/file/kanko_import/import.php?bak=1');

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// セッションにデータがなければエラー
if (!isset($_SESSION['post'])) {
	user_error("It isn't setted posted data in _session.", E_USER_ERROR);
}
$post = $_SESSION['post'];

// ウェブマスター以外でCSV情報優先の場合はエラー
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $post['cms_priority'] == KANKO_PRIORITY_CSV) {
	user_error('不正アクセスです。');
}
$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';
// ファイル存在チェック
if (!file_exists($tmpUpDir)) {
	user_error('取り込みデータが見つかりません。');
}
// ファイルが一つも選択されていなければエラー
if (!isset($_SESSION['kanko']['check']) || count($_SESSION['kanko']['check']) < 1) {
	user_error('取り込むページを選択してください。');
}
$up_page_line = $_SESSION['kanko']['check'];

// 取り込み処理
$aryUpFiles = array();
$item_ary = array();

// CSVの指定が無かった場合はエラー
if (!isset($_SESSION['post']['cms_csv_name']) || $_SESSION['post']['cms_csv_name'] == '') {
	user_error('CSVファイルの読み込みに失敗しました。');
}
$file_name_ary = array(
	$post['cms_csv_name']
);

// CSVファイルが指定されていた場合
// CSVファイル数ループ
foreach ($file_name_ary as $filename) {
	// ファイル情報を格納
	$aryF = array(
		'file_path' => $filename, 
		'page_title' => '', 
		'pagefile' => TRUE, 
		'error' => FALSE, 
		'mode' => 'ins', 
		'overwrite' => FALSE, 
		'message' => ''
	);
	
	// CSVファイルを開く
	$file_path = $tmpUpDir . $filename;
	if (!($CsvFno = @fopen($file_path, 'r'))) {
		$aryUpFiles[$filename][$filename] = _set_error($aryF, 'CSVファイルが参照できませんでした。');
		continue;
	}
	$buf = ChgEncoding(file_get_contents($file_path));
	$CsvFno = tmpfile();
	if (!fwrite($CsvFno, $buf)) {
		user_error('ファイルの書き込みに失敗しました。');
	}
	if (!rewind($CsvFno)) {
		user_error('ファイルポインタを先頭に戻す処理に失敗しました。');
	}
	
	// EOFになるまで読み出し
	$ok_cnt = -2;
	$bck_cnt = -3;
	// 添え字データ
	$arr_name = array();
	// CSVを読み終えるまでループ
	while ($csv_data = cms_fgetcsv($CsvFno, 10000)) {
		// 前の行数と今の行数が違えばカウントアップ
		if ($ok_cnt != $bck_cnt) {
			$bck_cnt = $ok_cnt;
			$ok_cnt++;
		}
		// 空行はスキップ
		if (!isset($csv_data[1])) {
			continue;
		}
		
		// ファイル情報を格納
		$aryF = array(
			'file_path' => $filename, 
			'page_title' => '', 
			'pagefile' => TRUE, 
			'error' => FALSE, 
			'mode' => 'ins', 
			'overwrite' => FALSE, 
			'message' => ''
		);
		//データ配列
		$arrCSV = array();
		//変数のクリア
		$aryMkFiles = array();
		$aryParent_path = '';
		$file_data_ary = array();
		//添え字クリア
		$csv_idx = 0;
		//1行目の添え字データを読み込む
		if ($ok_cnt == -1) {
			foreach ($csv_data as $data) {
				$arr_name[] = ChgEncoding(trim($data));
			}
		}
		// 2行目の添え字(日本語)をスキップ
		else if ($ok_cnt == 0) {
			continue;
		}
		// 項目格納（連想配列名はDB項目名と等しい）
		else {
			foreach ($csv_data as $data) {
				$arrCSV[$arr_name[$csv_idx++]] = ChgEncoding(trim($data));
			}
		}
		
		// 確認画面にて選択されていないページはスキップ
		if (!in_array($ok_cnt, $up_page_line)) {
			continue;
		}
		// 実データならDB書き込み
		if ($ok_cnt > 0) {
			// エラーが有ればロールバック
			if (isset($errFlg)) {
				if ($errFlg) {
					$objCnc->rollback();
				}
				// エラーが無ければコミット
				else {
					$objCnc->commit();
				}
			}
			// エラーフラグ初期化
			$errFlg = FALSE;
			
			// ページ情報登録
			if (isset($arrCSV[KANKO_IMP_PAGE_TITLE]) && $arrCSV[KANKO_IMP_PAGE_TITLE] != '') {
				$aryF['page_title'] = $arrCSV[KANKO_IMP_PAGE_TITLE];
			}
			
			// トランザクション
			$objCnc->begin();
			
			// エラーチェック
			// アップロード先のチェック
			$file_err = checkImportFile($arrCSV, $objLogin);
			if (!empty($file_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . '_'] = _set_error($aryF, $file_err);
				$errFlg = TRUE;
				continue;
			}
			
			// 優先情報がCSVのときのみチェック
			if ($post['cms_priority'] == KANKO_PRIORITY_CSV) {
				// 公開開始日、公開終了日、ユーザID、ファイルパスがCSVファイルに存在しない場合は、エラー出力
				if (!isset($arrCSV['publish_start']) || $arrCSV['publish_start'] == '') {
					user_error('公開開始日がCSVに指定されていません。');
				}
				if (!isset($arrCSV['publish_end']) || $arrCSV['publish_end'] == '') {
					user_error('公開終了日がCSVに指定されていません。');
				}
				if (!isset($arrCSV['user_id']) || $arrCSV['user_id'] == '') {
					user_error('作成者が指定されていません。');
				}
				if (!isset($arrCSV['file_path']) || $arrCSV['file_path'] == '') {
					user_error('ファイルパスが指定されていません。');
				}
				// フォーマットを揃える
				$arrCSV['publish_start'] = str_replace('/', '-', $arrCSV['publish_start']);
				$arrCSV['publish_end'] = str_replace('/', '-', $arrCSV['publish_end']);
				$publish_start_date = explode(' ', $arrCSV['publish_start']);
				// 時間が空の場合はデフォルト値を入れる
				if (!isset($publish_start_date[1]) && !empty($publish_start_date[0])) {
					$arrCSV['publish_start'] = $arrCSV['publish_start'] . ' ' . KANKO_IMPORT_START_TIME;
				}
				$publish_end_date = explode(' ', $arrCSV['publish_end']);
				// 時間が空の場合はデフォルト値を入れる
				if (!isset($publish_end_date[1]) && !empty($publish_end_date[0])) {
					$arrCSV['publish_end'] = $arrCSV['publish_end'] . ' ' . KANKO_IMPORT_END_TIME;
				}
				// 公開日時チェック
				$date_err = checkPublishDate($arrCSV['publish_start'], $arrCSV['publish_end']);
				if (!empty($date_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $date_err);
					$errFlg = TRUE;
					continue;
				}
				// 作成者チェック
				$user_err = checkUserId($arrCSV['user_id'], $objCnc, $arrCSV['file_path']);
				if (!empty($user_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $user_err);
					$errFlg = TRUE;
					continue;
				}
				else {
					// 存在するユーザーIDの場合は組織コードを取得する
					$objDac->setTableName('tbl_user');
					$objDac->select($objDac->_addslashesC('user_id', $arrCSV['user_id']), 'dept_code');
					while ($objDac->fetch()) {
						$post['cms_target3'] = $objDac->fld['dept_code'];
					}
				}
			}
			
			// アップロード先情報の取得
			$cms_dir = cms_dirname($arrCSV[KANKO_IMP_DIR_PATH]) . '/';
			if ($cms_dir === '.' || $cms_dir === '/') {
				$cms_dir = '/';
			}
			else if (substr($cms_dir, 0, 1) != '/') {
				$cms_dir = '/' . $cms_dir;
			}
			$cms_dir = str_replace('//', '/', $cms_dir);
			$file_name = basename($arrCSV[KANKO_IMP_DIR_PATH]);
			
			// テンプレート関連のエラーチェック
			$template_err = checkImportTemplate($arrCSV, $objDac, $objTool, $post['cms_target3']);
			if (!empty($template_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $template_err);
				$errFlg = TRUE;
				continue;
			}
			
			// 分類コードのエラーチェック
			$cate_err = checkImportCategory($arrCSV);
			if (!empty($cate_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $cate_err);
				$errFlg = TRUE;
				continue;
			}
			
			// 必須項目チェック
			// XMLファイルから情報取得
			if (!isset($item_ary[$arrCSV[KANKO_IMP_TMP_ID]])) {
				$item_ary[$arrCSV[KANKO_IMP_TMP_ID]] = getItem($arrCSV[KANKO_IMP_TMP_ID], '', 'edit');
			}
			$items = $item_ary[$arrCSV[KANKO_IMP_TMP_ID]];
			
			// 必須チェック
			$err_ary = isNull($items, $arrCSV, $KANKO_IMP_NOT_ERR_ID);
			// 必須エラーがあればエラーとしてセットする
			if ($err_ary[0]) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'CSVファイルの必須入力は全て入力してください。[' . $err_ary[1] . ']');
				$errFlg = TRUE;
				continue;
			}
			
			// 項目チェック
			$err_ary = isErr($items, $arrCSV, $tmpUpDir . $_SESSION['post']['import_dir_name']);
			// 項目エラーがあればエラーとしてセットする
			if ($err_ary[0]) {
				if ((string) $err_ary[0] == KANKO_IMP_CHECK_FILES_FLG) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $err_ary[2]);
				}
				else {
					// 依存ファイルのエラーでなかったらエラーフラグを立てる
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $err_ary[2] . '[' . $err_ary[1] . ']');
					$errFlg = TRUE;
					continue;
				}
			}
			
			//「tbl_～_page」の登録データをセット
			unset($ary);
			// tbl_publish_pageに登録するデータの確認
			$template_ver = $objTool->fld['template_ver'];
			$ary = setImportData($post, $template_ver, $objTool, $arrCSV);
			
			// 分類存在・イベントテンプレート時のイベント開催終了期間チェック
			$page_err = checkImportPage($ary, $template_ver, $objCate, $objTool);
			if (!empty($page_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $page_err);
				$errFlg = TRUE;
				continue;
			}
			
			// パンくず設定
			$ancestor_path = "";
			if (!($ary['template_kind'] == TEMPLATE_KIND_FIXED && $objTool->selectTemplateKankoType($ary['template_id']) == KANKO_TYPE_EVENT)) {
				if (isset($ary[KANKO_IMP_PAR_PATH]) && $ary[KANKO_IMP_PAR_PATH] != '') {
					$ancestor_err = checkImportAncestor($objCnc, $ary, $post['cms_user_id']);
					if (!empty($ancestor_err)) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $ancestor_err);
						$errFlg = TRUE;
						continue;
					}
					$objPage->selectFromPath($ary[KANKO_IMP_PAR_PATH]);
					$ancestor_path = $objPage->fld['ancestor_path'] . ',' . $objPage->fld['file_path'];
				}
				unset($ary[KANKO_IMP_PAR_PATH]);
				$ary['ancestor_path'] = $ancestor_path;
			}
			
			// 階層制限とフォルダの作成チェック
			$dir_err = checkImportDirectory($ary['file_path'], $objLogin);
			if (!empty($dir_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $dir_err);
				$errFlg = TRUE;
				continue;
			}
			
			// 問い合わせ先設定エラーチェック
			$err_msg = checkInquiryData($arrCSV, $objCnc);
			if (!empty($err_msg)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $err_msg);
				$errFlg = TRUE;
				continue;
			}
			// 問い合わせ先設定情報取得
			$inquiry_data_ary = setInquiryData($arrCSV);
			
			// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
			$objPage->setTableName(PUBLISH_TABLE);
			$objPage->select($objPage->_addslashesC('file_path', $ary['file_path']), 'page_id, work_class, status, template_id, inquiry_id, inquiry_flg');
			// 更新
			if ($objPage->fetch()) {
				$aryF['mode'] = 'upd';
				$page_id = $objPage->fld['page_id'];
				$ary['page_id'] = $page_id;
				$ary['pub_status'] = $objPage->fld['status'];
				
				// 更新情報のテンプレートチェック
				$update_err = checkImportUpdate($arrCSV[KANKO_IMP_TMP_ID], $objPage->fld['template_id'], $objPage->fld['status'], $objPage->fld['work_class']);
				if (!empty($update_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $update_err);
					$errFlg = TRUE;
					continue;
				}
				// 問い合わせ先ID
				$inquiry_id = '';
				$inquiry_flg = FLAG_OFF;
				if ((isset($inquiry_data_ary) && count($inquiry_data_ary) > 0) || isset($ary[KANKO_IMP_CSV_HEADER_INQUIRY_MEMO]) && $ary[KANKO_IMP_CSV_HEADER_INQUIRY_MEMO] != "") {
					if ($objPage->fld['inquiry_id'] == '') {
						$inquiry_id = $objInquiry->getSeqNextval();
						$inquiry_flg = FLAG_ON;
					}
					else {
						$inquiry_id = $objPage->fld['inquiry_id'];
						$inquiry_flg = FLAG_ON;
					}
				}
				$ary['inquiry_id'] = $inquiry_id;
				$ary['inquiry_flg'] = $inquiry_flg;
			}
			// 新規
			else {
				// 取り込みページファイルパス
				$filepath = DOCUMENT_ROOT . RPW . $cms_dir . $file_name;
				// 新規登録のファイル名チェック
				$ins_err = checkImportInsert($cms_dir, $file_name);
				if (!empty($ins_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $ins_err);
					$errFlg = TRUE;
					continue;
				}
				// 自動生成用ファイル既存チェック
				// 最新のテンプレート情報取得
				$tmp_fld = $objTool->selectTemplate($arrCSV[KANKO_IMP_TMP_ID]);
				if ($tmp_fld !== FALSE) {
					$mode_ary = array(
						'mobile' => '携帯'
					);
					foreach ((array) $mode_ary as $mode => $name) {
						// テンプレート登録チェック
						if ($tmp_fld[$mode . '_temp_txt'] == NULL || $tmp_fld[$mode . '_temp_txt'] == '') {
							continue;
						}
						if (strcmp($mode, 'mobile') == 0) {
							$dir_path = DIR_PATH_MOBILE;
						}
						$auto_add_filename = DOCUMENT_ROOT . RPW . $dir_path . $cms_dir . $file_name;
						if (@file_exists($auto_add_filename)) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $name . 'ページ自動アップロード先に同名のHTMLファイルが存在しています。【' . $dir_path . $cms_dir . $file_name . '】');
							$errFlg = TRUE;
							continue;
						}
					}
				}
				// ページIDの取得
				$page_id = $objPage->getSeqNextval();
				$ary['page_id'] = $page_id;
				// 新規作成ページをセット
				$aryMkFiles[$page_id] = $file_name;
				// 問い合わせ先IDを作成
				$inquiry_id = '';
				$inquiry_flg = FLAG_OFF;
				if ((isset($inquiry_data_ary) && count($inquiry_data_ary) > 0) || isset($ary[KANKO_IMP_CSV_HEADER_INQUIRY_MEMO]) && $ary[KANKO_IMP_CSV_HEADER_INQUIRY_MEMO] != "") {
					$inquiry_id = $objInquiry->getSeqNextval();
					$inquiry_flg = FLAG_ON;
				}
				$ary['inquiry_id'] = $inquiry_id;
				$ary['inquiry_flg'] = $inquiry_flg;
			}
			
			// CSV情報が優先の時はユーザーID、公開期間を格納する
			if ($post['cms_priority'] == KANKO_PRIORITY_CSV) {
				$ary['user_id'] = $arrCSV['user_id'];
				$ary['publish_start'] = $arrCSV['publish_start'];
				$ary['publish_end'] = $arrCSV['publish_end'];
			}
			
			//「tbl_～_page」に登録
			$page_err = insertPageData($aryF['mode'], $ary, $objDac, $objPage, $objLogin->login, $errmsg);
			if (!empty($page_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $page_err);
				$errFlg = TRUE;
				continue;
			}
			
			//「tbl_～_kanko」に登録
			$kanko_err = insertKankoData($aryF['mode'], $ary, $arrCSV, $objKanko, $objTool, $errmsg, $items, $KANKO_IMP_EDIT_DATA_ID, str_replace('/', '', $post['import_dir_name']));
			if (!empty($kanko_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $kanko_err);
				$errFlg = TRUE;
				continue;
			}
			
			//「tbl_～_link」に登録
			$link_err = insertLinkData($ary, $arrCSV, $objLinks, $errmsg, $items, $file_data_ary);
			if (!empty($link_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $link_err);
				$errFlg = TRUE;
				continue;
			}
			
			//「tbl_～_images」に登録
			$image_err = insertImagesData($ary, $arrCSV, $objImages, $errmsg, $items, $file_data_ary);
			if (!empty($image_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $image_err);
				$errFlg = TRUE;
				continue;
			}
			
			//「tbl_～_map」に登録
			$map_err = insertMapData($ary, $arrCSV, $errmsg, $items);
			if (!empty($map_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $map_err);
				$errFlg = TRUE;
				continue;
			}
			
			//「tbl_library」に登録
			$library_err = insertLibraryData($ary, $arrCSV, $errmsg, $aryF['mode']);
			if (!empty($library_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $library_err);
				$errFlg = TRUE;
				continue;
			}
			
			//「tbl_～_inquiry」に登録
			$inquiry_err = insertInquiryData($ary, $inquiry_data_ary, $errmsg);
			if (!empty($inquiry_err)) {
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $inquiry_err);
				$errFlg = TRUE;
				continue;
			}
			
			// イベントカレンダー複数日
			if (EVENT_CAL_MULTI_FLAG) {
				//「tbl_～_event」に登録
				if ($ary['template_kind'] == TEMPLATE_KIND_FIXED && $objTool->selectTemplateKankoType($ary['template_id']) == KANKO_TYPE_EVENT) {
					$event_err = insertEventData($ary, $errmsg, $aryF['mode']);
					if (!empty($event_err)) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $event_err);
						$errFlg = TRUE;
						continue;
					}
				}
			}
			
			// 親ページをセット
			if (preg_match('/^(.*,)?([^,]+)$/', $ary['ancestor_path'], $r)) {
				$aryParent_path = $r[2];
				// 親ページIDの更新
				// 親ページIDの取得
				$objPage->setTableName(PUBLISH_TABLE);
				$objPage->select($objPage->_addslashesC('file_path', $aryParent_path), 'page_id', 'page_id', '', 1);
				// IDが取得出来た場合
				if ($objPage->fetch() !== FALSE) {
					$parent_id = $objPage->fld['page_id'];
					// 更新処理
					$sql = 'UPDATE tbl_work_page SET parent_id = ' . $objDac->_addslashes($parent_id, 'INT') . ' WHERE page_id = ' . $page_id;
					if (!$objDac->execute($sql)) {
						$errmsg = '親ページIDの登録に失敗しました。【' . $page_id . '】';
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $errmsg);
						$errFlg = TRUE;
						continue;
					}
				}
			}
			
			// 権限を与えるディレクトリ
			$aryNewDir = array();
			// HTMLファイルの生成
			foreach ($aryMkFiles as $PID => $f_name) {
				$file_path = DOCUMENT_ROOT . RPW . $cms_dir . $f_name;
				$aryNewDir[] = $cms_dir;
				if (!mkNewDirectory($file_path)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'アップロード先フォルダの作成に失敗しました。【' . $file_path . '】');
					$errFlg = TRUE;
					continue;
				}
				if (mkNewPage($PID, $cms_dir . $f_name) === FALSE) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'HTMLファイルの生成に失敗しました。【' . $PID . '】');
					$errFlg = TRUE;
					continue;
				}
				
				// 自動生成処理
				if ($objTool->selectTemplate($arrCSV[KANKO_IMP_TMP_ID])) {
					$mode_ary = array(
						'mobile' => '携帯'
					);
					foreach ((array) $mode_ary as $mode => $name) {
						if (strcmp($mode, 'mobile') == 0) {
							$dir_path = DIR_PATH_MOBILE;
						}
						
						if ($objTool->fld[$mode . '_temp_txt'] != '') {
							// 自動生成ページダミーhtmlファイルパス
							$root_file_path = DOCUMENT_ROOT . RPW . $dir_path . $cms_dir . $f_name;
							// 自動生成ページダミーhtmlファイル保存先フォルダ作成
							if (!mkNewDirectory($root_file_path)) {
								$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $name . 'ページ自動アップロード先フォルダの作成に失敗しました。【' . $root_file_path . '】');
								$errFlg = TRUE;
								continue;
							}
							
							// 生成HTMLの内容
							$template_path = APPLICATION_ROOT . '/common/templates/' . $mode . '_dummypage.txt';
							$fp = fopen($template_path, 'r');
							$htmlStr = fread($fp, filesize($template_path));
							fclose($fp);
							// 自動掲載用ダミーHTML生成
							$fp = fopen($root_file_path, 'w');
							$r = fwrite($fp, $htmlStr);
							fclose($fp);
							chmod($root_file_path, 0777);
						}
					}
				}
			}
			
			// エラーがあった場合次へ
			if ($errFlg) {
				continue;
			}
			
			// 画像やその他ファイルのアップロード
			$up_dir = cms_dirname($arrCSV[KANKO_IMP_DIR_PATH]);
			foreach ((array) $file_data_ary as $dir_name => $file_data) {
				foreach ((array) $file_data as $file_path) {
					$file_basename = basename($file_path[0]);
					$file_name = $file_path[1];
					$copy_file_path = $tmpUpDir . str_replace('/', '', $post['import_dir_name']) . KANKO_IMP_FILE_DIR . '/' . preg_replace('/^\//', '', $file_path[0]);
					$up_file_path = $up_dir . $dir_name . '/' . strtolower($file_basename);
					
					$sExtension = substr($file_basename, (strrpos($file_basename, '.') + 1));
					$sExtension = strtolower($sExtension);
					$aryNewDir[] = cms_dirname($up_dir . $dir_name . '/' . strtolower($file_basename)) . '/';
					
					// フォルダ作成
					if (!mkNewDirectory(DOCUMENT_ROOT . RPW . $up_file_path)) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'アップロード先フォルダの作成に失敗しました。【' . $up_file_path . '】');
						$errFlg = TRUE;
						break;
					}
					// ファイルコピー
					// ファイルが一緒にアップロードされている場合
					if (!file_exists($copy_file_path)) {
						// 既にアップロードされているものを取得する
						$copy_file_path = KANKO_IMP_CHECK_FILE_PATH . '/' . preg_replace('/^\//', '', $file_path[0]);
					}
					// アップロード先にファイルがない場合のみファイルをコピーする（既にある場合は行わない）
					if (!file_exists(KANKO_IMP_CHECK_FILE_PATH . $up_file_path) && file_exists($copy_file_path)) {
						if (!@copy($copy_file_path, DOCUMENT_ROOT . RPW . $up_file_path)) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'ファイルのアップロードに失敗しました。【' . $up_file_path . '】');
							$errFlg = TRUE;
							break;
						}
						//パーミッションの変更
						if (!@chmod(DOCUMENT_ROOT . RPW . $up_file_path, 0777)) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'パーミッションの変更に失敗しました。【' . $up_file_path . '】');
							$errFlg = TRUE;
							break;
						}
					}
					
					// 画像のリサイズ
					$tmp_ary = array(
						'jpg', 
						'gif', 
						'jpeg', 
						'png'
					);
					if (in_array($sExtension, $tmp_ary)) {
						mkThumbnail(DOCUMENT_ROOT . RPW . $up_file_path, FCK_UPLOAD_IMAGE_W, FCK_UPLOAD_IMAGE_H);
					}
					
					//「tbl_fck_links」「tbl_fck_images」に登録
					if ($dir_name == FCK_IMAGES_FORDER) {
						$ary = array(
							'name' => $file_name, 
							'path' => $up_file_path
						);
						if ($objFCKImages->deleteFromImagePath($up_file_path) === FALSE) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, '画像情報の削除に失敗しました。【' . $up_file_path . '】');
							$errFlg = TRUE;
							break;
						}
						if ($objFCKImages->insert($ary) === FALSE) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, '画像情報の登録に失敗しました。【' . $up_file_path . '】');
							$errFlg = TRUE;
							break;
						}
					}
					else if ($dir_name == FCK_FILELINK_FORDER) {
						$filesize = '';
						$extension = '';
						$file_data = array();
						if (file_exists(DOCUMENT_ROOT . RPW . $up_file_path)) {
							$filesize = filesize(DOCUMENT_ROOT . RPW . $up_file_path);
							$file_data = pathinfo(DOCUMENT_ROOT . RPW . $up_file_path);
							if (isset($file_data['extension']) && $file_data['extension'] != '') {
								$extension = $file_data['extension'];
							}
						}
						
						$ary = array(
							'name' => $file_name, 
							'path' => $up_file_path, 
							'file_exte' => $extension, 
							'file_size' => $filesize
						);
						if ($objFCKLinks->deleteFromPageID($up_file_path) === FALSE) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'ファイル情報の削除に失敗しました。【' . $up_file_path . '】');
							$errFlg = TRUE;
							break;
						}
						if ($objFCKLinks->insert($ary) === FALSE) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'ファイル情報の登録に失敗しました。【' . $up_file_path . '】');
							$errFlg = TRUE;
							break;
						}
					}
				}
				// エラーがあった場合処理を抜ける
				if ($errFlg) {
					break;
				}
			}
			
			// エラーがあった場合次へ
			if ($errFlg) {
				continue;
			}
			
			// サムネイル画像を作成する
			$thumb_items = GetUseXmlId($arrCSV[KANKO_IMP_TMP_ID], $items);
			foreach ($thumb_items as $item) {
				$fixed_id = $item['id'];
				if (!isset($item['ctrl']) || $item['ctrl'] == '') {
					continue;
				}
				foreach ($item['ctrl'] as $ctrl) {
					// 定型項目が画像の場合
					if (strcmp($ctrl['type'], 'image') == 0) {
						//サムネイルの有無
						$thumbnail_flg = getFixedItemValue($thumb_items, $fixed_id, 'thumbnail');
						if ($thumbnail_flg !== FALSE && $thumbnail_flg == FLAG_ON) {
							// CSVに画像の指定が無い場合
							if (!isset($arrCSV[$fixed_id]) || trim($arrCSV[$fixed_id]) == '') {
								break 2;
							}
							// 画像URLの取得
							$fixed_context = trim($arrCSV[$fixed_id]);
							$pos = strpos($fixed_context, KANKO_ITEM_DELIMITER);
							if ($pos != 0) {
								$fixed_context = substr($fixed_context, 0, $pos);
							}
							$url = cms_dirname($arrCSV[KANKO_IMP_DIR_PATH]) . FCK_IMAGES_FORDER . '/' . strtolower(basename($fixed_context));
							if ($url == '') {
								break 2;
							}
							// サムネイルの作成
							if (file_exists(DOCUMENT_ROOT . RPW . $url)) {
								if (!createFixedThumbnail($page_id, DOCUMENT_ROOT . RPW . $url)) {
									$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'サムネイル画像の作成に失敗しました。【' . $up_file_path . '】');
									$errFlg = TRUE;
									break 2;
								}
							}
							break 2;
						}
					}
				}
			}
			
			// エラーがあった場合次へ
			if ($errFlg) {
				continue;
			}
			
			// 新しいディレクトリに権限を与える
			foreach (array_unique($aryNewDir) as $dir_path) {
				if ($dir_path === '' || $dir_path === $cms_dir . '/' || $dir_path === $cms_dir . './') {
					continue;
				}
				// ディレクトリがない場合は、各ディレクトリにも権限を設定する
				if (!@file_exists($dir_path)) {
					// ディレクトリの作成、移動
					if (preg_match_all('/([^\/]+)/', $dir_path, $d)) {
						$d = $d[1];
						$dir_path_temp = '';
						foreach ($d as $directory) {
							if (!preg_match('/\/$/', $dir_path_temp)) {
								$dir_path_temp .= '/';
							}
							$dir_path_temp .= $directory . '/';
							if (@file_exists($dir_path_temp)) {
								continue;
							}
							// 権限登録
							$tmp_ary = array(
								$dir_path_temp
							);
							insert_handler_directory($post['cms_target3'], $tmp_ary);
						}
					}
				}
			}
			
			// アップロードファイルの登録結果
			$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = $aryF;
		}
	}
	// CSVファイルClose
	fclose($CsvFno);
	// エラーが有ればロールバック
	if (isset($errFlg)) {
		if ($errFlg) {
			$objCnc->rollback();
		}
		// エラーが無ければコミット
		else {
			$objCnc->commit();
		}
	}
}

// 取り込みファイルの削除
removeDir($tmpUpDir);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>定型情報インポート</title>
<link rel="stylesheet" href="<?php echo (RPW); ?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="<?php echo (RPW); ?>/admin/style/outerimport.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?php echo (RPW); ?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?php echo (RPW); ?>/admin/js/library/scriptaculous.js" type="text/javascript"></script>
<script src="<?php echo (RPW); ?>/admin/js/shared.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
		<?php
		// ヘッダーメニュー挿入
		$headerMode = 'file';
		include (APPLICATION_ROOT . '/common/inc/special_menu.inc');
		?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img src="images/bar_kankoimport.jpg" alt="観光情報取り込み" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">アップロードしたファイル</th>
	</tr>
	<?php
	foreach ($aryUpFiles as $aryUpFile) {
		foreach ($aryUpFile as $key => $ary) {
			$icon_img = '&nbsp;';
			if (!$ary['error']) {
				if (!$ary['pagefile'] && $ary['overwrite']) {
					$icon_img = '[上書き]';
				}
				else if ($ary['mode'] == 'upd') {
					$icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_edit.jpg" alt="更新" width="70" height="25">';
				}
				else if ($ary['mode'] == 'ins') {
					$icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_new.jpg" alt="新規" width="70" height="25">';
				}
			}
			$chkbox_name = ($ary['pagefile']) ? 'cms_file_path' : 'cms_item_path';
			$chkbox_name = 'cms_target_line';
			print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
			print '<td align="left" valign="top" nowrap><p>' . htmlDisplay($key) . "\n";
			if ($ary['page_title'] != '') {
				print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
			}
			if ($ary['message'] != '') {
				print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
			}
			print '</p></td>' . "\n";
			print '</tr>' . "\n";
		}
	}
	?>
</table>
</div>
<div><img src="<?php echo (RPW); ?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>