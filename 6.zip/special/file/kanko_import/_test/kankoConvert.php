<?php
/*
 *
 */
// -- 取り込みモード
define("MODE_KANKO", "KANKO" );		// 観光施設
define("MODE_STAY",  "STAY"	);		// 宿泊施設

$IMPORT_MODE = MODE_KANKO;			// 取り込みモード
//$IMPORT_MODE = MODE_STAY;

if ( $IMPORT_MODE == MODE_KANKO ) {
	// 観光施設
	$CSV_FN = cms_dirname( __FILE__ ) . "/in/kanko.csv";	// ACCSS(CSV)ファイルフルパス
	$OUT_CSV_FN = "kanko.csv";							// 排出ファイル名
} elseif ( $IMPORT_MODE == MODE_STAY ) {
	// 宿泊施設
	$CSV_FN = cms_dirname( __FILE__ ) . "/in/stay.csv";
	$OUT_CSV_FN = "stay.csv";
}

// テンプレートID
$TEMPLATE_ID = array(
/*		// 開発環境
	MODE_KANKO	=>	"31",
	MODE_STAY	=>	"32",
*/	// 本番環境
	MODE_KANKO	=>	"2",
	MODE_STAY	=>	"3",
);

// アップフォルダ
$UP_FORDER = array(
	MODE_KANKO	=> "{city}fclt/{fn}",
	MODE_STAY	=> "{city}stay/{fn}",
);
if ( ! @file_exists( $CSV_FN ) ) {
	echo( "ファイルチェックエラー" );
	exit;
}

// 設定ファイルインクルード
include( "./set_up.inc" );

if ( $IMPORT_MODE == MODE_STAY ) {
	$accessCrom = array(
		// 宿泊情報
		"m_id"		=>	"cms_dir",		// アップロードファイル名
		"NAME"		=>	"name",			// 名称
		"KANA"		=>	"kana",			// 名称(カナ)
		"zip"		=>	"address",		// 郵便番号
		"city_n_j"	=>	"tbl_city_id",	// 市町村コード,
		"ADD3"		=>	"add_01",		// 住所(連結)
		"ADD4"		=>	"add_01",		// 住所(連結)
		"ADD5"		=>	"add_01",		// 住所(連結)
		"ADD6"		=>	"add_01",		// 住所(連結)
		"BOOKING"	=>	"reserve",		// 予約方法、予約方法(その他)
		"TEL"		=>	"tel",			// 電話番号
		"FAX"		=>	"fax",			// FAX
		"URL1"		=>	"url",			// URL,URLラベル
		"URL2"		=>	"reserve_url",	// インターネット予約　自社
		"ST_CODE"	=>	"tbl_class_large_id",		// ジャンル大／中
		"J_ROOM"	=>	"room_type",	// 和室
		"ROOM_S"	=>	"room_type",	// シングル
		"ROOM_T"	=>	"room_type",	// ツイン
		"ROOM_D"	=>	"room_type",	// ダブル
		"OTHER"		=>	"room_type",	// その他
		"OTHER_T"	=>	"room_type_etc",// その他(名前)
		"IN1"		=>	"check_in",		// チェックIN(AM or PM)
		"IN2"		=>	"check_in",		// チェックIN
		"OUT1"		=>	"check_out",	// チェックOUT(AM or PM)
		"OUT2"		=>	"check_out",	// チェックOUT
		"RATE1"		=>	"room_rate",	// 宿泊料金 ***円 ～		書式 ***円 ～ ***円(サービス料： */ 消費税： *)
		"RATE2"		=>	"room_rate",	// 宿泊料金 ～ ***円
		"CHARGE1"	=>	"room_rate",	// サービス料： 1 込 2 別
		"TAX1"		=>	"room_rate",	// 消費税： 1 込 2 別
		"BRE1_ROOM"	=>	"room_meal", 	// 食事の部屋だし 1 可 2 不可	朝
		"DIN1_ROOM"	=>	"room_meal", 	// 食事の部屋だし				夕
		"REST1"		=>	"rest",			// 休憩利用・日帰りプラン　1 あり 2 なし
		"VIEW01"	=>	"room_view",	// 部屋からの眺望(富士山が見える)
		"VIEW03"	=>	"room_view",	// 部屋からの眺望(海が見える)
		"VIEW05"	=>	"room_view",	// 部屋からの眺望(湖が見える)
		"SPRING"	=>	"hot_sp",		// 温泉の有無
		"BATH1"		=>	"bath",			// 露天風呂がある 3
		"my_bath"	=>	"bath",			// 貸切風呂がある 7
		"BATH4"		=>	"bath",			// 日帰り入浴ができる 6
		"PET"		=>	"pet",			// ペットの同伴ができる
		"ONEUSE"	=>	"unit",			// 1名での利用が可能
		"PARKING1"	=>	"p_big_cnt",	// 駐車場 大型車 台数	※入力ありで p_big を 1 それ以外は 0
		"PARKING2"	=>	"p_big_pay",	// 駐車場 大型車 代金
		"PARKING3"	=>	"p_small_cnt",	// 駐車場 普通車 台数	※p_small
		"PARKING4"	=>	"p_small_pay",	// 駐車場 普通車 台数
		"BOOK01"	=>	"ano_pamph",	// パンフレット
		"BOOK02"	=>	"ano_pamph_etc",// パンフレット(その他)
		"disp1"		=>	"ano_exp",		// 説明表示
		"disp2"		=>	"ano_exp_etc",	// 説異名表示(その他)
		"EXCHANGE1"	=>	"agio",			// 外貨の両替
		"EXCHANGE2"	=>	"agio_type",	// 外貨種類
		"card"		=>	"card",			// 利用可能カード 「  」区切りで登録されている
		"card_oth"	=>	"card_etc",		// 利用可能カード(その他)
		"it_use"	=>	"it",			// IT対応
		"cs_bs"		=>	"cs_bs",		// CS / BS放送
		"it_comment"=>	"it_memo",		// IT設備の補足説明
		"CAPTION"	=>	"caption",		// 説明
		"INDOOR"	=>	"inside_eq",	// "inside_eq_etc"),	// 室内設備 室内設備(その他)
		"OUTDOOR"	=>	"outside_eq",	// "outside_eq_etc"),	// 室外設備 室外設備(その他)
		"CONVENTION"=>	"convention",	// "convention_etc"),	// コンベンション設備 コンベンション設備(その他)
		"EAT_ROOM"	=>	"eat",			// "eat_etc"),				// 飲食設備 飲食設備(その他)
		"OTH_ROOM"	=>	"eq_etc",								// その他の設備
		"Q_アクセス_鉄道_station"	=>	"station",				// 起点となる新幹線駅
		"Q_アクセス_鉄道_access"	=>	"station_acc",			// 鉄道でのアクセス方法
		"Q_アクセス_自動車_station"	=>	"ic",					// 起点となるIC
		"Q_アクセス_自動車_access"	=>	"ic_acc",				// 自動車でのアクセス方法
		"ud"		=>	"ub",			// ユニバーサルデザイン
		"ud_oth"	=>	"ub_etc",		// ユニバーサルデザイン(その他)
		"apply_name"=>	"put_nm",		// 申請者名
		"apply_email"	=>	"put_email",// 申請者メールアドレス
	);
}
elseif ( $IMPORT_MODE == MODE_KANKO ) {
	$accessCrom = array(
		// 観光情報
		"ss_master_m_id"=>		"cms_dir",						// アップロードファイル名
		"ss_cate"		=>		"tbl_class_large_id",			// ジャンル中項目	※ tbl_class_large_id
		"kana"			=>		"kana",							// 名称カナ
		"name"			=>		"name",							// 名称
		"tel"			=>		"tel",							// 電話番号
		"fax"			=>		"fax",							// ファックス番号
		"url"			=>		"url",							// URL,URLラベル
		"email"			=>		"email",						// メールアドレス
		"charge"		=>		"pay",							// 料金
		"holiday"		=>		"holiday",						// 休業日
		"o_term"		=>		"open_len",						// 営業期間
		"o_time"		=>		"hours",						// 営業時間
		"o_facility"	=>		"eq_etc",						// その他の設備
		"access"		=>		"station_acc",					// 鉄道でのアクセス方法
		"parking1"		=>		"p_big_cnt",					// 駐車場大型(台数)		※入力があれば p_big = 1 なければ 0
		"parking2"		=>		"p_big_pay",					// 駐車場大型(円)		円付加
		"parking3"		=>		"p_small_cnt",					// 駐車場普通(台数)		※入力があれば p_small = 1 なければ 0
		"parking4"		=>		"p_small_pay",					// 駐車場普通(円)		円付加
		"lead"			=>		"txt_lead",						// リード文
		"caption"		=>		"caption",						// 内容・説明文
		"filename"		=>		"img_1_fnm",					// 画像1
		"file_alt"		=>		"img_1_cap",					// 画像1 ALT
		"guide"			=>		"guide",						// 説明員(ガイド)			NULL:登録なし; 1:あり; 2:なし;
		"book01"		=>		"ano_pamph",					// 外国語対応パンフレット
		"book02"		=>		"ano_pamph_etc",				// 外国語対応パンフレット(その他)
		"disp1"			=>		"ano_exp",						// 外国語説明表示
		"disp2"			=>		"ano_exp_etc",					// 外国語説明表示(その他)
		"ud"			=>		"ub",							// ユニバーサルデザイン		※コード変換
		"ud_oth"		=>		"ub_etc",						// ユニバーサルデザイン(その他)
		"latitude"		=>		"latitude",						// 緯度
		"longitude"		=>		"longitude",					// 経度
		"zip"			=>		"address",						// 郵便番号
		"add1"			=>		"add_01",						// 住所
		"add2"			=>		"add_01",						// 住所
		"city_n_j"		=>		"tbl_city_id",					// 市町村コード
	);
}

// フォルダ作成(画像アップロード用)
foreach ( $EACH_CITY_UP_FORDER as $k => $v ) {
	
	$dir = explode("/", $v['dir']);
	$cdir = "";
	for ( $i = 0 ; $i < count( $dir ) ; $i ++ ) {
		if ( $dir[$i] == "" ) continue;
		$cdir .= "/" . $dir[$i];
		if ( ! @file_exists( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $cdir ) ) {
			if ( ! @mkdir( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $cdir ) ) {
				echo("フォルダ作成失敗");
				exit;
			}
		}
	}
	if ( ! @file_exists( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "fclt/" ) ) {
		if ( ! @mkdir( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "fclt/" ) ) {
			echo("フォルダ作成失敗");
			exit;
		}
	}
	if ( ! @file_exists( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "stay/" ) ) {
		if ( ! @mkdir( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "stay/" ) ) {
			echo("フォルダ作成失敗");
			exit;
		}
	}

	if ( ! @file_exists( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "fclt/images/" ) ) {
		if ( ! @mkdir( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "fclt/images/" ) ) {
			echo("フォルダ作成失敗");
			exit;
		}
	}

	if ( ! @file_exists( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "stay/images/" ) ) {
		if ( ! @mkdir( "C:/Inetpub/wwwroot/php/kankoConvert/out" . $v['dir'] . "stay/images/" ) ) {
			echo("フォルダ作成失敗");
			exit;
		}
	}

}

$ExpCsvData = "";	// 出力用
for ( $i = 0 ; $i < count( $CSV_HEADER ) ; $i ++ ) {
	$ExpCsvData .= ( $ExpCsvData == "" ) ? $CSV_HEADER[$i] : "," . $CSV_HEADER[$i];
}
$ExpCsvData .= "\n";

//ファイルを開く
if ( ! ( $fp = fopen( $CSV_FN, 'r' ) ) ) {
	echo( "100 ファイルオープンエラー" );
	exit;
}

$cnt = 0;
while ( $inputCsvData = cms_fgetcsv( $fp, 50000 ) ) {

	// 配列作成
	$outputCsvData = array();

	// 1行目はヘッダー取得処理 --------------
	if ( $cnt == 0 ) {
		$accessHeader = array();
		foreach ( $inputCsvData as $k => $v ) {
			// ヘッダー情報を保持
			$accessHeader[$v] = $k;
		}
	} else {

		// 小数点削除
		foreach ( $accessCrom as $k => $v ) {
			// 緯度経度以外の文字列「.00を除去」
			if ( ! in_array( $k, array( "latitude", "longitude" ) ) ) {
				$inputCsvData[$accessHeader[$k]] = preg_replace( "/.00$/i", "", $inputCsvData[$accessHeader[$k]] );
			}
		}

		// CSVへ書き込む内容の作成
		foreach ( $accessCrom as $k => $v ) {


			// 宿泊施設の場合の特殊処理
			if ( $IMPORT_MODE == MODE_STAY ) {

				// アップロード dir
				if ( $k == "m_id" ) {
					$outputCsvData[$v] = $inputCsvData[$accessHeader[$k]] . ".html";
				}

				// 市町村コード
				if ( $k == "city_n_j" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $CITY_ARY );
				}

				// 住所
				if ( in_array( $k, array( "ADD3", "ADD4", "ADD5", "ADD6" ) ) && ! isset( $outputCsvData[$v] ) ) {
					// 文字列の連結
					$outputCsvData[$v] = ( isset( $accessHeader['ADD3'] ) ) ? $inputCsvData[$accessHeader['ADD3']] : "";
					$outputCsvData[$v].= ( isset( $accessHeader['ADD4'] ) ) ? $inputCsvData[$accessHeader['ADD4']] : "";
					$outputCsvData[$v].= ( isset( $accessHeader['ADD5'] ) ) ? $inputCsvData[$accessHeader['ADD5']] : "";
					$outputCsvData[$v].= ( isset( $accessHeader['ADD6'] ) ) ? $inputCsvData[$accessHeader['ADD6']] : "";
				}

				// 予約方法
				if ( $k == "BOOKING" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $RESERVE_ARY, $DEFAULT_RESERVE );
				}

				// URLラベル
				if ( $k == "URL1" ) {
					// ラベルをセット
					$outputCsvData['url_lbl'] = $inputCsvData[$accessHeader[$k]];
				}

				// 分類( ジャンル )
				if ( $k == "ST_CODE" ) {
					$inputCsvData[$accessHeader[$k]] = sprintf( "%d", $inputCsvData[$accessHeader[$k]] );
					// 大分類のコードをセット
					$outputCsvData['tbl_class_large_id'] = ( isset( $TBL_CLASS_MIDDLE_ID_ARY[$inputCsvData[$accessHeader[$k]]][0] ) ) ? $TBL_CLASS_MIDDLE_ID_ARY[$inputCsvData[$accessHeader[$k]]][0] : 0;
					// 中分類のコードをセット
					$outputCsvData['tbl_class_middle_id']= ( isset( $TBL_CLASS_MIDDLE_ID_ARY[$inputCsvData[$accessHeader[$k]]][1] ) ) ? $TBL_CLASS_MIDDLE_ID_ARY[$inputCsvData[$accessHeader[$k]]][1] : 0;
					// 小分類のコードをセット
					$outputCsvData['tbl_class_short_id'] = 0;
				}

				// 客室の種類
				if ( in_array( $k, array( "J_ROOM", "ROOM_S", "ROOM_T", "ROOM_D", "OTHER" ) ) && ! isset( $outputCsvData[$accessHeader[$k]] ) ) {
					$outputCsvData[$v] = selectUnity( $inputCsvData, $accessHeader, $ROOM_TYPE_ARY, TRUE );
				}

				// チェックイン
				if ( in_array( $k, array( "IN1", "IN2" ) ) && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = $inputCsvData[$accessHeader['IN1']] . $inputCsvData[$accessHeader['IN2']];
				}

				// チェックアウト
				if ( in_array( $k, array( "OUT1", "OUT2" ) ) && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = $inputCsvData[$accessHeader['OUT1']] . $inputCsvData[$accessHeader['OUT2']];
				}

				// 宿泊料金
				if ( in_array( $k, array( "RATE1", "RATE2", "CHARGE1", "TAX1" ) ) && ! isset( $outputCsvData[$v] ) ) {
					if ( $inputCsvData[$accessHeader['RATE1']] == "0" && $inputCsvData[$accessHeader['RATE2']] == "0" && $inputCsvData[$accessHeader['CHARGE1']] == "" && $inputCsvData[$accessHeader['TEXT1']] == "" ) {
						$outputCsvData[$v] = "";
					} else {
						$outputCsvData[$v] = ( $inputCsvData[$accessHeader['RATE1']] != "0" ) ? $inputCsvData[$accessHeader['RATE1']] . "円 " : "";
						$outputCsvData[$v].= "～ ";
						$outputCsvData[$v].= ( $inputCsvData[$accessHeader['RATE2']] != "0" ) ? $inputCsvData[$accessHeader['RATE2']] . "円 " : "";
						$outputCsvData[$v].= "(サービス料：";
						$outputCsvData[$v].= ( $inputCsvData[$accessHeader['CHARGE1']] == 1 ) ? "込" : "";
						$outputCsvData[$v].= ( $inputCsvData[$accessHeader['CHARGE1']] == 2 ) ? "別" : "";
						$outputCsvData[$v].= " / 消費税：";
						$outputCsvData[$v].= ( $inputCsvData[$accessHeader['TAX1']] == 1 ) ? "込" : "";
						$outputCsvData[$v].= ( $inputCsvData[$accessHeader['TAX1']] == 2 ) ? "別" : "";
						$outputCsvData[$v].= ")";
					}
				}

				// 食事の部屋だし
				if ( in_array( $k, array( "BRE1_ROOM", "DIN1_ROOM" ) ) && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $ROOM_MEAL_ARY );
				}

				// 日帰りプラン
				if ( $k == "REST1" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader['BRE1_ROOM']], "1", "2" );
				}

				// 部屋からの眺望
				if ( in_array( $k, array( "VIEW01", "VIEW03", "VIEW05" ) ) && ! isset( $outputCsvData[$accessHeader[$k]] ) ) {
					$outputCsvData[$v] = selectUnity( $inputCsvData, $accessHeader, $ROOM_VIEW_ARY, "1" );
					unset( $dummy );
				}

				// 温泉の有無
				if ( $k == "SPRING" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader[$k]], "1", "2" );
				}

				// 入浴施設
				if ( in_array( $k, array( "BATH1", "my_bath", "BATH4" ) ) && ! isset( $outputCsvData[$accessHeader[$k]] ) ) {
					$outputCsvData[$v] = selectUnity( $inputCsvData, $accessHeader, $BATH_ARY, "1" );
					unset( $dummy );
				}

				// ペットの同伴ができる
				if ( $k == "PET" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader[$k]], "1", "2" );
				}

				// 1名での利用が可能
				if ( $k == "ONEUSE" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader[$k]], "1", "2" );
				}

				// パンフレット
				if ( $k == "BOOK01" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $FOREIGN_COUNTRY_ARY, $DEFAULT_FOREIGN_COUNTRY );
				}

				// 説明表示
				if ( $k == "disp1" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $FOREIGN_COUNTRY_ARY, $DEFAULT_FOREIGN_COUNTRY );
				}

				// 外貨の両替
				if ( $k == "EXCHANGE1" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader[$k]], "1", "2" );
				}

				// 利用可能カード
				if ( $k == "card" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $CARD_ARY, $DEFAULT_CARD );
				}

				// IT対応
				if ( $k == "it_use" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader[$k]], "1", "2" );
				}

				// CS / BS放送
				if ( $k == "cs_bs" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader[$k]], "1", "2" );
				}

				// 室内設備
				if ( $k == "INDOOR" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $INSIDE_EQ_ARY, $DEFAULT_INSIDE_EQ );
					$outputCsvData['inside_eq_etc'] = selectString( $inputCsvData[$accessHeader[$k]], $INSIDE_EQ_ARY );
				}

				// 室外設備
				if ( $k == "OUTDOOR" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $OUTSIDE_EQ_ARY, $DEFAULT_OUTSIDE_EQ );
					$outputCsvData['outside_eq_etc'] = selectString( $inputCsvData[$accessHeader[$k]], $INSIDE_EQ_ARY );
				}

				// コンベンション設備
				if ( $k == "CONVENTION" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $CONVENTION_ARY, $DEFAULT_CONVENTION );
					$outputCsvData['convention_etc'] = selectString( $inputCsvData[$accessHeader[$k]], $CONVENTION_ARY );
				}

				// 飲食設備
				if ( $k == "EAT_ROOM" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $EAT_ARY, $DEFAULT_EAT );
					$outputCsvData['convention_etc'] = selectString( $inputCsvData[$accessHeader[$k]], $EAT_ARY );
				}

				// 起点となる新幹線駅
				if ( $k == "Q_アクセス_鉄道_station" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $STATION_ARY );
				}

				// 起点となるIC
				if ( $k == "Q_アクセス_自動車_station" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $IC_ARY );
				}

				// ユニバーサルデザイン
				if ( $k == "ud" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $UD_ARY );
				}

			// 観光施設の場合の特殊処理
			} elseif ( $IMPORT_MODE == MODE_KANKO ) {

				// アップロード dir
				if ( $k == "ss_master_m_id" ) {
					$outputCsvData[$v] = $inputCsvData[$accessHeader[$k]] . ".html";
				}

				// 分類( ジャンル )
				if ( $k == "ss_cate" ) {
					// デフォルト大分類、中分類、小分類
					$outputCsvData['tbl_class_large_id'] = 0;
					$outputCsvData['tbl_class_middle_id']= 0;
					$outputCsvData['tbl_class_short_id'] = 0;
					
					if ( strlen( $inputCsvData[$accessHeader[$k]] ) <= 3 ) {
						$inputCsvData[$accessHeader[$k]] = sprintf( "%03d", $inputCsvData[$accessHeader[$k]] );
					}
					if ( isset( $TBL_CLASS_MIDDLE_ID_ARY[$inputCsvData[$accessHeader[$k]]] ) ) {
						// 大分類のコードをセット
						$outputCsvData['tbl_class_large_id'] = $TBL_CLASS_MIDDLE_ID_ARY[$inputCsvData[$accessHeader[$k]]][0];
						// 中分類のコードをセット
						$outputCsvData['tbl_class_middle_id']= $TBL_CLASS_MIDDLE_ID_ARY[$inputCsvData[$accessHeader[$k]]][1];
					}
				}

				// URLラベル
				if ( $k == "url" ) {
					// ラベルをセット
					$outputCsvData['url_lbl'] = $inputCsvData[$accessHeader[$k]];
				}

				// 説明員(ガイド)
				if ( $k == "guide" && ! isset( $outputCsvData[$v] ) ) {
					$outputCsvData[$v] = radioYesNo( $inputCsvData[$accessHeader[$k]], "1", "2" );
				}

				// パンフレット
				if ( $k == "book01" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $FOREIGN_COUNTRY_ARY, $DEFAULT_FOREIGN_COUNTRY );
				}

				// 説明表示
				if ( $k == "disp1" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $FOREIGN_COUNTRY_ARY, $DEFAULT_FOREIGN_COUNTRY );
				}

				// ユニバーサルデザイン
				if ( $k == "ud" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $UD_ARY );
				}

				// 市町村コード
				if ( $k == "city_n_j" ) {
					$outputCsvData[$v] = selectCheck( $inputCsvData[$accessHeader[$k]], $CITY_ARY );
				}

				// 住所
				if ( in_array( $k, array( "add1", "add2" ) ) && ! isset( $outputCsvData[$accessHeader[$k]] ) ) {
					$outputCsvData[$v] = $inputCsvData[$accessHeader['add1']] . $inputCsvData[$accessHeader['add2']];
				}

			}
			// 情報を代入
			if ( ! isset( $outputCsvData[$v] ) ) {
				$outputCsvData[$v] = ( isset( $inputCsvData[$accessHeader[$k]] ) ) ? $inputCsvData[$accessHeader[$k]] : "";
			}
		}

		// 住所
		if ( isset( $outputCsvData['address'] ) && mb_strlen( $outputCsvData['address'] ) == 7 ) {
			$outputCsvData['address'] = mb_substr( $outputCsvData['address'] , 0, 3 ) . "-" . mb_substr( $outputCsvData['address'] , 3, 4 );
		}

		// ページタイトル = 施設名
		$outputCsvData['sightseeing_name'] = $outputCsvData['name'];

		// アップロード先
		if ( ! isset( $outputCsvData['cms_dir'] ) || ! isset( $outputCsvData['tbl_city_id'] ) ) {
			// エラー
			echo( "必要情報の取得に失敗しました" );
		}
		$outputCsvData['cms_dir'] = str_replace( "{fn}", $outputCsvData['cms_dir'], $UP_FORDER[$IMPORT_MODE] );
		$outputCsvData['cms_dir'] = str_replace( "{city}", $EACH_CITY_UP_FORDER[$outputCsvData['tbl_city_id']]['dir'], $outputCsvData['cms_dir'] );

		// ユーザーID
		$outputCsvData['user_id'] = $EACH_CITY_UP_FORDER[$outputCsvData['tbl_city_id']]['usr'];

		// 静岡と浜松のみ抽出 -- デバッグ
//			if ( $outputCsvData['user_id'] != 27 ) continue;
//			if ( $outputCsvData['user_id'] != 43 ) continue;

		// 宿泊の場合はグローバルユーザー
		if ( $IMPORT_MODE == MODE_STAY ) $outputCsvData['user_id'] = $STAY_USER_ID;

		// 画像1
		if ( isset( $outputCsvData['img_1_fnm'] ) && $outputCsvData['img_1_fnm'] != "" ) {
			// 市町村別にフォルダを分ける
			$copyImg = "C:/Inetpub/wwwroot/php/kankoConvert/in/fclt/" . $outputCsvData['img_1_fnm'];
			$outputCsvData['img_1_fnm'] = str_replace( "{fn}", "images/" . $outputCsvData['img_1_fnm'], $UP_FORDER[$IMPORT_MODE] );
			$outputCsvData['img_1_fnm'] = str_replace( "{city}", $EACH_CITY_UP_FORDER[$outputCsvData['tbl_city_id']]['dir'], $outputCsvData['img_1_fnm'] );
			// 画像のアップロード
			if ( @file_exists( $copyImg ) ) {
				// コピー先ファイルの削除
				if ( @file_exists( "C:/Inetpub/wwwroot/php/kankoConvert/out/" . $outputCsvData['img_1_fnm'] ) ) {
					@unlink( "C:/Inetpub/wwwroot/php/kankoConvert/out/" . $outputCsvData['img_1_fnm'] );
				}
				// コピー
				if ( ! @copy( $copyImg, "C:/Inetpub/wwwroot/php/kankoConvert/out/" . $outputCsvData['img_1_fnm'] ) ) {
					// echo("アップロードエラー");
					// exit;
				}
			}
			// ALT付加
			if ( isset( $outputCsvData['img_1_cap'] ) && $outputCsvData['img_1_cap'] != "" ) {
				$outputCsvData['img_1_fnm'] .= "|@cms@|" . $outputCsvData['img_1_cap'];
				unset( $outputCsvData['img_1_cap'] );
			} else {
				$outputCsvData['img_1_fnm'] .= "|@cms@|";
			}
		}

		// テンプレートID
		$outputCsvData['template_id'] = $TEMPLATE_ID[$IMPORT_MODE];

		// CSVデータに代入
		for ( $i = 0 ; $i < count( $CSV_HEADER ) ; $i ++ ) {
			if ( $i != 0 ) $ExpCsvData .= ",";
			if ( isset( $outputCsvData[$CSV_HEADER[$i]] ) ) {
				$ExpCsvData .= '"' . mb_convert_kana( str_replace( '"', '""', str_replace("\r","",$outputCsvData[$CSV_HEADER[$i]]) ), "rnK", "UTF-8" ) . '"';
			} else {
				$ExpCsvData .= '""';
			}
		}
		$ExpCsvData .= "\n";
	}
	$cnt ++;

// デバッグ用 途中で処理終了
//		if ( $cnt == 10 ) break;
}

fclose($fp);

// CSV出力
header("Content-Disposition: attachment; filename=". $OUT_CSV_FN );
header('Content-type: text/comma-separated-values');

print $ExpCsvData;

// 関数 -------------------------------------------------------------------- //

// ラジオボタン用
function radioYesNo( $_iValue, $_y, $_n ) {
	
	$ret = "";
	
	if ( $_iValue == $_y ) {
		$ret.= "1";
	}
	elseif ( $_iValue == $_n ) {
		$ret.= "0";
	}
	
	return $ret;
}

// セレクトボタン用( 文字列 -> コード 変換 )
function selectCheck( $_iValue, $_chAry, $_chDefault="", $_dem=" " ) {
	
	$ret = "";
	
	if ( $_iValue != "" ) {

		// "," で区切る
		$edit = explode( ",", str_replace( $_dem, ",", $_iValue ) );
		$dummy = array();

		// 文字列をコードに変換して代入
		foreach ( $edit as $_k => $_v ) {
			$_k = trim( $_k );
			$_v = trim( $_v );
			if ( $_v != "" ) {
				if ( isset( $_chAry[$_v] ) ) {
					array_push( $dummy, $_chAry[$_v] );
				} else {
					if ( $_chDefault != "" ) array_push( $dummy, $_chDefault );
				}
			}
		}
		// ソート＆同一の値を除去
		$dummy = array_unique( $dummy );
		sort( $dummy );
		$ret = implode( ",", $dummy );
	}

	return $ret;
}

// セレクトボタン用( コードに存在しない文字列を抽出 )
function selectString( $_iValue, $_chAry, $_link="\n", $_dem=" " ) {
	
	$ret = "";
	
	if ( $_iValue != "" ) {

		// "," で区切る
		$edit = explode( ",", str_replace( $_dem, ",", $_iValue ) );
		$dummy = array();

		// 文字列をコードに変換して代入
		foreach ( $edit as $_k => $_v ) {
			$_k = trim( $_k );
			$_v = trim( $_v );
			if ( $_v != "" ) {
				if ( ! isset( $_chAry[$_v] ) ) {
					array_push( $dummy, $_v );
				}
			}
		}
		// ソート＆同一の値を除去
		$dummy = array_unique( $dummy );
		sort( $dummy );
		$ret = implode( $_link, $dummy );
	}

	return $ret;
}

// セレクトボタン用( カラムの統一 )
function selectUnity( $_iAry, $_kAry, $_chAry, $_chValue="1" ) {
	
	$ret = "";
	$dummy = array();

	foreach ( $_chAry as $_k => $_v ) {
		if ( isset( $_iAry[$_kAry[$_k]] ) && $_iAry[$_kAry[$_k]] == $_chValue ) {
			array_push( $dummy, $_v );
		}
	}

	if ( count( $dummy ) > 0 ) {
		// ソート＆同一の値を除去
		$dummy = array_unique( $dummy );
		sort( $dummy );
		$ret = implode( ",", $dummy );
	}

	return $ret;
}

?>