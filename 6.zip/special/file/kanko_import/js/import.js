/*
 *
 */
cxPreImages(cms8341admin_path+'/images/menu/logout01_btn.jpg',
			cms8341admin_path+'/images/menu/logout02_btn.jpg');


//通信失敗処理
function cxFailure() {
	alert('情報取得中に通信エラーが発生しました');
}

//外部ページの取り込み
function cxSubmit() {
	var msg = new Array();
	if (!$('FrmZipnm').value) {
		msg.push('取り込みファイルを入力してください。');
	}
	else {
		var filetype = $('FrmZipnm').value.replace(/^.*\.([^\.]+$)/, '$1');
		filetype = filetype.toLowerCase();
		if (filetype != 'zip') {
			msg.push('取り込みファイルはzip形式でアップロードしてください。');
		}
		var filepath = $('FrmZipnm').value.match(/^[a-z]:\\.+/i);
		if (!filepath) {
			msg.push('取り込みファイルの参照先を正しく指定してください。');
		}
	}
	// 無期限設定のチェックボックスが選択されていた場合
	if ($('cms-pubend-Unrestricted-ws') && $('cms-pubend-Unrestricted-ws').checked) {
		cxPublicEndUnrestricted();
		$('cms_pdey').value = PUB_INDEFINITE_YAER;
		$('cms_pdem').value = PUB_INDEFINITE_MONTH;
		$('cms_pded').value = PUB_INDEFINITE_DAY;
		$('cms_pdeh').value = PUB_INDEFINITE_HOUR;
	}
	// 公開期間入力チェック
	dc = cxDateCheckNew('cms_pd', 'ymdh', 1, '公開期間');
	msg = msg.concat(dc);
	
	// 取り込み後のステータス選択チェック
	if (isSelectCheck('cms_status') != true) {
		msg.push('取り込み後のステータスを指定してください。');
	}
	if (!$('cms_user_id').value && $('cms_priority_1').checked) {
		msg.push('ページ作成者を選択してください。');
	}
	// エラー表示
	if (msg.length > 0) {
		// 無期限設定のチェックボックスが選択されていた場合
		if ($('cms-pubend-Unrestricted-ws') && $('cms-pubend-Unrestricted-ws').checked) {
			cxPublicEndUnrestricted();
		}
		cxComboHidden(new Array("cms_template_id"));
		$('cms8341-errormsg').innerHTML = msg.join("<br>");
		cxLayer('cms8341-error',1,500,500);
		return false;
	}
	$('cms_filename').value = $('FrmZipnm').value;
	document.cms_fImport.submit();
	return false;
}

//組織選択
function cxChangeDept(lv, val) {
	//reset
	if(val=="") {
		var t = lv + 1;
		for (var i=t;i<=3;i++) {
			var obj = $('cms_target'+i);
			while (obj.length>1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "                ";
		}
		var obj = $('cms_user_id');
		while (obj.length>1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "                ";
	}
	else {
		if (lv < 3) {
			//get data
			lv++;
			var prm = 'level='+lv+'&code='+val;
			cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
		}
		else {
			var prm = 'code='+val;
			cxAjaxCommand('cxGetUserCombo', prm, cxGetUserComboOK);
		}
	}
}
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for (var i=level; i<=3; i++) {
		var obj = $('cms_target'+i);
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		obj.options[0].text = "                ";
	}
	var obj = $('cms_user_id');
	while (obj.length>1) {
		obj.options[1] = null;
	}
	obj.options[0].text = "                ";
	var obj = $('cms_target'+level);
	for (var i=0; i<xmlDoc.childNodes.length; i++) {
		var nodeL = xmlDoc.childNodes.item(i);
		if (nodeL.nodeType == 1) {
			obj.length++;
			obj.options[obj.length - 1].text = nodeL.text || nodeL.textContent || '指定なし';
			var val = nodeL.attributes.getNamedItem('value').value;
			obj.options[obj.length - 1].value = val;
		}
	}
}
function cxGetUserComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'User') {
		cxFailure();
		return;
	}
	var obj = $('cms_user_id');
	while (obj.length > 1) {
		obj.options[1] = null;
	}
	obj.options[0].text = "------- 未選択 -------";
	for (var i=0; i<xmlDoc.childNodes.length; i++) {
		var nodeL = xmlDoc.childNodes.item(i);
		if (nodeL.nodeType == 1) {
			obj.length++;
			obj.options[obj.length - 1].text = nodeL.text || nodeL.textContent;
			var val = nodeL.attributes.getNamedItem('value').value;
			obj.options[obj.length - 1].value = val;
		}
	}
}

function cxErrorClose() {
	cxComboVisible();
	cxLayer('cms8341-error',0);
}

/**
 * 画面切り替え用js
 */
function changePriority(check){
	if (check == 1) {
		document.getElementById('cms_pd_tr').style.display = '';
		document.getElementById('cms_user_tr').style.display = '';
	}
	else if(check == 2){
		document.getElementById('cms_pd_tr').style.display = 'none';
		document.getElementById('cms_user_tr').style.display = 'none';
	}
	return false;
}

/**
 * ページ移動用
 */
function cxPageSet(p) {
	document.cms_fImport.cms_dispMode.value = "pageset";
	document.cms_fImport.cms_p.value = p;
	document.cms_fImport.action = "import_conf.php";
	document.cms_fImport.submit();
	return false;
}

/**
 * チェックボックスを選択したとき
 */
function cxCheck(line_num) {
	if ($('line_num_' + line_num).checked) {
		checked = 1;
	}
	else {
		checked = 0;
	}
	var prm = 'line_num=' + line_num + '&checked=' + checked;
	cxAjaxCommand('cxKankoLineCheck', prm, cxCheckSuccess);
}
function cxCheckSuccess(r) {
}

function cxCheckAll() {
	_checkAll(document['cms_fImport']['cms_target_line[]']);
}

function cxReleaseAll() {
	_releaseAll(document['cms_fImport']['cms_target_line[]']);
}
function _checkAll(alElem) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = true;
			cxCheck(alElem.value);
			// some checkboxes
		}
		else {
			for ( var i = 0; i < alElem.length; i++) {
				alElem[i].checked = true;
				cxCheck(alElem[i].value);
			}
		}
	}
}
function _releaseAll(alElem) {
	if (alElem) {
		//one checkbox
		if (!alElem.length && alElem.value) {
			alElem.checked = false;
			cxCheck(alElem.value);
			// some checkboxes
		}
		else {
			for ( var i = 0; i < alElem.length; i++) {
				alElem[i].checked = false;
				cxCheck(alElem[i].value);
			}
		}
	}
}
function cxDispNum() {
	document.cms_fImport.cms_dispMode.value = "change_num";
	document.cms_fImport.action = "import_conf.php";
	document.cms_fImport.submit();
	return false;
}

function cxSubmitExec() {
	var prm;
	cxAjaxCommand('cxIsKankoLineCheck', prm, cxIsCheckSuccess);
}

function cxIsCheckSuccess(r) {
	var rText = r.responseText;
	if (rText == '0') {
		alert("取り込みを行うページが一件も選択されていません。")
		return false;
	}
	$('cms8341-progressmsg').innerHTML = '<p>処理中です...</p>';
	cxLayer('cms8341-progress', 1, 500, 500);
	document.cms_fImport.submit();
	return false;
}
