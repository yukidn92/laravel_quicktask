<?php
/**
 * 定型情報インポート入力画面
 */

// 設定ファイルの読込
require ('../.htsetting');
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$obj_dept = new tbl_department($objCnc);
// 定型情報インポート・エクスポート用定数ファイル
require_once (APPLICATION_ROOT . '/common/setting_fixed.inc');

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// 初期表示値
$def_ary = array();
if (isset($_GET['bak']) && $_GET['bak'] == 1 && isset($_SESSION['post']) && is_array($_SESSION['post'])) {
	$def_ary = $_SESSION['post'];
}
else if (isset($_SESSION['post'])) {
	unset($_SESSION['post']);
}

if (!isset($def_ary['cms_pdsy'])) $def_ary['cms_pdsy'] = date('Y');
if (!isset($def_ary['cms_pdsm'])) $def_ary['cms_pdsm'] = date('n');
if (!isset($def_ary['cms_pdsd'])) $def_ary['cms_pdsd'] = date('j');
if (!isset($def_ary['cms_pdsh'])) $def_ary['cms_pdsh'] = date('H');
if (!isset($def_ary['cms_pdey'])) $def_ary['cms_pdey'] = date('Y', strtotime('+' . PUBLISH_END_MONTH . ' month'));
if (!isset($def_ary['cms_pdem'])) $def_ary['cms_pdem'] = date('n', strtotime('+' . PUBLISH_END_MONTH . ' month'));
if (!isset($def_ary['cms_pded'])) $def_ary['cms_pded'] = date('j', strtotime('+' . PUBLISH_END_MONTH . ' month'));
if (!isset($def_ary['cms_pdeh'])) $def_ary['cms_pdeh'] = 0;
if (!isset($def_ary['cms_status'])) $def_ary['cms_status'] = STATUS_SAVE;
if (!isset($def_ary['cms_target1'])) $def_ary['cms_target1'] = '';
if (!isset($def_ary['cms_target2'])) $def_ary['cms_target2'] = '';
if (!isset($def_ary['cms_target3'])) $def_ary['cms_target3'] = '';
if (!isset($def_ary['cms_user_id'])) $def_ary['cms_user_id'] = '';
if (!isset($def_ary['cms_priority'])) $def_ary['cms_priority'] = KANKO_PRIORITY_DISP;


// ステータスの初期選択
$def_checked[STATUS_SAVE] = '';
$def_checked[STATUS_PUBLISH_WAIT] = '';
$def_checked[$def_ary['cms_status']] = ' checked';

// 優先情報の初期選択
$def_checked[KANKO_PRIORITY_DISP] = '';
$def_checked[KANKO_PRIORITY_CSV] = '';
$def_checked[$def_ary['cms_priority']] = ' checked';

// 組織プルダウン生成
$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;">' . "\n";
$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;">' . "\n";
$dept_s3 = '<select id="cms_target3" name="cms_target3" onChange="javascript:cxChangeDept(3, this.value)" style="width:150px;">' . "\n";
$dept_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
$dept_e = '</select>&nbsp;&nbsp;';
$dept_op1 = $dept_opn;
$dept_op2 = $dept_opn;
$dept_op3 = $dept_opn;
if ($objLogin->get('isOuter') == FALSE) {
	// 第一組織プルダウンの生成
	$obj_dept->setTableName('tbl_department');
	$where = $obj_dept->_addslashesC('level', '1');
	$obj_dept->select($where, 'level, dept_code, name', 'sort_order, dept_code');
	while ($obj_dept->fetch()) {
		$selected = ($obj_dept->fld['dept_code'] == $def_ary['cms_target1']) ? ' selected' : '';
		$dept_op1 .= '<option value="' . $obj_dept->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
	}
	// 第二組織プルダウンの生成（第一組織が指定されている場合）
	if ($def_ary['cms_target1'] != '') {
		$obj_dept->setTableName('tbl_department');
		$where = $obj_dept->_addslashesC('level', '2');
		$where .= ' AND ' . $obj_dept->_addslashesC('dept_code', '^' . substr($def_ary['cms_target1'], 0, CODE_DIGIT_DEPT), 'REGEXP', 'TEXT');
		$obj_dept->select($where, 'level, dept_code, name', 'sort_order, dept_code');
		while ($obj_dept->fetch()) {
			$selected = ($obj_dept->fld['dept_code'] == $def_ary['cms_target2']) ? ' selected' : '';
			$dept_op2 .= '<option value="' . $obj_dept->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
		}
	}
	// 第三組織プルダウンの生成（第二組織が指定されている場合）
	if ($def_ary['cms_target2'] != '') {
		$obj_dept->setTableName('tbl_department');
		$where = $obj_dept->_addslashesC('level', '3');
		$where .= ' AND ' . $obj_dept->_addslashesC('dept_code', '^' . substr($def_ary['cms_target2'], 0, (CODE_DIGIT_DEPT * 2)), 'REGEXP', 'TEXT');
		$obj_dept->select($where, 'level, dept_code, name', 'sort_order, dept_code');
		while ($obj_dept->fetch()) {
			$selected = ($obj_dept->fld['dept_code'] == $def_ary['cms_target3']) ? ' selected' : '';
			$name = ($obj_dept->fld['name'] == " " || $obj_dept->fld['name'] == "　") ? "指定なし" : $obj_dept->fld['name'];
			$dept_op3 .= '<option value="' . $obj_dept->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($name) . '</option>' . "\n";
		}
	}
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
	// ユーザプルダウンの生成（第三組織が指定されている場合）
	if ($def_ary['cms_target3'] != '') {
		$obj_dac->setTableName('tbl_user');
		$where = $obj_dac->_addslashesC('class', USER_CLASS_WRITER);
		$where .= ' AND ' . $obj_dac->_addslashesC('dept_code', $def_ary['cms_target3']);
		$obj_dac->select($where, 'user_id, name', 'user_id');
		while ($obj_dac->fetch()) {
			$selected = ($obj_dac->fld['user_id'] == $def_ary['cms_user_id']) ? ' selected' : '';
			$user_op .= '<option value="' . $obj_dac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($obj_dac->fld['name']) . '</option>' . "\n";
		}
	}
}
else {
	// 外部ファイル取り込みを許可されている組織の場合は、組織プルダウンは自分の組織しか表示しない
	$deptAry = getDeptCode($objLogin->get('dept_code'));
	// 第一組織プルダウンの生成
	$obj_dept->selectFromCode($deptAry['dept1_code']);
	$dept_op1 = '<option value="' . $obj_dept->fld['dept_code'] . '" selected>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
	// 第二組織プルダウンの生成
	$obj_dept->selectFromCode($deptAry['dept2_code']);
	$dept_op2 = '<option value="' . $obj_dept->fld['dept_code'] . '" selected>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
	// 第三組織プルダウンの生成
	$obj_dept->selectFromCode($deptAry['dept3_code']);
	$dept_op3 = '<option value="' . $obj_dept->fld['dept_code'] . '" selected>' . htmlDisplay($obj_dept->fld['name']) . '</option>' . "\n";
	
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '';
	// ユーザプルダウンの生成
	$obj_dac->setTableName('tbl_user');
	$where = $obj_dac->_addslashesC('class', USER_CLASS_WRITER);
	$where .= ' AND ' . $obj_dac->_addslashesC('dept_code', $objLogin->get('dept_code'));
	$obj_dac->select($where, 'user_id, name', 'user_id');
	while ($obj_dac->fetch()) {
		$selected = ($obj_dac->fld['user_id'] == $objLogin->get('user_id')) ? ' selected' : '';
		$user_op .= '<option value="' . $obj_dac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($obj_dac->fld['name']) . '</option>' . "\n";
	}
}
$combo_user = $user_s1 . $user_op . $dept_e;
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>定型情報インポート</title>
<link rel="stylesheet" href="<?php echo(RPW); ?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="<?php echo(RPW); ?>/admin/style/outerimport.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?php echo(RPW); ?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/special/file/kanko_import/js/import.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
	<?php
	echo loadSettingVars();
	?>
	// 初期化
	function cxInit() {
		// 無期限設定のチェックボックスが選択されていた場合
		if ($('cms-pubend-Unrestricted-ws') && $('cms-pubend-Unrestricted-ws').checked == true) {
			// 入力項目非表示
			cxPublicEndUnrestricted();
			// 「年」項目初期化
			if ($('cms_pdey')) {
				$('cms_pdey').value = '';
			}
			// 「月」項目初期化
			if ($('cms_pdem')) {
				$('cms_pdem').value = '';
			}
			// 「日」項目初期化
			if ($('cms_pded')) {
				$('cms_pded').value = '';
			}
			// 「時」項目初期化
			if ($('cms_pdeh')) {
				$('cms_pdeh').value = '';
			}
		}
		return false;
	}
	Event.observe(window,'load',cxInit,false);
//-->
</script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . '/common/inc/special_menu.inc');
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<form id="cms_fImport" name="cms_fImport" class="cms8341-form" method="post" action="import_conf.php" enctype="multipart/form-data">
<input type="hidden" id="cms_filename" name="cms_filename" value="">
<div>
<img src="images/bar_kankoimport.jpg" alt="定型情報インポート" width="920"height="30">
</div>
<?php
if (file_exists(DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/')) {
?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
※取り込みファイルの展開フォルダにファイルが存在します。<br>
[取り込み確認]を行うと、展開フォルダ内は上書きされます。他ユーザが作業中でないことを確認して作業を続けてください。
</div>
<?php
}
?>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable">
<tr id="cms_FrmZipnm_tr">
<th width="150" align="left" valign="top" scope="row">
取り込みファイル<br>
<span class="cms_require">（必須）</span>
</th>
<td>
<input type="file" id="FrmZipnm" name="FrmZipnm" style="width: 500px;"><br>
※zip形式の圧縮ファイルを指定してください
</td>
</tr>
<tr id="cms_status_tr">
<th align="left" valign="top" nowrap scope="row">
取り込み後のステータス<br>
<span class="cms_require">（必須）</span>
</th>
<td>
<input type="radio" name="cms_status" id="cms_status_1" value="201" <?php echo($def_checked[STATUS_SAVE]); ?>>&nbsp;<label for="cms_status_1">一時保存</label>&nbsp;&nbsp;
<?php
if ($objLogin->get('isOuter') == FALSE) {
?>
<input name="cms_status" id="cms_status_2" value="401" type="radio" <?php echo($def_checked[STATUS_PUBLISH_WAIT]); ?>>&nbsp;<label for="cms_status_2">公開待ち</label>
<?php
}
?>
</td>
</tr>
<tr id="priority">
<th width="150" align="left" valign="top" scope="row">
優先情報
<span class="cms_require">（必須）</span>
</th>
<td>
<input type="radio" name="cms_priority" id="cms_priority_1" value="<?php echo KANKO_PRIORITY_DISP; ?>" onClick="changePriority(1)"<?php echo($def_checked[KANKO_PRIORITY_DISP]); ?>>&nbsp;<label for="cms_priority_1">画面情報</label>&nbsp;&nbsp;
<?php
if ($objLogin->get('isOuter') == FALSE) {
?>
<input name="cms_priority" id="cms_priority_2" value="<?php echo KANKO_PRIORITY_CSV; ?>" type="radio" onClick="changePriority(2)"<?php echo($def_checked[KANKO_PRIORITY_CSV]); ?>>&nbsp;<label for="cms_priority_2">CSV情報</label>
<?php
}
?>
</td>
</tr>
<?php
$display = 'style=""';
if($def_ary['cms_priority'] == KANKO_PRIORITY_CSV) {
	$display = 'style="display:none"';
}
?>
<tr id="cms_pd_tr" <?php echo $display; ?>>
<th align="left" valign="top" nowrap scope="row">
<label for="cms_pdsy">公開期間<span class="cms_require">（必須）</span></label>
</th>
<td>
<input type="text" maxlength="4" id="cms_pdsy" name="cms_pdsy" value="<?php echo($def_ary['cms_pdsy']); ?>" style="width: 50px; ime-mode: disabled"> 年 
<input type="text" maxlength="2" id="cms_pdsm" name="cms_pdsm" value="<?php echo($def_ary['cms_pdsm']); ?>" style="width: 30px; ime-mode: disabled"> 月 
<input type="text" maxlength="2" id="cms_pdsd" name="cms_pdsd" value="<?php echo($def_ary['cms_pdsd']); ?>" style="width: 30px; ime-mode: disabled"> 日 
<input type="text" maxlength="2" id="cms_pdsh" name="cms_pdsh" value="<?php echo($def_ary['cms_pdsh']); ?>" style="width: 30px; ime-mode: disabled"> 時 
<a href="javascript:" onClick="return cxCalendarOpen('cms_pd','start')">
<img src="<?php echo(RPW); ?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a> から &nbsp; 
<input type="text" maxlength="4" id="cms_pdey" name="cms_pdey" value="<?php echo($def_ary['cms_pdey']); ?>" style="width: 50px; ime-mode: disabled"> 年 
<input type="text" maxlength="2" id="cms_pdem" name="cms_pdem" value="<?php echo($def_ary['cms_pdem']); ?>" style="width: 30px; ime-mode: disabled"> 月 
<input type="text" maxlength="2" id="cms_pded" name="cms_pded" value="<?php echo($def_ary['cms_pded']); ?>" style="width: 30px; ime-mode: disabled"> 日 
<input type="text" maxlength="2" id="cms_pdeh" name="cms_pdeh" value="<?php echo($def_ary['cms_pdeh']); ?>" style="width: 30px; ime-mode: disabled"> 時 
<a href="javascript:" onClick="return cxCalendarOpen('cms_pd','end')">
<img src="<?php echo(RPW); ?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する" width="14" height="17" border="0" align="absmiddle"></a> まで
<?php
if (USE_INDEFINITE == true) {
	echo('<br />' . "\n");
	$publish_end = $def_ary['cms_pdey'] . '-' . $def_ary['cms_pdem'] . '-' . $def_ary['cms_pded'] . ' ' . $def_ary['cms_pdeh'] . ':00:00';
	$unrestricted_checked = '';
	if (get_publish_end_date($publish_end) == PUB_INDEFINITE) {
		$unrestricted_checked = ' checked';
	}
	echo('<input name="cms-pubend-Unrestricted-ws" type="checkbox" id="cms-pubend-Unrestricted-ws" style="width: 15px" value="" onclick="cxPublicEndUnrestricted();"' . $unrestricted_checked . '>' . "\n");
	echo('<label for="cms-pubend-Unrestricted-ws">' . PUB_INDEFINITE . '</label>' . "\n");
}
?>
</td>
</tr>
<tr id="cms_user_tr" <?php echo($display); ?>>
<th align="left" valign="top" nowrap scope="row">ページ作成者 <span class="cms_require">（必須）</span></th>
<td><?php echo($combo_dept); ?><?php echo($combo_user); ?></td>
</tr>
</table>
<p align="center"><img src="<?php echo(RPW); ?>/admin/images/icon/icon-flow.jpg" alt="" width="36" height="26"></p>
<p align="center" id="cms_submit">
<a href="javascript:" onClick="return cxSubmit()" onKeyDown="cxSubmit()">
<img src="<?php echo(RPW); ?>/admin/images/outerimport/btn_import_confirm.jpg" alt="取り込み確認" width="150" height="20" border="0" style="margin-right: 10px;">
</a>
</p>
</div>
<div>
<img src="<?php echo(RPW); ?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10">
</div>
</form>
</div>
</div>
<!-- cms8341-contents -->
<!--***カレンダーレイヤー ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
<table width="500" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
<tr>
<td align="left" valign="middle">
<img src="<?php echo(RPW); ?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー" width="200" height="20" style="margin: 4px 10px;">
</td>
<td width="78" align="right" valign="middle">
<a href="javascript:" onClick="return cxCalendarClose()">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58" height="19" border="0" style="margin: 4px 10px;">
</a>
</td>
</tr>
</table>
<div style="width: 100%; margin-top: 10px">
<div id="cms8341-calbody" style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;">
</div>
</div>
</td>
</tr>
</table>
</div>
<!--***カレンダーレイヤー ここまで********************************-->
<!--***エラーメッセージレイヤー ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
<table width="500" border="0" cellspacing="0" cellpadding="0" class="cms8341-layerheader">
<tr>
<td align="left" valign="middle">
<img src="<?php echo(RPW); ?>/admin/images/layer/bar_error.jpg" alt="エラー" width="480" height="20" style="margin: 4px 10px;">
</td>
</tr>
</table>
<div style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
<div align="center">
<div style="width: 430px; height: 120px; padding: 5px; text-align: left" id="cms8341-errormsg">メッセージ</div>
<div style="margin: 15px 0px;">
<a href="javascript:" onClick="return cxErrorClose();">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100" height="20" border="0">
</a>
</div>
</div>
</div>
</td>
</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで***********-->
</body>
</html>