<?php
/**
 * 定型情報インポート確認画面
 */

// 設定ファイルの読込
require ('../.htsetting');
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage2 = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
// イベントカレンダー複数日
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_event.inc');
$obj_event = new tbl_event($objCnc);

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$obj_dept = new tbl_department($objCnc);
require_once (APPLICATION_ROOT . '/common/setting_fixed.inc');
// 定型情報インポート共通関数ファイル
require_once ('./include/common.inc');


gd_errorhandler_ini_set('html0', RPW . '/admin/special/file/kanko_import/import.php?bak=1');

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}
// POST値に'cms_dispMode'が存在しない場合以下を処理
if (!isset($_POST['cms_dispMode']) || !in_array($_POST['cms_dispMode'], array('pageset', 'change_num'))) {
		// SESSIONに'post'が定義されていたら削除
		if (isset($_SESSION['post'])) {
			unset($_SESSION['post']);
		}
		if (isset($_SESSION['kanko']['check'])) {
			unset($_SESSION['kanko']['check']);
		}
	
	$_SESSION['post'] = $_POST;
	
	// （php.ini）post_max_size をオーバーすると$_POSTの値が飛んでこない
	if (count($_POST) == 0 || count($_FILES) == 0) {
		user_error('取り込みファイルのファイルサイズが大きすぎる可能性があります。<br>いくつかに分けて実行してください。');
	}
	// 取り込みファイルが指定されていなければエラー
	if (!isset($_FILES['FrmZipnm']) || $_FILES['FrmZipnm']['name'] == '') {
		user_error('取り込みファイルを指定してください。');
	}
	// （php.ini）upload_max_filesize をオーバーすると$_FILES['FrmZipnm']['size']はゼロになるので、ファイルサイズがゼロならエラー
	if ($_FILES['FrmZipnm']['size'] <= 0) {
		user_error('取り込みファイルの指定が正しくないか、取り込みファイルのファイルサイズが大きすぎる可能性があります。');
	}
	// 取り込みファイルはzip圧縮のファイルでなければエラー
	if (!preg_match('/\.zip$/i', $_FILES['FrmZipnm']['name'])) {
		user_error('取り込みファイルはzip形式の圧縮ファイルを指定してください。');
	}
	
	// 優先情報が「画面情報」のときのみ
	if($_POST['cms_priority'] == 1) {
		// 公開期間が指定されていなければエラー
		if (!checkdate($_POST['cms_pdsm'], $_POST['cms_pdsd'], $_POST['cms_pdsy'])) {
			user_error('公開開始日が正しく入力されていません。');
		}
		if (!checkdate($_POST['cms_pdem'], $_POST['cms_pded'], $_POST['cms_pdey'])) {
			user_error('公開終了日が正しく入力されていません。');
		}
		// 公開開始日・公開終了日を指定
		$_SESSION['post']['publish_start'] = $_POST['cms_pdsy'] . '-' . $_POST['cms_pdsm'] . '-' . $_POST['cms_pdsd'] . ' ' . $_POST['cms_pdsh'] . ':00:00';
		$_SESSION['post']['publish_end'] = $_POST['cms_pdey'] . '-' . $_POST['cms_pdem'] . '-' . $_POST['cms_pded'] . ' ' . $_POST['cms_pdeh'] . ':00:00';
	}
	
	// 取り込みファイルの展開ディレクトリ
	$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';
	chmodAll($tmpUpDir, 0777);
	if (@file_exists($tmpUpDir)) {
		removeDir($tmpUpDir);
	}
	if (!@mkdir($tmpUpDir, 0777)) {
		user_error('取り込みファイルの展開フォルダ作成に失敗しました。');
	}
	chmod($tmpUpDir, 0777);
	
	// 圧縮ファイルを解凍する
	// Windows・その他OS
	if (defined('SET_UNZIP_EXE')) {
		exec(SET_UNZIP_EXE . ' ' . $_FILES['FrmZipnm']['tmp_name'] . ' ' . $tmpUpDir);
	}
	// Unix系
	else {
		exec('unzip ' . $_FILES['FrmZipnm']['tmp_name'] . ' -d ' . $tmpUpDir);
	}
	
	// 取り込みファイルの確認
	$file_name = $_FILES['FrmZipnm']['name'];
	$pos = strrpos($file_name, '.'); // .が最後に現れる位置
	$name = substr($file_name, 0, $pos) . '/';
	$_SESSION['post']['import_dir_name'] = $name;
}
// POST値の'cms_dispMode'が存在し、'pageset'であった場合以下を処理
else if (isset($_POST['cms_dispMode']) && strcmp($_POST['cms_dispMode'], 'pageset') == 0) {
	$post = $_POST;
	$_POST = $_SESSION['post'];
}
// POST値の'cms_dispMode'が存在し、'change_num'であった場合以下を処理
else if (isset($_POST['cms_dispMode']) && strcmp($_POST['cms_dispMode'], 'change_num') == 0) {
	$post = $_POST;
	$_POST = $_SESSION['post'];
}

// 優先情報
if ($_POST['cms_priority'] == KANKO_PRIORITY_DISP) {
	$priority_str = '画面情報';
}
else if ($_POST['cms_priority'] == KANKO_PRIORITY_CSV) {
	$priority_str = 'CSV情報';
}

// ステータスを文字に変更
if ($_POST['cms_status'] == STATUS_SAVE) {
	$status_str = '一時保存';
}
else if ($_POST['cms_status'] == STATUS_PUBLISH_WAIT) {
	$status_str = '公開待ち';
}

// エラーチェック
// ステータスが指定されていなければエラー
// 優先情報が「画面情報」のときのみ
if ($_POST['cms_priority'] == KANKO_PRIORITY_DISP) {
	if (!isset($_POST['cms_status'])) {
		user_error('取り込み後のステータスが指定されていません。');
	}
	// ステータスが不正な値ならエラー
	else if ($_POST['cms_status'] != STATUS_SAVE && ($_POST['cms_status'] != STATUS_PUBLISH_WAIT)) {
		user_error('取り込み後のステータスが正しく指定されていません。');
	}

	// ページ作成者の所属が選択されていなければエラー
	if (!isset($_POST['cms_target3']) || $_POST['cms_target3'] == '') {
		user_error('ページ作成者の所属を選択してください。');
	}
	// 選択した所属が存在しなければエラー
	$obj_dept->setTableName('tbl_department');
	$where = $obj_dept->_addslashesC('level', '3');
	$where .= ' AND ' . $obj_dept->_addslashesC('dept_code', $_POST['cms_target3']);
	$obj_dept->select($where);
	if (!$obj_dept->fetch()) {
		user_error('指定したページ作成者の所属は登録されていません。');
	}
	// ページ作成者の所属取得
	$dept_fld = $obj_dept->fld;
	
	// ページ作成者が選択されていなければエラー
	if (!isset($_POST['cms_user_id']) || $_POST['cms_user_id'] == '') {
		user_error('ページ作成者を選択してください。');
	}
	// 選択した作成者が存在しなければエラー
	$objDac->setTableName('tbl_user');
	$where = $objDac->_addslashesC('user_id', $_POST['cms_user_id']);
	$where .= ' AND ' . $objDac->_addslashesC('class', USER_CLASS_WRITER);
	$objDac->select($where);
	if (!$objDac->fetch()) {
		user_error('指定したページ作成者は登録されていません。');
	}
	// ページ作成者の情報取得
	$user_fld = $objDac->fld;
}

$page_num = 1;
$disp_num = (isset($_POST['disp_num']) ? $_POST['disp_num'] : 10);
if (isset($post['cms_dispMode']) && strcmp($post['cms_dispMode'], 'pageset') == 0) {
	$page_num = (isset($post['cms_p']) ? $post['cms_p'] : 1);
	$disp_num = (isset($post['disp_num']) ? $post['disp_num'] : 10);
	$name = $post['cms_dir_name'];
}
else if (isset($post['cms_dispMode']) && strcmp($post['cms_dispMode'], 'change_num') == 0) {
	$disp_num = (isset($post['disp_num']) ? $post['disp_num'] : 10);
	$name = $post['cms_dir_name'];
}

// 表示開始件数
$start_num = (($page_num - 1) * $disp_num) + 1;
// 表示終了件数
$end_num = $page_num * $disp_num;
// 総データ数
$max_cnt = 0;

// アップロード先パス
$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';

$aryFiles = array();
$item_ary = array();
// 指定されたファイルのエラーチェック
$aryFiles = checkFiles($name, $aryFiles);
if ($aryFiles == false) {
	user_error('指定したファイルの読み込みに失敗しました。');
}

$aryUpFiles = array();
if (count($aryFiles) == 1 && !$aryFiles[0]['error']) {
	$post = $_SESSION['post'];
	$ok_cnt = 0;
	// CSVファイルが指定されていた場合
	// CSVファイル数ループ
	foreach ($aryFiles as $aryFile) {
		// ファイルパスがCSV拡張子の場合、以下を処理
		if (preg_match('/\.csv$/i', $aryFile['file_path'])) {
			$filename = $aryFile['file_path'];
			$_SESSION['post']['cms_csv_name'] = $filename;
		}
		// ファイルパスがCSV拡張子以外の場合、以下を処理
		else {
			continue;
		}
		// ファイル情報を格納
		$aryF = array(
			'file_path'	=>	$filename,
			'page_title'=>	'',
			'pagefile'	=>	TRUE,
			'error'		=>	FALSE,
			'mode'		=>	'ins',
			'overwrite'	=>	FALSE,
			'message'	=> '',
		);
		
		// CSVファイルを開く
		$file_path = $tmpUpDir . $filename;
		if (!($CsvFno = @fopen($file_path, 'r'))) {
			$aryUpFiles[$filename][$filename] = _set_error($aryF, 'CSVファイルが参照できませんでした。');
			continue;
		}
		$buf = ChgEncoding(file_get_contents($file_path));
		$CsvFno = tmpfile();
		if (!fwrite($CsvFno, $buf)) {
			user_error('ファイルの書き込みに失敗しました。');
		}
		if (!rewind($CsvFno)) {
			user_error('ファイルポインタを先頭に戻す処理に失敗しました。');
		}
		
		// EOFになるまで読み出し
		$ok_cnt = -2;
		$bck_cnt = -3;
		// 添え字データ
		$csv_index_ary = array();
		// CSVを読み終えるまでループ
		while ($csv_data = cms_fgetcsv($CsvFno, 10000)) {
			// 前の行数と今の行数が違えばカウントアップ
			if ($ok_cnt != $bck_cnt) {
				$bck_cnt = $ok_cnt;
				$ok_cnt++;
			}
			// 空行はスキップ
			if (!isset($csv_data[1])) {
				continue;
			}
			
			// ファイル情報を格納
			$aryF = array(
				'file_path'		=>	$filename,
				'page_title'	=>	'',
				'pagefile'		=>	TRUE,
				'error'			=>	FALSE,
				'mode'			=>	'ins',
				'overwrite'		=>	FALSE,
				'message'		=>	'',
				'line_num'		=>	$ok_cnt,
				'publish_start'	=>	'',
				'publish_end'	=>	''
			);
			// データ配列
			$arrCSV = array();
			// 変数のクリア
			$aryMkFiles = array();
			$aryParent_path = '';
			// 添え字クリア
			$csv_idx = 0;
			// 1行目の添え字データを読み込む
			if ($ok_cnt == -1) {
				foreach ($csv_data as $data) {
					$csv_index_ary[] = ChgEncoding(trim($data));
				}
			}
			// 2行目の添え字(日本語)をスキップ
			else if ($ok_cnt == 0) {
				continue;
			}
			// 項目格納（連想配列名はDB項目名と等しい）
			else {
				foreach ($csv_data as $data) {
					$arrCSV[$csv_index_ary[$csv_idx++]] = ChgEncoding(trim($data));
				}
			}
			
			// 実データならDB書き込み
			if ($ok_cnt > 0) {
				if (isset($errFlg)) {
					// エラーが有ればロールバック
					if ($errFlg) {
						$objCnc->rollback();
					}
					// エラーが無ければコミット
					else {
						$objCnc->commit();
					}
				}
				// エラーフラグ初期化
				$errFlg = FALSE;
				
				// ページ情報登録
				if (isset($arrCSV[KANKO_IMP_PAGE_TITLE]) && $arrCSV[KANKO_IMP_PAGE_TITLE] != '') {
					$aryF['page_title'] = $arrCSV[KANKO_IMP_PAGE_TITLE];
				}
				// トランザクション
				$objCnc->begin();
				
				// エラーチェック
				// アップロード先のチェック
				$file_err = checkImportFile($arrCSV, $objLogin);
				if (!empty($file_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . '_'] = _set_error($aryF, $file_err);
					$errFlg = TRUE;
					continue;
				}
				
				// 優先情報がCSVのときのみチェック
				if ($_POST['cms_priority'] == 2) {
					// 公開開始日、公開終了日、ユーザID、ファイルパスがCSVファイルに存在しない場合は、エラー出力
					if (!isset($arrCSV['publish_start']) || $arrCSV['publish_start'] == '') {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, '公開開始日を指定してください。');
						$errFlg = TRUE;
						continue;
					}
					if (!isset($arrCSV['publish_end']) || $arrCSV['publish_end'] == '') {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, '公開終了日を指定してください。');
						$errFlg = TRUE;
						continue;
					}
					if (!isset($arrCSV['user_id']) || $arrCSV['user_id'] == '') {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, '作成者を指定してください。');
						$errFlg = TRUE;
						continue;
					}
					if (!isset($arrCSV['file_path']) || $arrCSV['file_path'] == '') {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, 'ファイルパスを指定してください。');
						$errFlg = TRUE;
						continue;
					}
					// フォーマットを揃える
					$arrCSV['publish_start'] = str_replace('/', '-', $arrCSV['publish_start']);
					$arrCSV['publish_end'] = str_replace('/', '-', $arrCSV['publish_end']);
					$publish_start_date = explode(' ', $arrCSV['publish_start']);
					// 時間が空の場合はデフォルト値を入れる
					if (!isset($publish_start_date[1]) && !empty($publish_start_date[0])) {
						$arrCSV['publish_start'] = $arrCSV['publish_start'] . ' ' . KANKO_IMPORT_START_TIME;
					}
					$publish_end_date = explode(' ', $arrCSV['publish_end']);
					// 時間が空の場合はデフォルト値を入れる
					if (!isset($publish_end_date[1]) && !empty($publish_end_date[0])) {
						$arrCSV['publish_end'] = $arrCSV['publish_end'] . ' ' . KANKO_IMPORT_END_TIME;
					}
					// 公開日時チェック
					$date_err = checkPublishDate($arrCSV['publish_start'], $arrCSV['publish_end']);
					if (!empty($date_err)) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $date_err);
						$errFlg = TRUE;
						continue;
					}
					
					// 指定作成者チェック
					$user_err = checkUserId($arrCSV['user_id'], $objCnc, $arrCSV['file_path']);
					if (!empty($user_err)) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $user_err);
						$errFlg = TRUE;
						continue;
					}
					else {
						// 存在するユーザーIDの場合は組織コードを取得する
						$sql = 'SELECT dept_code FROM tbl_user WHERE user_id = ' . $arrCSV['user_id'];
						$objDac->execute($sql);
						while ($objDac->fetch()) {
							// 組織コードを格納
							$post['cms_target3'] = $objDac->fld['dept_code'];
						}
					}
				}
				
				// アップロード先情報の取得
				$cms_dir = cms_dirname($arrCSV[KANKO_IMP_DIR_PATH]) . '/';
				if ($cms_dir === '.' || $cms_dir === '/') {
					$cms_dir = '/';
				}
				else if (substr($cms_dir, 0, 1) != '/') {
					$cms_dir = '/' . $cms_dir;
				}
				$cms_dir = str_replace('//', '/', $cms_dir);
				$file_name = basename($arrCSV[KANKO_IMP_DIR_PATH]);
				
				// テンプレート関連のエラーチェック
				$template_err = checkImportTemplate($arrCSV, $objDac, $objTool, $post['cms_target3']);
				if (!empty($template_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $template_err);
					$errFlg = TRUE;
					continue;
				}
				
				// 分類コードのエラーチェック
				$cate_err = checkImportCategory($arrCSV);
				if (!empty($cate_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $cate_err);
					$errFlg = TRUE;
					continue;
				}
				
				// 必須項目チェック
				// XMLファイルから情報取得
				if (!isset($item_ary[$arrCSV[KANKO_IMP_TMP_ID]])) {
					$item_ary[$arrCSV[KANKO_IMP_TMP_ID]] = getItem($arrCSV[KANKO_IMP_TMP_ID], '', 'edit');
				}
				$items = $item_ary[$arrCSV[KANKO_IMP_TMP_ID]];
				$cols_err = checkImportNeed($arrCSV, $items, $KANKO_IMP_NOT_ERR_ID);
				if (!empty($cols_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $cols_err);
					$errFlg = TRUE;
					continue;
				}
				
				// 項目チェック
				$err_ary = isErr($items, $arrCSV, $tmpUpDir . $name);
				// 項目エラーがあればエラーとしてセットする
				if ($err_ary[0]) {
					if ((string)$err_ary[0] == KANKO_IMP_CHECK_FILES_FLG) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $err_ary[2]);
					}
					else {
						// 依存ファイルのエラーでなかったらエラーフラグを立てる
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $err_ary[2] . '[' . $err_ary[1] . ']');
						$errFlg = TRUE;
						continue;
					}
				}
				
				// 「tbl_～_page」の登録データをセット
				unset($ary);
				// tbl_publish_pageに登録するデータの確認
				$template_ver = $objTool->fld['template_ver'];
				$ary = setImportData($post, $template_ver, $objTool, $arrCSV);
				
				// 分類存在・イベントテンプレート時のイベント開催終了期間チェック
				$page_err = checkImportPage($ary, $template_ver, $objCate, $objTool);
				if (!empty($page_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $page_err);
					$errFlg = TRUE;
					continue;
				}
				
				// パンくず設定
				$ancestor_path = "";
				if (!($ary['template_kind'] == TEMPLATE_KIND_FIXED && $objTool->selectTemplateKankoType($ary['template_id']) == KANKO_TYPE_EVENT)) {
					if (isset($ary[KANKO_IMP_PAR_PATH]) && $ary[KANKO_IMP_PAR_PATH] != "") {
						$ancestor_err = checkImportAncestor($objCnc, $ary, $post['cms_user_id']);
						if(!empty($ancestor_err)) {
							$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $ancestor_err);
							$errFlg = TRUE;
							continue;
						}
						$objPage->selectFromPath($ary[KANKO_IMP_PAR_PATH]);
						$ancestor_path = $objPage->fld['ancestor_path'] . ',' . $objPage->fld['file_path'];
					}
					unset($ary[KANKO_IMP_PAR_PATH]);
					$ary['ancestor_path'] = $ancestor_path;
				}
				
				// 階層制限とフォルダの作成チェック
				$dir_err = checkImportDirectory($ary['file_path'], $objLogin);
				if (!empty($dir_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $dir_err);
					$errFlg = TRUE;
					continue;
				}
				
				// 問い合わせ先設定エラーチェック
				$inq_err = checkInquiryData($arrCSV, $objCnc);
				if (!empty($inq_err)) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $inq_err);
					$errFlg = TRUE;
					continue;
				}
				// 問い合わせ先設定情報取得
				$inquiry_data_ary = setInquiryData($arrCSV);
				
				// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
				$objPage->setTableName(PUBLISH_TABLE);
				$objPage->select($objPage->_addslashesC('file_path', $ary['file_path']), 'page_id,work_class,status,template_id');
				// 更新
				if ($objPage->fetch()) {
					$aryF['mode'] = 'upd';
					$ary['page_id'] = $objPage->fld['page_id'];
					$ary['pub_status'] = $objPage->fld['status'];
					
					// 更新情報のテンプレートチェック
					$update_err = checkImportUpdate($arrCSV[KANKO_IMP_TMP_ID], $objPage->fld['template_id'], $objPage->fld['status'], $objPage->fld['work_class']);
					if (!empty($update_err)) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $update_err);
						$errFlg = TRUE;
						continue;
					}
				}
				// 新規
				else {
					// 新規登録のファイル名チェック
					$ins_err = checkImportInsert($cms_dir, $file_name);
					if (!empty($ins_err)) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = _set_error($aryF, $ins_err);
						$errFlg = TRUE;
						continue;
					}
					// ページIDの取得
					$ary['page_id'] = $objPage->getSeqNextval();
					// 新規作成ページをセット
					$aryMkFiles[$ary['page_id']] = $file_name;
				}
				$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]] = $aryF;
				// 公開期間とユーザー名の格納 CSV情報のみ
				if ($_POST['cms_priority'] == KANKO_PRIORITY_CSV) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]]['publish_start'] = $arrCSV['publish_start'];
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]]['publish_end'] = $arrCSV['publish_end'];
					$objDac->setTableName('tbl_user');
					$objDac->select($objDac->_addslashesC('user_id', $arrCSV['user_id']), 'dept_name, name');
					while ($objDac->fetch()) {
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]]['dept_name'] = $objDac->fld['dept_name'];
						$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]]['user_name'] = $objDac->fld['name'];
					}
				}
				// 依存ファイルのエラーの時は注意喚起メッセージを追加する
				if ($err_ary[0] == KANKO_IMP_CHECK_FILES_FLG) {
					$aryUpFiles[$filename][$ok_cnt . '件目 ' . $arrCSV[KANKO_IMP_DIR_PATH]]['message'] = $err_ary[2];
				}
			}
		}
		// CSVファイルClose
		fclose($CsvFno);
		
		// エラーが有ればロールバック
		if (isset($errFlg)) {
			if ($errFlg) {
				$objCnc->rollback();
			}
			else {
				// エラーが無ければコミット
				$objCnc->commit();
			}
		}
		
		break;
	}
	$aryFiles = array();
	$max_cnt = $ok_cnt;
}
else {
	// 開始件数初期化
	$start_num = 0;
	
	// CSVファイルを一件も読み込めなかった場合エラー
	if (count($aryFiles) < 1) {
		$aryFiles[] = array(
			'file_path'	=>	'', 
			'page_title'=>	'', 
			'pagefile'	=>	false, 
			'error'		=>	true, 
			'mode'		=>	'', 
			'overwrite'	=>	false, 
			'message'	=>	'CSVファイルの読み込みに失敗しました。'
		);
	}
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>定型情報インポート</title>
<link rel="stylesheet" href="<?php echo(RPW); ?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="<?php echo(RPW); ?>/admin/style/outerimport.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?php echo(RPW); ?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/library/scriptaculous.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?php echo(RPW); ?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="./js/import.js" type="text/javascript"></script>
</head>
<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . '/common/inc/special_menu.inc');
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div>
<img src="images/bar_kankoimport.jpg" alt="定型情報取り込み" width="920" height="30">
</div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="left" valign="middle" style="background-image:url(<?php echo(RPW); ?>/admin/page/publiclist/images/bar_topbg.jpg);height:31px;">
<img src="<?php echo(RPW); ?>/admin/images/outerimport/bar_importconf.jpg" alt="取込条件" width="200" height="20" style="margin-left: 10px;">
</td>
</tr>
</table>
<div id="cms8341-search" style="display: block">
<table width="100%" border="0" cellpadding="7" cellspacing="0" class="cms8341-dataTable">
<tr>
<th width="150" align="left" valign="top" scope="row">取り込みファイル</th>
<td><?php echo(htmlDisplay($_POST['cms_filename'])); ?></td>
</tr>
<tr>
<th align="left" valign="top" nowrap scope="row">優先情報</th>
<td><?php echo($priority_str); ?></td>
</tr>
<tr>
<th align="left" valign="top" nowrap scope="row">取り込み後のステータス</th>
<td><?php echo($status_str); ?></td>
</tr>
<?php
// 優先情報が画面情報のときのみ以下を表示する
if ($_POST['cms_priority'] == 1) {
?>
<tr>
<th align="left" valign="top" nowrap scope="row">公開期間</th>
<td>
<?php 
echo dtFormat($_SESSION['post']['publish_start'], 'Y年m月d日H時') . 'から&nbsp;' . get_publish_end_date($_SESSION['post']['publish_end']) . 'まで';
?>
</tr>
<tr>
<th align="left" valign="top" nowrap scope="row">ページ作成者</th>
<td><?php echo(htmlDisplay($dept_fld['dept_name'] . ' ' . $user_fld['name'])); ?></td>
</tr>
<?php
}
?>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td align="right" valign="middle" style="background-image:url(<?php echo(RPW); ?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;">
<a href="javascript:" onClick="return cxBlind('cms8341-search','cms-searchSwitch')">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる" width="80" height="15" border="0" style="margin-right: 10px;" id="cms-searchSwitch">
</a>
</td>
</tr>
</table>
</div>
<form id="cms_fImport" name="cms_fImport" class="cms8341-form" method="post" action="import_exec.php">
<input type="hidden" id="cms_dispMode" name="cms_dispMode" value="">
<input type="hidden" id="cms_p" name="cms_p" value="">
<input type="hidden" id="cms_dir_name" name="cms_dir_name" value="<?php echo($name); ?>">
<p>
<a href="javascript:" onClick="return cxCheckAll();">
<img src="<?php echo(RPW); ?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する" width="120" height="20" border="0"></a>
<a href="javascript:" onClick="return cxReleaseAll();">
<img src="<?php echo(RPW); ?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する" width="120" height="20" hspace="20" border="0"></a>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-bottom: 10px; padding: 1px">
<tr valign="top">
<td colspan="3" align="right">
<?php echo(mkcombobox($MAXROW_LIST, "disp_num", $disp_num, "cxDispNum(this.value)")); ?>
</td>
</tr>
<tr>
<td width="30%" align="left" valign="middle" scope="row">
<?php
if ($start_num > 1) {
?>
<a href="javascript:" onClick="return cxPageSet(<?php echo(($page_num - 1)); ?>)">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_prev.gif" alt="" width="50" height="16" align="absmiddle" border="0">
</a>
<?php
}
else {
	print '&nbsp;';
}
?>
</td>
<td width="40%" align="center" valign="middle">
<?php echo($max_cnt); ?>件中 <?php echo($start_num); ?>～<?php echo($max_cnt < $end_num ? $max_cnt : $end_num); ?> 件表示
</td>
<td width="30%" align="right" valign="middle">
<?php
if ($max_cnt > $end_num) {
?>
<a href="javascript:" onClick="return cxPageSet(<?php echo(($page_num + 1)); ?>)">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_next.gif" alt="" width="50" height="16" align="absmiddle" border="0">
</a>
<?php
}
else {
	print '&nbsp;';
}
?>
</td>
</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">
<tr>
<th width="80" align="center" valign="middle" style="font-weight: normal" scope="col">選択</th>
<th width="80" align="center" valign="middle" style="font-weight: normal" scope="col">状態</th>
<th align="center" valign="middle" style="font-weight: normal" scope="col">取り込みファイル</th>
</tr>
<?php
// インポート用CSVファイルに関するエラー表示
if (count($aryFiles) > 0) {
	foreach ($aryFiles as $ary) {
		$icon_img = '&nbsp;';
		print '<tr>' . "\n";
		print '<td align="center" valign="middle">';
		print '&nbsp;';
		print '</td>' . "\n";
		print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
		print '<td align="left" valign="top" nowrap><p>' . htmlDisplay(SJIStoUTF8($ary['file_path'])) . "\n";
		if ($ary['page_title'] != '') {
			print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
		}
		// エラーメッセージの表示
		if ($ary['message'] != '') {
			print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
		}
		if (count($aryFiles) > 1) {
			print '<br><span class="cms8341-error">複数のCSVファイルは取り込めません。</span>' . "\n";
		}
		print '</p></td>' . "\n";
		print '</tr>' . "\n";
	}
}
?>
<?php
// 取り込みを行うページリスト表示
if (count($aryUpFiles) > 0) {
	foreach ($aryUpFiles as $aryUpFile) {
		foreach ($aryUpFile as $key => $ary) {
			$checked = (isset($_SESSION['kanko']['check']) && in_array($ary['line_num'], $_SESSION['kanko']['check'])) ? ' checked' : '';
			$icon_img = '&nbsp;';
			if (!$ary['error']) {
				if (!$ary['pagefile'] && $ary['overwrite']) {
					$icon_img = '[上書き]';
				}
				else if (strcmp($ary['mode'], 'upd') == 0) {
					$icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_edit.jpg" alt="更新" width="70" height="25">';
				}
				else if (strcmp($ary['mode'], 'ins') == 0) {
					$icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_new.jpg" alt="新規" width="70" height="25">';
				}
			}
			$chkbox_name = ($ary['pagefile']) ? 'cms_file_path' : 'cms_item_path';
			$chkbox_name = 'cms_target_line';
			print '<tr>' . "\n";
			print '<td align="center" valign="middle">';
			if ($ary['error']) {
				print '&nbsp;';
			}
			else {
				print '<input type="checkbox" name="' . $chkbox_name . '[]" id="line_num_' . $ary['line_num'] . '" value="' . $ary['line_num'] . '" onClick="return cxCheck(\'' . $ary['line_num'] . '\')" ' . $checked . '>' . "\n";
			}
			print '</td>' . "\n";
			print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
			print '<td align="left" valign="top" nowrap><p>' . htmlDisplay($key) . "\n";
			if ($ary['page_title'] != '') {
				print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
			}
			// 優先情報がCSV情報の場合のみ表示
			if($_POST['cms_priority'] == 2) {
				if(!empty($ary['publish_start']) && !empty($ary['publish_end'])) {
					print '<br />公開期間' ."&nbsp;" . dtFormat($ary['publish_start'], 'Y年m月d日H時') . '～' . get_publish_end_date($ary['publish_end']) . "\n";
				}
				if(!empty($ary['dept_name']) && !empty($ary['user_name'])){
					print '<br />' . $ary['dept_name'] . "&nbsp;" . $ary['user_name'] . "\n";
				}
			}
			if ($ary['message'] != '') {
				print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
			}
			print '</p></td>' . "\n";
			print '</tr>' . "\n";
		}
	}
}
?>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5" style="margin-top: 10px;">
<tr>
<td width="30%" align="left" valign="middle" scope="row">
<?php
if ($start_num > 1) {
?>
<a href="javascript:" onClick="return cxPageSet(<?php echo(($page_num - 1)); ?>)">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_prev.gif" alt="" width="50" height="16" align="absmiddle" border="0">
</a>
<?php
}
else {
	print '&nbsp;';
}
?>
</td>
<td width="40%" align="center" valign="middle">
<?php echo($max_cnt); ?>件中 <?php echo($start_num); ?>～<?php echo($max_cnt < $end_num ? $max_cnt : $end_num); ?> 件表示
</td>
<td width="30%" align="right" valign="middle">
<?php
if ($max_cnt > $end_num) {
?>
<a href="javascript:" onClick="return cxPageSet(<?php echo(($page_num + 1)); ?>)">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_next.gif" alt="" width="50" height="16" align="absmiddle" border="0">
</a>
<?php
}
else {
	print '&nbsp;';
}
?>
</td>
</tr>
</table>
<p align="center">
<img src="<?php echo(RPW); ?>/admin/images/icon/icon-flow.jpg" alt="" width="36" height="26">
</p>
<p align="center">
<?php
if (count($aryFiles) < 1) {
?>
<a href="javascript:" onClick="return cxSubmitExec()" onKeyDown="cxSubmitExec()">
<img src="<?php echo(RPW); ?>/admin/images/btn/btn_start.jpg" alt="取り込み開始" width="150" height="20" border="0" style="margin-right: 10px;"></a>
<?php
}
?>
<a href="./import.php?bak=1"><img src="<?php echo(RPW); ?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left: 10px;"></a>
</p>
</form>
</div>
<div>
<img src="<?php echo(RPW); ?>/admin/images/area920_bottom.jpg" alt="" width="920" height="10">
</div>
</div>
</div>
<!-- cms8341-contents -->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="500" align="center" valign="top" bgcolor="#DFDFDF" style="border: solid 1px #343434;">
<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?php echo(RPW); ?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
<tr>
<td align="left" valign="middle">
<img src="<?php echo(RPW); ?>/admin/images/layer/bar_progress.jpg" alt="処理中" width="480" height="20" style="margin: 4px 10px;">
</td>
</tr>
</table>
<div style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
<div align="center">
<div style="width: 430px; height: 120px; padding: 5px; text-align: left" id="cms8341-progressmsg">メッセージ
</div>
</div>
</div>
</td>
</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>