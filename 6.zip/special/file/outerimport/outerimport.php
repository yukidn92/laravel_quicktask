<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_department.inc');
$objDept = new tbl_department($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// 初期表示値
$def = array();
if (isset($_GET['bak']) && $_GET['bak'] == 1 && isset($_SESSION['post']) && is_array($_SESSION['post'])) {
	$def = $_SESSION['post'];
}
elseif (isset($_SESSION['post'])) {
	unset($_SESSION['post']);
}
if (!isset($def['cms_dir'])) {
	$where = " class ='" . HANDLER_CLASS_DEF_DIR1 . "'";
	$where .= " AND item1 ='" . $objLogin->get('dept_code') . "'";
	$objDac->setTableName("tbl_handler");
	$objDac->select($where);
	$objDac->fetch();
	if ($objDac->getRowCount() == 0) {
		$defFolder = "/";
	}
	else {
		$defFolder = $objDac->fld['item2'];
	}
	$def['cms_dir'] = $defFolder;
}

// デフォルト保存先フォルダ
$DEFAULT_DIR_FIXED = getDefineArray('DEFAULT_DIR_FIXED');
$def_dir_fixed_hidden = "";
foreach ((array) $DEFAULT_DIR_FIXED as $_type => $_dir) {
	// ディレクトリ名の前後に「/(スラッシュ)」
	$_dir = (preg_match("/^\//", $_dir)) ? $_dir : "/" . $_dir;
	$_dir .= (preg_match("/\/$/", $_dir)) ? "" : $_dir . "/";
	// 実存ファイルチェック
	if (@is_dir(DOCUMENT_ROOT . RPW . $_dir)) {
		$def_dir_fixed_hidden .= '<input type="hidden" id="cms_def_dir_fixed_' . $_type . '" name="cms_def_dir_fixed_' . $_type . '" value="' . htmlspecialchars($_dir) . '">' . PHP_EOL;
	}
}

if (!isset($def['cms_template_id'])) $def['cms_template_id'] = '';
if (!isset($def['cms_cate1'])) $def['cms_cate1'] = '';
if (!isset($def['cms_cate2'])) $def['cms_cate2'] = '';
if (!isset($def['cms_cate3'])) $def['cms_cate3'] = '';
if (!isset($def['cms_cate4'])) $def['cms_cate4'] = '';
if (!isset($def['cms_pdsy'])) $def['cms_pdsy'] = date('Y');
if (!isset($def['cms_pdsm'])) $def['cms_pdsm'] = date('n');
if (!isset($def['cms_pdsd'])) $def['cms_pdsd'] = date('j');
if (!isset($def['cms_pdsh'])) $def['cms_pdsh'] = date('H');
if (!isset($def['cms_pdey'])) $def['cms_pdey'] = date('Y', strtotime("+" . PUBLISH_END_MONTH . " month"));
if (!isset($def['cms_pdem'])) $def['cms_pdem'] = date('n', strtotime("+" . PUBLISH_END_MONTH . " month"));
if (!isset($def['cms_pded'])) $def['cms_pded'] = date('j', strtotime("+" . PUBLISH_END_MONTH . " month"));
if (!isset($def['cms_pdeh'])) $def['cms_pdeh'] = 0;
if (!isset($def['cms_status'])) $def['cms_status'] = '201';
if (!isset($def['cms_target1'])) $def['cms_target1'] = '';
if (!isset($def['cms_target2'])) $def['cms_target2'] = '';
if (!isset($def['cms_target3'])) $def['cms_target3'] = '';
if (!isset($def['cms_user_id'])) $def['cms_user_id'] = '';
if (!isset($def['cms_template_kind'])) $def['cms_template_kind'] = '';
if (!isset($def['cms_filename'])) $def['cms_filename'] = '';
if (!isset($def['cms_non_template'])) $def['cms_non_template'] = '';
$def['template_src'] = "javascript:''";
$def['template_name'] = '';

// ステータスの初期選択
$def_checked['201'] = '';
$def_checked['401'] = '';
$def_checked[$def['cms_status']] = ' checked';

// テンプレート選択フォームの生成
$fields = "t.template_id, t.template_ver, t.temp_txt, t.name, t.template_kind, t.kanko_type";
$where = "t.template_ver = (SELECT MAX(template_ver) FROM tbl_template WHERE template_id = t.template_id)";
if ($objLogin->get("class") != USER_CLASS_WEBMASTER) {
	$where .= " AND " . $objDac->_addslashesC("h.class", HANDLER_CLASS_TEMPLATE);
	$where .= " AND t.template_id=h.item2";
	$where .= " AND " . $objDac->_addslashesC("h.item1", $objLogin->get('dept_code'));
	$objDac->setTableName("tbl_template AS t, tbl_handler AS h");
}
else {
	// ウェブマスターは tbl_handler を見ない
	$objDac->setTableName("tbl_template AS t");
}
$where .= " AND " . $objDac->_addslashesC("t.disp_flg", FLAG_ON);
$where .= " AND " . $objDac->_addslashesC("t.template_kind", TEMPLATE_KIND_FREE . "," . TEMPLATE_KIND_MOBILE, "IN");
$orderBy = "t.sort_order,t.template_id";
$objDac->select($where, $fields, $orderBy);
$combo_template = '<select name="cms_template_id" id="cms_template_id" size="12" style="width:250px;" onChange="cxSelectTemplate()">' . "\n";
while ($objDac->fetch()) {
	if ($objDac->fld['template_id'] == TEMPLATE_ID_NONE) continue;
	$src = DIR_PATH_TEMPLATE . $objDac->fld['temp_txt'];
	$selected = '';
	if ($objDac->fld['template_id'] == $def['cms_template_id']) {
		$def['template_src'] = RPW . '/admin/page/common/tplview.php?path=' . $src;
		$def['template_name'] = 'テンプレート：' . htmlDisplay($objDac->fld['name']) . ' が選択されています。';
		$selected = ' selected';
	}
	$combo_template .= '<option value="' . $objDac->fld['template_id'] . '" id="' . $src . '"' . $selected;
	$combo_template .= ' _kind="' . $objDac->fld['template_kind'] . '"  _kanko_type="' . $objDac->fld['kanko_type'] . '">';
	$combo_template .= htmlDisplay($objDac->fld['name']);
	$combo_template .= '</option>' . "\n";
}
$combo_template .= '</select>' . "\n";

// カテゴリプルダウン生成
$combo_cate = '';
$cate_s1 = '<select id="cms_cate1" name="cms_cate1" onChange="javascript:cxChangeCate(2, this.value)" style="width:150px;">' . "\n";
$cate_s2 = '<select id="cms_cate2" name="cms_cate2" onChange="javascript:cxChangeCate(3, this.value)" style="width:150px;">' . "\n";
$cate_s3 = '<select id="cms_cate3" name="cms_cate3" onChange="javascript:cxChangeCate(4, this.value)" style="width:150px;">' . "\n";
$cate_s4 = '<select id="cms_cate4" name="cms_cate4" onChange="javascript:cxChangeCate(5, this.value)" style="width:150px;">' . "\n";
$cate_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
$cate_e = '</select>&nbsp;&nbsp;';
$cate_op1 = $cate_opn;
$cate_op2 = $cate_opn;
$cate_op3 = $cate_opn;
$cate_op4 = $cate_opn;
// 第一カテゴリプルダウンの生成
$sql = "SELECT level,cate_code,name FROM tbl_category WHERE level = 1 ORDER BY disaster_flg " . (isDisasterFlg() ? 'DESC' : 'ASC') .  ", sort_order, cate_code";
$objDac->execute($sql);
while ($objDac->fetch()) {
	$selected = ($objDac->fld['cate_code'] == $def['cms_cate1']) ? ' selected' : '';
	$cate_op1 .= '<option value="' . $objDac->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
}
// 第二カテゴリプルダウンの生成（第一カテゴリが指定されている場合）
if ($def['cms_cate1'] != '') {
	$objCate->selectChildren($def['cms_cate1']);
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $def['cms_cate2']) ? ' selected' : '';
		$cate_op2 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
// 第三カテゴリプルダウンの生成（第二カテゴリが指定されている場合）
if ($def['cms_cate2'] != '') {
	$objCate->selectChildren($def['cms_cate2']);
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $def['cms_cate3']) ? ' selected' : '';
		$cate_op3 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
// 第四カテゴリプルダウンの生成（第三カテゴリが指定されている場合）
if ($def['cms_cate3'] != '') {
	$objCate->selectChildren($def['cms_cate3']);
	while ($objCate->fetch()) {
		$selected = ($objCate->fld['cate_code'] == $def['cms_cate4']) ? ' selected' : '';
		$cate_op4 .= '<option value="' . $objCate->fld['cate_code'] . '"' . $selected . '>' . htmlDisplay($objCate->fld['name']) . '</option>' . "\n";
	}
}
$cate1 = $cate_s1 . $cate_op1 . $cate_e;
$cate2 = $cate_s2 . $cate_op2 . $cate_e;
$cate3 = $cate_s3 . $cate_op3 . $cate_e;
$cate4 = $cate_s4 . $cate_op4 . $cate_e;
$combo_cate = $cate1 . $cate2 . $cate3 . $cate4;

//組織プルダウン生成
$dept_s1 = '<select id="cms_target1" name="cms_target1" onChange="javascript:cxChangeDept(1, this.value)" style="width:150px;">' . "\n";
$dept_s2 = '<select id="cms_target2" name="cms_target2" onChange="javascript:cxChangeDept(2, this.value)" style="width:150px;">' . "\n";
$dept_s3 = '<select id="cms_target3" name="cms_target3" onChange="javascript:cxChangeDept(3, this.value)" style="width:150px;">' . "\n";
$dept_opn = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
$dept_e = '</select>&nbsp;&nbsp;';
$dept_op1 = $dept_opn;
$dept_op2 = $dept_opn;
$dept_op3 = $dept_opn;
if ($objLogin->get('isOuter') == FALSE) {
	// 第一組織プルダウンの生成
	$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=1 ORDER BY sort_order, dept_code";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$selected = ($objDac->fld['dept_code'] == $def['cms_target1']) ? ' selected' : '';
		$dept_op1 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
	// 第二組織プルダウンの生成（第一組織が指定されている場合）
	if ($def['cms_target1'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=2 AND dept_code REGEXP '^" . substr($def["cms_target1"], 0, CODE_DIGIT_DEPT) . "' ORDER BY sort_order, dept_code";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['dept_code'] == $def['cms_target2']) ? ' selected' : '';
			$dept_op2 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
		}
	}
	// 第三組織プルダウンの生成（第二組織が指定されている場合）
	if ($def['cms_target2'] != '') {
		$sql = "SELECT level,dept_code,name FROM tbl_department WHERE level=3 AND dept_code REGEXP '^" . substr($def["cms_target2"], 0, (CODE_DIGIT_DEPT * 2)) . "' ORDER BY sort_order, dept_code";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['dept_code'] == $def['cms_target3']) ? ' selected' : '';
			$name = ($objDac->fld['name'] == " " || $objDac->fld['name'] == "　") ? "指定なし" : $objDac->fld['name'];
			$dept_op3 .= '<option value="' . $objDac->fld['dept_code'] . '"' . $selected . '>' . htmlDisplay($name) . '</option>' . "\n";
		}
	}
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '<option value="" selected>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>' . "\n";
	// ユーザプルダウンの生成（第三組織が指定されている場合）
	if ($def['cms_target3'] != '') {
		$sql = "SELECT user_id,name FROM tbl_user WHERE class = " . USER_CLASS_WRITER . " AND dept_code = '" . $def["cms_target3"] . "' ORDER BY user_id";
		$objDac->execute($sql);
		while ($objDac->fetch()) {
			$selected = ($objDac->fld['user_id'] == $def['cms_user_id']) ? ' selected' : '';
			$user_op .= '<option value="' . $objDac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
		}
	}
}
else {
	// 外部ファイル取り込みを許可されている組織の場合は、組織プルダウンは自分の組織しか表示しない
	$deptAry = getDeptCode($objLogin->get('dept_code'));
	// 第一組織プルダウンの生成
	$objDept->selectFromCode($deptAry['dept1_code']);
	$dept_op1 = '<option value="' . $objDept->fld['dept_code'] . '" selected>' . htmlDisplay($objDept->fld['name']) . '</option>' . "\n";
	// 第二組織プルダウンの生成
	$objDept->selectFromCode($deptAry['dept2_code']);
	$dept_op2 = '<option value="' . $objDept->fld['dept_code'] . '" selected>' . htmlDisplay($objDept->fld['name']) . '</option>' . "\n";
	// 第三組織プルダウンの生成
	$objDept->selectFromCode($deptAry['dept3_code']);
	$dept_op3 = '<option value="' . $objDept->fld['dept_code'] . '" selected>' . htmlDisplay($objDept->fld['name']) . '</option>' . "\n";
	
	$target1 = $dept_s1 . $dept_op1 . $dept_e;
	$target2 = $dept_s2 . $dept_op2 . $dept_e;
	$target3 = $dept_s3 . $dept_op3 . $dept_e;
	$combo_dept = $target1 . $target2 . $target3;
	
	$user_s1 = '<select id="cms_user_id" name="cms_user_id" style="width:150px;">' . "\n";
	$user_op = '';
	// ユーザプルダウンの生成
	$sql = "SELECT user_id,name FROM tbl_user WHERE class = " . USER_CLASS_WRITER . " AND dept_code = '" . $objLogin->get('dept_code') . "' ORDER BY user_id";
	$objDac->execute($sql);
	while ($objDac->fetch()) {
		$selected = ($objDac->fld['user_id'] == $objLogin->get('user_id')) ? ' selected' : '';
		$user_op .= '<option value="' . $objDac->fld['user_id'] . '"' . $selected . '>' . htmlDisplay($objDac->fld['name']) . '</option>' . "\n";
	}
}
$combo_user = $user_s1 . $user_op . $dept_e;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部ファイルインポート</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/outerimport.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<form id="cms_fImport" name="cms_fImport" class="cms8341-form"
	method="post" action="outerimport_conf.php"
	enctype="multipart/form-data"><input type="hidden" id="cms_filename"
	name="cms_filename" value=""> <input type="hidden"
	name="cms_template_kind" id="cms_template_kind"
	value="<?=$def['cms_template_kind']?>"> <input type="hidden"
	name="cms_template_kanko_type" id="cms_template_kanko_type" value="">
<?=$def_dir_fixed_hidden?>
<div><img src="images/bar_outerimport.jpg" alt="外部ファイルインポート" width="920"
	height="30"></div>
<?php
if (file_exists(DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/')) {
	?>
<div class="cms8341-areamessage" id="cms8341-denaillist-msg">
※取り込みファイルの展開フォルダにファイルが存在します。<br>
[取り込み確認]を行うと、展開フォルダ内は上書きされます。他ユーザが作業中でないことを確認して作業を続けてください。</div>
<?php
}
?>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="left" valign="top" nowrap scope="row" width="170"><label
			for="">テンプレート<br>
		<span class="cms_require">（必須）</span></label></th>
		<td>
		<p id="cms-template-selected"><?=$def['template_name']?></p>
		<p><span id="cms_template_setting_btn"><a href="javascript:"
			onClick="return cxTemplateSet()"><img
			src="<?=RPW?>/admin/images/btn/btn_set.jpg" alt="設定する" width="100"
			height="20" border="0"></a></span>
<?=mkcheckbox(array(FLAG_ON => "使用しない"), "cms_non_template", $def['cms_non_template'], "", "", "return cxNonTemplate()")?>
</p>
		</td>
	</tr>
	<tr id="cms_FrmZipnm_tr" style="display: none">
		<th width="150" align="left" valign="top" scope="row">取り込みファイル<br>
		<span class="cms_require">（必須）</span></th>
		<td><input type="file" id="FrmZipnm" name="FrmZipnm"
			style="width: 500px;"><br>
		※zip形式の圧縮ファイルを指定してください</td>
	</tr>
	<tr id="cms_dir_tr" style="display: none">
		<th align="left" valign="top" scope="row"><label for="cms_dir">アップロード先<br>
		<span class="cms_require">（必須）</span></label></th>
		<td><?=HTTP_ROOT . RPW?>&nbsp;<input type="text" id="cms_dir"
			name="cms_dir" value="<?=htmlspecialchars($def['cms_dir'])?>"
			style="width: 300px;"></td>
	</tr>
	<tr id="cms_cate_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row"><label
			for="cms_cate1">分類 <span class="cms_require">（必須）</span></label></th>
		<td><?=$combo_cate?></td>
	</tr>
	<tr id="cms_pd_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row"><label for="cms_pdsy">公開期間
		<span class="cms_require">（必須）</span></label></th>
		<td><input type="text" maxlength="4" id="cms_pdsy" name="cms_pdsy"
			value="<?=$def['cms_pdsy']?>"
			style="width: 50px; ime-mode: disabled"> 年 <input type="text"
			maxlength="2" id="cms_pdsm" name="cms_pdsm"
			value="<?=$def['cms_pdsm']?>"
			style="width: 30px; ime-mode: disabled"> 月 <input type="text"
			maxlength="2" id="cms_pdsd" name="cms_pdsd"
			value="<?=$def['cms_pdsd']?>"
			style="width: 30px; ime-mode: disabled"> 日 <input type="text"
			maxlength="2" id="cms_pdsh" name="cms_pdsh"
			value="<?=$def['cms_pdsh']?>"
			style="width: 30px; ime-mode: disabled"> 時 <a href="javascript:"
			onClick="return cxCalendarOpen('cms_pd','start')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a> から &nbsp; <input
			type="text" maxlength="4" id="cms_pdey" name="cms_pdey"
			value="<?=$def['cms_pdey']?>"
			style="width: 50px; ime-mode: disabled"> 年 <input type="text"
			maxlength="2" id="cms_pdem" name="cms_pdem"
			value="<?=$def['cms_pdem']?>"
			style="width: 30px; ime-mode: disabled"> 月 <input type="text"
			maxlength="2" id="cms_pded" name="cms_pded"
			value="<?=$def['cms_pded']?>"
			style="width: 30px; ime-mode: disabled"> 日 <input type="text"
			maxlength="2" id="cms_pdeh" name="cms_pdeh"
			value="<?=$def['cms_pdeh']?>"
			style="width: 30px; ime-mode: disabled"> 時 <a href="javascript:"
			onClick="return cxCalendarOpen('cms_pd','end')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a> まで</td>
	</tr>
	<tr id="cms_status_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">取り込み後のステータス<br>
		<span class="cms_require">（必須）</span></th>
		<td><input type="radio" name="cms_status" id="cms_status_1"
			value="201" <?=$def_checked['201']?>>&nbsp;<label for="cms_status_1">一時保存</label>&nbsp;&nbsp;
<?php
if ($objLogin->get('isOuter') == FALSE) {
	?>
<input name="cms_status" id="cms_status_2" value="401" type="radio"
			<?=$def_checked['401']?>>&nbsp;<label for="cms_status_2">公開待ち</label>
<?php
}
?>
</td>
	</tr>
	<tr id="cms_user_tr" style="display: none">
		<th align="left" valign="top" nowrap scope="row">ページ作成者 <span
			class="cms_require">（必須）</span></th>
		<td><?=$combo_dept?><?=$combo_user?></td>
	</tr>
</table>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center" id="cms_submit" style="display: none"><a
	href="javascript:" onClick="return cxSubmit()" onKeyDown="cxSubmit()"><img
	src="<?=RPW?>/admin/images/outerimport/btn_import_confirm.jpg"
	alt="取り込み確認" width="150" height="20" border="0"
	style="margin-right: 10px;"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
<!-- ** テンプレート設定レイヤー　ここから ************************************* -->
<div id="cms8341-template-select" class="cms8341-layer">
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="600" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="600" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/template_select/title_template_select.jpg"
					alt="テンプレートの選択" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxTemplateClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div
			style="width: 560px; height: 235px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<table width="540" border="0" cellpadding="0" cellspacing="0"
			class="cms8341-noneBorder">
			<tr>
				<td align="left" valign="top">
				<div id="cms_template_list"><label for="cms_template_id">テンプレートリスト</label>
<?=$combo_template?>
</div>
				</td>
				<td width="275" align="left" valign="middle">
				<div id="cms_thumb_cover" style="position: absolute; width: 275px; height: 215px; filter: Alpha(opacity = 0)"></div>
				<iframe src="<?=$def['template_src']?>" name="cms_thumb"
					id="cms_thumb" width="270" height="210" frameborder="0"
					scrolling="no" style="border: solid 1px #666"></iframe></td>
			</tr>
		</table>
		</div>
		</div>
		<p style="margin: 10px 0px;"><a href="javascript:"
			onClick="return cxTemplateSubmit()"><img
			src="<?=RPW?>/admin/images/btn/btn_submit.jpg" alt="決定" width="102"
			height="21" border="0"></a></p>
		</td>
	</tr>
</table>
</div>
<!-- ** テンプレート設定レイヤー　ここまで ************************************* --></form>
</div>
</div>
<!-- cms8341-contents -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー　　ここから***********-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxErrorClose();"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー　　ここまで***********-->
</body>
</html>
