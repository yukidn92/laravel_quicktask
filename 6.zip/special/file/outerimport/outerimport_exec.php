<?php
/*
 *
 */
/** 外部ページの取り込み処理 **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_links.inc');
$objLinks = new tbl_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_images.inc');
$objImages = new tbl_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
$objTool2 = new dac_tools($objCnc);
$objTool3 = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_inquiry.inc');
$objInquiry = new tbl_inquiry($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_library.inc');
$objLibrary = new tbl_library($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objHandler = new tbl_handler($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_links.inc');
$objFCKLinks = new tbl_fck_links($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_fck_images.inc');
$objFCKImages = new tbl_fck_images($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_kanko.inc');
$objKanko = new tbl_kanko($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_map.inc');
$objMap = new tbl_map($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_output_handler.inc');
$objOutputHandler = new tbl_output_handler($objCnc);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

// セッションにデータがなければエラー
if (!isset($_SESSION['post'])) {
	user_error("It isn't setted posted data in _session.", E_USER_ERROR);
}
$post = $_SESSION['post'];
$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';
if (!file_exists($tmpUpDir)) {
	user_error('取り込みデータが見つかりません。');
}

// ファイルが一つも選択されていなければエラー
if ((!isset($_POST['cms_file_path']) || !is_array($_POST['cms_file_path']) || count($_POST['cms_file_path']) == 0) && (!isset($_POST['cms_item_path']) || !is_array($_POST['cms_item_path']) || count($_POST['cms_item_path']) == 0)) {
	user_error('取り込むファイルを選択してください。');
}

if (isset($post['cms_non_template']) && $post['cms_non_template'][0] == FLAG_ON) {
}
else {
	// テンプレート情報を取得
	if ($objTool->selectTemplate($post['cms_template_id']) === FALSE) {
		user_error('指定したテンプレートは登録されていません。');
	}
	// テンプレートのバージョン（最新バージョン）：$template_ver
	$template_ver = $objTool->fld['template_ver'];
	// テンプレートファイルのパス：$template_path
	$template_path = DOCUMENT_ROOT . DIR_PATH_TEMPLATE . $objTool->fld['temp_txt'];
	// テンプレートファイルが存在しなければエラー
	if (!file_exists($template_path)) {
		user_error('テンプレートファイルが見つかりません。【' . $template_path . '】');
	}
}

// トランザクション
$objCnc->begin();

// 取り込み処理
$aryUpFiles = array();
$aryMkFiles = array();
$aryParent = array();

if (isset($_POST['cms_file_path']) && is_array($_POST['cms_file_path'])) {
	foreach ($_POST['cms_file_path'] as $filename) {
		// ファイル情報を格納
		$aryF = array(
				'file_path' => $filename, 
				'page_title' => '', 
				'pagefile' => true, 
				'error' => false, 
				'mode' => 'ins', 
				'overwrite' => false, 
				'message' => ''
		);
		// 既存チェック
		if (file_exists(DOCUMENT_ROOT . RPW . $post['cms_dir'] . $filename)) $aryF['overwrite'] = true;
		
		$file_path = $tmpUpDir . $filename;
		if (($fp = @fopen($file_path, "r")) == FALSE) {
			$aryUpFiles[$filename] = _set_error($aryF, 'HTMLファイルが参照できませんでした。');
			continue;
		}
		$htmlStr = fread($fp, filesize($file_path));
		fclose($fp);
		
		// 登録データのセット：$ary
		if (isset($post['cms_non_template']) && $post['cms_non_template'][0] == FLAG_ON) {
			$ary = _set_data_nontpl($post, $filename, $htmlStr);
		}
		else {
			$ary = _set_data($post, $filename, $template_ver, $objTool, $htmlStr);
		}
		if (!is_array($ary) || count($ary) == 0) {
			$aryUpFiles[$filename] = _set_error($aryF, 'ページ情報の格納ができませんでした。');
			continue;
		}
		$aryF['page_title'] = $ary['page_title'];
		
		// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
		$sql = "SELECT page_id,work_class,status,inquiry_id FROM tbl_publish_page WHERE file_path = '" . $post['cms_dir'] . $filename . "'";
		$objDac->execute($sql);
		// 更新
		if ($objDac->fetch()) {
			$aryF['mode'] = 'upd';
			$ary['page_id'] = $objDac->fld['page_id'];
			$ary['pub_status'] = $objDac->fld['status'];
			// 既存データが公開待ちか公開済みじゃなければ更新できない（更新の場合）
			if ($objDac->fld['status'] < 401) {
				$aryUpFiles[$filename] = _set_error($aryF, '現在このページは更新できません。');
				continue;
			}
			if (isset($ary['inquiry'])) {
				if (!$objDac->fld['inquiry_id'] || $objDac->fld['inquiry_id'] == "") {
					$ary['inquiry_id'] = $objInquiry->getSeqNextval();
				}
				else {
					$ary['inquiry_id'] = $objDac->fld['inquiry_id'];
				}
				for($i = 1; $i < count($ary['inquiry']) + 1; $i++) {
					$ary['inquiry'][$i]['inquiry_id'] = $ary['inquiry_id'];
				}
			}
			// データはないけれどファイルが存在する場合、更新してはいけない可能性がある。
		}
		elseif ($aryF['overwrite']) {
			$aryUpFiles[$filename] = _set_error($aryF, 'アップロード先に同名のHTMLファイルが存在しています。');
			continue;
			
		// 新規
		}
		else {
			// ページIDの取得
			$ary['page_id'] = $objPage->getSeqNextval();
			// 新規作成ページをセット
			$aryMkFiles[$ary['page_id']] = $filename;
			if (isset($ary['inquiry'])) {
				$ary['inquiry_id'] = $objInquiry->getSeqNextval();
				for($i = 1; $i < count($ary['inquiry']) + 1; $i++) {
					$ary['inquiry'][$i]['inquiry_id'] = $ary['inquiry_id'];
				}
			}
		}
		
		// ページ情報、リンク情報、画像情報の登録
		if (_insert_data($aryF['mode'], $ary, $objPage, $objLinks, $objImages, $objLogin->login, $errmsg, $objInquiry, $objHandler, $objTool3, $objLibrary) == FALSE) {
			_error($errmsg, $aryMkFiles, $post['cms_dir']);
		}
		
		$aryUpFiles[$filename] = $aryF;
		
		// 親ページをセット
		if (preg_match('/^(.*,)?([^,]+)$/', $ary['ancestor_path'], $r)) {
			$aryParent[] = array(
					'page_id' => $ary['page_id'], 
					'parent_path' => $r[2]
			);
		}
	}
}

// 親ページIDの取得
foreach ($aryParent as $ary) {
	$sql = "SELECT page_id FROM tbl_publish_page" . " WHERE file_path = '" . $ary['parent_path'] . "'" . " ORDER BY page_id LIMIT 1";
	$objDac->execute($sql);
	if ($objDac->fetch() === FALSE) continue;
	$parent_id = $objDac->fld['page_id'];
	$sql = "UPDATE tbl_work_page SET parent_id = " . $objDac->_addslashes($parent_id, 'INT') . " WHERE page_id = " . $ary['page_id'];
	$r = $objDac->execute($sql);
	if (!$r) {
		$errmsg = '親ページIDの登録に失敗しました。【' . $ary['page_id'] . '】';
		_error($errmsg, $aryMkFiles, $post['cms_dir']);
	}
}

$errFlg = false;

// HTMLファイルの生成
foreach ($aryMkFiles as $PID => $filename) {
	$file_path = DOCUMENT_ROOT . RPW . $post['cms_dir'] . $filename;
	addAuthDir($file_path, $post, $filename);
	if (!mkNewDirectory($file_path)) {
		$aryUpFiles[$filename] = _set_error($aryUpFiles[$filename], 'アップロード先フォルダの作成に失敗しました。【' . $file_path . '】');
		$errFlg = true;
		continue;
	}
	if (mkNewPage($PID, $post['cms_dir'] . $filename) === FALSE) {
		$aryUpFiles[$filename] = _set_error($aryUpFiles[$filename], 'HTMLファイルの生成に失敗しました。【' . $PID . '】');
		$errFlg = true;
		continue;
	}
}

// 画像やドキュメントのアップロード
if (isset($_POST['cms_item_path']) && is_array($_POST['cms_item_path'])) {
	foreach ($_POST['cms_item_path'] as $filename) {
		// ファイル情報を格納
		$aryF = array(
				'file_path' => $filename, 
				'page_title' => '', 
				'pagefile' => false, 
				'error' => false, 
				'mode' => '', 
				'overwrite' => false, 
				'message' => ''
		);
		$sExtension = substr($filename, (strrpos($filename, '.') + 1));
		$sExtension = strtolower($sExtension);
		$file_path = DOCUMENT_ROOT . RPW . $post['cms_dir'] . $filename;
		addAuthDir($file_path, $post, $filename);
		// 既存チェック
		if (file_exists($file_path)) $aryF['overwrite'] = true;
		if (!mkNewDirectory($file_path)) {
			$aryUpFiles[$filename] = _set_error($aryF, 'アップロード先フォルダの生成に失敗しました。【' . $file_path . '】');
			$errFlg = true;
			break;
		}
		if (!@copy($tmpUpDir . $filename, $file_path)) {
			$aryUpFiles[$filename] = _set_error($aryF, 'ファイルのアップロードに失敗しました。【' . $file_path . '】');
			$errFlg = true;
			continue;
		}
		if (!@chmod($file_path, 0777)) {
			$aryUpFiles[$filename] = _set_error($aryF, 'パーミッションの変更に失敗しました。【' . $file_path . '】');
			$errFlg = true;
			continue;
		}
		// 画像のリサイズ
		if (in_array($sExtension, array(
				'jpg', 
				'gif', 
				'jpeg', 
				'png'
		))) {
			if ($post['cms_template_kind'] == TEMPLATE_KIND_MOBILE) {
				mkThumbnail($file_path, FCK_MOBILE_UPLOAD_IMAGE_W, FCK_MOBILE_UPLOAD_IMAGE_H);
			}
			else {
				mkThumbnail($file_path, FCK_UPLOAD_IMAGE_W, FCK_UPLOAD_IMAGE_H);
			}
		}
		
		// FCK テーブルへの登録
		if (@file_exists($file_path) && preg_match("/(" . reg_replace(FCK_IMAGES_FORDER) . '|' . reg_replace(FCK_FILELINK_FORDER) . ')$/', cms_dirname($file_path), $match)) {
			// ファイル名取得
			$file_name = basename($file_path);
			
			if ($match[1] == FCK_IMAGES_FORDER) {
				$ary = array(
						"name" => $post['cms_dir'] . $filename, 
						"path" => $post['cms_dir'] . $filename
				);
				if ($objFCKImages->deleteFromImagePath($post['cms_dir'] . $filename) === FALSE) {
					$aryUpFiles[$filename] = _set_error($aryF, '画像情報の削除に失敗しました。【' . $post['cms_dir'] . $filename . '】');
					$errFlg = true;
					continue;
				}
				if ($objFCKImages->insert($ary) === FALSE) {
					$aryUpFiles[$filename] = _set_error($aryF, '画像情報の登録に失敗しました。【' . $post['cms_dir'] . $filename . '】');
					$errFlg = true;
					continue;
				}
			}
			elseif ($match[1] == FCK_FILELINK_FORDER) {
				$filesize = "";
				$extension = "";
				$file_data = array();
				if (file_exists($file_path)) {
					$filesize = filesize($file_path);
					$file_data = pathinfo($file_path);
					if (isset($file_data['extension']) && $file_data['extension'] != "") {
						$extension = $file_data['extension'];
					}
				}
				
				$ary = array(
						"name" => $post['cms_dir'] . $filename, 
						"path" => $post['cms_dir'] . $filename, 
						"file_exte" => $extension, 
						"file_size" => $filesize
				);
				if ($objFCKLinks->deleteFromPageID($post['cms_dir'] . $filename) === FALSE) {
					$aryUpFiles[$filename] = _set_error($aryF, 'ファイル情報の削除に失敗しました。【' . $post['cms_dir'] . $filename . '】');
					$errFlg = true;
					continue;
				}
				if ($objFCKLinks->insert($ary) === FALSE) {
					$aryUpFiles[$filename] = _set_error($aryF, 'ファイル情報の登録に失敗しました。【' . $post['cms_dir'] . $filename . '】');
					$errFlg = true;
					continue;
				}
			}
		}
		
		$aryUpFiles[$filename] = $aryF;
	}
}

if ($errFlg) {
	// ロールバック
	$objCnc->rollback();
}
else {
	// コミット
	$objCnc->commit();
}

// 取り込みファイルの削除
removeDir($tmpUpDir);

// 新規ディレクトリに権限を与える
function addAuthDir($file_path, $post, $filename) {
	global $objCnc;
	require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
	$objHandler = new tbl_handler($objCnc);
	//ディレクトリがない場合は、各ディレクトリにも権限を設定する
	if (!@file_exists($file_path)) {
		// ディレクトリの作成、移動
		if (preg_match_all('/([^\/]+)/', $post['cms_dir'] . cms_dirname($filename) . '/', $d)) {
			$d = $d[1];
			$dir_path_temp = '';
			foreach ($d as $directory) {
				$dir_path_temp .= "/" . $directory;
				if (@file_exists(DOCUMENT_ROOT . RPW . $dir_path_temp)) continue;
				//権限登録
				insert_handler_directory($post['cms_target3'], array(
						$dir_path_temp
				));
			}
		}
	}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部ファイル取り込み</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img
	src="<?=RPW?>/admin/special/file/outerimport/images/bar_outerimport.jpg"
	alt="外部取り込み" width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">アップロードしたファイル</th>
	</tr>
<?php
foreach ($aryUpFiles as $ary) {
	$icon_img = '&nbsp;';
	if (!$ary['error']) {
		if (!$ary['pagefile'] && $ary['overwrite']) $icon_img = '[上書き]';
		elseif ($ary['mode'] == 'upd') $icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_edit.jpg" alt="更新" width="70" height="25">';
		elseif ($ary['mode'] == 'ins') $icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_new.jpg" alt="新規" width="70" height="25">';
	}
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
	print '<td align="left" valign="top" nowrap><p>' . htmlDisplay($post['cms_dir'] . $ary['file_path']) . "\n";
	if ($ary['page_title'] != '') print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
	if ($ary['message'] != '') print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>
</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
<?php
/***********************************/
// パスを整形する
function _formPath($str = '', $current_dir = '', $template_kind) {
	$str = delHttpRoot($str);
	$str = delRootPath($str);
	$mobile_flg = ($template_kind == TEMPLATE_KIND_MOBILE) ? TRUE : FALSE;
	$str = setAbsolutePath($str, $current_dir, '', $mobile_flg);
	return $str;
}

// エラー
function _error($errmsg, $in_mkFiles, $cms_dir) {
	global $objCnc;
	//HTMLファイルを削除
	foreach ($in_mkFiles as $filename) {
		$html_path = DOCUMENT_ROOT . RPW . $cms_dir . $filename;
		if (file_exists($html_path)) unlink($html_path);
	}
	//ロールバック
	$objCnc->rollback();
	//エラーページの表示
	user_error($errmsg);
	exit();
}

function _set_error($aryF, $msg) {
	$aryF['error'] = true;
	$aryF['message'] = $msg;
	return $aryF;
}

function _set_data($post, $filename, $template_ver, $objTool, &$htmlStr) {
	
	global $objTool;
	global $objTool3;
	
	$template_kind = $objTool->fld['template_kind'];
	$dn = cms_dirname($filename);
	$dn = ($dn == '') ? '' : $dn . '/';
	$dir_path = $post['cms_dir'] . $dn;
	$filename = basename($filename);
	$ary = array();
	$r = "";
	// ページ情報（<!-- PageInfo で始まるコメント記述）
	$PageInfo = getCommentData($htmlStr, 'PageInfo contents_top_flg');
	if ($PageInfo !== FALSE) {
		$contents_top_flg = $PageInfo['attributes']['contents_top_flg'];
		$htmlStr = str_replace($PageInfo['start'], '', $htmlStr);
	}
	else {
		$contents_top_flg = 0;
	}
	
	// 文字コードをUTF-8にする
	if (preg_match('/<meta [^>]*charset=shift_jis[^>]*>/i', $htmlStr)) {
		$htmlStr = SJIStoUTF8($htmlStr);
		$htmlStr = preg_replace('/(<meta [^>]*charset=)(shift_jis)([^>]*>)/i', '${1}utf-8${3}', $htmlStr);
	}
	
	// ページタイトル：$page_title
	$page_title = (preg_match('/<title>(.*?)<\/title>/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? $r[1][0] : '';
	$page_title = htmlEncode($page_title);
	
	// パンくず用パス：$ancestor_path
	$ancestor_path = '';
	$pankuzu_str = getMidString($htmlStr, '<!-- InstanceBeginEditable name="pankuzu" -->', '<!-- InstanceEndEditable -->');
	if ($pankuzu_str != '') {
		$pankuzu_str = _formPath($pankuzu_str, $dir_path, $template_kind); // パスの整形
		preg_match_all('/<a href="([^"]+)">/i', $pankuzu_str, $ret);
		foreach ($ret[1] as $key => $ansPath) {
			if (substr($ansPath, -1) == "/") $ret[1][$key] = $ansPath . "index.html";
		}
		$ancestor_path = implode(',', $ret[1]);
	}
	// 見出し：$page_header
	$page_header = htmlEncode(getMidString($htmlStr, '<!-- InstanceBeginEditable name="header" -->', '<!-- InstanceEndEditable -->'));
	// FCKeditor領域：$context
	$context = getMidString($htmlStr, '<!-- InstanceBeginEditable name="contents" -->', '<!-- InstanceEndEditable -->');
	if ($context === FALSE && $PageInfo === FALSE) {
		if (preg_match('/<body[^>]*>/i', $htmlStr, $r1, PREG_OFFSET_CAPTURE) && preg_match('/<\/body>/i', $htmlStr, $r2, PREG_OFFSET_CAPTURE)) {
			$spos = $r1[0][1] + strlen($r1[0][0]);
			$leng = $r2[0][1] - $spos;
			$context = substr($htmlStr, $spos, $leng);
		}
	}
	$context = preg_replace('/(^[\r\n]*|[\r\n]*$)/', '', $context);
	$context = _formPath($context, $dir_path, $template_kind); // パスの整形
	// 文字の変換
	$replace_array = array(
			"&#160;" => "&nbsp;"
	);
	foreach ($replace_array as $moto => $rep) {
		$context = str_replace($moto, $rep, $context);
	}
	// キーワード：$keywords
	$keywords = (preg_match('/<meta name="keywords" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? htmlEncode($r[1][0]) : '';
	// 説明文：$description
	$description = (preg_match('/<meta name="description" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? htmlEncode($r[1][0]) : '';
	// 要約文：$summary
	$summary = (preg_match('/<meta name="summary" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? htmlEncode($r[1][0]) : '';
	// 問い合わせ先表示フラグ：$inquiry_flg（問い合わせ先を表示=1 / 非表示=0）
	$chk = getMidString($htmlStr, '<!-- InstanceBeginEditable name="inquiry" -->', '<!-- InstanceEndEditable -->');
	$inquiry_flg = ($chk !== FALSE) ? 1 : 0; // 問い合わせ先領域コメントが記述されていれば、表示
	// 問い合わせ先メモ：$inquiry_memo
	$inquiry_memo = htmlEncode(getMidString($chk, '<!-- BeginInqMemo -->', '<!-- EndInqMemo -->'));
	// 自動生成領域の有無をチェック：$index_flg（自動生成あり=1 / なし=0）
	$total_str = $objTool3->getTemplateContext($post['cms_template_id']) . $context;
	$index_flg = (isIncludeIndex($total_str)) ? 1 : 0;
	// コンテンツトップフラグ：$contents_top_flg
	$contents_top_flg = ($contents_top_flg != '') ? $contents_top_flg : 0;
	
	// ページ情報をセット
	$ary['cate_code'] = $post['cate_code']; // カテゴリ
	$ary['template_id'] = $post['cms_template_id']; // テンプレートID
	$ary['template_ver'] = $template_ver; // テンプレートバージョン
	$ary['ancestor_path'] = $ancestor_path; // パンくず用パス
	$ary['user_id'] = $post['cms_user_id']; // 作成者ID
	$ary['dir_path'] = $dir_path; // ディレクトリパス
	$ary['filename'] = $filename; // ファイル名
	$ary['file_path'] = $dir_path . $filename; // ファイルパス
	$ary['page_title'] = $page_title; // ページタイトル
	$ary['header'] = $page_header; // 見出し
	$ary['context'] = $context; // FCKeditor領域
	$ary['keywords'] = $keywords; // （検索エンジン用）キーワード
	$ary['description'] = $description; // （検索エンジン用）説明文
	$ary['summary'] = $summary; // （リンク掲載用）要約文
	$ary['inquiry_flg'] = $inquiry_flg; // 問い合わせ先表示フラグ
	$inquiry_memo = preg_replace('/\r?\n/', "", $inquiry_memo);
	$inquiry_memo = preg_replace('/\r/', "", $inquiry_memo);
	$inquiry_memo = preg_replace('/<br *\/?>/', "\n", $inquiry_memo);
	$ary['inquiry_memo'] = $inquiry_memo; // 問合せ先メモ
	$ary['index_flg'] = $index_flg; // 自動生成ページフラグ
	//	$ary['index_title'] = $page_title;				// リンク掲載用タイトル
	$ary['contents_top_flg'] = $contents_top_flg; // コンテンツトップフラグ
	$ary['publish_start'] = $post['publish_start']; // 公開開始日
	$ary['publish_end'] = $post['publish_end']; // 公開終了日
	$ary['status'] = $post['cms_status']; // ステータス
	$ary['update_datetime'] = 'NOW'; // 更新日時
	

	$ary['template_kind'] = $template_kind; // テンプレート種類
	$ary['inquiry'] = setInquiryDate($htmlStr); // お問合せ先
	

	return $ary;
}

function _set_data_nontpl($post, $filename, &$htmlStr) {
	$dn = cms_dirname($filename);
	$dn = ($dn == '') ? '' : $dn . '/';
	$dir_path = $post['cms_dir'] . $dn;
	$filename = basename($filename);
	$ary = array();
	$r = "";
	
	// 文字コードをUTF-8にする
	if (preg_match('/<meta [^>]*charset=shift_jis[^>]*>/i', $htmlStr)) {
		$htmlStr = SJIStoUTF8($htmlStr);
		$htmlStr = preg_replace('/(<meta [^>]*charset=)(shift_jis)([^>]*>)/i', '${1}utf-8${3}', $htmlStr);
	}
	
	// ページタイトル：$page_title
	$page_title = (preg_match('/<title>(.*?)<\/title>/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? $r[1][0] : '';
	$page_title = htmlEncode($page_title);
	
	$context = $htmlStr;
	$context = preg_replace('/(^[\r\n]*|[\r\n]*$)/', '', $context);
	$context = _formPath($context, $dir_path, TEMPLATE_KIND_NONE); // パスの整形
	// キーワード：$keywords
	$keywords = (preg_match('/<meta name="keywords" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? htmlEncode($r[1][0]) : '';
	// 説明文：$description
	$description = (preg_match('/<meta name="description" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? htmlEncode($r[1][0]) : '';
	// 要約文：$summary
	$summary = (preg_match('/<meta name="summary" content="([^"]*)"/si', $htmlStr, $r, PREG_OFFSET_CAPTURE)) ? htmlEncode($r[1][0]) : '';
	
	// ページ情報をセット
	$ary['cate_code'] = $post['cate_code']; // カテゴリ
	$ary['template_id'] = TEMPLATE_ID_NONE; // テンプレートID
	$ary['template_ver'] = 1; // テンプレートバージョン
	$ary['ancestor_path'] = ""; // パンくず用パス
	$ary['user_id'] = $post['cms_user_id']; // 作成者ID
	$ary['dir_path'] = $dir_path; // ディレクトリパス
	$ary['filename'] = $filename; // ファイル名
	$ary['file_path'] = $dir_path . $filename; // ファイルパス
	$ary['page_title'] = $page_title; // ページタイトル
	/*	$ary['header'] = "";					// 見出し
*/	$ary['context'] = $context; // FCKeditor領域
	$ary['keywords'] = $keywords; // （検索エンジン用）キーワード
	$ary['description'] = $description; // （検索エンジン用）説明文
	$ary['summary'] = $summary; // （リンク掲載用）要約文
	/*	$ary['inquiry_flg'] = "";			// 問い合わせ先表示フラグ
	$ary['inquiry_memo'] = "";			// 問合せ先メモ
	$ary['index_flg'] = FLAG_OFF;				// 自動生成ページフラグ
	$ary['contents_top_flg'] = $contents_top_flg;	// コンテンツトップフラグ*/
	$ary['publish_start'] = $post['publish_start']; // 公開開始日
	$ary['publish_end'] = $post['publish_end']; // 公開終了日
	$ary['status'] = $post['cms_status']; // ステータス
	$ary['update_datetime'] = 'NOW'; // 更新日時
	

	$ary['template_kind'] = TEMPLATE_KIND_NONE; // テンプレート種類
	

	return $ary;
}

function setInquiryDate($htmlStr) {
	global $objTool2;
	$inq_ary = array();
	// 問い合わせ先表示フラグ：$inquiry_flg（問い合わせ先を表示=1 / 非表示=0）
	$inquiry_str = getMidString($htmlStr, '<!-- InstanceBeginEditable name="inquiry" -->', '<!-- InstanceEndEditable -->');
	for($i = 1; $i < 10; $i++) {
		$inquiry_detail = htmlEncode(getMidString($inquiry_str, '<!-- BeginInq' . $i . ' -->', '<!-- EndInq' . $i . ' -->'));
		if ($inquiry_detail == FALSE) continue;
		$inq_detail_ary = array();
		$inq_detail_ary['inquiry_no'] = $i;
		$name1 = getMidString($inquiry_detail, '<!-- BeginInqName1 -->', '<!-- EndInqName1 -->');
		$name2 = getMidString($inquiry_detail, '<!-- BeginInqName2 -->', '<!-- EndInqName2 -->');
		$name3 = getMidString($inquiry_detail, '<!-- BeginInqName3 -->', '<!-- EndInqName3 -->');
		if (!($name1 === FALSE && $name2 === FALSE && $name3 === FALSE)) {
			$sql = "SELECT dept_code FROM tbl_department WHERE dept_name ='" . $name1 . $name2 . $name3 . "'";
			$objTool2->execute($sql);
			if ($objTool2->getRowCount() > 0) {
				$objTool2->fetchrow = 0;
				$objTool2->fetch();
				$inq_detail_ary['dept_code'] = $objTool2->fld['dept_code'];
			}
		}
		$charge = getMidString($inquiry_detail, '<!-- BeginInqCharge -->', '<!-- EndInqCharge -->');
		if ($charge != FALSE) $inq_detail_ary['name'] = $charge;
		$tel2 = getMidString($inquiry_detail, '<!-- BeginInqTel2 -->', '<!-- EndInqTel2 -->');
		if ($tel2 != FALSE) $inq_detail_ary['anex_number'] = $tel2;
		$tel = getMidString($inquiry_detail, '<!-- BeginInqTel -->', '<!-- EndInqTel -->');
		if ($tel != FALSE) $inq_detail_ary['drxt_number'] = $tel;
		$fax = getMidString($inquiry_detail, '<!-- BeginInqFax -->', '<!-- EndInqFax -->');
		if ($fax != FALSE) $inq_detail_ary['fax'] = $fax;
		$email = getMidString($inquiry_detail, '<!-- BeginInqEmail -->', '<!-- EndInqEmail -->');
		if ($email != FALSE) $inq_detail_ary['email'] = $email;
		$inq_ary[$i] = $inq_detail_ary;
	}
	
	return $inq_ary;
}

function _insert_data($mode, $ary1, $objPage, $objLinks, $objImages, $login, &$errmsg, $objInquiry, $objHandler, $objTool3, $objLibrary) {
	global $objKanko;
	global $objMap;
	global $objOutputHandler;
	
	$errmsg = '';
	if (isset($ary1['pub_status'])) {
		$pub_status = $ary1['pub_status'];
		unset($ary1['pub_status']);
	}
	if ($mode == 'ins') {
		if ($ary1['ancestor_path'] != '') {
			// 親ページのページIDを取得
			$parent_path = preg_replace('/(^.*,)?([^,]*)/', '${2}', $ary1['ancestor_path']);
			if ($objPage->selectFromPath($parent_path, 1, 'page_id')) {
				$ary1['parent_id'] = $objPage->fld['page_id'];
			}
		}
		$parent_id = (isset($ary1['parent_id'])) ? $ary1['parent_id'] : NULL;
		$ary1['menu_generation_order'] = $objPage->getNextMenuGenerationOrder($parent_id);
		// 公開ページ情報の登録（INSERT INTO tbl_publish_page）
		if ($objPage->insert($ary1, 1) === FALSE) {
			$errmsg = '公開ページ情報の登録に失敗しました。';
			return FALSE;
		}
		// 編集ページ情報の登録（INSERT INTO tbl_work_page SELECT FROM tbl_publish_page）
		if ($objPage->insertWorkFromPublish($ary1['page_id'], $login) === FALSE) {
			$errmsg = '編集ページ情報の登録に失敗しました。';
			return FALSE;
		}
		// お問い合わせ登録
		if (isset($ary1["inquiry_id"])) {
			foreach ($ary1["inquiry"] as $inquiry_ary) {
				if ($objInquiry->insert($inquiry_ary) === FALSE) {
					$errmsg = '公開ページ情報のお問い合わせの登録に失敗しました。';
					return FALSE;
				}
			}
			if ($objInquiry->insertWorkFromPublish($ary1["inquiry_id"]) === FALSE) {
				$errmsg = '編集ページ情報のお問い合わせの登録に失敗しました。';
				return FALSE;
			}
		}
		// デフォルトライブラリを設定
		// 
		$libHtmlStr = $objTool3->getTemplateContext($ary1['template_id'], $ary1['template_ver']);
		$libAry = array();
		// ライブラリ領域を検索
		while (getLibraryArea($libAry, $libHtmlStr, 0)) {
			// ライブラリ情報を登録
			if (isset($libAry["id"]) && $libAry["id"] != "" && $objLibrary->selectFromID($libAry["id"]) !== FALSE) {
				// 登録情報の作成
				$db_ary['page_id'] = $ary1['page_id'];
				$db_ary['area'] = $libAry["area"];
				$db_ary['library_id'] = $libAry["id"];
				$db_ary['library_ver'] = $objLibrary->fld['library_ver'];
				// DBに登録
				if ($objHandler->insertLibrary($db_ary, WORK_TABLE) === FALSE) {
					$errmsg = 'ライブラリ情報の登録に失敗しました。';
					return FALSE;
				}
			}
			// 登録したエリア情報を対象から除外
			$libHtmlStr = str_replace($libAry["match"], "", $libHtmlStr);
		}
	}
	elseif ($mode == 'upd') {
		if ($ary1['ancestor_path'] != '') {
			// 親ページのページIDを取得
			$parent_path = preg_replace('/(^.*,)?([^,]*)/', '${2}', $ary1['ancestor_path']);
			if ($objPage->selectFromPath($parent_path, 1, 'page_id')) {
				$parent_id = $objPage->fld['page_id'];
			}
		}
		else {
			$parent_id = '';
		}
		// 編集ページ情報の登録（INSERT INTO tbl_work_page SELECT FROM tbl_publish_page）
		if (isset($pub_status) && $pub_status == 402) {
			if ($objPage->insertWorkFromPublish($ary1['page_id'], $login) === FALSE) {
				$errmsg = '編集ページ情報の登録に失敗しました。';
				return FALSE;
			}
		}
		// 編集ページ情報の更新（UPDATE tbl_work_page）
		$ary2 = array();
		$ary2 = $ary1;
		unset($ary2['ancestor_path']);
		unset($ary2['dir_path']);
		unset($ary2['filename']);
		//非公開中の場合があるため、強制的に公開中にする
		$ary2['close_flg'] = 0;
		if (isset($parent_id)) $ary2['parent_id'] = $parent_id;
		if ($objPage->update($ary2, 2) === FALSE) {
			$errmsg = '編集ページ情報の更新に失敗しました。';
			return FALSE;
		}
		// 公開ページの更新：ステータス更新（UPDATE tbl_publish_page）
		$ary3 = array(
				'page_id' => $ary1['page_id'], 
				'status' => $ary1['status']
		);
		if ($pub_status == STATUS_PUBLISH) $ary3['bak_status'] = STATUS_PUBLISH;
		if ($objPage->update($ary3, 1) === FALSE) {
			$errmsg = '公開ページ情報の更新に失敗しました。';
			return FALSE;
		}
		// お問い合わせ更新
		if (isset($ary1["inquiry_id"])) {
			$objInquiry->deleteFromID($ary1["inquiry_id"], PUBLISH_TABLE);
			$objInquiry->deleteFromID($ary1["inquiry_id"], WORK_TABLE);
			foreach ($ary1["inquiry"] as $inquiry_ary) {
				if ($objInquiry->insert($inquiry_ary) === FALSE) {
					$errmsg = '公開ページ情報のお問い合わせの登録に失敗しました。';
					return FALSE;
				}
			}
			if ($objInquiry->insertWorkFromPublish($ary1["inquiry_id"]) === FALSE) {
				$errmsg = '編集ページ情報のお問い合わせの登録に失敗しました。';
				return FALSE;
			}
		}
		// 公開中ページの取り込みの場合は情報をコピー
		if ($pub_status == STATUS_PUBLISH) {
			// ライブラリ情報のコピー
			if ($objHandler->insertLibraryWfromP($ary1['page_id']) === FALSE) {
				$errmsg = 'ライブラリ情報の登録に失敗しました。';
				return FALSE;
			}
			// 自動リンク依頼のコピー
			if ($objHandler->insertAutoLinkWfromP($ary1['page_id']) === FALSE) {
				$errmsg = '自動リンク依頼の登録に失敗しました。';
				return FALSE;
			}
			// 定型情報のコピー
			if ($objKanko->insertWorkFromPublish($ary1['page_id']) === FALSE) {
				$errmsg = '定型情報の登録に失敗しました。';
				return FALSE;
			}
			// 地図情報のコピー
			if (ENABLE_OPTION_GOOGLEMAP) {
				if ($objMap->insertWorkFromPublish($ary1['page_id']) === FALSE) {
					$errmsg = '地図情報の登録に失敗しました。';
					return FALSE;
				}
			}
			// 外部出力のコピー
			if (ENABLE_OPTION_OUTPUT) {
				if ($objOutputHandler->insertWorkFromPublish($ary1['page_id']) === FALSE) {
					$errmsg = '外部出力の登録に失敗しました。';
					return FALSE;
				}
			}
		}
	}
	
	// 自動生成領域の有無をチェックするために、ページ生成の要素となる文字列を取得
	$total_str = $ary1['context'];
	$total_str .= $objTool3->getTemplateContext($ary1['template_id'], $ary1['template_ver']);
	$lib_ary = array();
	// ライブラリ領域を検索
	while (getLibraryArea($lib_ary, $total_str, 0)) {
		$library_context = '';
		// 取得したライブラリ領域のエリア名よりページで使用されているライブラリ情報を取得
		if ($objLibrary->selectFromPageArea($ary1['page_id'], $lib_ary['area'], WORK_TABLE)) {
			$library_context = $objLibrary->fld['context'];
		}
		$total_str = str_replace($lib_ary['match'], $library_context, $total_str);
	}
	
	// ページで使用する自動リンク情報を登録
	if (entryAutolinkPage($total_str, $ary1['page_id']) === FALSE) {
		$errmsg = 'ページで使用する自動リンク依頼の登録に失敗しました。';
		return FALSE;
	}
	// ページで使用するローカルナビ情報を登録
	if (entry_lnavi_page($total_str, $ary1['page_id']) === FALSE) {
		$errmsg = 'ページで使用するローカルナビの登録に失敗しました。';
		return FALSE;
	}
	// 広告使用ページ情報を登録
	if (entryAdvertPage($total_str, $ary1['page_id']) === FALSE) {
		$errmsg = '広告使用ページ情報の登録に失敗しました。';
		return FALSE;
	}
	// サイトマップ使用ページ情報を登録
	if (entry_sitemap_page($total_str, $ary1['page_id']) === FALSE) {
		$errmsg = 'サイトマップ使用ページ情報の登録に失敗しました。';
		return FALSE;
	}
	// 大規模災害用分類ページ情報を登録
	if (entryDisasterListTop($total_str, $ary1['page_id']) === FALSE) {
		$errmsg = '大規模災害用分類ページ情報の登録に失敗しました。';
		return FALSE;
	}
	
	// リンク情報、画像情報取得用コンテキスト：自動生成領域は除外する
	$chkContext = repMidStr(AUTOLINK_BEGIN, AUTOLINK_END, '', $ary1['context']);
	
	// リンク情報の削除（DELETE FROM tbl_work_links）
	if ($objLinks->deleteFromPageID($ary1['page_id'], 2) === FALSE) {
		$errmsg = 'リンク情報の削除に失敗しました。';
		return FALSE;
	}
	// リンク情報の登録
	$p = 0;
	$no = 0;
	while (1) {
		$r = dac_insertLink($chkContext, $objLinks, $ary1['page_id'], $no, $p);
		if ($r == -9) break;
		if ($r == -8) {
			$errmsg = 'リンク情報の登録に失敗しました。';
			return FALSE;
		}
	}
	$nontpl_no = $no;
	
	// 画像情報の削除（DELETE FROM tbl_work_images）
	if ($objImages->deleteFromPageID($ary1['page_id'], 2) === FALSE) {
		$errmsg = '画像情報の削除に失敗しました。';
		return FALSE;
	}
	// 画像情報の登録
	$p = 0;
	$no = 0;
	while (1) {
		$r = dac_insertImage($chkContext, $objImages, $ary1['page_id'], $no, $p);
		if ($r == -9) break;
		if ($r == -8) {
			$errmsg = '画像情報の登録に失敗しました。';
			return FALSE;
		}
	}
	
	if ($ary1['template_kind'] == TEMPLATE_KIND_NONE) {
		dac_insertLink_nontpl($chkContext, $ary1['page_id'], $nontpl_no);
	}
	
	// ログ登録(一時保存・編集完了)
	$log_flg = false;
	if ($ary1['status'] == STATUS_SAVE) {
		$log_flg = WRITE_INFO_LOG_PAGEEDIT_TMPSAVE;
		$log_status = LOG_STATUS_PAGEEDIT_TMPSAVE;
	}
	else if ($ary1['status'] == STATUS_PUBLISH_WAIT) {
		$log_flg = WRITE_INFO_LOG_PAGEEDIT_END;
		$log_status = LOG_STATUS_PAGEEDIT_END;
	}
	if ($log_flg) {
		if (set_log_data($log_status, $ary1) === FALSE) {
			$errmsg = 'ログ情報の登録に失敗しました。';
			return FALSE;
		}
	}
	
	return TRUE;
}

?>