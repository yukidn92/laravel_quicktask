<?php
/*
 *
 */
/** 外部ページの取り込み **/
require ("../.htsetting");
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$objDac = new dac($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_category.inc');
$objCate = new tbl_category($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac_tools.inc');
$objTool = new dac_tools($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);

// ウェブマスターと外部ファイル実行権限組織以外はアクセスできない
if ($objLogin->get('class') != USER_CLASS_WEBMASTER && $objLogin->get('isOuter') == FALSE) {
	user_error('不正アクセスです。');
}

//print_dp($_POST);
if (isset($_SESSION['post'])) unset($_SESSION['post']);
$_SESSION['post'] = $_POST;
gd_errorhandler_ini_set("html0", RPW . '/admin/special/file/outerimport/outerimport.php?bak=1');

// （php.ini）post_max_size をオーバーすると$_POSTの値が飛んでこない
if (count($_POST) == 0 || count($_FILES) == 0) {
	user_error('取り込みファイルのファイルサイズが大きすぎる可能性があります。<br>いくつかに分けて実行してください。');
}
// 取り込みファイルが指定されていなければエラー
if (!isset($_FILES['FrmZipnm']) || $_FILES['FrmZipnm']['name'] == '') {
	user_error('取り込みファイルを指定してください。');
}
// （php.ini）upload_max_filesize をオーバーすると$_FILES['FrmZipnm']['size']はゼロになる
// ファイルサイズがゼロならエラー
if ($_FILES['FrmZipnm']['size'] <= 0) {
	user_error('取り込みファイルの指定が正しくないか、取り込みファイルのファイルサイズが大きすぎる可能性があります。');
}
// 取り込みファイルはzip圧縮のファイルでなければエラー
if (!preg_match('/\.zip$/i', $_FILES['FrmZipnm']['name'])) {
	user_error('取り込みファイルはzip形式の圧縮ファイルを指定してください。');
}

// アップロード先が入力されていなければエラー
if (!isset($_POST['cms_dir'])) {
	user_error('アップロード先を入力してください。');
}
// ディレクトリパスの整形
$cms_dir = $_POST['cms_dir'];
$cms_dir = preg_replace('/(^\/?|\/?$)/', '/', $cms_dir);
$cms_dir = preg_replace('/\/+/', '/', $cms_dir);
// 対象ディレクトリが存在しなければエラー
if (!@file_exists(DOCUMENT_ROOT . RPW . $cms_dir)) {
	user_error('指定したアップロード先は存在しません。');
}
$_SESSION['post']['cms_dir'] = $cms_dir;

//チェック用配列を作成する
$outerimport_check_status_ary = array(
	'template_check' => FLAG_ON,	//テンプレートチェック
	'dependence_file' => FLAG_ON,	//依存ファイルチェック
);

//テンプレートなしの場合、チェックしない項目がある
if (isset($_POST['cms_non_template']) && $_POST['cms_non_template'][0] == FLAG_ON) {
	$outerimport_check_status_ary['template_check'] = FLAG_OFF;
	$outerimport_check_status_ary['dependence_file'] = FLAG_OFF;
}

//テンプレートチェック
if ($outerimport_check_status_ary['template_check'] == FLAG_ON) {
	// テンプレートが選択されていなければエラー
	if (!isset($_POST['cms_template_id']) || $_POST['cms_template_id'] == '') {
		user_error('テンプレートを選択してください。');
	}
	// 選択されたテンプレートが存在しなければエラー
	$sql = "SELECT * FROM tbl_template WHERE template_id = " . $_POST['cms_template_id'] . " order by template_ver desc";
	$objDac->execute($sql);
	if (!$objDac->fetch()) {
		user_error('指定したテンプレートは登録されていません。');
	}
	$template_fld = $objDac->fld;
	
	// テンプレート種類が存在しなければエラー
	if (!isset($_POST['cms_template_kind']) || $_POST['cms_template_kind'] == '') {
		user_error('テンプレート種類が確認できません。');
	}
	$template_kind = $_POST['cms_template_kind'];
}
else {
	$template_fld['name'] = '使用しない';
}

// 分類が選択されていなければエラー
if (!isset($_POST['cms_cate1']) || $_POST['cms_cate1'] == '') {
	user_error('分類を選択してください。');
}
$cate_code = $_POST['cms_cate1']; // 第一分類（必須）しか選択されていなければ$_POST['cms_cate1']が分類コードになる
if (isset($_POST['cms_cate2']) && $_POST['cms_cate2']) $cate_code = $_POST['cms_cate2']; // 第二分類が選択されていれば$_POST['cms_cate2']が分類コードになる
if (isset($_POST['cms_cate2']) && $_POST['cms_cate3']) $cate_code = $_POST['cms_cate3']; // 第三分類が選択されていれば$_POST['cms_cate3']が分類コードになる
if (isset($_POST['cms_cate2']) && $_POST['cms_cate4']) $cate_code = $_POST['cms_cate4']; // 第四分類が選択されていれば$_POST['cms_cate4']が分類コードになる
// 選択された分類が存在しなければエラー
$cateInfo = $objCate->getCategoryInfo($cate_code);
if ($cateInfo['name'] == '') {
	user_error('指定した分類は登録されていません。');
}
$_SESSION['post']['cate_code'] = $cate_code;

// 公開期間が指定されていなければエラー
if (!checkdate($_POST['cms_pdsm'], $_POST['cms_pdsd'], $_POST['cms_pdsy'])) {
	user_error('公開開始日が正しく入力されていません。');
}
if (!checkdate($_POST['cms_pdem'], $_POST['cms_pded'], $_POST['cms_pdey'])) {
	user_error('公開終了日が正しく入力されていません。');
}
$publish_start = $_POST['cms_pdsy'] . '-' . $_POST['cms_pdsm'] . '-' . $_POST['cms_pdsd'] . ' ' . $_POST['cms_pdsh'] . ':00:00';
$publish_end = $_POST['cms_pdey'] . '-' . $_POST['cms_pdem'] . '-' . $_POST['cms_pded'] . ' ' . $_POST['cms_pdeh'] . ':00:00';
$_SESSION['post']['publish_start'] = $publish_start;
$_SESSION['post']['publish_end'] = $publish_end;

// ステータスが指定されていなければエラー
if (!isset($_POST['cms_status'])) {
	user_error('取り込み後のステータスが指定されていません。');
}
if ($_POST['cms_status'] == 201) {
	$status_str = '一時保存';
}
elseif ($_POST['cms_status'] == 401) {
	$status_str = '公開待ち';
	// ステータスが不正な値ならエラー
}
else {
	user_error('取り込み後のステータスが正しく指定されていません。');
}

// ページ作成者の所属が選択されていなければエラー
if (!isset($_POST['cms_target3']) || $_POST['cms_target3'] == '') {
	user_error('ページ作成者の所属を選択してください。');
}
// 選択した所属が存在しなければエラー
$sql = "SELECT * FROM tbl_department" . " WHERE level = 3 AND dept_code = '" . $_POST['cms_target3'] . "'";
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('指定したページ作成者の所属は登録されていません。');
}
$dept_fld = $objDac->fld;

// ページ作成者が選択されていなければエラー
if (!isset($_POST['cms_user_id']) || $_POST['cms_user_id'] == '') {
	user_error('ページ作成者を選択してください。');
}
// 選択した作成者が存在しなければエラー
$sql = "SELECT * FROM tbl_user" . " WHERE user_id = " . $_POST['cms_user_id'] . " AND class = " . USER_CLASS_WRITER;
$objDac->execute($sql);
if (!$objDac->fetch()) {
	user_error('指定したページ作成者は登録されていません。');
}
$user_fld = $objDac->fld;

// 作成者にディレクトリへの編集権限がなければエラー
if (!_isAbledDir($cms_dir)) {
	user_error('指定したページ作成者には対象フォルダへの編集権限がありません。');
}
if ($outerimport_check_status_ary['template_check'] == FLAG_ON) {
	// 作成者にテンプレートの使用権限がなければエラー
	$sql = "SELECT * FROM tbl_handler" . " WHERE class = " . HANDLER_CLASS_TEMPLATE . " AND item1 = '" . $_POST['cms_target3'] . "'" . " AND item2 = '" . $_POST['cms_template_id'] . "'";
	$objDac->execute($sql);
	if (!$objDac->fetch()) {
		user_error('指定したページ作成者にはテンプレートへの編集権限がありません。');
	}
}

// 取り込みファイルの展開ディレクトリ
$tmpUpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/';
chmodAll($tmpUpDir, 0777);
if (@file_exists($tmpUpDir)) removeDir($tmpUpDir);
if (!@mkdir($tmpUpDir, 0777)) {
	user_error('取り込みファイルの展開フォルダ作成に失敗しました。');
}
chmod($tmpUpDir, 0777);

// 圧縮ファイルを解凍する
if (defined("SET_UNZIP_EXE")) {
	exec(SET_UNZIP_EXE . ' ' . $_FILES['FrmZipnm']['tmp_name'] . ' ' . $tmpUpDir);
}
else {
	exec('unzip ' . $_FILES['FrmZipnm']['tmp_name'] . ' -d ' . $tmpUpDir);
}

// 取り込みファイルの確認
$aryFilenameErr = array();
$aryFiles = array();
_chk_files('', $cms_dir, $aryFilenameErr, $aryFiles);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>外部ファイル取り込み</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/outerimport.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/outerimport_conf.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'file';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-outerimport">
<div><img
	src="<?=RPW?>/admin/special/file/outerimport/images/bar_outerimport.jpg"
	alt="外部ファイル取り込み" width="920" height="30"></div>
<div class="cms8341-area-corner">
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_topbg.jpg);height:31px;"><img
			src="<?=RPW?>/admin/special/file/outerimport/images/bar_importconf.jpg"
			alt="取込条件" width="200" height="20" style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="display: block">
<table width="100%" border="0" cellpadding="7" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="150" align="left" valign="top" scope="row">取り込みファイル</th>
		<td><?=htmlDisplay($_POST['cms_filename'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" scope="row">アップロード先</th>
		<td><?=HTTP_ROOT . RPW?><?=$_POST['cms_dir']?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">テンプレート</th>
		<td><?=htmlDisplay($template_fld['name'])?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">分類</th>
		<td><?=$cateInfo['name']?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">公開期間</th>
		<td><?=$_POST['cms_pdsy']?>年<?=$_POST['cms_pdsm']?>月<?=$_POST['cms_pdsd']?>日<?=$_POST['cms_pdsh']?>時から
&nbsp;<?=$_POST['cms_pdey']?>年<?=$_POST['cms_pdem']?>月<?=$_POST['cms_pded']?>日<?=$_POST['cms_pdeh']?>時まで</td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">取り込み後のステータス</th>
		<td><?=$status_str?></td>
	</tr>
	<tr>
		<th align="left" valign="top" nowrap scope="row">ページ作成者</th>
		<td><?=htmlDisplay($dept_fld['dept_name'] . ' ' . $user_fld['name'])?></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle" style="background-image:url(<?=RPW?>/admin/page/publiclist/images/bar_bottombg.jpg);height:32px;">
		<a href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/btn_close_mini.jpg" alt="閉じる"
			width="80" height="15" border="0" style="margin-right: 10px;"
			id="cms-searchSwitch"></a></td>
	</tr>
</table>
</div>
<form id="cms_fImport" name="cms_fImport" class="cms8341-form"
	method="post" action="outerimport_exec.php">
<p><a href="javascript:" onClick="return cxCheckAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allselect.jpg" alt="全て選択する"
	width="120" height="20" border="0"></a> <a href="javascript:"
	onClick="return cxReleaseAll();"><img
	src="<?=RPW?>/admin/images/upload/btn_allcansel.jpg" alt="全て解除する"
	width="120" height="20" hspace="20" border="0"></a></p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">選択</th>
		<th width="80" align="center" valign="middle"
			style="font-weight: normal" scope="col">状態</th>
		<th align="center" valign="middle" style="font-weight: normal"
			scope="col">取り込みファイル</th>
	</tr>
<?php
foreach ($aryFiles as $ary) {
	$icon_img = '&nbsp;';
	if (!$ary['error']) {
		if (!$ary['pagefile'] && $ary['overwrite']) $icon_img = '[上書き]';
		elseif ($ary['mode'] == 'upd') $icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_edit.jpg" alt="更新" width="70" height="25">';
		elseif ($ary['mode'] == 'ins') $icon_img = '<img src="' . RPW . '/admin/page/workflow/images/icon_new.jpg" alt="新規" width="70" height="25">';
	}
	$chkbox_name = ($ary['pagefile']) ? 'cms_file_path' : 'cms_item_path';
	print '<tr>' . "\n";
	print '<td align="center" valign="middle">';
	if ($ary['error']) print '&nbsp;';
	else print '<input type="checkbox" name="' . $chkbox_name . '[]" value="' . $ary['file_path'] . '">';
	print '</td>' . "\n";
	print '<td align="center" valign="middle">' . $icon_img . '</td>' . "\n";
	print '<td align="left" valign="top" nowrap><p>' . htmlDisplay($ary['file_path']) . "\n";
	if ($ary['page_title'] != '') print '<br><strong>' . htmlDisplay($ary['page_title']) . '</strong>' . "\n";
	if ($ary['message'] != '') print '<br><span class="cms8341-error">' . $ary['message'] . '</span>' . "\n";
	print '</p></td>' . "\n";
	print '</tr>' . "\n";
}
?>
</table>
<?php
if (count($aryFilenameErr) > 0) {
	print '<div class="cms8341-errorDiv">' . "\n";
	foreach ($aryFilenameErr as $dir => $cnt) {
		print 'アップロードできないファイル名のものが&nbsp;' . $dir . '&nbsp;フォルダ内に ' . $cnt . ' ファイルあります。<br>' . "\n";
	}
	print '<p class="cms8341-error">ファイル名に使用できるのは半角英数字と - _ . ~ です。</p>' . "\n";
	print '</div>' . "\n";
}
?>
<p align="center"><img src="<?=RPW?>/admin/images/icon/icon-flow.jpg"
	alt="" width="36" height="26"></p>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_start.jpg" alt="取り込み開始" width="150"
	height="20" border="0" style="margin-right: 10px;"></a> <a
	href="./outerimport.php?bak=1"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px;"></a></p>
</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***処理中プロパティレイヤー ここから********************************-->
<div id="cms8341-progress" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0" style="background-image:url(<?=RPW?>/admin/images/layer/titlebar_bg.jpg);height:30px;">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_progress.jpg" alt="処理中"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 180px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-progressmsg">メッセージ</div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***処理中プロパティレイヤー ここまで********************************-->
</body>
</html>
<?php
function _chk_files($in_currDir, $in_upDir, &$in_fnErr, &$in_aryFiles) {
	global $objDac;
	global $objLogin;
	global $objTool;
	global $objPage;
	global $outerimport_check_status_ary;
	$tmpDir = DOCUMENT_ROOT . DIR_PATH_IMPORT . $objLogin->get('user_id') . '/' . $in_currDir;
	if (($dh = @opendir($tmpDir)) == FALSE) return false;
	// 既存ディレクトリの場合、権限チェック
	if (file_exists(DOCUMENT_ROOT . RPW . $in_upDir . $in_currDir) && !_isAbledDir($in_upDir . $in_currDir)) {
		$in_aryFiles[] = array(
				'file_path' => $in_upDir . $in_currDir, 
				'page_title' => '', 
				'pagefile' => false, 
				'error' => true, 
				'mode' => '', 
				'overwrite' => false, 
				'message' => 'フォルダに権限がないためファイルをアップロードできません。'
		);
	}
	else {
		// ファイルを検出
		while (($entry = @readdir($dh)) !== false) {
			if ($entry == '.' || $entry == '..') continue;
			@chmod($tmpDir . $entry, 0777);
			if (!is_file($tmpDir . $entry)) continue;
			// ファイル名のチェック（半角英数字、-、_、.、~ 以外は無効）
			if (preg_match('/[^\w\-_\.~]/i', $entry)) {
				$in_fnErr[$in_currDir] = (isset($in_fnErr[$in_currDir])) ? $in_fnErr[$in_currDir] + 1 : 1;
				continue;
			}
			$sExtension = getExtension($entry);
			// ファイル情報を格納
			$aryF = array(
					'file_path' => $in_currDir . $entry, 
					'page_title' => '', 
					'pagefile' => false, 
					'error' => false, 
					'mode' => '', 
					'overwrite' => false, 
					'message' => ''
			);
			
			// フォルダの半角数字チェック
			if (preg_match('/[^\w\-_~\/]/i', $in_currDir)) {
				$in_aryFiles[] = _set_error($aryF, 'フォルダ名に使用できるのは半角英数字と - _ ~ です。');
				continue;
			}
			if (strtolower($in_currDir) != $in_currDir) {
				$in_aryFiles[] = _set_error($aryF, 'フォルダ名に大文字があります。小文字に変換してください。');
				continue;
			}
			
			if (strpos($entry, '.') != strrpos($entry, '.')) {
				$in_aryFiles[] = _set_error($aryF, 'ファイル名に「.」が二つ以上ついているファイルは取り込めません。');
				continue;
			}
			if (preg_match('/^\.html?$/i', $entry)) {
				$in_aryFiles[] = _set_error($aryF, 'このファイルは取り込めません。');
				continue;
			}
			
			if (filesize($tmpDir . $entry) == 0) {
				$in_aryFiles[] = _set_error($aryF, 'ファイルサイズが0バイトのファイルは取り込めません。');
				continue;
			}
			// 既存チェック
			if (file_exists(DOCUMENT_ROOT . RPW . $in_upDir . $in_currDir . $entry)) $aryF['overwrite'] = true;
			
			// HTMLファイル
			if ($sExtension == 'html') {
				
				if (strlen(LIMIT_DIR_STRUCTURE) != 0 && count(explode("/", preg_replace("/^\//i", "", $in_upDir) . $in_currDir)) > LIMIT_DIR_STRUCTURE) {
					$in_aryFiles[] = _set_error($aryF, 'フォルダ階層に制限があるため、ファイルを取り込めません。');
					continue;
				}
				// フォルダの作成は行えない
				if ($objLogin->get('class') != USER_CLASS_WEBMASTER && LIMIT_DIR_CREATE && !is_dir(DOCUMENT_ROOT . RPW . $in_upDir . $in_currDir)) {
					$in_aryFiles[] = _set_error($aryF, 'フォルダ作成に制限があるため、ファイルを取り込めません。');
					continue;
				}
				
				$aryF['pagefile'] = true;
				
				$fp = fopen($tmpDir . $entry, "r");
				$htmlStr = fread($fp, filesize($tmpDir . $entry));
				fclose($fp);
				
				// 文字コードをUTF-8にする＋機種依存文字チェック
				if (preg_match('/<meta [^>]*charset=shift_jis[^>]*>/i', $htmlStr)) {
					//					$chk = checkMachineCode_sjis($htmlStr);
					$htmlStr = SJIStoUTF8($htmlStr);
					$htmlStr = preg_replace('/(<meta [^>]*charset=)(shift_jis)([^>]*>)/i', '${1}utf-8${3}', $htmlStr);
				}
				else {
					//					$chk = checkMachineCode($htmlStr);
				}
				// 機種依存文字を含んでいたらエラー
				/*				if (!$chk) {
					$in_aryFiles[] = _set_error($aryF, '機種依存文字を含んでいます。');
					continue;
				}*/
				
				// <html タグがなければ取り込めない
				if (!stristr($htmlStr, '<html')) {
					$in_aryFiles[] = _set_error($aryF, 'HTMLファイルの記述が不正です。');
					continue;
				}
				
				// ページタイトル
				//				$page_title = getMidString($htmlStr, '<title>', '</title>');
				// ページタイトルがなければエラー
				if (!preg_match('/<title>(.*?)<\/title>/si', $htmlStr, $r, PREG_OFFSET_CAPTURE) || $r[1][0] == '') {
					$in_aryFiles[] = _set_error($aryF, 'タイトルが記述されていません。');
					continue;
				}
				$aryF['page_title'] = htmlEncode($r[1][0]);
				
				$page_id = "";
				// ページ情報の既存チェック⇒既存データあり：更新、なし：新規
				$sql = "SELECT page_id,template_id,work_class,status FROM tbl_publish_page WHERE file_path = '" . $in_upDir . $in_currDir . $entry . "'";
				$objDac->execute($sql);
				if ($objDac->fetch()) {
					$page_id = $objDac->fld['page_id'];
					$aryF['mode'] = 'upd';
					// 既存データが公開待ちか公開済みじゃなければ更新できない（更新の場合）
					if ($objDac->fld['status'] < 401) {
						$in_aryFiles[] = _set_error($aryF, '現在このページは更新できません。');
						continue;
					}
					//テンプレートIDをセット
					if (isset($_POST['cms_non_template']) && $_POST['cms_non_template'][0] == FLAG_ON) {
						$temp_id = TEMPLATE_ID_NONE;
					}
					else {
						$temp_id = $_POST['cms_template_id'];
					}
					//テンプレートが変更されている
					if ($objDac->fld['template_id'] != $temp_id) {
						//テンプレート選択レイヤ以外のテンプレート種類への変更ができない。
						$temp_fld = $objTool->selectTemplate($objDac->fld['template_id']);
						if (!in_array($temp_fld['template_kind'], array(
								TEMPLATE_KIND_FREE, 
								TEMPLATE_KIND_MOBILE
						))) {
							$in_aryFiles[] = _set_error($aryF, 'フリーテンプレート以外のページのテンプレートは変更できません。');
							continue;
						}
						//テンプレートなしへのテンプレート変更はできない。
						if ($temp_id === TEMPLATE_ID_NONE) {
							$in_aryFiles[] = _set_error($aryF, 'フリーテンプレート以外のページのテンプレートは変更できません。');
							continue;
						}
					}
					// データはないけれどファイルが存在する場合、更新してはいけない可能性がある。
				}
				elseif ($aryF['overwrite']) {
					$in_aryFiles[] = _set_error($aryF, 'アップロード先に同名のHTMLファイルが存在しています。');
					continue;
				}
				else {
					$aryF['mode'] = 'ins';
				}
				
				// パンくずのチェック
				$pankuzu_str = getMidString($htmlStr, '<!-- InstanceBeginEditable name="pankuzu" -->', '<!-- InstanceEndEditable -->');
				if ($pankuzu_str != '') {
					$ancestor_path = "";
					$parent_path = "";
					$pankuzu_err = FLAG_OFF;
					$pankuzu_str = _formPath($pankuzu_str, $in_upDir . $in_currDir, $_POST['cms_template_kind']); // パスの整形
					preg_match_all('/<a href="([^"]+)">/i', $pankuzu_str, $ret);
					foreach ($ret[1] as $key => $ansPath) {
						if (substr($ansPath, -1) == "/") $ret[1][$key] = $ansPath . "index.html";
						$parent_path = $ret[1][$key];
						// 存在しなないパスを指定していたらエラー
						if ($objPage->selectFromPath($parent_path, PUBLISH_TABLE) === FALSE) {
							$pankuzu_err = FLAG_ON;
							break;
						}
					}
					// エラー
					if ($pankuzu_err == FLAG_ON) {
						$in_aryFiles[] = _set_error($aryF, 'パンくずにCMS上で存在しないパスが指定されています。');
						continue;
					}
					// パンくずを , でつなげる
					$ancestor_path = implode(',', $ret[1]);
					$ancestor_path = preg_replace("/(,)?" . reg_replace($parent_path) . "$/", "", $ancestor_path);
					$ancestorAry = explode(",", $ancestor_path);
					// 親ページの ancestor_path
					$parent_ancestor_path = $objPage->fld['ancestor_path'];
					$parent_ancestorAry = explode(",", $parent_ancestor_path);
					// パンくずの数が一致しない
					if (count($ancestorAry) != count($parent_ancestorAry)) {
						$pankuzu_err = FLAG_ON;
					}
					else {
						// パンくずの整合性のチェック
						for($i = 0; $i < count($parent_ancestorAry); $i++) {
							if ($ancestorAry[$i] != $parent_ancestorAry[$i]) {
								$pankuzu_err = FLAG_ON;
								break;
							}
						}
					}
					// エラー
					if ($pankuzu_err == FLAG_ON) {
						$in_aryFiles[] = _set_error($aryF, 'パンくずのパスの指定に誤りがあります。');
						continue;
					}
					else {
						// 親ページパスよりパンくず階層制限チェックを行う
						if (is_pankuzu_limit_over($parent_path)) {
							$in_aryFiles[] = _set_error($aryF, '取り込むページの階層がパンくず階層制限を超えるため取り込めません。');
							continue;
						}
						// 末端子ページ階層制限チェック
						if (isset($page_id) && $page_id != "" && $aryF['mode'] == 'upd') {
							if (is_pankuzu_limit_over($parent_path, $page_id)) {
								$err_child_msg = "";
								if (isset($_SESSION['pankuzu_check']) && count($_SESSION['pankuzu_check'])) {
									$child_page_id = reset($_SESSION['pankuzu_check']);
									if ($objPage->selectFromID($child_page_id)) {
										$err_child_msg .= '<br>' . '※階層制限を越える子ページ【' . 'ページタイトル：' . htmlDisplay($objPage->fld['page_title']) . '】';
									}
								}
								$in_aryFiles[] = _set_error($aryF, '取り込むページを親ページに含む子ページの階層がパンくず階層制限を超えるため取り込めません。' . $err_child_msg);
								continue;
							}
						}
					}
				}
				
				// イベントカレンダー単一日
				if (!EVENT_CAL_MULTI_FLAG) {
					if ($_POST['cms_template_kind'] == TEMPLATE_KIND_FIXED && $objTool->selectTemplateKankoType($_POST['cms_template_id']) == KANKO_TYPE_EVENT) {
						// 開催日時の取得
						$open_start = getMidString($htmlStr, '<!-- InstanceBeginEditable name="open_start" -->', '<!-- InstanceEndEditable -->');
						if ($open_start === FALSE) {
							$in_aryFiles[] = _set_error($aryF, '開催日時（開始）を記述してください。');
							continue;
						}
						$year = substr($open_start, 0, strpos($open_start, '年'));
						$month = getMidString($open_start, '年', '月');
						$day = getMidString($open_start, '月', '日');
						if ($year == "" || $month === FALSE || $month == "" || $day === FALSE || $day == "") {
							$in_aryFiles[] = _set_error($aryF, '開催日時（開始）は、XXXX年XX月XX日のフォーマットにしてください。例)2007年4月12日');
							continue;
						}
						$open_start = $year . "-" . $month . "-" . $day . " 0:00:00";
						$_SESSION['post']['open_start'] = $open_start;
						
						$open_end = getMidString($htmlStr, '<!-- InstanceBeginEditable name="open_end" -->', '<!-- InstanceEndEditable -->');
						if ($open_end === FALSE) {
							$_SESSION['post']['open_end'] = $open_start;
						}
						else {
							$year = substr($open_end, 0, strpos($open_end, '年'));
							$month = getMidString($open_end, '年', '月');
							$day = getMidString($open_end, '月', '日');
							if ($year == "" || $month === FALSE || $month == "" || $day === FALSE || $day == "") {
								$in_aryFiles[] = _set_error($aryF, '開催日時（終了）は、XXXX年XX月XX日のフォーマットにしてください。例)2007年4月12日');
								continue;
							}
							$open_end = $year . "-" . $month . "-" . $day . " 0:00:00";
							$_SESSION['post']['open_end'] = $open_end;
						}
					}
				}
				
				// お問合わせチェック
				$err_flg = FLAG_OFF;
				$inquiry_str = getMidString($htmlStr, '<!-- InstanceBeginEditable name="inquiry" -->', '<!-- InstanceEndEditable -->');
				if ($inquiry_str) {
					$memo = getMidString($inquiry_str, '<!-- BeginInqMemo -->', '<!-- EndInqMemo -->');
					for($i = 1; $i < 10; $i++) {
						$inquiry_detail = getMidString($inquiry_str, '<!-- BeginInq' . $i . ' -->', '<!-- EndInq' . $i . ' -->');
						if ($inquiry_detail == FALSE) continue;
						$name1 = getMidString($inquiry_detail, '<!-- BeginInqName1 -->', '<!-- EndInqName1 -->');
						$name2 = getMidString($inquiry_detail, '<!-- BeginInqName2 -->', '<!-- EndInqName2 -->');
						$name3 = getMidString($inquiry_detail, '<!-- BeginInqName3 -->', '<!-- EndInqName3 -->');
						if (!($name1 === FALSE && $name2 === FALSE && $name3 === FALSE)) {
							$sql = "SELECT dept_code FROM tbl_department WHERE dept_name ='" . $name1 . $name2 . $name3 . "'";
							$objDac->execute($sql);
							if ($objDac->getRowCount() == 0) {
								$in_aryFiles[] = _set_error($aryF, 'お問い合わせ' . $i . 'の所属' . $name1 . $name2 . $name3 . 'は存在しません。');
								$err_flg = FLAG_ON;
								break;
							}
						}
					}
					if ($err_flg == FLAG_ON) continue;
				}
			}
			// 画像やドキュメント
			else {
				$VISIBLE_EXTENSIONS_IMAGE = getDefineArray("VISIBLE_EXTENSIONS_IMAGE");
				//テンプレートなしの場合はチェックしない
				if ($outerimport_check_status_ary['dependence_file'] == FLAG_ON) {
					// 規定フォルダチェック
					if (in_array($sExtension, $VISIBLE_EXTENSIONS_IMAGE)) {
						if (!preg_match('/(' . reg_replace(FCK_IMAGES_FORDER . '/') . '|' . reg_replace(FCK_FILELINK_FORDER . '/') . '$)/', "/" . $in_currDir)) {
							$in_aryFiles[] = _set_error($aryF, '画像が規定のフォルダ【' . FCK_IMAGES_FORDER . 'または' . FCK_FILELINK_FORDER . '】に格納されていません。');
							continue;
						}
					}
					else {
						if (!preg_match('/(' . reg_replace(FCK_FILELINK_FORDER . '/') . '$)/', "/" . $in_currDir)) {
							$in_aryFiles[] = _set_error($aryF, 'ドキュメントファイルが規定のフォルダ【' . FCK_FILELINK_FORDER . '】に格納されていません。');
							continue;
						}
					}
				}
				// ファイルサイズチェック
				// リサイズ無効フォルダの場合はサイズチェックを行わない
				if (is_none_check_dir($in_upDir . $in_currDir) === FALSE) {
					$sSizeMax = (in_array($sExtension, $VISIBLE_EXTENSIONS_IMAGE)) ? FCK_UPLOAD_MAX_IMAGE : FCK_UPLOAD_MAX_FILE;
					$sSizeMax = $sSizeMax * 1024;
					if ($sSizeMax != false && filesize($tmpDir . $entry) > $sSizeMax) {
						$in_aryFiles[] = _set_error($aryF, 'ファイルサイズが大き過ぎます。');
						continue;
					}
				}
				// 階層制限
				if (strlen(LIMIT_DIR_STRUCTURE) != 0 && count(explode("/", preg_replace("/^\//i", "", $in_upDir) . $in_currDir)) > LIMIT_DIR_STRUCTURE + 1) {
					$in_aryFiles[] = _set_error($aryF, 'フォルダ階層に制限があるため、ファイルを取り込めません。');
					continue;
				}
				// ウェブマスター以外
				// フォルダの作成は行えない
				if ($objLogin->get('class') != USER_CLASS_WEBMASTER && LIMIT_DIR_CREATE && !is_dir(preg_replace("/(" . reg_replace(FCK_FILELINK_FORDER) . "|" . reg_replace(FCK_IMAGES_FORDER) . ")\/$/", "/", DOCUMENT_ROOT . RPW . $in_upDir . $in_currDir))) {
					$in_aryFiles[] = _set_error($aryF, 'フォルダ作成に制限があるため、ファイルを取り込めません。');
					continue;
				}
			}
			
			$in_aryFiles[] = $aryF;
		}
	}
	// ディレクトリを検出
	rewinddir($dh);
	while (($entry = @readdir($dh)) !== false) {
		if ($entry == '.' || $entry == '..') continue;
		if (!is_dir($tmpDir . $entry)) continue;
		_chk_files($in_currDir . $entry . '/', $in_upDir, $in_fnErr, $in_aryFiles);
	}
	closedir($dh);
	return;
}

function _isAbledDir($in_dir) {
	global $_POST;
	
	return (checkHandlerDirectory($_POST['cms_target3'], $in_dir) == TRUE ? TRUE : FALSE);
}

function _set_error($aryF, $msg) {
	$aryF['error'] = true;
	$aryF['message'] = $msg;
	return $aryF;
}

// パスを整形する
function _formPath($str = '', $current_dir = '', $template_kind) {
	$str = delHttpRoot($str);
	$str = delRootPath($str);
	$mobile_flg = ($template_kind == TEMPLATE_KIND_MOBILE) ? TRUE : FALSE;
	$str = setAbsolutePath($str, $current_dir, '', $mobile_flg);
	return $str;
}
?>