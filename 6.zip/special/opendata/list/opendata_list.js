/*
 *
 */
function cxSearch() {
	if (!($F('pdsy') == "" && $F('pdsm') == "" && $F('pdsd') == "")) {
		dc = cxDateCheckNew("pd", "ymd", 2, "掲載日");
		if (!disp_date_error(dc, "pdsd"))
			return false;
	}
	if (!($F('pdey') == "" && $F('pdem') == "" && $F('pded') == "")) {
		dc = cxDateCheckNew("pd", "ymd", 3, "掲載日");
		if (!disp_date_error(dc, "pded"))
			return false;
	}
	if ($F('pdsy') != "" && $F('pdsm') != "" && $F('pdsd') != ""
			&& $F('pdey') != "" && $F('pdem') != "" && $F('pded') != "") {
		dc = cxDateCheckNew("pd", "ymd", 1, "掲載日");
		if (!disp_date_error(dc, "pdsd"))
			return false;
	}
	if (!($F('ptsy') == "" && $F('ptsm') == "" && $F('ptsd') == "")) {
		dc = cxDateCheckNew("pt", "ymd", 2, "データ時点");
		if (!disp_date_error(dc, "ptsd"))
			return false;
	}
	if (!($F('ptey') == "" && $F('ptem') == "" && $F('pted') == "")) {
		dc = cxDateCheckNew("pt", "ymd", 3, "データ時点");
		if (!disp_date_error(dc, "pted"))
			return false;
	}
	if ($F('ptsy') != "" && $F('ptsm') != "" && $F('ptsd') != ""
			&& $F('ptey') != "" && $F('ptem') != "" && $F('pted') != "") {
		dc = cxDateCheckNew("pt", "ymd", 1, "データ時点");
		if (!disp_date_error(dc, "ptsd"))
			return false;
	}
	$('dispMode').value = "search";
	document.cms_fSearch.submit();
	return false;
}
function cxLastSearch() {
	$('dispMode').value = "last_condition";
	document.cms_fSearch.submit();
	return false;
}
//表示件数
function cxDispNum(max_val) {
	$('dispMode').value = "disp_num";
	document.cms_fSearch.submit();
	return false;
}
function cxCloseError() {
	cxLayer('cms8341-error', 0);
	cxComboVisible();
}
// page sending
function cxPageSet(p) {
	document.cms_fSearch.dispMode.value = "pageset";
	document.cms_fSearch.p.value = p;
	document.cms_fSearch.submit();
	return false;
}
var cate_id;
function cxChangeCate(level, id, code) {
	cate_id = id;
	var prm = 'level=' + level + '&code=' + code;
	cxAjaxCommand('cxGetCateCombo', prm, cxGetCateComboOK);
}
function cxGetCateComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Categories') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for ( var i = level; i <= 4; i++) {
		var cmb = $(cate_id + i);
		while (cmb.length > 1) {
			cmb.options[1] = null;
		}
	}
	var cmb = $(cate_id + level);
	for ( var i = 0; i < xmlDoc.childNodes.length; i++) {
		nodeL = xmlDoc.childNodes.item(i);
		cmb.length++;
		cmb.options[i + 1].text = nodeL.text;
		var val = nodeL.attributes.getNamedItem('value').value;
		cmb.options[i + 1].value = val;
	}
}
// 組織変更プルダウン処理
function cxChangeDept(lv, val) {
	//reset
	if (val == "") {
		var t = lv + 1;
		for ( var i = t; i <= 3; i++) {
			var obj = $('dept' + i);
			while (obj.length > 1) {
				obj.options[1] = null;
			}
			obj.options[0].text = "";
		}
	} else {
		//get data
		lv++;
		var prm = 'level=' + lv + '&code=' + val;
		cxAjaxCommand('cxGetDeptCombo', prm, cxGetDeptComboOK);
	}
}
function cxGetDeptComboOK(r) {
	//PHPから処理終了を受信
	var xmlDoc = r.responseXML.documentElement;
	if (xmlDoc.nodeName != 'Department') {
		cxFailure();
		return;
	}
	var level = xmlDoc.attributes.getNamedItem('level').value;
	for ( var i = level; i <= 3; i++) {
		var obj = $('dept' + i);
		while (obj.length > 1) {
			obj.options[1] = null;
		}
		if (i == level) {
			obj.options[0].text = "指定なし";
		} else {
			obj.options[0].text = "";
		}
	}
	var obj = $('dept' + level);
	var xmlDocfix = xmlDoc.childElementCount;
	for (var i=0; i<xmlDocfix; i++) {
		nodeL = xmlDoc.firstElementChild;
		obj.length++;
		obj.options[i+1].text = nodeL.textContent;
		var val = nodeL.attributes.getNamedItem('value').value;
		obj.options[i+1].value = val;
		xmlDoc.removeChild(xmlDoc.firstElementChild);
	}
}

//使う画像の先読み
var imgObj = new Image();
imgObj.src = "./images/detail_open.jpg";
var imgObj = new Image();
imgObj.src = "./images/detail_close.jpg";
// 情報の詳細表示
function cxdisp(id) {
	var obj = document.getElementById(id + '_dispmode');
	if (obj.style.display == 'none') {
		obj.style.display = 'block';
		$(id + '_btn').src = $(id + '_btn').src.replace("detail_open.jpg",
				"detail_close.jpg");
	} else {
		obj.style.display = 'none';
		$(id + '_btn').src = $(id + '_btn').src.replace("detail_close.jpg",
				"detail_open.jpg");
	}
}