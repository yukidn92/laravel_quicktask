<?php
/*
 *
 */
/** require **/
require ("../.htsetting");
global $objCnc;

// GETパラメータを取得
if (isset($_GET["page_id"]) && isset($_GET["no"])) {
	$page_id = $_GET["page_id"];
	$no = $_GET["no"];
}
else {
	// ページID、noが取得できなかった場合はエラーとする
	DispError("パラメータ取得エラー", 'opendata', "javascript:history.back()", MENU_KIND_SPECIAL);
	exit();
}

// init
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_opendata = new tbl_open_data($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);

// オープンデータタイプ配列
$OPENDATA_DATA_TYPE = getDefineArray("OPENDATA_DATA_TYPE");
// オープンデータカテゴリ
$OPENDATA_CATEGORY = getOpenDataCategory();
// オープンデータライセンス
$OPENDATA_LICENSE = getDefineArray("OPENDATA_LICENSE");
// ライセンスのセレクトボックス作成用に配列を作成
$lisence_ary = array();
foreach ($OPENDATA_LICENSE as $key => $value) {
	$lisence_ary[$key] = $value['name'];
}
// オープンデータデータタイプ
$OD_DATA_TYPE = getDefineArray("OD_DATA_TYPE");

// コンテキストメニュー表示パラメータ(0固定)
$menu_no = 1;
$opendata_fld = array();
// パラメータで渡されたページID,noを元にオープンデータ情報を取得する
// tableをセット
$table = "tbl_publish_open_data as po ";
$table .= "LEFT JOIN tbl_publish_page as pp ON po.page_id = pp.page_id ";
$table .= "LEFT JOIN tbl_user as u ON pp.user_id = u.user_id ";
// ページID,noを指定
$whereAry[] = $obj_opendata->_addslashesC('po.page_id', $page_id, '=', 'INT');
$whereAry[] = $obj_opendata->_addslashesC('po.no', $no, '=', 'INT');
$where = implode(' AND ', $whereAry);
$orderby = '';
$offset = '';
$limit = '';
// 条件でヒットする件数を取得する
$hit_count = $obj_opendata->getCount($where, $table);
if ($hit_count != 1) {
	DispError("オープンデータ情報の取得に失敗しました。[cnt = " . $hit_count . "]", 'opendata', "javascript:history.back()", MENU_KIND_SPECIAL);
	exit();
}
// 対象を抽出
$obj_opendata->select($where, 'po.*, pp.page_title, pp.file_path, u.dept_name, u.class', $orderby, $offset, $limit);
$obj_opendata->fetchrow = 0;
if($obj_opendata->fetch() == FALSE) {
	// 取得失敗時はエラー画面
	DispError("オープンデータ情報の取得に失敗しました。", 'opendata', "javascript:history.back()", MENU_KIND_SPECIAL);
	exit();
}
$opendata_fld = $obj_opendata->fld;

// オープンデータのタイプがファイルの場合は、掲載ページ情報を取得する
if ($opendata_fld['opendata_type'] == OPENDATA_DATA_TYPE_FILE || $opendata_fld['opendata_type'] == OPENDATA_DATA_TYPE_VARIABLE_FILE || $opendata_fld['opendata_type'] == OPENDATA_DATA_TYPE_FIXED_FILE) {
	$sql = '';
	$related_page_ary = array();
	// SQLを生成(tbl_publish_linksにオープンデータファイルのパスと同じパスを持つページの情報を取得する)
	$sql .= "SELECT p.page_id as page_id, p.file_path as file_path, p.page_title as page_title, l.path as link_path ";
	$sql .= "FROM tbl_publish_page as p ";
	$sql .= "LEFT JOIN tbl_publish_links as l ON (p.page_id = l.page_id) ";
	$sql .= "WHERE l.path = '" . gd_addslashes($opendata_fld['opendata_file_path']) . "' ";
	// ページのclose_flgがOFF,output_html_flgがOnのページを対象とする
	$sql .= "AND " . $obj_dac->_addslashesC("p.close_flg", FLAG_OFF, "=", "INT") . " ";
	$sql .= "AND " . $obj_dac->_addslashesC("p.output_html_flg", FLAG_ON, "=", "INT") . " ";
	// 情報を取得
	$obj_dac->execute($sql);
	while ($obj_dac->fetch()) {
		// 掲載中ページ情報を配列に格納する
		$related_page_ary[$obj_dac->fld['page_id']]['page_title'] = $obj_dac->fld['page_title'];
		$related_page_ary[$obj_dac->fld['page_id']]['file_path'] = $obj_dac->fld['file_path'];
	}
}

// 表示用ライセンス文字列を取得
if ($opendata_fld['opendata_license'] != '') {
	$display_license = $lisence_ary[$opendata_fld['opendata_license']];
}
else {
	$display_license = '';
}

// 表示用カテゴリ文字列を取得
$display_category = '';
if ($opendata_fld['opendata_category'] != '') {
	$mk_category_ary = explode(",", $opendata_fld['opendata_category']);
	foreach ((array)$mk_category_ary as $mk_category) {
		$display_category .= $OPENDATA_CATEGORY[$mk_category] . ',';
	}
}
$display_category = substr($display_category, 0, -1);

// オープンデータデータタイプ
// 表示用データタイプ文字列を取得
if ($opendata_fld['od_data_type'] != '' && $opendata_fld['od_data_type'] != 0) {
	$display_od_data_type = $OD_DATA_TYPE[$opendata_fld['od_data_type']];
}
else {
	$display_od_data_type = '';
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>オープンデータ詳細</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="./opendata_list.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'opendata';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<form name="cms_fOpendataDetail" id="cms_fOpendataDetail" class="cms8341-form"
	method="post" action=""><input type="hidden" name="cms_dispMode"
	id="cms_dispMode" value=""> <input type="hidden" name="cms_preview_color"
	id="cms_preview_color" value="" disabled> <input type="hidden" name="cms_page_id"
	id="cms_page_id" value=""></form>
<div id="cms8341-contents">
<div align="center" id="cms8341-template">
<div><img src="./images/opendata_detail.jpg" alt="オープンデータ詳細" width="920" height="30"></div>
<div class="cms8341-area-corner">
<p>オープンデータ情報を編集する場合は、<br />ページタイトルをクリックして表示されるメニューより、「編集」を選択して下さい。</p>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th width="200" align="left" valign="top" scope="row">オープンデータタイプ</th>
		<td align="left" valign="middle"><?=htmlDisplay($OPENDATA_DATA_TYPE[$opendata_fld['opendata_type']])?></td>
	</tr>
<?php
	if ($opendata_fld['opendata_type'] == OPENDATA_DATA_TYPE_PAGE) {
?>
	<tr>
		<th width="200" align="left" valign="top" scope="row"><p>ページ</p></th>
		<td align="left" valign="middle">
			<p><a href="javascript:" onClick="return cxContentsMenu2(event, 'cms_menu_<?=$menu_no?>','<?=$page_id?>','cms_fOpendataDetail','<?=$headerMode?>')"
					onContextMenu="cxContentsMenu2(event, 'cms_menu_<?=$menu_no?>','<?=$page_id?>','cms_fOpendataDetail','<?=$headerMode?>');return false;"><?=htmlDisplay($opendata_fld['page_title'])?></a></p>
			<div id="cms_menu_<?=$menu_no?>" class="cms8341-layer"></div>
			<p><small>URL:&nbsp;<a href="<?=HTTP_REAL_ROOT . $opendata_fld['file_path']?>" target="_blank"><?=htmlDisplay(HTTP_REAL_ROOT . $opendata_fld['file_path'])?></a></small></p>
		</td>
	</tr>
<?php
	}
	else {
?>
	<tr>
		<th width="200" align="left" valign="top" scope="row"><p>ファイル</p></th>
		<td align="left" valign="middle">
			<p><a href="<?=RPW?>/admin/page/common/file_download.php?dl_file_path=<?=RPW . $opendata_fld['opendata_file_path']?>"><img src="./images/download_file.jpg" alt="ファイルダウンロード" width="150" height="20" border="0" /></a></p>
			<?php
			// 掲載ページが1つ以上あるか
			if (count($related_page_ary) > 0) {
				echo '<p><small>[掲載ページ]</small></p>';
			}
			// 掲載ページ情報を表示する
			foreach($related_page_ary as $key_page_id => $data_ary) {
			?>
				<p><a href="javascript:" onClick="return cxContentsMenu2(event, 'cms_menu_<?=$menu_no?>','<?=$key_page_id?>','cms_fOpendataDetail','<?=$headerMode?>')"
						onContextMenu="cxContentsMenu2(event, 'cms_menu_<?=$menu_no?>','<?=$key_page_id?>','cms_fOpendataDetail','<?=$headerMode?>');return false;"><?=htmlDisplay($data_ary['page_title'])?></a></p>
				<div id ="cms_menu_<?=$menu_no?>" class="cms8341-layer"></div>
				<p><small>URL:&nbsp;<a href="<?=HTTP_REAL_ROOT . $data_ary['file_path']?>" target="_blank"><?=htmlDisplay(HTTP_REAL_ROOT . $data_ary['file_path'])?></a></small></p>
			<?php
				$menu_no++;
			}
			?>
		</td>
	</tr>
<?php
	}
?>
	<tr>
		<th width="200" align="left" valign="top" scope="row">データタイトル</th>
		<td align="left" valign="middle"><?=htmlDisplay($opendata_fld['opendata_title'])?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">概要</th>
		<td align="left" valign="middle"><?=htmlDisplay($opendata_fld['opendata_summary'])?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">ライセンス</th>
		<td align="left" valign="middle"><?=htmlDisplay($display_license)?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">データ時点</th>
		<td align="left" valign="middle"><?=htmlDisplay(dtFormat($opendata_fld['point_of_time'], 'Y年m月d日'))?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">掲載日</th>
		<td align="left" valign="middle"><?=htmlDisplay(dtFormat($opendata_fld['publication_date'], 'Y年m月d日'))?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">カテゴリ</th>
		<td align="left" valign="middle"><?=htmlDisplay($display_category)?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">データタイプ</th>
		<td align="left" valign="middle"><?=htmlDisplay($display_od_data_type)?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">キーワード検索タグ</th>
		<td align="left" valign="middle"><?=htmlDisplay($opendata_fld['opendata_keywords'])?></td>
	</tr>
	<tr>
		<th width="200" align="left" valign="top" scope="row">所有者情報</th>
		<td align="left" valign="middle"><?=htmlDisplay($opendata_fld['dept_name'])?></td>
	</tr>
	
</table>
<p align="center">
<input type="image" onclick="javascript:history.back();" src="./images/btn_small_back.jpg" alt="戻る" width="120" height="20" border="0">
</p>
</div>
<div><img src="../../../images/area920_bottom.jpg" alt="" width="920"
	height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
