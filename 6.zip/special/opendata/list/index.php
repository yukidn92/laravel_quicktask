<?php
/*********************************************************
 * オープンデータ情報管理画面データ一覧表示トップ
 * 
 * 
 * 
 *********************************************************/

/** require **/
require ("../.htsetting");
global $objCnc;

// ログイン情報
$login = $objLogin->login;

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_open_data.inc');
$obj_opendata = new tbl_open_data($objCnc);
$obj_opendata2 = new tbl_open_data($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/dac.inc');
$obj_dac = new dac($objCnc);

//検索ウインドウ
$btn = array(
	"dis" => "display:none", 
	"img" => "btn_open_mini.jpg", 
	"alt" => "開く"
);

$html = '';
// オープンデータ情報のループ表示用フォーマット
$fmt = '<table width="100%" border="0" cellpadding="5" cellspacing="0" style="border:none;">' . "\n";
$fmt .= '<tr>' . "\n";
$fmt .= '<td width="30%" align="left" valign="middle" style="border:none">' . "\n";
$fmt .= '<strong><a href="' . RPW . '/admin/special/opendata/list/opendata_detail.php?page_id={pid}&amp;no={no}">{opendata_title}</a></strong>' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '</tr>' . "\n";
$fmt .= '</table>' . "\n";
$fmt .= '<table class="cms8341-dataTable" width="100%">' . "\n";
$fmt .= '<tr>' . "\n";
$fmt .= '<td style="background-color:#F0F0F0; width:7%;">タイプ</td>' . "\n";
$fmt .= '<td style="width:18%;" colspan="2">{opendata_type}</td>' . "\n";
$fmt .= '<td style="background-color:#F0F0F0; width:10%;">組織名</td>' . "\n";
$fmt .= '<td style="width:27%;" colspan="2">{department_name}</td>' . "\n";
$fmt .= '<td style="background-color:#F0F0F0; width:10%;">ライセンス</td>' . "\n";
$fmt .= '<td style="width:18%;" colspan="2">{opendata_license}</td>' . "\n";
$fmt .= '</tr>' . "\n";
$fmt .= '<tr>' . "\n";
$fmt .= '<td style="background-color:#F0F0F0; width:10%;" colspan="2">オープンデータ</td>' . "\n";
$fmt .= '<td style="width:90%; padding:5px;" colspan="7">' . "\n";
$fmt .= '<a href="javascript:" onClick="cxdisp(\'{id}\')"><img src="' . RPW . '/admin/special/opendata/list/images/detail_open.jpg" alt="詳細情報を開く" id="{id}_btn" width="128" height="22" border="0"></a></p>' . "\n";
$fmt .= '<span id="{id}_dispmode" style="display:none">' . "\n";
$fmt .= '<p class="open_data-p">{opendata_detail}</p>' . "\n";
$fmt .= '</span>' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '</tr>' . "\n";
$fmt .= '</table><br />' . "\n";


// 検索条件
$search = array(
	// ページID検索
	'page_id' => '',
	//キーワード検索
	'search_keywords' => '', 
	// カテゴリ
	'opendata_category' => '', 
	// データタイプ
	'od_data_type' => '', 
	// ライセンス
	'opendata_license' => '', 
	// 掲載日
	'publication_date_start' => '', 
	'publication_date_end' => '', 
	// データ時点
	'point_of_time_start' => date("Y-m-d"), 
	'point_of_time_end' => '', 
	// 掲載日年月日分割
	'pdsy' => '', 
	'pdsm' => '', 
	'pdsd' => '', 
	'pdey' => '', 
	'pdem' => '', 
	'pded' => '', 
	// データ時点年月日分割
	'ptsy' => (int) date("Y"), 
	'ptsm' => (int) date("m"), 
	'ptsd' => (int) date("d"), 
	'ptey' => (int) date("Y"), 
	'ptem' => (int) date("m"), 
	'pted' => (int) date("d"), 
	// 組織
	'dept_code' => array(
		'dept1' => '', 
		'dept2' => '', 
		'dept3' => ''
	), 
	// 形式
	'file_extention' => '', 
	//ページ表示件数
	'page_limit' => '10', 
	// 表示順項目
	'disp_order' => 'publication_date', 
	// 昇順か降順か
	'sort_pattern' => 'DESC', 
	// ページ番号
	'p' => 1
);

// 組織コード初期値設定
// ウェブマスター以外の場合
if ($login['class'] != USER_CLASS_WEBMASTER) {
	$dept1 = '';
	$dept2 = '';
	$dept3 = '';
	$dept_ary = str_split($login['dept_code'], CODE_DIGIT_DEPT);
	// 所属組織コードを初期値に設定する
	if ($dept_ary['2'] != '000') {
		$dept1 = str_pad($dept_ary[0], 3 * CODE_DIGIT_DEPT, 0, STR_PAD_RIGHT);
		$dept2 = str_pad($dept_ary[0] . $dept_ary[1], 3 * CODE_DIGIT_DEPT, 0, STR_PAD_RIGHT);
		$dept3 = $login['dept_code'];
	} elseif ($dept_ary['1'] != '000') {
		$dept1 = str_pad($dept_ary[0], 3 * CODE_DIGIT_DEPT, 0, STR_PAD_RIGHT);
		$dept2 = str_pad($dept_ary[0] . $dept_ary[1], 3 * CODE_DIGIT_DEPT, 0, STR_PAD_RIGHT);
	} else {
		$dept1 = str_pad($dept_ary[0], 3 * CODE_DIGIT_DEPT, 0, STR_PAD_RIGHT);
	}
	$search['dept_code']['dept1'] = $dept1;
	$search['dept_code']['dept2'] = $dept2;
	$search['dept_code']['dept3'] = $dept3;	
}

$MAXROW_LIST = getDefineArray("MAXROW_LIST");
// オープンデータカテゴリ
$OPENDATA_CATEGORY = getOpenDataCategory();
// オープンデータライセンス
$OPENDATA_LICENSE = getDefineArray("OPENDATA_LICENSE");
// オープンデータタイプ
$OPENDATA_DATA_TYPE = getDefineArray("OPENDATA_DATA_TYPE");
// ライセンスのセレクトボックス作成用に配列を作成
$lisence_ary = array();
foreach ($OPENDATA_LICENSE as $key => $value) {
	$lisence_ary[$key] = $value['name'];
}
// オープンデータデータタイプ
$OD_DATA_TYPE = getDefineArray("OD_DATA_TYPE");

//表示順プルダウン作成用配列
$disp_order_colum = array(
	// 表示順項目 => ソート用カラム名
	"publication_date" => "掲載日", 
	"point_of_time" => "データ時点"
);
// 昇順・降順
$disp_order_ary = array(
		"ASC" => "昇順", 
		"DESC" => "降順"
);

// 表示モードを取得。パラメータにcms_dispModeが未指定の場合は初期表示の処理を行う
$search_mode = (isset($_POST['cms_dispMode']) && $_POST['cms_dispMode'] != "") ? $_POST['cms_dispMode'] : "init";

// 同一ページ以外から来た場合セッション削除
if (!isset($_SERVER['HTTP_REFERER']) || preg_replace('/\?.*$/i', '', $_SERVER['HTTP_REFERER']) != HTTP_ROOT . $_SERVER['PHP_SELF']) {
	unset($_SESSION['search']);
}

//モード
switch ($search_mode) {
	case "search" :
		// 検索実行時
		$btn['dis'] = "display:block";
		$btn['img'] = "btn_close_mini.jpg";
		$btn['alt'] = "閉じる";
		$search = margePost($search);
		$_SESSION['search'] = $search;
		// 検索条件をセッションに保存しておく
		$_SESSION['last_search_condition']['open_data_info_search'] = $search;
		// 検索を実行
		search($search, $obj_opendata);
		break;
	case "pageset" :
		$search = $_SESSION['search'];
		$search['p'] = $_POST['p'];
		// 検索を実行
		search($search, $obj_opendata);
		break;
	case "init" :
		// 初期表示
		if (isset($_SESSION['last_search_condition']['open_data_info_search'])) {
			// セッションに前回の検索条件が残っている場合は前回条件にて初期表示を行う
			$search = $_SESSION['last_search_condition']['open_data_info_search'];
		}
		$_SESSION['search'] = $search;
		// 検索を実行
		search($search, $obj_opendata);
		break;
	case "disp_num" :
		$btn['dis'] = "display:none";
		$btn['img'] = "btn_open_mini.jpg";
		$btn['alt'] = "開く";
		$search = margePost($search);
		// 検索を実行
		search($search, $obj_opendata);
		break;
	case "last_condition" :
		// 前回の条件で表示
		$btn['dis'] = "display:block";
		$btn['img'] = "btn_close_mini.jpg";
		$btn['alt'] = "閉じる";
		$search = $_SESSION['last_search_condition']['open_data_info_search'];
		$_SESSION['search'] = $search;
		// 検索を実行
		search($search, $obj_opendata);
		break;
	default :
		break;
}

// 対象項目生成
// ページID検索
$search_page_id = (!empty($search['page_id'])) ? implode(' ', $search['page_id']) : '';
// 対象
$cms_target = create_department_list("dept", $search['dept_code'], "120");

// オープンデータのカテゴリリストを作成
$open_data_cate = create_list("opendata_category", $OPENDATA_CATEGORY, $search['opendata_category'],120, 0);
// オープンデータのデータタイプリストを作成
$open_data_od_data_type = create_list("od_data_type", $OD_DATA_TYPE, $search['od_data_type'],120, 0);
// オープンデータのライセンスリストを作成
$open_data_license = create_list("opendata_license", $lisence_ary, $search['opendata_license'], 120, 0);
// オープンデータファイル形式のリストを作成
$open_data_file_extension_ary = create_fileextention_array($obj_opendata2);
$open_data_file_ext = create_list("file_extention", $open_data_file_extension_ary, $search['file_extention'], 120, 0);
//表示順
$disp_order = create_list("disp_order", $disp_order_colum, $search['disp_order'], 120, 1);
$sort_pattern = mkradiobutton($disp_order_ary, "sort_pattern", $search['sort_pattern'], 2);
// ページ表示数
$page_suu = mkcombobox($MAXROW_LIST, "page_limit", $search['page_limit'], "cxDispNum(this.value)");
$disp_last_condition = ""; //前回の検索ボタンHTML
// 前回の検索ボタン表示
if (isset($_SESSION['last_search_condition']['open_data_info_search'])) {
	$disp_last_condition = '<span style="margin:15px;" class="cms8341-verticalMiddle"><a href="javascript:" onclick="return cxLastSearch()"><img src="' . RPW . '/admin/images/btn/btn_search_condition.jpg" alt="前回の条件で検索" width="150" height="20" border="0"></a></span>' . "\n";
}

// search関数の検索結果を元にリストに表示する文字列をセットする
if ($obj_opendata->getRowCount() > 0) {
	while ($obj_opendata->fetch()) {
		// オープンデータタイプ
		$opendata_type = '';
		if (array_key_exists($obj_opendata->fld['opendata_type'], $OPENDATA_DATA_TYPE)) {
			$opendata_type = $OPENDATA_DATA_TYPE[$obj_opendata->fld['opendata_type']];
		}
		
		// オープンデータタイトル
		$opendata_title = $obj_opendata->fld['opendata_title'];
		
		// ライセンス表示
		$opendata_license = '';
		if (array_key_exists($obj_opendata->fld['opendata_license'], $lisence_ary)) {
			$opendata_license = $lisence_ary[$obj_opendata->fld['opendata_license']];
		}
		// 組織名
		$dept_name = $obj_opendata->fld['dept_name'];
		// オープンデータ詳細
		$opendata_detail = createOpenDataDetailStr($obj_opendata->fld, $obj_dac);
		// ページID
		$page_id = $obj_opendata->fld['page_id'];
		// no
		$data_no = $obj_opendata->fld['no'];
		// ページタイトル
		$page_title = $obj_opendata->fld['page_title'];
		// 詳細、簡易切り替えspanに付与するIDのユニーク部分
		$id_unique = $obj_opendata->fld['page_id'] . '_' . $obj_opendata->fld['no'];
		
		// 検索結果リストのフォーマット内の置換対象文字列を置換
		$tmp = $fmt;
		$tmp = str_replace('{opendata_type}', htmlspecialchars($opendata_type), $tmp);
		$tmp = str_replace('{pid}', htmlspecialchars($page_id), $tmp);
		$tmp = str_replace('{no}', htmlspecialchars($data_no), $tmp);
		$tmp = str_replace('{opendata_title}', htmlspecialchars($opendata_title), $tmp);
		$tmp = str_replace('{opendata_license}', htmlspecialchars($opendata_license), $tmp);
		$tmp = str_replace('{department_name}', htmlspecialchars($dept_name), $tmp);
		$tmp = str_replace('{id}', htmlspecialchars($id_unique), $tmp);
		$tmp = str_replace('{opendata_detail}', $opendata_detail, $tmp);
		$html .= $tmp;
	}
}

/*----------------------------------------------------------
 * 検索準備
 * POSTにて受け取るデータを検索条件に反映する
 * param : $pSearch - 検索条件
 * return : none
 *----------------------------------------------------------*/
function margePost($search) {
	
	foreach ($search as $key => $value) {
		if (!isset($_POST[$key])) {
			continue;
		}
		$search[$key] = $_POST[$key];
		if ($key == "search_keywords") {
			$search[$key] = str_replace('　', ' ', $search[$key]);
			$search[$key] = preg_replace('/(^ | $)/', '', $search[$key]);
		}
	}
	$search['p'] = 1;
	
	// ページID検索
	if (!empty($search['page_id'])) {
		$search['page_id'] = explode(' ', preg_replace('/\s+/', ' ', $search['page_id']));
	}
	// 掲載日指定期間開始日
	if (($search['pdsy'] != '') && ($search['pdsm'] != '') && ($search['pdsd'] != '')) {
		$search['publication_date_start'] = $search['pdsy'] . '-' . $search['pdsm'] . '-' . $search['pdsd'];
	}
	else {
		$search['publication_date_start'] = "";
	}
	// 掲載日指定期間終了日
	if (($search['pdey'] != '') && ($search['pdem'] != '') && ($search['pded'] != '')) {
		$search['publication_date_end'] = $search['pdey'] . '-' . $search['pdem'] . '-' . $search['pded'] . ' 23:59:59';
	}
	else {
		$search['publication_date_end'] = "";
	}
	// データ時点指定期間開始日
	if (($search['ptsy'] != '') && ($search['ptsm'] != '') && ($search['ptsd'] != '')) {
		$search['point_of_time_start'] = $search['ptsy'] . '-' . $search['ptsm'] . '-' . $search['ptsd'];
	}
	else {
		$search['point_of_time_start'] = "";
	}
	// データ時点指定期間終了日
	if (($search['ptey'] != '') && ($search['ptem'] != '') && ($search['pted'] != '')) {
		$search['point_of_time_end'] = $search['ptey'] . '-' . $search['ptem'] . '-' . $search['pted'] . ' 23:59:59';
	}
	else {
		$search['point_of_time_end'] = "";
	}
	// -- 対象
	if (isset($search['dept_code'])) {
		$search['dept_code']['dept1'] = $_POST['dept1'];
		$search['dept_code']['dept2'] = $_POST['dept2'];
		$search['dept_code']['dept3'] = $_POST['dept3'];
	}
	
	$_SESSION['search'] = $search;
	
	return $search;
}

/*----------------------------------------------------------
 * 検索処理
 * tbl_pulish_open_dateよりデータを取得して表示する
 * param : $pSearch - 検索条件
 * param : $obj_opendata(参照) - openデータクラスオブジェクト
 * return : none
 *----------------------------------------------------------*/
function search($p_search, &$obj_opendata) {
	
	// 検索条件を元にSQLを生成する
	$whereAry = array();
	
	// tableをセット
	$table = "tbl_publish_open_data as po ";
	$table .= "LEFT JOIN tbl_publish_page as pp ON po.page_id = pp.page_id ";
	$table .= "LEFT JOIN tbl_user as u ON pp.user_id = u.user_id ";

	// ページID検索
	if (!empty($p_search['page_id'])) {
		$pSearch['page_id'] = implode(',', $p_search['page_id']);
		$whereAry[] = $obj_opendata->_addslashesC('po.page_id', $pSearch['page_id'], 'IN', 'INT');
	}
	// 検索条件のキーワードをチェック
	if (isset($p_search['search_keywords']) && $p_search['search_keywords'] != '') {
		// キーワードをスペース区切りで分割
		$keyAry = explode(" ", $p_search['search_keywords']);
		foreach ($keyAry as $k => $v) {
			if ($v == '') {
				continue;
			}
			$whereAry[] = $obj_opendata->_addslashesC('po.page_id', $obj_opendata->mk_sql_kewords(PUBLISH_TABLE, 'DISTINCT opendata.page_id', $v), 'IN');
		}
	}
	
	// カテゴリ
	if (isset($p_search['opendata_category']) && $p_search['opendata_category'] != '') {
		$p_search_category = '(^|,)' . $p_search['opendata_category'] . '(,|$)';
		$whereAry[] = $obj_opendata->_addslashesC('po.opendata_category', $p_search_category, 'REGEXP', 'TEXT');;
	}
	

	// データタイプ
	if (isset($p_search['od_data_type']) && $p_search['od_data_type'] != '') {
		$whereAry[] = $obj_opendata->_addslashesC('po.od_data_type', $p_search['od_data_type'], '=', 'INT');
	}
	
	// ライセンス
	if (isset($p_search['opendata_license']) && $p_search['opendata_license'] != '') {
		$whereAry[] = $obj_opendata->_addslashesC('po.opendata_license', $p_search['opendata_license'], '=', 'INT');
	}	
	
	// データ時点 から
	if (isset($p_search['point_of_time_start']) && $p_search['point_of_time_start'] != '') {
		$whereAry[] = $obj_opendata->_addslashesC('po.point_of_time', $p_search['point_of_time_start'], '>=', 'DATE');
	}
	// データ時点 まで
	if (isset($p_search['point_of_time_end']) && $p_search['point_of_time_end'] != '') {
		$whereAry[] = $obj_opendata->_addslashesC('po.point_of_time', $p_search['point_of_time_end'], '<', 'DATE');
	}
	// 掲載日 から
	if (isset($p_search['publication_date_start']) && $p_search['publication_date_start'] != '') {
		$whereAry[] = $obj_opendata->_addslashesC('po.publication_date', $p_search['publication_date_start'], '>=', 'DATE');
	}
	// 掲載日 まで
	if (isset($p_search['publication_date_end']) && $p_search['publication_date_end'] != '') {
		$whereAry[] = $obj_opendata->_addslashesC('po.publication_date', $p_search['publication_date_end'], '<', 'DATE');
	}
	
	// 組織別
	$dept1 = (isset($p_search['dept_code']['dept1'])) ? $p_search['dept_code']['dept1'] : '';
	$dept2 = (isset($p_search['dept_code']['dept2'])) ? $p_search['dept_code']['dept2'] : '';
	$dept3 = (isset($p_search['dept_code']['dept3'])) ? $p_search['dept_code']['dept3'] : '';
	if ($dept3 != '') {
		$whereAry[] = $obj_opendata->_addslashesC('u.dept_code', $dept3, '=', 'INT');
	}
	elseif ($dept2 != '') {
		$digit = 2 * CODE_DIGIT_DEPT;
		$dept2 = "^" . substr($dept2, 0, $digit);
		$whereAry[] = $obj_opendata->_addslashesC('u.dept_code', $dept2, 'REGEXP', 'TEXT');
	}
	elseif ($dept1 != '') {
		$digit = 1 * CODE_DIGIT_DEPT;
		$dept1 = "^" . substr($dept1, 0, $digit);
		$whereAry[] = $obj_opendata->_addslashesC('u.dept_code', $dept1, 'REGEXP', 'TEXT');
	}
	
	// 形式
	if (isset($p_search['file_extention']) && $p_search['file_extention'] != '') {
		$whereAry[] = $obj_opendata->_addslashesC("po.file_extention", "%" . $p_search['file_extention'] . "%", "LIKE");
	}
	
	// ページのclose_flgがOFF,output_html_flgがOnのページに紐づくものを対象とする
	$whereAry[] = $obj_opendata->_addslashesC("pp.close_flg", FLAG_OFF, "=", "INT");
	$whereAry[] = $obj_opendata->_addslashesC("pp.output_html_flg", FLAG_ON, "=", "INT");
	
	// whereをセット
	$where = implode(' AND ', $whereAry);
	
	// 条件でヒットする件数を取得する
	$all = $obj_opendata->getCount($where, $table);
	
	// ページング設定
	if (isset($p_search['p'])) {
		$obj_opendata->objP = new page_control();
		$obj_opendata->objP->limit = $p_search['page_limit'];
		$p = (isset($p_search['p'])) ? $p_search['p'] : 1;
		$obj_opendata->objP->set($p, $all);
		$offset = $obj_opendata->objP->getOffset();
		$limit = $obj_opendata->objP->getLimit();
	}
	else {
		$offset = '';
		$limit = '';
	}
	
	//表示順
	if (isset($p_search['disp_order']) && $p_search['disp_order'] != "" && isset($p_search['sort_pattern']) && $p_search['sort_pattern'] != "") {
		// orderの指定があればセット
		$orderby = "po." . $p_search['disp_order'] . " " . $p_search['sort_pattern'];
	}
	else {
		// 無い場合は第1key掲載日降順、第2Keyデータ時点降順とする
		$orderby = "po.publication_date DESC, po.publish_end DESC";
	}
	
	// 対象を抽出
	$obj_opendata->select($where, 'po.*, pp.*, u.dept_name, u.dept_code, u.class', $orderby, $offset, $limit);
	$obj_opendata->fetchrow = 0;
}

/*----------------------------------------------------------
 * プルダウン作成
 * param : $name - 付与するnameの値
 * param : $ary - プルダウン要素を格納した配列
 * param : $select - 初期選択させる要素
 * param : $select - サイズ
 * param : $nasi - 先頭に「指定なし」の表示を行うか
 * return : none
 *----------------------------------------------------------*/
function create_list($name, $ary, $select, $width, $nasi = '0') {
	$liststr = '<select id="' . $name . '" name="' . $name . '" style="width:' . $width . 'px;">' . "\n";
	if ($nasi == 0) {
		$liststr .= '<option value="">指定なし</option>' . "\n";
	}
	foreach ($ary as $key => $listary) {
		$selected = ($key == $select) ? ' selected' : '';
		$liststr .= '<option value="' . $key . '"' . $selected . '>' . htmlDisplay($listary) . '</option>' . "\n";
	}
	$liststr .= '</select>' . "\n";
	return $liststr;
}

/*----------------------------------------------------------
 * ファイル形式の一覧をDBより取得し、配列を作成する。
 * param : 無し
 * return : 生成した配列
 *----------------------------------------------------------*/
function create_fileextention_array($obj_opendata2) {
	$return_list_ary = array();
	
	// 取得条件を設定(重複無しでファイル拡張子をすべて取得)
	$table = 'tbl_publish_open_data as po ';
	$fields = 'DISTINCT po.file_extention';
	$where = 'po.file_extention IS NOT NULL';
	$orderby = 'po.file_extention ASC';
	$offset = '';
	$limit = '';
		
	// 対象を抽出
	$obj_opendata2->select($where, $fields, $orderby, $offset, $limit, $table);
	
	// 対象が存在する場合
	if ($obj_opendata2->getRowCount() > 0) {
		while ($obj_opendata2->fetch()) {
			// value,表示値共に拡張子文字列として配列に格納
			$return_list_ary[$obj_opendata2->fld['file_extention']] = $obj_opendata2->fld['file_extention'];
		}
	}
	// 作成した配列を返す(対象がない場合は空配列)
	return $return_list_ary;
}

/*----------------------------------------------------------
 * オープンデータ詳細情報の作成
 * タイプがページの場合：ページへのリンクを表示
 * タイプがファイルの場合：ファイルのダウンロードパスおよび、
 *                         同ファイルを参照しているページのリスト
 * param : $fld - オープンデータ情報
 * param : $obj_dac - dacオブジェクト
 * return : 作成した文字列を返す
 *----------------------------------------------------------*/
function createOpenDataDetailStr($fld, $obj_dac) {
	$detail_html = '';
	
	if ($fld['opendata_type'] == OPENDATA_DATA_TYPE_PAGE) {
		// ページへのリンクを表示
		$detail_html .= '<p><small>URL:&nbsp;<a href="' . HTTP_REAL_ROOT . $fld['file_path'] . '" target="_blank">' . HTTP_REAL_ROOT . $fld['file_path'] . '</a></small></p>';
	}
	else {
		// 掲載ページ情報格納用配列を初期化
		$related_page_ary = array();
		// タイプがファイルの場合は、ダウンロードリンクを表示する
		$detail_html .= '<p><a href="' . RPW . '/admin/page/common/file_download.php?dl_file_path=' . RPW . $fld['opendata_file_path'] . '"><img src="./images/download_file.jpg" alt="ファイルダウンロード" width="150" height="20" border="0" /></a></p>';
		
		// 対象のオープンデータにリンクしているページの情報を取得する
		$sql = "SELECT p.page_id as page_id, p.file_path as file_path, p.page_title as page_title, l.path as link_path ";
		$sql .= "FROM tbl_publish_page as p ";
		$sql .= "LEFT JOIN tbl_publish_links as l ON (p.page_id = l.page_id) ";
		$sql .= "WHERE l.path = '" . gd_addslashes($fld['opendata_file_path']) . "' ";
		// ページのclose_flgがOFF,output_html_flgがOnのページを対象とする
		$sql .= "AND " . $obj_dac->_addslashesC("p.close_flg", FLAG_OFF, "=", "INT") . " ";
		$sql .= "AND " . $obj_dac->_addslashesC("p.output_html_flg", FLAG_ON, "=", "INT") . " ";
		// 情報を取得
		$obj_dac->execute($sql);
		if ($obj_dac->getRowCount() > 0) {
			$detail_html .= '<p><small>[掲載ページ]</small></p>';
		}
		while ($obj_dac->fetch()) {
			// 掲載中ページ情報を配列に格納する
			$related_page_ary[$obj_dac->fld['page_id']]['page_title'] = $obj_dac->fld['page_title'];
			$related_page_ary[$obj_dac->fld['page_id']]['file_path'] = $obj_dac->fld['file_path'];
		}
		// 掲載ページの存在をチェック
		if(count($related_page_ary) > 0) {
			// 掲載ページ情報を作成
			foreach($related_page_ary as $data_ary) {
				// リンクテーブルに、自分以外のページから対象オープンデータへのリンクがあった場合は掲載ページへのリンクを表示する
				$detail_html .= '<p><small>' . $data_ary['page_title'] . '</small><br />';
				$detail_html .= '<small>URL:&nbsp;<a href="' . HTTP_REAL_ROOT . $data_ary['file_path'] . '" target="_blank">' . HTTP_REAL_ROOT . $data_ary['file_path'] . '</a></small></p>';
			}
		}
	}
	
	// 作成した文字列を返す
	return $detail_html;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>オープンデータ情報管理</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css" type="text/css">
<link rel="stylesheet" href="./opendata_list.css" type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/special/opendata/list/opendata_list.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php echo loadSettingVars(); ?>
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'opendata';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-pageinfo">
<div><img
	src="<?=RPW?>/admin/special/opendata/list/images/title_opendata.jpg"
	alt="ページ情報" width="920" height="30"></div>
<div class="cms8341-area-corner">
<form name="cms_fSearch" id="cms_fSearch" class="cms8341-form"
	method="post" action="index.php"><input type="hidden" id="dispMode"
	name="cms_dispMode" value=""> <input type="hidden" name="p" id="p"
	value=""> 
<div id="cms8341-searcharea">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" valign="middle"
			style="background-image: url(images/bar_topbg.jpg); height: 31px;"><img
			src="./images/bar_search.jpg" alt="検索" width="200" height="20"
			style="margin-left: 10px;"></td>
	</tr>
</table>
<div id="cms8341-search" style="<?=$btn['dis']?>">
<table width="100%" border="0" cellpadding="0" cellspacing="0"
	bgcolor="#F0F0F0">
	<tr>
		<td>
		<table width="100%" border="0" cellpadding="10" cellspacing="0"
			bgcolor="#F0F0F0">
			<!-- ページID検索 -->
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ページID</th>
				<td align="left" valign="middle"><input type="text"
					id="page_id" name="page_id"
					value="<?=htmlspecialchars($search_page_id)?>"
					style="width: 250px; ime-mode: disabled;">
					<br><small>※複数指定する場合はスペース区切りで指定してください。</small></td>
			</tr>

			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">キーワード</th>
				<td align="left" valign="middle">
				<input type="text" id="search_keywords" name="search_keywords"
					value="<?=htmlspecialchars($search['search_keywords'])?>"
					style="width: 500px;"><br>
				<small>※大文字と小文字は区別されません。</small></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">ライセンス</th>
				<td align="left" valign="middle"><?=$open_data_license?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">データ時点</th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="ptsy" name="ptsy"
					value="<?=htmlspecialchars($search['ptsy'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="ptsm" name="ptsm"
					value="<?=htmlspecialchars($search['ptsm'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="ptsd" name="ptsd"
					value="<?=htmlspecialchars($search['ptsd'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pt','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="ptey" name="ptey"
					value="<?=htmlspecialchars($search['ptey'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="ptem" name="ptem"
					value="<?=htmlspecialchars($search['ptem'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pted" name="pted"
					value="<?=htmlspecialchars($search['pted'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pt','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">掲載日</th>
				<td align="left" valign="middle"><input type="text" maxlength="4"
					id="pdsy" name="pdsy"
					value="<?=htmlspecialchars($search['pdsy'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdsm" name="pdsm"
					value="<?=htmlspecialchars($search['pdsm'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pdsd" name="pdsd"
					value="<?=htmlspecialchars($search['pdsd'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','start')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a> から <input
					type="text" maxlength="4" id="pdey" name="pdey"
					value="<?=htmlspecialchars($search['pdey'])?>"
					style="width: 60px; ime-mode: disabled"> 年 <input type="text"
					maxlength="2" id="pdem" name="pdem"
					value="<?=htmlspecialchars($search['pdem'])?>"
					style="width: 40px; ime-mode: disabled"> 月 <input type="text"
					maxlength="2" id="pded" name="pded"
					value="<?=htmlspecialchars($search['pded'])?>"
					style="width: 40px; ime-mode: disabled"> 日 <a href="javascript:"
					onClick="return cxCalendarOpen('pd','end')"><img
					src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
					width="14" height="17" border="0" align="absmiddle"></a></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">カテゴリ</th>
				<td align="left" valign="middle"><?=$open_data_cate?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">データタイプ</th>
				<td align="left" valign="middle"><?=$open_data_od_data_type?></td>
			</tr>
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">形式</th>
				<td align="left" valign="middle"><?=$open_data_file_ext?></td>
			</tr>
			<?php if ($login['class'] != USER_CLASS_WEBMASTER) { ?>
			<tr style="display:none;">
		<?php } else { ?>
			<tr>
		<?php } ?>
				<th width="120" align="left" valign="middle" nowrap scope="row">組織</th>
				<td align="left" valign="middle"><?=$cms_target?></td>
			</tr>
			<!--
			<tr>
				<th width="120" align="left" valign="middle" nowrap scope="row">表示順</th>
				<td align="left" valign="middle"><?=$disp_order?><?=$sort_pattern?></td>
			</tr>
			-->
		</table>
		</td>
		<td align="center" valign="middle"><img
			src="<?=RPW?>/admin/images/icon/icon-flow-side.jpg" alt="" width="26"
			height="28"></td>
		<td width="121" align="center" valign="middle"><a href="javascript:"
			onClick="return cxSearch()"><img
			src="<?=RPW?>/admin/images/btn/btn_search.jpg" alt="検索する" width="101"
			height="21" border="0"></a></td>
	</tr>
</table>
</div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="right" valign="middle"
			style="background-image: url(./images/bar_bottombg.jpg); height: 32px;"><a
			href="javascript:"
			onClick="return cxBlind('cms8341-search','cms-searchSwitch')"><img
			src="<?=RPW?>/admin/images/btn/<?=$btn['img']?>"
			alt="<?=$btn['alt']?>" width="80" height="15" border="0"
			style="margin-right: 10px;" id="cms-searchSwitch"></a></td>
	</tr>
</table>
</div>
<?php
if ($obj_opendata->getRowCount() == 0) {
	?>
<?php

	if ($disp_last_condition != "") {
		?>
<div style="margin-bottom: 10px; padding: 1px" align="right"><?=$disp_last_condition?></div>
<?php
	}
	?>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th align="center" valign="middle" scope="col"
			style="font-weight: normal">&nbsp;</th>
	</tr>
	<tr>
		<td align="center" valign="middle">該当する情報はありません。</td>
	</tr>
</table>
</form>
<?php
}
else {
	?>
<!-- ページ送り -->
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr valign="top">
		<td colspan="3" align="right">
<?=$disp_last_condition?>
<?=$page_suu?>
</td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$obj_opendata->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$obj_opendata->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$obj_opendata->getNextLink()?></td>
	</tr>
</table>
</form>
<!-- ページ送り ここまで-->
</form>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$html?>
</table>
<!-- ページ送り -->
<table width="100%" border="0" cellspacing="0" cellpadding="5"
	style="margin-top: 10px;">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$obj_opendata->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$obj_opendata->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$obj_opendata->getNextLink()?></td>
	</tr>
</table>
<!-- ページ送り ここまで-->
<?php
}
?>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%; margin-top: 10px">
		<div id="cms8341-calbody"
			style="width: 480px; height: 380px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
<!--***エラーメッセージレイヤー ここから********************************-->
<div id="cms8341-error" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/layer/bar_error.jpg" alt="エラー"
					width="480" height="20" style="margin: 4px 10px;"></td>
			</tr>
		</table>
		<div
			style="width: 460px; height: 300px; overflow: auto; margin: 10px 0px; background-color: #FFFFFF; padding: 10px; text-align: left; border: solid 1px #999999">
		<div align="center">
		<div
			style="width: 430px; height: 120px; padding: 5px; text-align: left"
			id="cms8341-errormsg">メッセージ</div>
		<div style="margin: 15px 0px;"><a href="javascript:"
			onClick="return cxCloseError()"><img
			src="<?=RPW?>/admin/images/btn/btn_ok.jpg" alt="OK" width="100"
			height="20" border="0"></a></div>
		</div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***エラーメッセージレイヤー ここまで********************************-->
<form id="pageinfo" class="cms8341-form" name="pageinfo" action=""
	method="post"><input type="hidden" id="cms_page_id" name="cms_page_id"
	value=""> <input type="hidden" id="cms_dispMode" name="cms_dispMode"
	value=""></form>

</body>
</html>
