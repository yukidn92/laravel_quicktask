<?php
/*
 * 広告クリック数集計：確認画面
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/advertCommonFunc.inc");

// ** global 宣言 ---------------------------
global $objCnc;

// ** database controll ---------------------
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_advert_area.inc');
$objAdArea = new tbl_advert_area($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_advert_banner.inc');
$objAdBanner = new tbl_advert_banner($objCnc);

// ** POST 取得 -----------------------------


// -- POSTが取得できない場合エラー
if (!isset($_POST['cms_advert_area'])) {
	advertError("不正アクセスです。");
}

// -- 広告エリア
$advert['area_id'] = $_POST['cms_advert_area'];
// -- 集計対象期間
$advert['pds'] = array( // 始
		"y" => (isset($_POST['cms_pdsy'])) ? $_POST['cms_pdsy'] : "", 
		"m" => (isset($_POST['cms_pdsm'])) ? $_POST['cms_pdsm'] : "", 
		"d" => (isset($_POST['cms_pdsd'])) ? $_POST['cms_pdsd'] : ""
);
$advert['pde'] = array( // 終
		"y" => (isset($_POST['cms_pdey'])) ? $_POST['cms_pdey'] : "", 
		"m" => (isset($_POST['cms_pdem'])) ? $_POST['cms_pdem'] : "", 
		"d" => (isset($_POST['cms_pded'])) ? $_POST['cms_pded'] : ""
);
// -- Unix タイムスタンプに変換
if (!in_array("", $advert['pds'])) {
	$advert['pds']['ymd'] = strtotime($advert['pds']['y'] . "-" . $advert['pds']['m'] . "-" . $advert['pds']['d']);
}
if (!in_array("", $advert['pde'])) {
	$advert['pde']['ymd'] = strtotime($advert['pde']['y'] . "-" . $advert['pde']['m'] . "-" . $advert['pde']['d']);
}

// ** hidden 属性の作成 ---------------------


// 集計対象期間 -- 始
$htmlHidden = '<input type="hidden" id="pds" name="pds" value="';
$htmlHidden .= (isset($advert['pds']['ymd'])) ? $advert['pds']['ymd'] : "";
$htmlHidden .= '">' . PHP_EOL;
// 集計対象期間 -- 終
$htmlHidden .= '<input type="hidden" id="pde" name="pde" value="';
$htmlHidden .= (isset($advert['pde']['ymd'])) ? $advert['pde']['ymd'] : "";
$htmlHidden .= '">' . PHP_EOL;

// ** DB データの取得 -----------------------


// -- エリア情報の取得
if ($advert['area_id'] == "") {
	// ID 指定がない場合は全ての情報
	$objAdArea->select();
	while ($objAdArea->fetch()) {
		$area[$objAdArea->fld['area_id']] = $objAdArea->fld['name'];
	}
}
else {
	// ID 指定がある場合は指定IDのみ
	if ($objAdArea->selectFromID($advert['area_id']) !== FALSE) {
		$area[$objAdArea->fld['area_id']] = $objAdArea->fld['name'];
	}
}

// -- バナー情報の取得
if ($advert['area_id'] == "") {
	// ID 指定がない場合は全てのバナー情報
	$objAdBanner->select("", "*", "sort_order ASC");
}
else {
	// ID 指定がある場合は指定IDのみ
	$objAdBanner->select($objAdBanner->_addslashesC("area_id", $advert['area_id'], "="), "*", "sort_order ASC");
}

while ($objAdBanner->fetch()) {
	// バナー情報代入
	if (!isset($banner[$objAdBanner->fld['area_id']])) {
		// エリアIDの情報を新規取得した場合
		// 新規配列を作成しバナー情報を代入
		$banner[$objAdBanner->fld['area_id']] = array( // $banner[ エリアID ][ バナーID ]
				$objAdBanner->fld['banner_id'] => array(
						"banner_name" => $objAdBanner->fld['name'],  // バナー名称
						"sort_order" => $objAdBanner->fld['sort_order'],  // ソート
						"count" => 0
				)
		);// クリック数

	}
	else {
		// 既にエリアIDの情報が代入されている場合
		// 既存配列内にバナー情報を代入
		$banner[$objAdBanner->fld['area_id']][$objAdBanner->fld['banner_id']] = array(
				"banner_name" => $objAdBanner->fld['name'],  // バナー名称
				"sort_order" => $objAdBanner->fld['sort_order'],  // ソート
				"count" => 0
		); // クリック数
	

	}
}

// ** CSV読み込み ---------------------------


// ダウンロード可能フラグ
$csvDL_flg = FLAG_OFF;

// HTML出力用
$showHTML = "";

// エリアを取得できる場合のみ集計結果取得
if (isset($area)) {
	
	// htmlテンプレート(広告エリア)
	$htmlTMP_H = '';
	$htmlTMP_H .= '<div class="cms8341-advert-area">{cmsClickAreaName}</div>' . PHP_EOL;
	
	// htmlテンプレート(クリック集計情報)
	$htmlTMP_C = '';
	$htmlTMP_C .= '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . PHP_EOL;
	$htmlTMP_C .= '<tr>' . PHP_EOL;
	$htmlTMP_C .= '<th width="80%" align="center" valign="middle" nowrap scope="row">広告バナー名称</th>' . PHP_EOL;
	$htmlTMP_C .= '<th width="20%" align="center" valign="middle" nowrap scope="row">クリック数</th>' . PHP_EOL;
	$htmlTMP_C .= '</tr>' . PHP_EOL;
	$htmlTMP_C .= '{cmsClickBbannerInfo}' . PHP_EOL;
	$htmlTMP_C .= '</table>' . PHP_EOL;
	
	// -- エリアID.csvファイルを読み込む
	foreach ($area as $k => $v) {
		
		// ※エリア指定なしの場合は全てのエリア情報を読み込む
		

		$bannerInfo = "";
		$bannerHidden = "";
		
		// - csvファイル選択
		$csvFn = DOCUMENT_ROOT . DIR_PATH_CLICKTOTALCSV . $k . ".csv";
		// CSVファイルの存在チェック
		// 広告バナー情報の存在チェック
		if (@file_exists($csvFn) && isset($banner[$k])) {
			// CSVオープン
			if (($CsvFno = @fopen($csvFn, 'r'))) {
				// CSVの内容
				// 0 = バナーID
				// 1 = クリック日(YYYY-MM-DD)
				while ($data = cms_fgetcsv($CsvFno, 4000)) {
					// エリア内に指定されたバナーIDが存在する
					if (isset($banner[$k][$data[0]])) {
						// 日付のチェック
						if (isset($advert['pds']['ymd'])) {
							// - 開始期間
							if ($advert['pds']['ymd'] > strtotime($data[1])) continue;
						}
						if (isset($advert['pde']['ymd'])) {
							// - 開始期間
							if ($advert['pde']['ymd'] < strtotime($data[1])) continue;
						}
						$banner[$k][$data[0]]['count']++;
					}
				}
				// CSVクローズ
				@fclose($csvFn);
				
				// 集計情報をHTML出力用に調整
				foreach ($banner[$k] as $banner_id => $value) {
					// HTML を作成
					$bannerInfo .= '<tr>' . PHP_EOL;
					$bannerInfo .= '<td>' . PHP_EOL;
					$bannerInfo .= htmlDisplay($banner[$k][$banner_id]['banner_name']) . PHP_EOL;
					$bannerInfo .= '</td>' . PHP_EOL;
					$bannerInfo .= '<td align="center">' . PHP_EOL;
					$bannerInfo .= $banner[$k][$banner_id]['count'] . PHP_EOL;
					$bannerInfo .= '</td>' . PHP_EOL;
					$bannerInfo .= '</tr>' . PHP_EOL;
					// hidden を作成
					$bannerHidden .= '<input type="hidden" ' . 'id="cms_banner[' . $k . '][' . $banner_id . '][banner_name]" ' . 'name="cms_banner[' . $k . '][' . $banner_id . '][banner_name]" ' . 'value="' . htmlspecialchars($banner[$k][$banner_id]['banner_name']) . '">' . PHP_EOL;
					$bannerHidden .= '<input type="hidden" ' . 'id="cms_banner[' . $k . '][' . $banner_id . '][count]" ' . 'name="cms_banner[' . $k . '][' . $banner_id . '][count]" ' . 'value="' . $banner[$k][$banner_id]['count'] . '">' . PHP_EOL;
				}
				// 文字列置き換え
				$bannerInfo = str_replace("{cmsClickAreaName}", htmlDisplay($v), $htmlTMP_H) . str_replace("{cmsClickBbannerInfo}", $bannerInfo, $htmlTMP_C);
				$bannerInfo .= $bannerHidden;
				// 情報代入
				$showHTML .= '<p>' . $bannerInfo . '</p>';
				// フラグオン
				$csvDL_flg = FLAG_ON;
			}
		}
		
		// バナー情報が取得できない場合
		if ($bannerInfo == "") {
			$showHTML .= '<p>' . str_replace("{cmsClickAreaName}", htmlDisplay($v), $htmlTMP_H);
			$showHTML .= '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . PHP_EOL;
			$showHTML .= '<tr>' . PHP_EOL;
			$showHTML .= '<td align="center">';
			if (@file_exists($csvFn)) {
				$showHTML .= '現在登録されている広告バナーはありません。';
			}
			else {
				$showHTML .= 'データがありません。';
			}
			$showHTML .= '</td>' . PHP_EOL;
			$showHTML .= '</tr>' . PHP_EOL;
			$showHTML .= '</table></p>' . PHP_EOL;
		}
	
	}

}
else {
	// 広告エリアが存在しない場合
	$showHTML .= '<p><table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . PHP_EOL;
	$showHTML .= '<tr>' . PHP_EOL;
	$showHTML .= '<td align="center">';
	$showHTML .= 'データがありません。';
	$showHTML .= '</td>' . PHP_EOL;
	$showHTML .= '</tr>' . PHP_EOL;
	$showHTML .= '</table></p>' . PHP_EOL;
}

// ** HTML 出力 -----------------------------
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>クリック数集計結果</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/library/scriptaculous.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script src="./click_total.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
<?php
echo loadSettingVars();
?>

//contentsmenu preload images
cxPreImages(cms8341admin_path+'/special/advert/images/title_clicktotal_result.jpg',
		    cms8341admin_path+'/special/advert/images/btn_total_result_download.jpg');
//-->
</script>
</head>
<body id="cms8341-mainbg">
<form id="click_total_form" name="click_total_form" class="cms8341-form"
	method="post" action="./click_download.php" target="">
<?php
// ヘッダーメニュー挿入
$headerMode = 'advert';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
	<div align="center" id="cms8341-contents">
<div><img src="../images/title_clicktotal_result.jpg" alt="クリック数集計結果"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td>
<?=$showHTML?>
					</td>
	</tr>
</table>
<?php
if ($csvDL_flg == FLAG_ON) { /* ダウンロードを行える場合はボタン表示 */	?>
			<p align="center"><a href="javascript:"
	onClick="return cxSubmit( 'click_total_form' )"><img
	src="<?=RPW?>/admin/images/btn/btn_total_result_download.jpg"
	width="150" height="20" border="0" alt="集計結果ダウンロード"></a></p>
<?php
}
?>
		</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
<!-- cms8341-contents -->
<?=$htmlHidden?>
</form>
</body>
</html>