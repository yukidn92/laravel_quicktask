<?php
/*
 * 広告クリック数集計：CSVダウンロード
 */
// ** require -------------------------------
require ("../.htsetting");
require ("../include/advertCommonFunc.inc");

// ** 変数初期化 ----------------------------
$csvHeader = '"広告バナー名称",'; // ダウンロードCSVヘッダー
$csvHeader .= '"クリック数"' . "\n";
$csvFn = "click_total.csv"; // 出力ファイル名


// ** POST 取得 -----------------------------
$advert = $_POST;

// ** 変数初期化 ----------------------------
$expCsvData = ""; // 出力データ


// ** CSVデータ作成 -------------------------
if (isset($advert['cms_banner'])) {
	foreach ($advert['cms_banner'] as $area) {
		foreach ($area as $banner => $value) {
			// 「"」を「""」にエスケープして書き込みデータを作成
			$expCsvData .= csvWrite($area[$banner]['banner_name'], '"', '"') . ","; // 広告バナー名称
			$expCsvData .= csvWrite($area[$banner]['count'], '"', '"') . "\n"; // クリック数
		}
	}
}
else {
	// 集計情報が存在しない(不正なアクセスの場合)
	advertError("不正アクセスです。");
}

// ** CSV出力


// ヘッダーの結合
$expCsvData = $csvHeader . $expCsvData;

header("Content-Disposition: attachment; filename=" . mb_convert_encoding($csvFn, "sjis", "utf-8"));
header('Content-type: text/comma-separated-values');
// 出力
print mb_convert_encoding($expCsvData, "sjis", "utf-8");

?>