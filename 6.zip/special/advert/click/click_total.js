/*
 * クリック集計用jsファイル
 */

/**
 * サブミット
 * 
 * @param string
 *            form サブミットするフォームのname
 * 
 */
function cxSubmit(form) {
	$(form).submit();
	return false;
}

/**
 * エラーレイヤーのクローズ
 */
function cxCloseError() {
	cxComboVisible();
	cxLayer('cms8341-error', 0);
}

/**
 * クリック集計プログラム用エラーチェック
 * 
 * @param	string	form	サブミットするフォームのname
 * 
 *【備考】
 * エラーが存在する場合はレイヤーにエラーを表示
 * エラーチェックが正常に完了した場合はサブミット
 * 
 */
function cxClickErrChk(form) {

	// エラーチェック
	var msg = new Array();
	var sub = new Array();
	var pdsy = $('cms_pdsy');
	var pdsm = $('cms_pdsm');
	var pdsd = $('cms_pdsd');
	var pdey = $('cms_pdey');
	var pdem = $('cms_pdem');
	var pded = $('cms_pded');

	/*
	 * ** エラーチェックの特徴 ** ----- 入力なしを許可(全件検索) 開始日、終了日のみの入力を許可 **
	 * --------------------------
	 */

	// 受付対象期間(年月日全て)に入力があるかチェック
	if (pdsy.value || pdsm.value || pdsd.value) {
		if (!pdsy.value || !pdsm.value || !pdsd.value) {
			msg.push('受付対象期間の指定をする場合は、年月日すべてを指定してください。');
		}
	}

	if (msg.length <= 0) {
		if (pdey.value || pdem.value || pded.value) {
			if (!pdey.value || !pdem.value || !pded.value) {
				msg.push('受付対象期間の指定をする場合は、年月日すべてを指定してください。');
			}
		}
	}

	if (msg.length <= 0) {
		// 受付対象期間(左右)に入力がある場合
		if (pdsy.value && pdey.value) {
			// 開始日、終了日のチェック
			sub = cxDateCheckNew("cms_pd", "ymd", 1, "受付対象");
			if (sub.length > 0) {
				for (i = 0; i < sub.length; i++) {
					msg.push(sub[i]);
				}
			}
		} else {
			// 受付対象期間(左)に入力がある場合
			if (pdsy.value) {
				// 開始日のチェック
				sub = cxDateCheckNew("cms_pd", "ymd", 2, "受付対象期間 開始");
				if (sub.length > 0) {
					for (i = 0; i < sub.length; i++) {
						msg.push(sub[i]);
					}
				}
			}
			// 受付対象期間(右)に入力がある場合
			if (pdey.value) {
				// 終了日のチェック
				sub = cxDateCheckNew("cms_pd", "ymd", 3, "受付対象期間 終了");
				if (sub.length > 0) {
					for (i = 0; i < sub.length; i++) {
						msg.push(sub[i]);
					}
				}
			}
		}

	}

	// エラー表示
	if (msg.length > 0) {

		var output_msg = '<p>';
		// msg.sort();
		for ( var i = 0; i < msg.length; i++) {
			output_msg += msg[i] + '<br>';
		}
		output_msg += '</p>';

		cxComboHidden(new Array("cms_template_id"));
		$('cms8341-errormsg').innerHTML = output_msg;
		cxLayer('cms8341-error', 1, 500, 500);
		return false;
	}

	// エラーなしなのでサブミット
	cxSubmit(form);
	return false;
}