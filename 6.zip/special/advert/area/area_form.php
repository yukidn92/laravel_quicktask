<?php
/*
 * 広告掲載機能　広告エリア追加画面
 */
/** require **/
require ("../.htsetting");
require ("../include/advertCommonFunc.inc");
require ("../include/advertAreaFunc.inc");
$ADVERT_DELIVERY_FROM = getDefineArray("ADVERT_DELIVERY_FROM");
$ADVERT_ORDER_FROM = getDefineArray("ADVERT_ORDER_FROM");
$ADVERT_RECRUITMENT_FROM = getDefineArray("ADVERT_RECRUITMENT_FROM");

//main
$behavior = (!isset($_POST["behavior"])) ? ADVERT_ADD : ADVERT_UPD;

$area_id = (isset($_POST['area_id'])) ? $_POST['area_id'] : "";

$templateDat = getTemplateDB();
$emptyDat = craeteEmptyAreaData();
$dat = getAdvertAreaDB($area_id);
$dat = array_merge($emptyDat, $dat);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>エリア設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(){
	// 入力チェック
	if(!isEmpty('name',"エリア名称") ) return false;
	if(!isSelect('delivery_from',"配信形式") ) return false;
	if(!isEmpty('layout_line','レイアウト行') ) return false;
	if(!isNumric('layout_line','レイアウト行','<?=ADVERT_AREA_MAX_LAYOUT_LINE?>') ) return false;
	if(!isEmpty('layout_row',"レイアウト列") ) return false;
	if(!isNumric('layout_row',"レイアウト列",'<?=ADVERT_AREA_MAX_LAYOUT_ROW?>') ) return false;
	if(!isSelect('order_from',"表示順") ) return false;
	if(!isEmpty('banner_width',"バナーサイズ幅") ) return false;
	if(!isNumric('banner_width',"バナーサイズ幅",'<?=ADVERT_AREA_MAX_BANNER_WIDTH?>') ) return false;
	if(!isEmpty('banner_height',"バナーサイズ高さ") ) return false;
	if(!isNumric('banner_height',"バナーサイズ高さ",'<?=ADVERT_AREA_MAX_BANNER_HEIGHT?>') ) return false;
	if(!isSelect('recruitment_from',"募集中バナー") ) return false;
	
	$('ad_form').submit();
	return false;
}	
// 空チェック
function isEmpty(id,name){
	if($F(id) == ""){
		alert(name+"が入力されていません")
		$(id).focus();
		return false;
	}
	return true;
}
// 選択チェック
function isSelect(id,name){
	if (isSelectCheck(id) != true) {
		var select = document.getElementsByName(id);
		alert(name+"が選択されていません");
		if (select[0]) select[0].focus();
		return false;
	}
	return true;
}
// 数字チェック
function isNumric(id,name,max){
	num = new Number($F(id));
	if(!cxDateNumeric($F(id))){
		alert(name+"は1以上"+max+"以下の数字を入力してください")
		$(id).focus();
		return false;
	}
	if(num < 1 || num > max){
		alert(name+"は1以上"+max+"以下の数字を入力してください")
		$(id).focus();
		return false;
	}
	return true;
}
//配信方式を変更した場合
function cngDeliveryFrom(){
	//配信方式にCSVを選択していた場合
	if($('delivery_from_1').checked){
		$('template_id_tr').style.display = '';
		$('template_id').disabled = false;
	}
	//それ以外の場合
	else{
		$('template_id_tr').style.display = 'none';
		$('template_id').disabled = true;
	}
}
window.attachEvent('onload', cngDeliveryFrom);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'advert';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="../images/bar_advert_area_form.jpg" alt="エリア設定"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form id="ad_form" class="cms8341-form" name="ad_form" method="post"
	action="area_confirm.php">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th style="width: 150px">エリア名称<span class="cms_require">（必須）</span></th>
		<td><input type="text" name="name" id="name"
			value="<?=htmlspecialchars($dat['name'])?>" style="width: 400px"></td>
	</tr>
	<tr>
		<th>配信形式<span class="cms_require">（必須）</span></th>
		<td>
				<?php
				echo mkradiobutton($ADVERT_DELIVERY_FROM, "delivery_from", $dat['delivery_from'], 0, '', 'cngDeliveryFrom();');
				?>
			</td>
	</tr>
	<tr>
		<th>レイアウト<span class="cms_require">（必須）</span></th>
		<td>行&nbsp;&nbsp;&nbsp;<input type="text" maxlength=2
			name="layout_line" id="layout_line"
			value="<?=htmlspecialchars($dat['layout_line'])?>"
			style="width: 50px; ime-mode: disabled">&nbsp;&nbsp;&nbsp;
		列&nbsp;&nbsp;&nbsp;<input type="text" maxlength=2 name="layout_row"
			id="layout_row" value="<?=htmlspecialchars($dat['layout_row'])?>"
			style="width: 50px; ime-mode: disabled"></td>
	</tr>
	<tr>
		<th>表示順<span class="cms_require">（必須）</span></th>
		<td>
				<?php
				echo mkradiobutton($ADVERT_ORDER_FROM, "order_from", $dat['order_from'], 0);
				?>
			</td>
	</tr>
	<tr>
		<th>バナーサイズ<span class="cms_require">（必須）</span></th>
		<td>幅&nbsp;&nbsp;&nbsp;<input type="text" maxlength=3
			name="banner_width" id="banner_width"
			value="<?=htmlspecialchars($dat['banner_width'])?>"
			style="width: 50px; ime-mode: disabled">&nbsp;px&nbsp;&nbsp;&nbsp;
		高さ&nbsp;&nbsp;&nbsp;<input type="text" maxlength=3
			name="banner_height" id="banner_height"
			value="<?=htmlspecialchars($dat['banner_height'])?>"
			style="width: 50px; ime-mode: disabled">&nbsp;px</td>
	</tr>
	<tr id="template_id_tr" style="display: none;">
		<th style="width: 150px">使用テンプレート</th>
		<td>
				<?php
				echo mkcombobox($templateDat, "template_id", $dat['template_id']);
				?>
			</td>
	</tr>
	<tr>
		<th style="width: 150px">募集中バナー<span class="cms_require">（必須）</span></th>
		<td>
				<?php
				echo mkradiobutton($ADVERT_RECRUITMENT_FROM, "recruitment_from", $dat['recruitment_from']);
				?>
			</td>
	</tr>
</table>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px"></a> <a
	href="index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
<input type="hidden" id="area_id" name="area_id" value="<?=$area_id?>">
<input type="hidden" id="behavior" name="behavior"
	value="<?=$behavior?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
