<?php
/*
 * 広告掲載機能　初期表示画面
 */
/** require **/
require ("../.htsetting");
global $objCnc;
require ("../include/advertCommonFunc.inc");
require ("../include/advertAreaFunc.inc");
require ("../include/advertBannerFunc.inc");
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_advert_area.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_advert_banner.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_handler.inc');
$objAdArea = new tbl_advert_area($objCnc);
$objAdBanner = new tbl_advert_banner($objCnc);
$objHandler = new tbl_handler($objCnc);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>バナー管理</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(bv,area_id,banner_id) {
	switch(bv) {
		// 広告エリアクリック
		case 1:
			$('area_id').value = area_id;
			$('behavior').value = 4;
			$('ad_form').action = 'area_confirm.php';
			break;
		// 広告バナークリック
		case 2:
			$('area_id').value = area_id;
			$('banner_id').value = banner_id;
			$('behavior').value = 4;
			$('ad_form').action = '../banner/banner_confirm.php';
			break;
		// 表示順変更
		case 3:
			$('area_id').value = area_id;
			$('ad_form').action = 'sortorder.php';
			break;
		default:
			alert('パラメータエラー（behavior）');
			exit;
	}
	$('ad_form').submit();
	return false;
}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'advert';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="../images/bar_advert_setting.jpg" alt="バナー管理" width="920"
	height="30"></div>
<div class="cms8341-area-corner">
<?php
$objAdArea->select();
if ($objAdArea->getRowCount() == 0) {
	echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . "\n";
	echo '<tr><td>現在登録されている広告エリアはありません。</td></tr>' . "\n";
	echo '</table>' . "\n";
}
while ($objAdArea->fetch()) {
	$area_id = $objAdArea->fld['area_id'];
	$areaFld = $objAdArea->fld;
	echo '<div class="cms8341-advert-area"><a href="javascript:" onClick="return cxSubmit(1,' . $area_id . ')">' . htmlDisplay($areaFld['name']) . '</a></div>' . "\n";
	echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">' . "\n";
	echo '<tr><th align="center">ステータス</th><th align="center">広告バナー名称</th><th align="center">掲載期間</th></tr>' . "\n";
	$objAdBanner->selectFromAreaID($area_id);
	if ($objAdBanner->getRowCount() == 0) {
		echo '<tr><td colspan="3">現在登録されている広告バナーはありません。</td></tr>' . "\n";
	}
	while ($objAdBanner->fetch()) {
		$banner_id = $objAdBanner->fld['banner_id'];
		$bannerFld = $objAdBanner->fld;
		$statusAry = getBannerStatus($objAdBanner->fld);
		echo '<tr>' . "\n";
		echo '<td style="width:10%"><img src=' . RPW . '/admin/special/advert/images/status_' . $statusAry['id'] . '.jpg alt="' . $statusAry['name'] . '" bolder="0"></td>' . "\n";
		echo '<td style="width:60%"><a href="javascript:" onClick="return cxSubmit(2,' . $area_id . ',' . $banner_id . ')">' . htmlDisplay($bannerFld['name']) . '</a></td>' . "\n";
		echo '<td style="width:30%">' . dtFormat($bannerFld['publish_start']) . '～' . dtFormat($bannerFld['publish_end']) . '</td>' . "\n";
		echo '</tr>' . "\n";
	}
	echo '</table>' . "\n";
	echo '<p align="right" style="margin-top:10px"><a href="javascript:" onClick="return cxSubmit(3,' . $area_id . ')"><img src="' . RPW . '/admin/images/btn/btn_list.jpg" alt="表示順変更" width="101" height="21" border="0" style="margin-left:10px"></a></p>' . "\n";
}
?>
<form id="ad_form" class="cms8341-form" name="ad_form" method="post"
	action=""><input type="hidden" name="behavior" id="behavior" value="">
<input type="hidden" name="area_id" id="area_id" value=""> <input
	type="hidden" name="banner_id" id="banner_id" value=""></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
