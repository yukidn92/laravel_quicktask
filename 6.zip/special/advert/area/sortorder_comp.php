<?php
/*
 * 広告掲載機能　表示順変更実行
 */
/*--- 設定ファイル読み込み ---*/
require ("../.htsetting");
global $objCnc;
require ("../include/advertCommonFunc.inc");
require ("../include/advertBannerFunc.inc");

if (!isset($_POST['area_id'])) {
	advertError("不正なパラメータです。");
}

// トランザクション開始
$objCnc->begin();
//---画面項目の取得とチェック
$ArrItem = array();
foreach ($_POST as $banner_id => $sort_order) {
	if (!is_numeric($banner_id)) continue;
	// 必須チェック
	if ($sort_order == "") {
		advertError("表示順序の省略はできません。");
	}
	// 半角数値チェック
	if (!(preg_match("/^[0-9]+$/", $sort_order))) {
		advertError("表示順序は半角数値のみ有効です。");
	}
	$uAry = array(
			"area_id" => $_POST['area_id']
	);
	$uAry['banner_id'] = $banner_id;
	$uAry['sort_order'] = $sort_order;
	updateAdvertBanner($uAry);
}

// コミット
$objCnc->commit();

/*---一覧画面へと戻る---*/
header("Location: " . "./index.php");
?>
