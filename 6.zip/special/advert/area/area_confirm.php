<?php
/*
 * 広告掲載機能　広告エリア情報確認画面
 */
/** require **/
require ("../.htsetting");
require ("../include/advertCommonFunc.inc");
require ("../include/advertAreaFunc.inc");
require ("../include/advertBannerFunc.inc");
unset($_SESSION["hidden"]);
$ADVERT_DELIVERY_FROM = getDefineArray("ADVERT_DELIVERY_FROM");
$ADVERT_ORDER_FROM = getDefineArray("ADVERT_ORDER_FROM");
$ADVERT_RECRUITMENT_FROM = getDefineArray("ADVERT_RECRUITMENT_FROM");
if (!isset($_POST['behavior']) || !in_array($_POST['behavior'], array(
		ADVERT_ADD, 
		ADVERT_UPD, 
		ADVERT_DEL, 
		ADVERT_INF
))) {
	advertError("不正なパラメータです。");
}
$templateDat = getTemplateDB();
$behavior = $_POST["behavior"];
switch ($behavior) {
	case ADVERT_ADD :
	case ADVERT_UPD :
		$emptyDat = craeteEmptyAreaData();
		$dat = getAdvertAreaPost($_POST);
		$dat = array_merge($emptyDat, $dat);
		if ($behavior == ADVERT_UPD) $area_ary = getAdvertAreaDB($_POST['area_id']);
		break;
	case ADVERT_DEL :
	case ADVERT_INF :
		$emptyDat = craeteEmptyAreaData();
		$dat = getAdvertAreaDB($_POST['area_id']);
		$dat = array_merge($emptyDat, $dat);
		$source_code_str = createSourceStr($dat['source_code']);
		$usePageCnt = getUsePage($_POST['area_id']);
		$useLibraryAry = getUseLibrary($source_code_str);
		break;
}
checkAdvertArea($dat, $_POST['behavior']);
$_SESSION["hidden"] = $dat;

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>エリア設定確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(bv){
	switch(bv) {
		// エリア追加から
		case 1:
			$('behavior').value = bv;
			$('ad_form').action = 'area_submit.php';
			break;
		// エリア修正から
		case 2:
			$('behavior').value = bv;
			$('ad_form').action = 'area_submit.php';
			break;
		// エリア削除から
		case 3:
			if (!confirm("この広告エリア情報を削除します\nよろしいですか？")) {
				return false;
			}		
			$('behavior').value = bv;
			$('ad_form').action = 'area_submit.php';
			break;
		// エリア確認から
		case 4:
			$('behavior').value = bv;
			$('ad_form').action = 'area_form.php';
			break;
		default:
			alert('パラメータエラー（behavior）');
			exit;
	}
	$('ad_form').submit();
	return false;
}	
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'advert';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="../images/bar_advert_area_confirm.jpg" alt="エリア設定確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th style="width: 150px">エリア名称<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($dat['name'])?></td>
	</tr>
	<tr>
		<th>配信形式<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td>
				<?=htmlDisplay($ADVERT_DELIVERY_FROM[$dat['delivery_from']])?>
				<?=(isset($area_ary['delivery_from']) && $area_ary['delivery_from'] != $dat['delivery_from'] ? '<br /><span style="font-size:12px;color:#FF0000;">※配信形式を変更する場合は、このエリアが表示されている全てのページを再公開してください。</span>' : '')?>
			</td>
	</tr>
	<tr>
		<th>レイアウト<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td>
				行：&nbsp;&nbsp;&nbsp;<?=htmlDisplay($dat['layout_line'])?>&nbsp;&nbsp;&nbsp;
				列：&nbsp;&nbsp;&nbsp;<?=htmlDisplay($dat['layout_row'])?>
			</td>
	</tr>
	<tr>
		<th>表示順<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($ADVERT_ORDER_FROM[$dat['order_from']])?></td>
	</tr>
	<tr>
		<th>バナーサイズ<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td>
				幅：&nbsp;&nbsp;&nbsp;<?=htmlDisplay($dat['banner_width'])?>&nbsp;px&nbsp;&nbsp;&nbsp;
				高さ：&nbsp;&nbsp;&nbsp;<?=htmlDisplay($dat['banner_height'])?>&nbsp;px
			</td>
	</tr>
	<?php
	//CSVが選択されていた場合
	if ($dat['delivery_from'] == ADVERT_DELIVERY_FROM_CSV) {
		echo '<tr>';
		echo '<th>使用テンプレート</th>';
		echo '<td>' . htmlDisplay($templateDat[$dat['template_id']]) . '</td>';
		echo '</tr>';
	}
	?>
	<tr>
		<th>募集中バナー<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($ADVERT_RECRUITMENT_FROM[$dat['recruitment_from']])?></td>
	</tr>
<?php
if ($behavior == ADVERT_INF) {
	echo '<tr>';
	echo '<th>掲載ページ数</th>';
	echo '<td>' . $usePageCnt . 'ページ</td>';
	echo '</tr>';
}
?>
	</table>
<?php
if ($behavior == ADVERT_INF) {
	echo '<p style="margin-bottom:10px">広告エリア設定コード</p>';
	echo '<table width="100%" border="0" cellpadding="5" cellspacing="0" class="cms8341-dataTable">';
	echo '<tr>';
    echo '<td><textarea id="source" name="source" readonly="true" style="width:99%;height:100px;vertical-align:top;overflow:hidden;">' . htmlspecialchars($source_code_str) . '</textarea></td>';
	echo '</tr>';
	echo '</table>';
}
?>
	
	<p align="center">
<?php
switch ($behavior) {
	case ADVERT_ADD :
		echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_ADD . ')"><img src="' . RPW . '/admin/images/btn/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
	case ADVERT_UPD :
		echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_UPD . ')"><img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
	case ADVERT_DEL :
		break;
	case ADVERT_INF :
		$del_btn = FLAG_ON;
		echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_INF . ')"><img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px"></a>';
		$bannerAry = getAdvertBannerAll($dat['area_id']);
		if (count($bannerAry) > 0 || $usePageCnt > 0 || count($useLibraryAry) > 0) {
			echo '<img src="' . RPW . '/admin/images/btn/btn_del_off.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px">';
		}
		else {
			echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_DEL . ')"><img src="' . RPW . '/admin/images/btn/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px"></a>';
		}
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_back.jpg" alt="戻る" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
}
?>	
	</p>
<form id="ad_form" class="cms8341-form" name="ad_form" method="post"
	action=""><input type="hidden" id="behavior" name="behavior"
	value="<?=$behavior?>"> <input type="hidden" id="area_id"
	name="area_id" value="<?=$dat['area_id']?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
