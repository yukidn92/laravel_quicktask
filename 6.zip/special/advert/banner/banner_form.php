<?php
/*
 * 広告掲載機能　広告バナー追加画面
 */
/** require **/
require ("../.htsetting");
require ("../include/advertCommonFunc.inc");
require ("../include/advertBannerFunc.inc");
$ADVERT_BANNER_TYPE = getDefineArray("ADVERT_BANNER_TYPE");
$ADVERT_BANNER_STATUS = getDefineArray("ADVERT_BANNER_STATUS");
$AREA_ARY = getAdvertAreaAll();

if (!isset($_GET["back"])) {
	//main
	$behavior = (!isset($_POST["behavior"])) ? ADVERT_ADD : ADVERT_UPD;
	$area_id = (isset($_POST['area_id'])) ? $_POST['area_id'] : "";
	$banner_id = (isset($_POST['banner_id'])) ? $_POST['banner_id'] : "";
	$emptyDat = craeteEmptyBannerData();
	$dat = getAdvertBannerDB($area_id, $banner_id);
	$dat = array_merge($emptyDat, $dat);
}
else {
	$dat = $_SESSION['hidden'];
	$behavior = ADVERT_ADD;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>バナー設定</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/calendar.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(){
	// 入力チェック
	if (!isRadioSelect('banner_type', "バナー種別")) {
		return false;
	}
	if(!isEmpty('name',"バナー名称")) return false;
	if(!isSelect('area_id',"広告エリア")) return false;
	if(!isEmpty('link_url',"リンクURL")) return false;
	var banner_type_form = document.getElementsByName("banner_type");
	for (var i = 0; i < banner_type_form.length; i++) {
		if (banner_type_form[i].checked){
			//画像バナーの場合
			if (banner_type_form[i].value == 1) {
				if (!isImage('image_path', "バナー画像")) {
					return false;
				}
				if (!isEmpty('image_alt', "バナーALT")) {
					return false;
				}
			}
			//テキストバナーの場合
			else {
				if (!isEmpty('text_banner_text', "バナーテキスト")) {
					return false;
				}
			}
		}
	}
	if(!isDate('pd',"掲載")) return false;
	if(!isRadioSelect('status',"ステータス")) return false;
	$('ad_form').submit();
	return false;
}	
// 空チェック
function isEmpty(id,name){
	if($F(id) == ""){
		alert(name+"が入力されていません");
		$(id).focus();
		return false;
	}
	return true;
}
// 選択チェック(プルダウン)
function isSelect(id,name){
	if($F(id) == ""){
		alert(name+"が選択されていません");
		$(id).focus();
		return false;
	}
	return true;
}
//選択チェック(ラジオボタン)
function isRadioSelect(id,name){
	if (isSelectCheck(id) != true) {
		var select = document.getElementsByName(id);
		alert(name+"が選択されていません")
		if (select[0]) select[0].focus();
		return false;
	}
	return true;
}
// 数字チェック
function isNumric(id,name){
	if(!cxDateNumeric($F(id)) || $F(id) < 1){
		alert(name+"は１以上の数字を入力してください");
		$(id).focus();
		return false;
	}
	return true;
}
// 日付チェック
function isDate(id,name){
	if($F(id+'sy') == "" || $F(id+'sm') == "" || $F(id+'sd') == ""){
		alert(name+"開始日が入力されていません");
		$(id+'sy').focus();
		return false;
	}
	if($F(id+'ey') == "" || $F(id+'em') == "" || $F(id+'ed') == ""){
		alert(name+"終了日が入力されていません");
		$(id+'ey').focus();
		return false;
	}
	dc = cxDateCheckNew(id, 'ymd', 1, name);
	msg = new Array();
	msg = msg.concat(dc);
	if (msg.length > 0) {
		msg_str = msg.join('\n');
		alert(msg_str);
		$(id+'sy').focus();
		return false;
	}
	return true;
}
// 画像チェック
function isImage(id,name){
	if ($(id).value == "") {
		if ($('image_path_upd') && $('image_path_upd').value != "") {
			$(id).disabled = true;
			return true;
		}
		alert(name+"が選択されていません");
		$(id).focus();
		return false;
	}	pos = $(id).value.lastIndexOf("\\");
	file = $(id).value.slice(pos+1);
	if(!file.match(/^[0-9a-zA-Z\.\-_]+$/)){ 
		alert(name+"は半角英数字にしてください");
		$(id).focus();
		return false;
	}
	pos = file.lastIndexOf(".");
	exp = file.slice(pos+1);
	if(!exp.match(/jpg|jpeg|png|gif|bmp/i)){
		alert(name+"の登録できる画像は以下のものを指定してください。\n jpg、jpeg、png、gif、bmp");
		$(id).focus();
		return false;
	}
	return true;
}
//バナー種別を変更した場合
function cngBannerType(){
	//バナー種別に画像を選択していた場合
	if ($('banner_type_1').checked) {
		//無効にする
		$('text_banner_text_tr').style.display = 'none';
		$('text_banner_details_tr').style.display = 'none';
		//有効にする
		$('img_banner_image_tr').style.display = '';
		$('img_banner_alt_tr').style.display = '';
	}
	//それ以外の場合
	else {
		//無効にする
		$('img_banner_image_tr').style.display = 'none';
		$('img_banner_alt_tr').style.display = 'none';
		//有効にする
		$('text_banner_text_tr').style.display = '';
		$('text_banner_details_tr').style.display = '';
	}
	return true;
}
window.addEventListener('load', cngBannerType);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'advert';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="../images/bar_advert_banner_form.jpg" alt="バナー設定"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<form id="ad_form" class="cms8341-form" name="ad_form" method="post"
	action="banner_confirm.php" enctype="multipart/form-data">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th style="width: 150px">バナー種別<span class="cms_require">（必須）</span></th>
		<td>
			<?php
			echo mkradiobutton($ADVERT_BANNER_TYPE, "banner_type", $dat['banner_type'], 0, '', 'cngBannerType();');
			?>
		</td>
	</tr>
	<tr>
		<th style="width: 150px">バナー名称<span class="cms_require">（必須）</span></th>
		<td><input type="text" name="name" id="name"
			value="<?=htmlspecialchars($dat['name'])?>" style="width: 400px"></td>
	</tr>
	<tr>
		<th style="width: 150px">広告エリア<span class="cms_require">（必須）</span></th>
		<td>
				<?php
				if ($behavior == ADVERT_UPD) {
					echo htmlDisplay($AREA_ARY[$dat['area_id']]);
				}
				else {
					echo mkcombobox($AREA_ARY, "area_id", $dat['area_id']);
				}
				?>
			</td>
	</tr>
	<tr>
		<th style="width: 150px">リンクURL<span class="cms_require">（必須）</span></th>
		<td><input type="text" name="link_url" id="link_url"
			value="<?=htmlspecialchars($dat['link_url'])?>" style="width: 400px"></td>
	</tr>
	<tr id="img_banner_image_tr" style="display: none;">
		<th style="width: 150px">バナー画像<span class="cms_require">（必須）</span></th>
		<td><input type="file" name="image_path" id="image_path" value=""
			style="width: 400px">
				<?php
				if ($behavior == ADVERT_UPD && isset($dat['image_path']) && $dat['image_path'] != "") {
					echo '<br><img src="' . $dat['image_path'] . '?rnd=' . rand() . '">';
				}
				?>
			</td>
	</tr>
	<tr id="img_banner_alt_tr" style="display: none;">
		<th style="width: 150px">バナーALT<span class="cms_require">（必須）</span></th>
		<td><input type="text" name="image_alt" id="image_alt"
			value="<?=htmlspecialchars($dat['image_alt'])?>" style="width: 400px">
		</td>
	</tr>
	<tr id="text_banner_text_tr" style="display: none;">
		<th style="width: 150px">バナーテキスト<span class="cms_require">（必須）</span></th>
		<td><input type="text" name="text_banner_text" id="text_banner_text"
			value="<?=htmlspecialchars($dat['text_banner_text'])?>"
			style="width: 400px"></td>
	</tr>
	<tr id="text_banner_details_tr" style="display: none;">
		<th style="width: 150px">詳細テキスト</th>
		<td><textarea id="text_banner_details" name="text_banner_details"
			style="width: 400px;" rows="5"><?=htmlspecialchars($dat['text_banner_details'])?></textarea>
		</td>
	</tr>
	<tr>
		<th>掲載開始日<span class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
				<?php
				if ($dat['publish_start'] != "") {
					$publish_start = strtotime($dat['publish_start']);
					$y = date("Y", $publish_start);
					$m = date("n", $publish_start);
					$d = date("j", $publish_start);
				}
				else {
					$y = "";
					$m = "";
					$d = "";
				}
				?>
				<input type="text" maxlength="4" id="pdsy" name="pdsy"
			value="<?=htmlspecialchars($y)?>"
			style="width: 60px; ime-mode: disabled">年 <input type="text"
			maxlength="2" id="pdsm" name="pdsm" value="<?=htmlspecialchars($m)?>"
			style="width: 40px; ime-mode: disabled">月 <input type="text"
			maxlength="2" id="pdsd" name="pdsd" value="<?=htmlspecialchars($d)?>"
			style="width: 40px; ime-mode: disabled">日 <a href="javascript:"
			onClick="return cxCalendarOpen('pd','start')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a></td>
	</tr>
	<tr>
		<th>掲載終了日<span class="cms_require">（必須）</span></th>
		<td align="left" valign="middle">
				<?php
				if ($dat['publish_end'] != "") {
					$publish_end = strtotime($dat['publish_end']);
					$y = date("Y", $publish_end);
					$m = date("n", $publish_end);
					$d = date("j", $publish_end);
				}
				else {
					$y = "";
					$m = "";
					$d = "";
				}
				?>
				<input type="text" maxlength="4" id="pdey" name="pdey"
			value="<?=htmlspecialchars($y)?>"
			style="width: 60px; ime-mode: disabled">年 <input type="text"
			maxlength="2" id="pdem" name="pdem" value="<?=htmlspecialchars($m)?>"
			style="width: 40px; ime-mode: disabled">月 <input type="text"
			maxlength="2" id="pded" name="pded" value="<?=htmlspecialchars($d)?>"
			style="width: 40px; ime-mode: disabled">日 <a href="javascript:"
			onClick="return cxCalendarOpen('pd','end')"><img
			src="<?=RPW?>/admin/images/icon/icon_calendar.jpg" alt="カレンダーで設定する"
			width="14" height="17" border="0" align="absmiddle"></a></td>
	</tr>
	<tr>
		<th>ステータス<span class="cms_require">（必須）</span></th>
		<td>
				<?php
				echo mkradiobutton($ADVERT_BANNER_STATUS, "status", $dat['status'], 0);
				?>
			</td>
	</tr>

</table>
<p align="center"><a href="javascript:" onClick="return cxSubmit()"><img
	src="<?=RPW?>/admin/images/btn/btn_conf.jpg" alt="確認" width="150"
	height="20" border="0" style="margin-right: 10px"></a> <a
	href="../area/index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル"
	width="150" height="20" border="0" style="margin-left: 10px"></a></p>
	<?php
	if ($behavior == ADVERT_UPD) {
		?>
	<input type="hidden" id="area_id" name="area_id"
	value="<?=$dat['area_id']?>"> <input type="hidden" id="image_path_upd"
	name="image_path_upd" value="<?=htmlspecialchars($dat['image_path'])?>">
	<?php
	}
	?>
	<input type="hidden" id="banner_id" name="banner_id"
	value="<?=$dat['banner_id']?>"> <input type="hidden" id="behavior"
	name="behavior" value="<?=$behavior?>"></form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<!--***カレンダーレイヤー　　　 ここから********************************-->
<div id="cms8341-calendar" class="cms8341-layer">
<table width="500" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="500" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="500" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/images/calendar/title_calendar.jpg" alt="カレンダー"
					width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="javascript:"
					onClick="return cxCalendarClose()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>
		<div style="width: 100%;">
		<div id="cms8341-calbody"
			style="width: 480px; height: 450px; overflow: visible; border: solid 1px #999; background-color: #FFF; margin-bottom: 10px;"></div>
		</div>
		</td>
	</tr>
</table>
</div>
<!--***カレンダーレイヤー　　　 ここまで********************************-->
</body>
</html>
