<?php
/*
 * 広告掲載機能　広告バナー設定完了画面
 */
/** require **/
require ("../.htsetting");
require ("../include/advertCommonFunc.inc");
require ("../include/advertBannerFunc.inc");
$ADVERT_BANNER_STATUS = getDefineArray("ADVERT_BANNER_STATUS");
if (!isset($_POST["behavior"])) {
	advertError("パラメータが不正です。");
}
$dat = $_SESSION["hidden"];
checkAdvertBanner($dat, $_POST['behavior']);
switch ($_POST['behavior']) {
	// 追加
	case ADVERT_ADD :
		$dat['banner_id'] = getBannerId($dat['area_id']);
		//画像バナーの場合
		if ($dat['banner_type'] == ADVERT_BANNER_TYPE_IMAGE) {
			copyImage($dat);
		}
		insertAdvertBanner($dat);
		break;
	// 修正
	case ADVERT_UPD :
		//画像バナーの場合
		if ($dat['banner_type'] == ADVERT_BANNER_TYPE_IMAGE) {
			if ($_POST['isUpload'] == FLAG_ON) {
				copyImage($dat);
			}
		}
		updateAdvertBanner($dat);
		break;
	// 削除
	case ADVERT_DEL :
		deleteAdvertBanner($dat['area_id'], $dat['banner_id'], $dat['image_path']);
		break;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>バナー設定完了</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'advert';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="../images/bar_advert_banner_submit.jpg" alt="バナー設定完了"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<?php
if ($_POST['behavior'] != ADVERT_DEL) {
	echo '<p align="center">広告バナーの設定が完了しました。</p>';
}
else {
	echo '<p align="center">広告バナーの削除が完了しました。</p>';
}
?>	
	<p align="center"><a href="../area/index.php"><img
	src="<?=RPW?>/admin/images/btn/btn_back.jpg" alt="戻る" width="150"
	height="20" border="0" style="margin-right: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
