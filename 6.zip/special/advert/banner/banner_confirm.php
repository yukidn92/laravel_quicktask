<?php
/*
 * 広告掲載機能　広告バナー情報確認画面
 */
/** require **/
require ("../.htsetting");
require ("../include/advertCommonFunc.inc");
require ("../include/advertBannerFunc.inc");
require ("../include/advertAreaFunc.inc");
unset($_SESSION["hidden"]);
if (!isset($_POST['behavior']) || !in_array($_POST['behavior'], array(
		ADVERT_ADD, 
		ADVERT_UPD, 
		ADVERT_DEL, 
		ADVERT_INF
))) {
	advertError("不正なパラメータです。");
}

$behavior = $_POST["behavior"];
$ADVERT_BANNER_TYPE = getDefineArray("ADVERT_BANNER_TYPE");
$ADVERT_BANNER_STATUS = getDefineArray("ADVERT_BANNER_STATUS");
$AREA_ARY = getAdvertAreaAll();
switch ($behavior) {
	case ADVERT_ADD :
		$emptyDat = craeteEmptyBannerData();
		$dat = getAdvertBannerPost($_POST);
		$dat = array_merge($emptyDat, $dat);
		//画像バナーの場合
		if ($dat['banner_type'] == ADVERT_BANNER_TYPE_IMAGE) {
			$file_name = bannerUpload();
			$dat['image_path'] = $_POST['area_id'] . "/" . $file_name;
			$image_path = DIR_PATH_TEMP . $objLogin->get('user_id') . '/' . $file_name;
		}
		break;
	case ADVERT_UPD :
		$emptyDat = craeteEmptyBannerData();
		$dat = getAdvertBannerPost($_POST);
		$dat = array_merge($emptyDat, $dat);
		//画像バナーの場合
		if ($dat['banner_type'] == ADVERT_BANNER_TYPE_IMAGE) {
			$file_name = bannerUpload();
			if ($file_name === FALSE) {
				$dat['image_path'] = $_POST['image_path_upd'];
				$image_path = $_POST['image_path_upd'];
				$isUpload = FLAG_OFF;
			}
			else {
				$dat['image_path'] = $_POST['area_id'] . "/" . $file_name;
				$image_path = DIR_PATH_TEMP . $objLogin->get('user_id') . '/' . $file_name;
				$isUpload = FLAG_ON;
			}
		}
		else {
			$isUpload = FLAG_OFF;
		}
		break;
	case ADVERT_DEL :
	case ADVERT_INF :
		$emptyDat = craeteEmptyBannerData();
		$dat = getAdvertBannerDB($_POST['area_id'], $_POST['banner_id']);
		$dat = array_merge($emptyDat, $dat);
		//画像バナーの場合
		if ($dat['banner_type'] == ADVERT_BANNER_TYPE_IMAGE) {
			$image_path = $dat['image_path'];
		}
		break;
}
checkAdvertBanner($dat, $_POST['behavior']);
$_SESSION["hidden"] = $dat;
$areaInfo = getAdvertAreaDB($dat['area_id']);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>バナー設定確認</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/special/advert/advert.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
function cxSubmit(bv){
	switch(bv) {
		// バナー追加から
		case 1:
			$('behavior').value = bv;
			$('ad_form').action = 'banner_submit.php';
			break;
		// バナー修正から
		case 2:
			$('behavior').value = bv;
			$('ad_form').action = 'banner_submit.php';
			break;
		// バナー削除から
		case 3:
			if(!confirm("この広告バナー情報を削除します\nよろしいですか？")) return false;
			$('behavior').value = bv;
			$('ad_form').action = 'banner_submit.php';
			break;
		// バナー確認から
		case 4:
			$('behavior').value = bv;
			$('ad_form').action = 'banner_form.php';
			break;
		default:
			alert('パラメータエラー（behavior）');
			break;
	}
	$('ad_form').submit();
	return false;
}	
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'advert';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-templates">
<div><img src="../images/bar_advert_banner_confirm.jpg" alt="バナー設定確認"
	width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr>
		<th style="width: 150px">バナー種別<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($ADVERT_BANNER_TYPE[$dat['banner_type']])?></td>
	</tr>
	<tr>
		<th style="width: 150px">バナー名称<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($dat['name'])?></td>
	</tr>
	<tr>
		<th>広告エリア<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($AREA_ARY[$dat['area_id']])?></td>
	</tr>
	<tr>
		<th>リンクURL<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><a href="<?=htmlspecialchars($dat['link_url'])?>" target="_blank"><?=htmlDisplay($dat['link_url'])?></a></td>
	</tr>
	<?php
	//画像バナーの場合
	if ($dat['banner_type'] == ADVERT_BANNER_TYPE_IMAGE) {
		?>
	<tr>
		<th>バナー画像<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><img src="<?=$image_path . "?rnd=" . rand()?>" border="0"
			alt="<?=htmlDisplay($dat['image_alt'])?>">
			<?php
			if (@file_exists(DOCUMENT_ROOT . $image_path)) {
				$sizeInfo = getimagesize(DOCUMENT_ROOT . $image_path);
				$width = $sizeInfo[0];
				$height = $sizeInfo[1];
				if ($height != $areaInfo['banner_height']) {
					echo '<br><span style="font-size:90%;color:red;font-weight:bold">バナー画像の高さが規定の値(' . $areaInfo['banner_height'] . ')とは違うため表示が崩れる場合があります。</span>';
				}
				if ($width != $areaInfo['banner_width']) {
					echo '<br><span style="font-size:90%;color:red;font-weight:bold">バナー画像の幅が規定の値(' . $areaInfo['banner_width'] . ')とは違うため表示が崩れる場合があります。</span>';
				}
			}
			?>
		</td>
	</tr>
	<tr>
		<th>バナーALT<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($dat['image_alt'])?></td>
	</tr>
	<?php
	}
	?>
	<?php
	//画像バナーの場合
	if ($dat['banner_type'] == ADVERT_BANNER_TYPE_TEXT) {
		?>
	<tr>
		<th>バナーテキスト<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($dat['text_banner_text'])?></td>
	</tr>
	<tr>
		<th>詳細テキスト</th>
		<td>
		<?php
		echo escapeBannerDetails($dat['text_banner_details']);
		?>
		</td>
	</tr>
	<?php
	}
	?>
	<tr>
		<th>掲載開始日<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay(dtFormat($dat['publish_start']))?></td>
	</tr>
	<tr>
		<th>掲載終了日<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay(dtFormat($dat['publish_end']))?></td>
	</tr>
	<tr>
		<th>ステータス<?=(($behavior == ADVERT_ADD || $behavior == ADVERT_UPD) ? '<span class="cms_require">（必須）</span>' : '')?></th>
		<td><?=htmlDisplay($ADVERT_BANNER_STATUS[$dat['status']])?></td>
	</tr>
</table>

<p align="center">
<?php
switch ($behavior) {
	case ADVERT_ADD :
		echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_ADD . ')"><img src="' . RPW . '/admin/images/btn/btn_add.jpg" alt="追加" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="./banner_form.php?back=1"><img src="' . RPW . '/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
	case ADVERT_UPD :
		echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_UPD . ')"><img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_cansel_large.jpg" alt="キャンセル" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
	case ADVERT_DEL :
		break;
	case ADVERT_INF :
		echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_INF . ')"><img src="' . RPW . '/admin/images/btn/btn_fix.jpg" alt="修正" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="javascript:" onClick="return cxSubmit(' . ADVERT_DEL . ')"><img src="' . RPW . '/admin/images/btn/btn_del.jpg" alt="削除" width="150" height="20" border="0" style="margin-right:10px"></a>';
		echo '<a href="javascript:history.back();"><img src="' . RPW . '/admin/images/btn/btn_back.jpg" alt="戻る" width="150" height="20" border="0" style="margin-left:10px"></a>';
		break;
}
?>	
	</p>
<form id="ad_form" class="cms8341-form" name="ad_form" method="post"
	action=""><input type="hidden" id="behavior" name="behavior"
	value="<?=$behavior?>"> <input type="hidden" id="area_id"
	name="area_id" value="<?=$dat['area_id']?>"> <input type="hidden"
	id="banner_id" name="banner_id" value="<?=$dat['banner_id']?>">
		<?php
		if ($behavior == ADVERT_UPD) {
			?>
		<input type="hidden" id="isUpload" name="isUpload"
	value="<?=$isUpload?>">
		<?php
		}
		?>
	</form>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
</body>
</html>
