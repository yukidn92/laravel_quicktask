<?php
/*
 *
 */

/** require **/
require ("../.htsetting");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>アンケート集計</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<style type="text/css">
#cms8341-enqsettingarea {
	width: 485px;
	height: 565px;
	overflow: scroll;
	margin: 10px 0px;
	background-color: #FFFFFF;
	padding: 9px 19px 0px 19px;
	text-align: left;
	border: solid 1px #999999;
	font-size: 14px;
}
</style>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
//
function cxDetail() {
	window.dialogArguments = window.frameElement.args;
	var argAry = window.dialogArguments;
	page_id = argAry[0];
	enquete_id = argAry[1];
	title = argAry[2];
	var prm = 'page_id='+page_id+'&enquete_id='+enquete_id;
	cxAjaxCommand('cxEnqueteDetail', prm, cxEnqueteDetailDisp);
	$('cms_title').innerHTML = title;
	return false;
}
//認証OK処理
function cxEnqueteDetailDisp(r) {
	var rText = r.responseText;
	$('cms_enq_detail').innerHTML = rText;
}
//通信失敗処理
function cxFailure() {
	$('cms_enq_detail').innerHTML = '<p align="center">エラーが発生しました</p>';
}
Event.observe(window,'load',cxDetail,false);
//-->
</script>
</head>

<body id="cms8341-mainbg">
<table width="542" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="542" align="center" valign="top" bgcolor="#DFDFDF"
			style="border: solid 1px #343434;">
		<table width="542" border="0" cellspacing="0" cellpadding="0"
			class="cms8341-layerheader">
			<tr>
				<td align="left" valign="middle"><img
					src="<?=RPW?>/admin/special/enquete/enqtotal/images/title_enqtotal_mini.jpg"
					alt="アンケート集計" width="200" height="20" style="margin: 4px 10px;"></td>
				<td width="78" align="right" valign="middle"><a href="#"
					id="header_close" onclick="cxIframeLayerCallback()"><img
					src="<?=RPW?>/admin/images/btn/btn_close.jpg" alt="閉じる" width="58"
					height="19" border="0" style="margin: 4px 10px;"></a></td>
			</tr>
		</table>

		<div id="cms8341-enqsettingarea">
		<p id="cms_title"></p>
		<div style="width: 468px">
		<div id="cms_enq_detail"></div>
		</div>

		</div>
		</div>

</body>
</html>
