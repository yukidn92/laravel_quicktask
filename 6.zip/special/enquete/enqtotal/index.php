<?php
/*
 *
 */
/** require **/
require ("../.htsetting");
//function
unset($_SESSION["hidden"]);
$html = "";
$page = (isset($_POST['cms_page']) && is_numeric($_POST['cms_page']) ? floor($_POST['cms_page']) : 1);
$row_cnt = 0;
$MAXROW_LIST = getDefineArray("MAXROW_LIST");
$maxRow = (isset($_POST['maxrow']) && is_numeric($_POST['maxrow']) ? floor($_POST['maxrow']) : key($MAXROW_LIST));
//list format
$fmt = '<tr>' . "\n";
$fmt .= '<td align="left" valign="top">' . "\n";
$fmt .= '<p><strong><span id="{id}_title"><a href="javascript:" onClick="return cxPreview(\'enq_form\',\'{id}\',\'1\')">{page_title}</a></span></strong></p>' . "\n";
$fmt .= '<p><small>ステータス：<img src="{status_url}" alt="{status_alt}" class="cms8341-verticalMiddle"></small></p>' . "\n";
$fmt .= '<p><small>公開期間：{publish_date}</small></p>' . "\n";
$fmt .= '<p><small><img src="' . RPW . '/admin/images/btn/btn_pubpage.jpg" alt="公開中ページ" width="80" height="20" class="cms8341-verticalMiddle"> <a href="{url}" target="_blank">{url}</a></small></p>' . "\n";
;
$fmt .= '</td>' . "\n";
$fmt .= '<td align="center" valign="middle" width="175">' . "\n";
$fmt .= '<a href="javascript:" onClick="return cxSubmit(\'{id}\')" {img_disp}><img src="' . RPW . '/admin/special/enquete/images/btn_total.jpg" width="150" height="20" border="0" alt="集計" vspace="2"></a><br>' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '</tr>' . "\n";

// ログイン情報
$login = $objLogin->login;

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
require_once (APPLICATION_ROOT . '/common/dbcontrol/page_control.inc');
$objP = new page_control();
$where = "p.user_id = u.user_id";
$where .= " AND " . $objPage->_addslashesC("template_kind", TEMPLATE_KIND_ENQUETE, "=");
$where .= " AND " . $objPage->_addslashesC("enquete_kind", ENQ_KIND_CGI, "=");
$where .= " AND " . $objPage->_addslashesC("work_class", WORK_CLASS_PUBLISH . "," . WORK_CLASS_DELETE, "IN");
switch ($login['class']) {
	case USER_CLASS_WRITER :
		$where .= "AND u.user_id = '" . $login['user_id'] . "' AND u.dept_code = '" . $login['dept_code'] . "'";
		break;
	case USER_CLASS_APPROVER1 :
		$where .= "AND u.dept_code = '" . $login['dept_code'] . "'";
		break;
	case USER_CLASS_APPROVER2 :
		$where .= "AND CONCAT(LEFT(u.dept_code, " . (CODE_DIGIT_DEPT * 2) . "), '" . str_repeat('0', CODE_DIGIT_DEPT) . "') = '" . $login['dept_code'] . "'";
		break;
	case USER_CLASS_APPROVER3 :
		$where .= "AND CONCAT(LEFT(u.dept_code, " . CODE_DIGIT_DEPT . "), '" . str_repeat('0', (CODE_DIGIT_DEPT * 2)) . "') = '" . $login['dept_code'] . "'";
		break;
}

$objPage->setTableName("tbl_publish_page as p,tbl_user as u");

//全件数取得
$row_cnt = $objPage->getCount($where, $objPage->table_name);
//取得件数を指定し再取得
$objP->limit = $maxRow;
$objP->set($page, $row_cnt);
$objPage->select($where, "*", "page_id desc", $objP->getOffset(), $objP->getLimit());
if ($objPage->getRowCount() > 0) {
	while ($objPage->fetch()) {
		$page_title = $objPage->fld['page_title'];
		$status_url = ($objPage->fld['close_flg'] == FLAG_ON) ? RPW . "/admin/images/treelist/stat_close_work.jpg" : RPW . "/admin/images/treelist/stat_public.jpg";
		$status_alt = ($objPage->fld['close_flg'] == FLAG_ON) ? "非公開中" : "公開中";
		$publish_start = dtFormat($objPage->fld['publish_start'], 'Y年m月d日H時');
		$publish_end = get_publish_end_date($objPage->fld['publish_end']);
		$page_id = $objPage->fld['page_id'];
		$img_disp = ($objPage->fld['enquete_status'] == '100') ? 'style="display:none"' : '';
		//
		$tmp = $fmt;
		//
		$tmp = str_replace('{page_title}', htmlspecialchars($page_title), $tmp);
		$tmp = str_replace('{status_url}', $status_url, $tmp);
		$tmp = str_replace('{status_alt}', $status_alt, $tmp);
		$tmp = str_replace('{publish_date}', htmlspecialchars($publish_start) . 'から' . htmlspecialchars($publish_end) . 'まで', $tmp);
		$tmp = str_replace('{id}', $page_id, $tmp);
		$tmp = str_replace('{img_disp}', htmlspecialchars($img_disp), $tmp);
		$tmp = str_replace('{url}', htmlspecialchars(HTTP_REAL_ROOT . $objPage->fld['file_path']), $tmp);
		$html .= $tmp;
	}
}
else {
	$html = '<tr><td align="center" valign="top">現在、アンケートは登録されていません。</td></tr>';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>アンケート集計</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/enqtotal.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/common_action.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
	var cms_prev_layer;
	//
	function cxSubmit(id){
		$('cms_page_id').value = id;
		$('enq_form').action = cms8341admin_path+'/special/enquete/enqtotal/confirm.php';
		$('enq_form').target = '_self';
		$('enq_form').submit();
		return false;
	}

	/**
	 * ページ番号をPOSTする
	 * @param page ページ番号
	 * @return false
	 */
	function cxPageSet(page){
		$('cms_page_post').cms_page.value = page;
		$('cms_page_post').maxrow.value = $('dispNum').value;
		$('cms_page_post').submit();
		return false;
	}
	
	/**
	 * 表示件数を変える
	 * @param prev_num 表示件数
	 * @return false
	 */
	function cxDispNum(prev_num){
		$('cms_page_post').cms_page.value = 1;
		$('cms_page_post').maxrow.value = prev_num;
		$('cms_page_post').submit();
		return false;
	}
//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'enquete';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-enqtotal">
<div><img
	src="<?=RPW?>/admin/special/enquete/enqtotal/images/title_enqtotal.jpg"
	alt="アンケート集計" width="920" height="30"></div>
<div class="cms8341-area-corner-page-count"
	style="text-align: center; padding: 20px 40px 0px 40px;">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr valign="top">
		<td colspan="3" align="right">
			<?php
			if ($row_cnt > 0) print(mkcombobox($MAXROW_LIST, "dispNum", $maxRow, "cxDispNum(this.value)"));
			?>
		</td>
	</tr>
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objP->getNextLink()?></td>
	</tr>
</table>
</div>
<div class="cms8341-area-corner" style="padding: 0px 40px 0px 40px;">
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
	<tr align="center">
		<th>アンケート内容</th>
		<th>集計情報</th>
	</tr>
<?=$html?>
</table>
</div>
<div class="cms8341-area-corner-page-count" style="text-align: center;">
<table width="100%" border="0" cellspacing="0" cellpadding="0"
	style="margin-bottom: 10px; padding: 1px">
	<tr>
		<td width="30%" align="left" valign="middle" scope="row"><?=$objP->getBackLink()?></td>
		<td width="40%" align="center" valign="middle"><?=$objP->getViewCount()?></td>
		<td width="30%" align="right" valign="middle"><?=$objP->getNextLink()?></td>
	</tr>
</table>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="enq_form" class="cms8341-form" name="enq_form"
	action="confirm.php" method="post"><input type="hidden"
	id="cms_page_id" name="cms_page_id" value=""> <input type="hidden"
	id="cms_dispMode" name="cms_dispMode" value=""></form>
<form name="cms_page_post" id="cms_page_post" method="post" action=""><input
	type="hidden" name="cms_page" id="cms_page" value=""> <input
	type="hidden" name="maxrow" id="maxrow" value=""></form>
</body>
</html>
