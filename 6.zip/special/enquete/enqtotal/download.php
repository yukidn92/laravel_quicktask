<?php
/*
 *
 */
/** require **/
require ("../.htsetting");

if (!isset($_POST['page_id']) || !isset($_POST['page_title'])) {
	user_error("必要なパラメーターが指定されていません。");
	exit();
}
$PID = $_POST['page_id'];
$csvData = "";
$csvHeader = "";
// CSV読み込み
$csv_file = DOCUMENT_ROOT . DIR_PATH_ENQUETECSV . $PID . ".csv";
//ファイルを開く
if (!($CsvFno = fopen($csv_file, 'r'))) {
	//エラーページの表示
	exit();
}
while ($datas = cms_fgetcsv($CsvFno, 200000)) {
	$line = "";
	foreach ($datas as $data) {
		$sep = ($line == "") ? "" : ",";
		$line .= $sep . str_replace("\\\\", "\\", csvWrite($data, "\""));
	}
	$csvData .= $line . "\n";
}

require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
$objEnq = new tbl_enquete($objCnc);
$objEnq->selectFromPID($PID);

if ($objEnq->getRowCount() > 0) {
	$line = "";
	while ($objEnq->fetch()) {
		$line .= ($line == "") ? "" : ",";
		$line .= csvWrite($objEnq->fld['name'], "\"");
	}
	$csvHeader .= $line;
}
$csvHeader .= ($csvHeader != "") ? ',' : '"';
$csvHeader .= '"回答日時"';
$csvHeader .= "\n";

//ファイルの名前に使えない文字置き換え
$ary = array();
$ary[] = '\\';
$ary[] = '/';
$ary[] = ':';
$ary[] = '*';
$ary[] = '?';
$ary[] = '"';
$ary[] = '<';
$ary[] = '>';
$ary[] = '|';

$ary2 = array();
$ary2[] = '￥';
$ary2[] = '／';
$ary2[] = '：';
$ary2[] = '＊';
$ary2[] = '？';
$ary2[] = '”';
$ary2[] = '＜';
$ary2[] = '＞';
$ary2[] = '｜';

//SJISで文字化けする文字を置き換え
$ary3 = array();
$ary3[] = 'ℓ';
$ary3[] = '®';
$ary3[] = '㎥';
$ary3[] = '㎠';
$ary3[] = '㎤';
$ary3[] = '㎖';
$ary3[] = '㏔';
$ary3[] = '㎢';
$ary3[] = '㎳';

$ary4 = array();
$ary4[] = 'l';
$ary4[] = 'R';
$ary4[] = 'm3';
$ary4[] = 'cm2';
$ary4[] = 'cm3';
$ary4[] = 'ml';
$ary4[] = 'mb';
$ary4[] = 'km3';
$ary4[] = 'ms';

$fileName = $_POST['page_title'];
$fileName = str_replace($ary, $ary2, $fileName);
$fileName = str_replace($ary3, $ary4, $fileName);

/*---一覧画面へと戻る---*/
$fileName = UTF8toSJIS($fileName) . "_" . date('Y') . date('n') . date('j') . date('H') . date('i') . ".csv";
header("Content-Disposition: attachment; filename=" . $fileName);
header('Content-type: text/comma-separated-values');
$csvHeader = str_replace($ary3, $ary4, $csvHeader);
$csvData = str_replace($ary3, $ary4, $csvData);
print UTF8toSJIS($csvHeader);
print UTF8toSJIS($csvData);

?>