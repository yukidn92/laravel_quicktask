<?php
/*
 *
 */
/** require **/
require ("../.htsetting");

if (!isset($_POST['cms_page_id'])) {
	user_error("必要なパラメーターが指定されていません。");
	exit();
}
$PID = $_POST['cms_page_id'];

$html = "";
//list format
$fmt = '<tr>' . "\n";
$fmt .= '<th id="cms_{enquete_id}" align="left" valign="top" width="35%">{name}</th>' . "\n";
$fmt .= '<td>' . "\n";
$fmt .= '{detail}' . "\n";
$fmt .= '</td>' . "\n";
$fmt .= '</tr>' . "\n";

/** database controll **/
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_page.inc');
$objPage = new tbl_page($objCnc);
$objPage->selectFromID($PID);
$pFld = $objPage->fld;

// CSV読み込み
$csv_file = DOCUMENT_ROOT . DIR_PATH_ENQUETECSV . $PID . ".csv";
//ファイルを開く
if (($CsvFno = @fopen($csv_file, 'r'))) {
	$cnt = 0;
	while ($data = cms_fgetcsv($CsvFno, 4000))
		$cnt++;
	$html = '<tr>' . "\n";
	$html .= '<th align="left" valign="top">有効回答件数</th><td>' . $cnt . '件</td>' . "\n";
	$html .= '</tr>' . "\n";
}
require_once (APPLICATION_ROOT . '/common/dbcontrol/tbl_enquete.inc');
require_once (APPLICATION_ROOT . '/common/dbcontrol/commands.inc');
$objEnq = new tbl_enquete($objCnc);
$objEnq->selectFromPID($PID);
if (isset($cnt) && $objEnq->getRowCount() > 0) {
	while ($objEnq->fetch()) {
		$Efld = $objEnq->fld;
		$require = ($Efld['require_flg'] == FLAG_ON) ? "（必須）" : "";
		$tmp = $fmt;
		$tmp = str_replace('{name}', htmlDisplay($Efld['name']) . $require, $tmp);
		if (in_array($Efld['control_kind'], array(
				"input", 
				"textarea"
		))) {
			$detail = cxEnqueteDetail($objCnc, $PID, $Efld['enquete_id'], ENQ_TOTAL_DISP_TEXT);
			$r = getCommentData($detail, "Result");
			if ($r['attributes']['cnt'] > ENQ_TOTAL_DISP_TEXT) {
				$detail .= '<a href="javascript:" onClick="return cxSubmit(\'{page_id}\',\'{enquete_id}\')"><span style="font-size:12px">続きを見る</span></a>';
			}
		}
		else {
			$detail = cxEnqueteDetail($objCnc, $PID, $Efld['enquete_id']);
		}
		$tmp = str_replace('{detail}', $detail, $tmp);
		$tmp = str_replace('{page_id}', $PID, $tmp);
		$tmp = str_replace('{enquete_id}', $Efld['enquete_id'], $tmp);
		$html .= $tmp;
	}
}
else {
	$html = '<tr><td align="center" valign="top">データがありません。</td></tr>';
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<title>アンケート集計</title>
<link rel="stylesheet" href="<?=RPW?>/admin/style/shared.css"
	type="text/css">
<link rel="stylesheet" href="<?=RPW?>/admin/style/enqtotal.css"
	type="text/css">
<?php print(TOOLBAR_FIX_CSS); ?>
<script src="<?=RPW?>/admin/js/library/prototype.js"
	type="text/javascript"></script>
<script src="<?=RPW?>/admin/js/shared.js" type="text/javascript"></script>
<script type="text/javascript">
<!--
//
function cxSubmit(page_id,enquete_id){
	args = new Array();
	args[0] = page_id;
	args[1] = enquete_id;
	args[2] = $('cms_'+enquete_id).innerHTML;
	cxIframeLayer(
		cms8341admin_path+"/special/enquete/enqtotal/exec.php",
		550,
		680,
		COVER_SETTING.COLOR,
		'',
		undefined,
		false,
		false,
		args
	);
}
function cxDownloadCsv(){
	$('enq_form').action = cms8341admin_path + "/special/enquete/enqtotal/download.php";
	$('enq_form').submit();
	return false;
}

//-->
</script>
</head>

<body id="cms8341-mainbg">
<?php
// ヘッダーメニュー挿入
$headerMode = 'enquete';
include (APPLICATION_ROOT . "/common/inc/special_menu.inc");
?>
<div id="cms8341-contents">
<div align="center" id="cms8341-enqtotalresult">
<div><img
	src="<?=RPW?>/admin/special/enquete/enqtotal/images/title_enqtotal.jpg"
	alt="アンケート集計" width="920" height="30"></div>
<div class="cms8341-area-corner">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td align="left" valign="top">
		<p><?=$pFld['page_title']?>ページの集計結果</p>
		</td>
		<td align="right" valign="top" width="160">
		<p>
<?php
if (isset($cnt)) {
	echo '<a href="javascript:" onclick="return cxDownloadCsv()"><img src="' . RPW . '/admin/images/enquete/btn_download.jpg" alt="アンケート結果のダウンロード" width="150" height="20" border="0"></a>';
}
?>
</p>
		</td>
	</tr>
</table>
<table width="100%" border="0" cellpadding="5" cellspacing="0"
	class="cms8341-dataTable">
<?=$html?>
</table>
<p align="center" class="ctrl"><a href="javascript:history.back()"><img
	src="<?=RPW?>/admin/master/images/btn_small_back.jpg" alt="戻る"
	width="120" height="20" border="0" style="margin-left: 10px"></a></p>
</div>
<div><img src="<?=RPW?>/admin/images/area920_bottom.jpg" alt=""
	width="920" height="10"></div>
</div>
</div>
<!-- cms8341-contents -->
<form id="enq_form" class="cms8341-form" name="enq_form" action=""
	method="post"><input type="hidden" id="page_id" name="page_id"
	value="<?=$PID?>"> <input type="hidden" id="page_id" name="page_title"
	value="<?=$pFld['page_title']?>"></form>
</body>
</html>
