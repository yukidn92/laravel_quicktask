<?php
class dbConfig {
    protected $serverName;
    protected $userName;
    protected $password;
    protected $dbName;
    protected $timeZone;

    function dbConfig() {
        $this -> serverName = 'localhost';
        $this -> userName = 'root';
        $this -> password = 'cms-8341';
        $this -> dbName = 'my_database';
    }

    
    function set_time_zone() {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
    }
}
?>
